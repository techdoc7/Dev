# Nova OS

Nova OS is an original, browser‑based desktop environment: a complete windowed shell, a virtual disk, eleven built‑in apps and a small automation API — all in plain HTML, CSS and ES modules.

> **Nova OS is an original interface inspired by modern desktop conventions.** It is not macOS, is not affiliated with Apple, and ships no Apple assets, logos or fonts. Every icon in this project is drawn by hand as inline SVG.

---

## Running it

No build step, no package manager, no network access required.

```powershell
cd D:\opencode
python -m http.server 8123 --bind 127.0.0.1
```

Then open <http://127.0.0.1:8123>.

The app must be served over HTTP (ES modules do not load from `file://`). Python 3 is the only requirement.

### First boot

Nova boots with a short splash, a generated wallpaper and a welcome notification. Everything you create lives in `localStorage`, so the desktop, files and settings survive a reload. Clearing site data resets the machine.

---

## What is included

### Desktop shell
- Animated boot splash, generated gradient wallpapers (eight presets), light and dark themes, eight accent colours.
- Top menu bar with the Nova logo, the active app name (which doubles as the application menu), per‑app menus, live clock, simulated Wi‑Fi/battery/volume status, Control Center and Notification Center.
- Dock with magnification, launch bounce, running indicators, minimise animation, auto‑hide, left/right/bottom placement and drag‑to‑reorder.
- Desktop icons, marquee selection, drag & drop, snap‑to‑grid, right‑click context menus, refresh, and personalisation.
- Spotlight search (`Ctrl/⌘ + Space`) across apps, files and quick actions.
- Lock screen (`Ctrl + Q`), keyboard shortcuts, toasts, modal dialogs and confirmation sheets.

### Window manager
Drag, eight‑way resize, minimise, maximise, restore, close, focus stacking, active/inactive chrome, open/close animations, double‑click‑to‑zoom, and per‑app singleton/multi‑window rules. Minimising animates into the app's dock icon.

### Applications

| App | Highlights |
| --- | --- |
| **Finder** | Sidebar, breadcrumbs, grid/list views, search, preview, sorting, copy/paste, rename, trash, new folders, drag & drop |
| **Files** | The same file browser tuned for a list‑first, power‑user layout |
| **Browser** | Tabs, address bar, history, bookmarks, start page, loading progress, and a clear explanation (with an external‑open action) when a site refuses to be framed |
| **Terminal** | Multiple sessions, command registry, history, tab completion, suggestions, coloured output, and ~45 commands across system, filesystem, applications, windows, settings and network |
| **Notes** | Autosaving notes, pinning, search, delete confirmation |
| **Calculator** | Full keyboard support, expression history, percentage/sign/decimal handling |
| **Calendar** | Month grid, day agenda, event creation, calendars and colours |
| **Text Editor** | Syntax highlighting, line numbers, undo/redo, find, save and save‑as, unsaved‑change protection |
| **Settings** | Appearance, Desktop & Dock, Displays, Sound, Network, Notifications, Keyboard, Storage and About |
| **App Store** | Discover/Updates/categories, featured app, install simulation and open buttons |
| **Weather** | Hourly and seven‑day forecast, multiple cities, Celsius/Fahrenheit |

The Browser never bypasses `X-Frame-Options` or `CSP: frame-ancestors`. When a site is blocked it says so plainly and offers to open the page in a real tab; it never claims the site is broken.

---

## Virtual disk

All file operations are confined to an in‑browser virtual filesystem (`nova.fs`):

```
/
├── Applications      read-only app bundles
├── System            read-only system files (incl. Release Notes.md)
└── Users/nova
    ├── Desktop       Welcome.md
    ├── Documents · Downloads · Music · Pictures
    ├── Projects · Workspace
```

- Protected roots (`/`, `/Users`, `/Users/nova`, `/System`, `/Applications`) cannot be deleted or renamed.
- `/System` and `/Applications` are read‑only.
- Every API path is normalised and validated; `..` traversal is rejected.
- **The terminal can never touch the host filesystem**, and dragging real files onto the page is blocked.

---

## Automation API

`window.OS` (alias `window.nova`) is the supported way for scripts and AI agents to drive the OS. Use it instead of clicking DOM nodes.

```js
// Apps
OS.openApp('terminal');                 // launch or focus
OS.openApp('browser', { url: 'https://example.com' });
OS.closeApp('notes');
OS.runningApps();
OS.apps.list();

// Files (virtual disk only)
OS.createFolder('/Users/nova/Projects/Demo');
OS.createFile('/Users/nova/Projects/Demo/hello.txt', 'Hello Nova');
OS.readFile('/Users/nova/Projects/Demo/hello.txt');
OS.listDir('/Users/nova/Projects/Demo');
OS.searchFiles('hello');
OS.moveFile(from, to);
OS.copyFile(from, to);
OS.deleteFile(path);

// Windows
OS.windows.list();                      // { id, appId, title, state, focused, rect }
OS.windows.minimize(id);
OS.windows.maximize(id);
OS.windows.restore(id);

// Terminal (stateful session: cd carries over)
await OS.exec('cd /Users/nova/Documents');
await OS.exec('ls -la');
OS.shell.cwd();

// Appearance & system
OS.setTheme('dark');                    // 'dark' | 'light' | 'auto'
OS.setWallpaper('nebula');
OS.setAccent('purple');
OS.notify('Build finished', 'All checks passed');
OS.spotlight('settings');
OS.controlCenter();
OS.lock();

// Notes
OS.notes.create('Ideas', 'Ship Nova 1.0');
OS.notes.list();
OS.notes.update(id, { title: 'Renamed', body: 'Updated body' });
OS.notes.remove(id);

// Settings
OS.settings.get('dock.autohide');
OS.settings.set('dock.position', 'left');

// Policy
OS.permissions;                         // { filesystem: 'virtual-sandbox', hostAccess: false, ... }
```

`OS.exec` runs through the same command registry as the Terminal app, so `help`, `open`, `theme`, `wallpaper`, `windows`, `notifications` and the rest all work from automation.

---

## Keyboard shortcuts

| Shortcut | Action |
| --- | --- |
| `Ctrl/⌘ + Space` | Spotlight |
| `Ctrl/⌘ + ,` | Settings |
| `Ctrl/⌘ + W` | Close window |
| `Ctrl/⌘ + M` | Minimise window |
| `Ctrl/⌘ + \`` | Cycle windows |
| `Ctrl + Q` | Lock screen |
| `Esc` | Close menus / Spotlight |
| `Enter` (lock screen) | Unlock |
| In Terminal: `Tab`, `↑`, `↓`, `Ctrl + L`, `Ctrl + C` | Complete, history, clear, cancel |
| In Editor: `Ctrl/⌘ + S`, `Shift + Ctrl/⌘ + S`, `Ctrl/⌘ + O`, `Ctrl/⌘ + N` | Save, save as, open, new |

---

## Project layout

```
index.html
css/
  base.css        design tokens, theming, typography, resets
  shell.css       menubar, dock, desktop, Spotlight, control/notification centers, lock screen
  windows.css     window chrome, traffic lights, resize handles, window animations
  apps.css        per-app layouts
js/
  main.js         boot sequence, global shortcuts, dev query params
  api.js          window.OS automation surface + path sandbox
  core/
    icons.js      hand-drawn Lucide-style SVG icon registry
    util.js       DOM helpers, formatting, path/text utilities
    bus.js        tiny event bus
    storage.js    localStorage wrapper
    state.js      settings, theme, accents, wallpapers, notifications
    fs.js         virtual filesystem, protected paths, search
    sound.js      generated UI sounds (created after first gesture)
    ui.js         menus, popovers, modals, dialogs, toasts, sliders
    windowManager.js  window lifecycle, drag, resize, stacking
    dock.js       dock rendering, magnification, autohide, reorder
    menubar.js    menu construction, status items, Control/Notification Centers
    desktop.js    desktop icons, marquee, context menus
    spotlight.js  fuzzy search over apps, files and actions
    lockscreen.js lock overlay
  apps/           one module per application
  dev/            gated QA helpers (never imported during normal use)
```

Each app exports `meta`, `mount(body, ctx)` and optional `menus(win)`. `mount` appends its own `.app` root inside `.window-body` and returns an optional API object (`{ dispose }` plus app‑specific helpers).

---

## Developer QA helpers

These only activate with query parameters and are not part of the product surface.

| URL | Purpose |
| --- | --- |
| `?app=finder` | Open an app on load |
| `?apps=finder,browser` | Open several apps |
| `?theme=light` | Force a theme |
| `?wallpaper=nebula` | Force a wallpaper |
| `?path=/Users/nova` | Start the file browser at a path |
| `?spotlight=1&q=set` | Open Spotlight with a query |
| `?panel=cc` / `?panel=nc` | Open Control Center / Notification Center |
| `?lock=1` | Start locked |
| `?reset=1` | Erase all Nova data in this browser (files, settings, notes) and reload |
| `?selftest=1` | Run the 39‑check API/window/filesystem self‑test |
| `?cmdtest=1` | Run the terminal command sweep |
| `?demo=<name>` | Trigger scripted UI demos (menus, drag, dock, terminal keys, …) |

---

## Design notes

- **No frameworks, no bundler.** Pure ES modules keep the whole OS readable and instantly reloadable.
- **No external assets.** Icons are original inline SVG paths; wallpapers are CSS gradients; type uses the system UI stack.
- **Glass with restraint.** Translucent chrome, hairline borders, layered shadows and short, eased transitions.
- **Accessibility.** Buttons carry labels, menus expose roles, the lock screen and dialogs trap focus, and the whole shell is usable from the keyboard.

Nova OS v1.0.0 “Aurora” · Build 26A‑1001 · Not affiliated with Apple.
