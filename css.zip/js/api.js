/* ============================================================
   Nova OS — public automation API
   window.OS is the supported way for scripts and AI agents to
   drive the desktop. Everything is confined to the virtual disk.
   ============================================================ */

import { getApp, listApps, categories, launch } from './core/registry.js';
import wm from './core/windowManager.js';
import { fs, HOME, WORKSPACE, ROOT, SYSTEM_DIR, APPLICATIONS } from './core/fs.js';
import {
  get, set, getSettings, setTheme, toggleTheme, resolvedTheme,
  setWallpaper, notificationsAPI, SYSTEM,
} from './core/state.js';
import { wallpapers } from './core/wallpapers.js';
import { toast } from './core/ui.js';
import { openSpotlight, closeSpotlight } from './core/spotlight.js';
import { controlCenter, notificationCenter, closePanels } from './core/menubar.js';
import { lockScreen, unlockScreen, isLocked } from './core/lockscreen.js';
import { renderDesktop } from './core/desktop.js';
import { executeLine } from './apps/terminal.js';

/* ------------------------------------------------------------
   Path safety — nothing may escape the virtual root
   ------------------------------------------------------------ */

function safePath(input) {
  if (typeof input !== 'string' || !input.trim()) {
    throw new Error('A path inside the Nova virtual disk is required.');
  }
  if (input.includes('\0')) throw new Error('Invalid path.');
  const normalized = fs.normalize(input.trim(), HOME);
  if (!normalized.startsWith('/')) throw new Error('Paths must resolve inside the virtual disk.');
  if (normalized.split('/').some((part) => part === '..')) throw new Error('Path traversal is not allowed.');
  return normalized;
}

const metaOf = (app) => ({
  id: app.id,
  name: app.name,
  icon: app.icon,
  category: app.category,
  description: app.description,
});

const winInfo = (win) => ({
  id: win.id,
  appId: win.appId,
  title: win.title,
  state: win.state,
  focused: wm.getActiveWindow()?.id === win.id,
  rect: { ...win.rect },
});

/* ------------------------------------------------------------
   Applications
   ------------------------------------------------------------ */

function openApp(appId, params = {}, opts = {}) {
  const app = getApp(appId);
  if (!app) throw new Error(`Unknown application: ${appId}`);
  const wins = wm.getWindowsForApp(appId);
  const hasParams = params && Object.keys(params).length > 0;
  if (wins.length && !opts?.newWindow) {
    const visible = wins.filter((w) => w.state !== 'minimized');
    const target = visible.sort((a, b) => Number(b.el.style.zIndex) - Number(a.el.style.zIndex))[0] || wins[0];
    wm.focusWindow(target.id);
    if (hasParams) target.ctx.onParams?.({ ...params });
    return target;
  }
  return launch(appId, params, opts);
}

function closeApp(appId) {
  const wins = wm.getWindowsForApp(appId);
  wins.forEach((win) => wm.closeWindow(win.id));
  return wins.length;
}

function openWebsite(url) {
  if (!url || typeof url !== 'string') throw new Error('A URL is required.');
  const existing = wm.getWindow('browser');
  if (existing) {
    wm.focusWindow(existing.id);
    existing.ctx.onParams?.({ url });
    return existing;
  }
  return launch('browser', { url });
}

function runningApps() {
  return Array.from(new Set(wm.getWindows().map((win) => win.appId)));
}

/* ------------------------------------------------------------
   Filesystem (virtual only)
   ------------------------------------------------------------ */

function createFile(path, text = '') {
  const target = safePath(path);
  const stat = fs.writeFile(target, String(text));
  return { path: target, size: stat.size, modified: stat.modified };
}

function readFile(path) {
  const target = safePath(path);
  const stat = fs.stat(target);
  if (stat.type === 'dir') throw new Error(`“${target}” is a folder, not a file.`);
  return fs.readFile(target);
}

function listDir(path = HOME) {
  const target = safePath(path);
  return fs.list(target).map((entry) => ({
    name: entry.name,
    path: entry.path,
    type: entry.type,
    size: entry.size || 0,
    modified: entry.modified,
  }));
}

function createFolder(path) {
  const target = safePath(path);
  fs.mkdir(target);
  return { path: target, type: 'dir' };
}

function deleteFile(path) {
  const target = safePath(path);
  fs.remove(target);
  return { path: target, deleted: true };
}

function moveFile(from, to) {
  const src = safePath(from);
  const dest = safePath(to);
  fs.move(src, dest);
  return { from: src, to: dest };
}

function copyFile(from, to) {
  const src = safePath(from);
  const dest = safePath(to);
  fs.copy(src, dest);
  return { from: src, to: dest };
}

function searchFiles(query, from = HOME) {
  const target = safePath(from);
  return fs.search(String(query || ''), target).map((entry) => ({
    name: entry.name,
    path: entry.path,
    type: entry.type,
    size: entry.size || 0,
  }));
}

/* ------------------------------------------------------------
   App bridges — notes are reachable through OS.notes
   ------------------------------------------------------------ */

function notesHandle() {
  const win = wm.getWindow('notes') || launch('notes', {}, {});
  if (!win?.api) throw new Error('Notes is unavailable right now.');
  return win.api;
}

const notesBridge = {
  list: () => wm.getWindow('notes')?.api?.list?.() || [],
  create: (title = '', body = '') => notesHandle().create?.(title, body),
  update: (id, patch = {}) => notesHandle().update?.(id, patch),
  remove: (id) => notesHandle().remove?.(id),
};

/* ------------------------------------------------------------
   Terminal
   ------------------------------------------------------------ */

const apiSession = { id: 'api', cwd: HOME, history: [], historyIndex: -1 };

async function exec(command) {
  if (typeof command !== 'string' || !command.trim()) {
    throw new Error('A terminal command is required.');
  }
  const output = [];
  await executeLine(command, apiSession, (text, cls = '') => {
    output.push({ text: String(text ?? ''), cls });
  });
  return output.map((line) => line.text).join('\n');
}

function resetShell() {
  apiSession.cwd = HOME;
  apiSession.history.length = 0;
  apiSession.historyIndex = -1;
  return { cwd: apiSession.cwd };
}

/* ------------------------------------------------------------
   Public object
   ------------------------------------------------------------ */

export const OS = {
  name: SYSTEM.name,
  version: SYSTEM.version,
  codename: SYSTEM.codename,
  build: SYSTEM.build,

  /* paths — the sandbox agents should use */
  home: HOME,
  workspace: WORKSPACE,
  sandbox: WORKSPACE,
  root: ROOT,
  systemDir: SYSTEM_DIR,
  applicationsDir: APPLICATIONS,

  /* apps */
  openApp,
  closeApp,
  quitApp: closeApp,
  openWebsite,
  runningApps,
  apps: {
    list: () => listApps().map(metaOf),
    get: (id) => {
      const app = getApp(id);
      return app ? metaOf(app) : null;
    },
    categories: () => categories(),
  },

  /* windows */
  windows: {
    list: () => wm.getWindows().map(winInfo),
    active: () => {
      const win = wm.getActiveWindow();
      return win ? winInfo(win) : null;
    },
    get: (id) => {
      const win = wm.getWindow(id);
      return win ? winInfo(win) : null;
    },
    focus: (id) => { wm.focusWindow(id); return true; },
    close: (id) => { wm.closeWindow(id); return true; },
    minimize: (id) => { wm.minimizeWindow(id); return true; },
    maximize: (id) => { wm.maximizeWindow(id); return true; },
    restore: (id) => { wm.restoreWindow(id); return true; },
    minimizeAll: () => { wm.minimizeAll(); return true; },
    restoreAll: () => { wm.restoreAll(); return true; },
    cycle: () => { wm.cycleWindows(); return true; },
  },

  /* filesystem */
  createFile,
  readFile,
  writeFile: createFile,
  listDir,
  createFolder,
  deleteFile,
  moveFile,
  copyFile,
  searchFiles,
  exists: (path) => fs.exists(safePath(path)),

  /* app bridges */
  notes: notesBridge,

  /* appearance */
  get theme() { return resolvedTheme(); },
  setTheme: (theme) => setTheme(theme),
  toggleTheme: () => toggleTheme(),
  get wallpapers() { return wallpapers.map((wp) => ({ id: wp.id, name: wp.name })); },
  setWallpaper: (id) => setWallpaper(id),
  setAccent: (id) => set('accent', id),
  setVolume: (value) => set('volume', Math.max(0, Math.min(100, Number(value) || 0))),
  setBrightness: (value) => set('brightness', Math.max(35, Math.min(100, Number(value) || 100))),

  /* notifications */
  notify: (title, text = '', icon = 'bell') => notificationsAPI.add({ title, text, icon }),
  notifications: {
    list: () => notificationsAPI.list().map((n) => ({ ...n })),
    add: (opts) => notificationsAPI.add(opts || {}),
    remove: (id) => notificationsAPI.remove(id),
    clear: () => notificationsAPI.clear(),
    markAllRead: () => notificationsAPI.markAllRead(),
    unread: () => notificationsAPI.unread(),
  },
  clearNotifications: () => { notificationsAPI.clear(); return true; },

  /* shell */
  exec,
  resetShell,
  shell: {
    cwd: () => apiSession.cwd,
    reset: resetShell,
    history: () => [...apiSession.history],
  },
  spotlight: (query = '') => { openSpotlight(query); return true; },
  closeSpotlight,
  controlCenter: () => { controlCenter(); return true; },
  notificationCenter: () => { notificationCenter(); return true; },
  closePanels,
  lock: () => { lockScreen(); return true; },
  unlock: () => unlockScreen(),
  isLocked: () => isLocked(),
  refreshDesktop: () => { renderDesktop(); return true; },
  settings: {
    get: (path, fallback) => get(path, fallback),
    set: (path, value) => set(path, value),
    all: () => JSON.parse(JSON.stringify(getSettings())),
  },

  /* toast shortcut */
  toast: (opts) => toast(opts || {}),

  /* policy description */
  permissions: {
    filesystem: 'virtual-sandbox',
    hostAccess: false,
    downloads: 'ask-first',
    network: 'browser-only',
  },
};

export function installOS() {
  window.OS = OS;
  window.nova = OS;
  if (!window.__NOVA_OS__) {
    window.__NOVA_OS__ = OS;
  }
  return OS;
}

export default OS;
