/* ============================================================
   Nova OS — App Store
   Discover the built-in apps, add them to the Dock, and apply
   new wallpapers. Everything shown here is already on disk.
   ============================================================ */

import { h, debounce, formatBytes, escapeHTML } from '../core/util.js';
import { icon, appIcon } from '../core/icons.js';
import { wallpapers } from '../core/wallpapers.js';
import { get, set, setWallpaper, SYSTEM } from '../core/state.js';
import { showModal, toast, emptyState } from '../core/ui.js';
import sounds from '../core/sound.js';

export const meta = {
  id: 'appstore',
  name: 'App Store',
  icon: 'appstore',
  category: 'System',
  description: 'Browse every app included with Nova, and refresh your desktop.',
  defaultSize: { w: 960, h: 640 },
  minSize: { w: 620, h: 420 },
  singleton: true,
};

const SECTIONS = [
  { id: 'discover', name: 'Discover', icon: 'sparkles' },
  { id: 'create', name: 'Create', icon: 'palette' },
  { id: 'work', name: 'Work', icon: 'calendar' },
  { id: 'utilities', name: 'Utilities', icon: 'calculator' },
  { id: 'system', name: 'System', icon: 'shield' },
  { id: 'wallpapers', name: 'Wallpapers', icon: 'image' },
  { id: 'updates', name: 'Updates', icon: 'refresh' },
];

const FALLBACK_APPS = [
  { id: 'finder', name: 'Finder', category: 'System', description: 'Browse your files and folders.', icon: 'finder' },
  { id: 'browser', name: 'Browser', category: 'Internet', description: 'A tabbed browser for embeddable sites.', icon: 'browser' },
  { id: 'terminal', name: 'Terminal', category: 'Utilities', description: 'A real command line for the virtual OS.', icon: 'terminal' },
  { id: 'notes', name: 'Notes', category: 'Productivity', description: 'Fast notes that save themselves.', icon: 'notes' },
  { id: 'calculator', name: 'Calculator', category: 'Utilities', description: 'A precise calculator with a tape.', icon: 'calculator' },
  { id: 'calendar', name: 'Calendar', category: 'Productivity', description: 'Plan your month and your day.', icon: 'calendar' },
  { id: 'files', name: 'Files', category: 'Utilities', description: 'A list-first view of your disk.', icon: 'files' },
  { id: 'editor', name: 'Text Editor', category: 'Productivity', description: 'A code editor with highlighting.', icon: 'editor' },
  { id: 'settings', name: 'Settings', category: 'System', description: 'Make Nova feel like yours.', icon: 'settings' },
  { id: 'weather', name: 'Weather', category: 'Utilities', description: 'A calm, generated forecast.', icon: 'weather' },
];

function appList() {
  const list = window.OS?.apps?.list?.();
  return Array.isArray(list) && list.length ? list : FALLBACK_APPS;
}

function inDock(id) {
  const items = get('dock.items', []);
  return Array.isArray(items) && items.includes(id);
}

function addToDock(id) {
  const items = [...get('dock.items', [])];
  if (items.includes(id)) return false;
  items.push(id);
  set('dock.items', items);
  return true;
}

const sizeOf = (id) => ['browser', 'editor', 'appstore'].includes(id) ? '18.4 MB' : '6.2 MB';

export function mount(body, ctx) {
  const root = h('div');
  body.append(root);
  root.classList.add('app', 'store-app');

  let section = ctx.params?.section && SECTIONS.some((s) => s.id === ctx.params.section) ? ctx.params.section : 'discover';
  let query = '';

  const sidebar = h('aside', { class: 'app-sidebar sidebar store-sidebar' });
  const sidebarScroll = h('div', { class: 'sidebar-scroll' });
  sidebar.append(sidebarScroll);

  const titleEl = h('h2', { text: 'Discover' });
  const searchInput = h('input', { type: 'search', placeholder: 'Search apps', spellcheck: 'false' });
  const searchField = h('div', { class: 'search-field' }, h('span', { html: icon('search') }), searchInput);
  const head = h('div', { class: 'store-head' }, titleEl, searchField);
  const content = h('div', { class: 'store-content' }, head);
  const scroll = h('div', { class: 'store-scroll' }, content);
  root.append(sidebar, scroll);

  /* ---------------- sidebar ---------------- */
  function renderSidebar() {
    sidebarScroll.replaceChildren();
    for (const s of SECTIONS) {
      const item = h('button', { class: `sidebar-item${section === s.id ? ' active' : ''}` },
        h('span', { html: icon(s.icon), style: { display: 'contents' } }),
        h('span', { class: 'si-text', text: s.name }),
      );
      if (s.id === 'updates') {
        item.append(h('span', { class: 'si-count', text: '1', style: { fontSize: '10px' } }));
      }
      item.addEventListener('click', () => {
        section = s.id;
        query = '';
        searchInput.value = '';
        render();
        scroll.scrollTop = 0;
        sounds.click();
      });
      sidebarScroll.append(item);
    }
    sidebarScroll.append(h('div', { class: 'sidebar-label', text: 'Account' }));
    const account = h('button', { class: 'sidebar-item' },
      h('span', { html: icon('user'), style: { display: 'contents' } }),
      h('span', { class: 'si-text', text: get('fullName', 'Nova User') }),
    );
    account.addEventListener('click', () => {
      showModal({
        title: 'Nova Account',
        icon: 'user',
        width: 380,
        body: `<p>You are signed in as <strong>${escapeHTML(get('fullName', 'Nova User'))}</strong>.</p>
               <p class="muted">Nova is a local desktop environment. There is no account server, no sync and no tracking.</p>`,
        actions: [{ label: 'OK', value: true, primary: true }],
      });
    });
    sidebarScroll.append(account);
  }

  /* ---------------- builders ---------------- */
  function appRow(app, { showCategory = false } = {}) {
    const row = h('div', { class: 'store-app-row' });
    row.append(h('div', { html: appIcon(app.id) }));
    const info = h('div', { class: 'sap-info' },
      h('div', { class: 'sap-name', text: app.name }),
      h('div', { class: 'sap-desc', text: app.description || app.category || '' }),
    );
    row.append(info);
    if (showCategory) row.append(h('span', { class: 'badge', text: app.category || 'App' }));
    if (!inDock(app.id)) {
      const add = h('button', { class: 'btn btn-plain', text: 'Add to Dock', title: 'Add to Dock', style: { minWidth: 'auto', fontSize: '10.5px' } });
      add.addEventListener('click', (e) => {
        e.stopPropagation();
        if (addToDock(app.id)) {
          add.remove();
          toast({ title: 'Added to Dock', text: app.name, icon: 'layout' });
          render();
        }
      });
      row.append(add);
    }
    const open = h('button', { class: 'btn', text: 'Open' });
    open.addEventListener('click', () => {
      window.OS?.openApp(app.id);
      toast({ title: `Opening ${app.name}`, icon: 'sparkles' });
    });
    row.append(open);
    row.addEventListener('click', (e) => {
      if (e.target.closest('button')) return;
      showAppDetails(app);
    });
    return row;
  }

  function appCard(app) {
    const card = h('button', { class: 'store-card', style: { display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: '7px', textAlign: 'left' } },
      h('div', { html: appIcon(app.id) }),
      h('div', { class: 'sc-name', text: app.name }),
      h('div', { class: 'sc-desc', text: app.description || app.category || '' }),
      h('span', { class: 'btn', text: 'Open' }),
    );
    card.addEventListener('click', () => {
      window.OS?.openApp(app.id);
    });
    card.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      showAppDetails(app);
    });
    return card;
  }

  function showAppDetails(app) {
    const docked = inDock(app.id);
    showModal({
      title: app.name,
      icon: null,
      width: 440,
      body: `<div style="display:flex;gap:16px;align-items:center;margin-bottom:12px">
               ${appIcon(app.id, 'lg')}
               <div>
                 <div style="font-size:15px;font-weight:650;color:var(--text)">${escapeHTML(app.name)}</div>
                 <div class="muted" style="font-size:11px">${escapeHTML(app.category || 'Application')} · Version 1.0</div>
                 <div class="muted" style="font-size:11px">${sizeOf(app.id)} · Included with Nova</div>
               </div>
             </div>
             <p>${escapeHTML(app.description || 'Part of the Nova desktop environment.')}</p>
             <p class="muted" style="font-size:11px">No purchase, download or account is required. This app is already installed in your virtual filesystem.</p>`,
      actions: [
        { label: docked ? 'In Dock' : 'Add to Dock', value: 'dock', disabled: docked },
        { label: 'Open', value: 'open', primary: true },
      ],
    }).then((res) => {
      if (res === 'open') window.OS?.openApp(app.id);
      if (res === 'dock') {
        if (addToDock(app.id)) {
          toast({ title: 'Added to Dock', text: app.name, icon: 'layout' });
          render();
        }
      }
    });
  }

  function wallpaperCard(wp) {
    const card = h('button', { class: 'store-wall', title: `Apply ${wp.name}` },
      h('div', { class: 'sw-img', style: { background: wp.css } }),
      h('span', { class: 'sw-name', text: wp.name }),
    );
    card.addEventListener('click', () => {
      setWallpaper(wp.id);
      toast({ title: 'Wallpaper applied', text: wp.name, icon: 'image' });
      sounds.success();
    });
    return card;
  }

  /* ---------------- sections ---------------- */
  function discoverView() {
    const apps = appList();
    const wrap = h('div');
    const featured = apps.find((a) => a.id === 'editor') || apps[0];

    const hero = h('div', { class: 'store-hero' },
      h('div', { class: 'sh-icon', html: appIcon(featured.id) }),
      h('div', { class: 'sh-eyebrow', text: 'Featured' }),
      h('h2', { text: 'Make something worth keeping.' }),
      h('p', { text: 'The Nova Text Editor pairs a distraction-free canvas with syntax highlighting for the files already on your disk.' }),
      h('div', { class: 'sh-actions' },
        h('button', { class: 'btn btn-light', text: 'Open Editor', onclick: () => window.OS?.openApp('editor') }),
        h('button', { class: 'btn btn-glass', text: 'Learn More', onclick: () => showAppDetails(featured) }),
      ),
    );
    wrap.append(hero);

    wrap.append(h('div', { class: 'store-section' },
      h('div', { class: 'store-section-head' }, h('h3', { text: 'Nova Essentials' })),
      h('div', { class: 'store-apps' },
        ...apps.filter((a) => ['finder', 'browser', 'terminal', 'notes'].includes(a.id)).map((a) => appRow(a)),
      ),
    ));

    wrap.append(h('div', { class: 'store-section' },
      h('div', { class: 'store-section-head' }, h('h3', { text: 'New & Noteworthy' })),
      h('div', { class: 'store-cards' },
        ...apps.filter((a) => ['calendar', 'calculator', 'weather', 'files'].includes(a.id)).map(appCard),
      ),
    ));

    wrap.append(h('div', { class: 'store-section' },
      h('div', { class: 'store-section-head' },
        h('h3', { text: 'Wallpapers' }),
        h('button', { class: 'btn btn-plain', text: 'See All', onclick: () => { section = 'wallpapers'; render(); scroll.scrollTop = 0; } }),
      ),
      h('div', { class: 'store-walls' }, ...wallpapers.slice(0, 3).map(wallpaperCard)),
    ));

    wrap.append(h('div', { class: 'store-section' },
      h('div', { class: 'store-apps' },
        h('div', { class: 'store-app-row' },
          h('div', { html: `<span class="app-icon ai-weather">${icon('cloud-sun')}</span>` }),
          h('div', { class: 'sap-info' },
            h('div', { class: 'sap-name', text: 'Everything is included' }),
            h('div', { class: 'sap-desc', text: 'No downloads, no trials, no account. Nova ships complete.' }),
          ),
          h('span', { class: 'badge accent', text: 'Free' }),
        ),
      ),
    ));
    return wrap;
  }

  function categoryView(category) {
    const apps = appList().filter((a) => (a.category || 'Other') === category);
    const wrap = h('div');
    if (!apps.length) {
      wrap.append(emptyState('bag', 'Nothing here yet', 'No apps in this category.'));
      return wrap;
    }
    wrap.append(h('div', { class: 'store-section' },
      h('div', { class: 'store-apps' }, ...apps.map((a) => appRow(a, { showCategory: true }))),
    ));
    return wrap;
  }

  function wallpaperView() {
    const wrap = h('div');
    wrap.append(h('div', { class: 'store-section' },
      h('p', { class: 'muted', style: { fontSize: '12px', marginBottom: '12px' }, text: 'Each wallpaper is generated with layered CSS gradients. Click one to apply it instantly.' }),
      h('div', { class: 'store-walls', style: { gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))' } }, ...wallpapers.map(wallpaperCard)),
    ));
    return wrap;
  }

  function updatesView() {
    const wrap = h('div');
    const card = h('div', { class: 'store-apps' },
      h('div', { class: 'store-app-row' },
        h('div', { html: appIcon('settings') }),
        h('div', { class: 'sap-info' },
          h('div', { class: 'sap-name', text: SYSTEM.name }),
          h('div', { class: 'sap-desc', text: `Version ${SYSTEM.version} · Build ${SYSTEM.build}` }),
        ),
        h('span', { class: 'badge accent', text: 'Up to date' }),
      ),
    );
    wrap.append(h('div', { class: 'store-section' },
      h('div', { class: 'store-section-head' }, h('h3', { text: 'Software Update' })),
      card,
      h('p', { class: 'muted', style: { fontSize: '11px', marginTop: '10px' }, text: 'Nova runs entirely in your browser. New versions arrive with the page, so there is nothing to install.' }),
    ));
    const check = h('button', { class: 'btn btn-primary', html: `${icon('refresh')} Check Again`, style: { marginTop: '4px' } });
    check.addEventListener('click', () => {
      check.disabled = true;
      check.textContent = 'Checking…';
      setTimeout(() => {
        check.disabled = false;
        check.innerHTML = `${icon('check')} Up to Date`;
        toast({ title: 'You’re up to date', text: `${SYSTEM.name} ${SYSTEM.version}`, icon: 'check' });
        setTimeout(() => { check.innerHTML = `${icon('refresh')} Check Again`; }, 2600);
      }, 900);
    });
    wrap.append(check);
    return wrap;
  }

  function searchView() {
    const q = query.toLowerCase();
    const apps = appList().filter((a) => `${a.name} ${a.description || ''} ${a.category || ''}`.toLowerCase().includes(q));
    const wrap = h('div');
    if (!apps.length) {
      const empty = emptyState('search', 'No results', `Nothing in the App Store matches “${query}”.`);
      empty.style.padding = '50px 20px';
      wrap.append(empty);
      return wrap;
    }
    wrap.append(h('div', { class: 'store-section' },
      h('div', { class: 'store-section-head' }, h('h3', { text: `${apps.length} result${apps.length === 1 ? '' : 's'}` })),
      h('div', { class: 'store-apps' }, ...apps.map((a) => appRow(a, { showCategory: true }))),
    ));
    return wrap;
  }

  /* ---------------- render ---------------- */
  function render() {
    renderSidebar();
    content.replaceChildren(head);
    const current = SECTIONS.find((s) => s.id === section);
    titleEl.textContent = query ? 'Search Results' : current?.name || 'Discover';

    let view;
    if (query) view = searchView();
    else if (section === 'discover') view = discoverView();
    else if (section === 'wallpapers') view = wallpaperView();
    else if (section === 'updates') view = updatesView();
    else {
      const map = { create: 'Productivity', work: 'Productivity', utilities: 'Utilities', system: 'System' };
      view = categoryView(map[section] || 'Other');
    }
    content.append(view);
  }

  const onSearch = debounce(() => {
    query = searchInput.value.trim();
    render();
  }, 160);
  searchInput.addEventListener('input', onSearch);
  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { searchInput.value = ''; query = ''; render(); }
  });

  ctx.onParams = (params) => {
    if (params?.section && SECTIONS.some((s) => s.id === params.section)) {
      section = params.section;
      render();
    }
    if (params?.search) {
      searchInput.value = params.search;
      query = params.search;
      render();
    }
  };

  render();

  return {
    open(sectionId) {
      if (SECTIONS.some((s) => s.id === sectionId)) {
        section = sectionId;
        query = '';
        searchInput.value = '';
        render();
      }
    },
    search(text) {
      searchInput.value = text;
      query = text;
      render();
    },
    dispose() { /* nothing external */ },
  };
}

/* ------------------------------------------------------------ */

export function menus(win) {
  const api = win.api || {};
  return {
    Store: [
      { label: 'Discover', icon: 'sparkles', action: () => api.open?.('discover') },
      { label: 'Wallpapers', icon: 'image', action: () => api.open?.('wallpapers') },
      { label: 'Updates', icon: 'refresh', action: () => api.open?.('updates') },
      { separator: true },
      { label: 'Close Window', shortcut: '⌘W', action: () => win.ctx.close() },
    ],
    View: [
      { label: 'Search…', shortcut: '⌘F', icon: 'search', action: () => win.el.querySelector('.store-head input')?.focus() },
      { separator: true },
      { label: 'Create', icon: 'palette', action: () => api.open?.('create') },
      { label: 'Work', icon: 'calendar', action: () => api.open?.('work') },
      { label: 'Utilities', icon: 'calculator', action: () => api.open?.('utilities') },
      { label: 'System', icon: 'shield', action: () => api.open?.('system') },
    ],
  };
}
