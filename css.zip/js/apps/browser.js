/* ============================================================
   Nova OS — Browser
   Tabbed iframe browser with bookmarks, history and a helpful
   fallback for sites that refuse to be embedded.
   ============================================================ */

import { h, uid, debounce, normalizeURL, hostOf, formatTime, formatDate, escapeHTML } from '../core/util.js';
import { icon } from '../core/icons.js';
import { on } from '../core/bus.js';
import { load, save } from '../core/storage.js';
import { showMenu, confirmDialog, toast, emptyState } from '../core/ui.js';
import { get, SYSTEM } from '../core/state.js';
import sounds from '../core/sound.js';

export const meta = {
  id: 'browser',
  name: 'Browser',
  icon: 'browser',
  category: 'Internet',
  description: 'Browse embeddable websites in tabs, with bookmarks and history.',
  defaultSize: { w: 1020, h: 680 },
  minSize: { w: 560, h: 380 },
  singleton: false,
};

const QUICK_LINKS = [
  { name: 'Example', host: 'example.com', url: 'https://example.com', color: 'linear-gradient(150deg,#6ea8fe,#3b6fd4)', letter: 'E' },
  { name: 'Wikipedia', host: 'wikipedia.org', url: 'https://www.wikipedia.org', color: 'linear-gradient(150deg,#5a5a5a,#1f1f1f)', letter: 'W' },
  { name: 'Hacker News', host: 'news.ycombinator.com', url: 'https://news.ycombinator.com', color: 'linear-gradient(150deg,#ff9d4d,#ff6600)', letter: 'Y' },
  { name: 'MDN Web Docs', host: 'developer.mozilla.org', url: 'https://developer.mozilla.org', color: 'linear-gradient(150deg,#3b3b46,#111)', letter: 'M' },
  { name: 'OpenStreetMap', host: 'openstreetmap.org', url: 'https://www.openstreetmap.org', color: 'linear-gradient(150deg,#8fd07e,#4f9d45)', letter: 'O' },
  { name: 'Internet Archive', host: 'archive.org', url: 'https://archive.org', color: 'linear-gradient(150deg,#5c6d7e,#2b3440)', letter: 'A' },
  { name: 'DuckDuckGo', host: 'duckduckgo.com', url: 'https://duckduckgo.com', color: 'linear-gradient(150deg,#ff8a65,#de5833)', letter: 'D' },
  { name: 'W3C', host: 'w3.org', url: 'https://www.w3.org', color: 'linear-gradient(150deg,#3f8ed0,#005a9c)', letter: 'W3' },
];

let bookmarks = load('browser.bookmarks', [
  { id: 'bm_example', title: 'Example Domain', url: 'https://example.com' },
  { id: 'bm_hn', title: 'Hacker News', url: 'https://news.ycombinator.com' },
]);
let history = load('browser.history', []);
if (!Array.isArray(bookmarks)) bookmarks = [];
if (!Array.isArray(history)) history = [];

const saveBookmarks = () => save('browser.bookmarks', bookmarks.slice(0, 200));
const saveHistory = () => save('browser.history', history.slice(0, 250));

function searchURL(q) {
  const engine = get('browser.searchEngine', 'DuckDuckGo');
  const base = {
    DuckDuckGo: 'https://duckduckgo.com/?q=',
    Google: 'https://www.google.com/search?q=',
    Bing: 'https://www.bing.com/search?q=',
  }[engine] || 'https://duckduckgo.com/?q=';
  return base + encodeURIComponent(q);
}

function resolveInput(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  if (raw === 'nova://start' || raw === 'start') return '';
  if (/\s/.test(raw) && !raw.includes('.')) return searchURL(raw);
  if (/^[a-z][a-z0-9+.-]*:/i.test(raw)) {
    return /^https?:/i.test(raw) ? raw : searchURL(raw);
  }
  if (/^[\w-]+(\.[\w-]+)+(:\d+)?(\/.*)?$/.test(raw) || raw.startsWith('localhost')) {
    return `https://${raw}`;
  }
  return searchURL(raw);
}

function openExternal(url) {
  if (!url) return;
  const a = document.createElement('a');
  a.href = url;
  a.target = '_blank';
  a.rel = 'noopener noreferrer';
  a.style.display = 'none';
  document.body.append(a);
  a.click();
  a.remove();
  toast({ title: 'Opened in your browser', text: hostOf(url), icon: 'external' });
}

export function mount(body, ctx) {
  const root = h('div');
  body.append(root);
  root.classList.add('app', 'browser');

  const tabs = [];
  let activeId = null;
  let panel = null;

  /* ---------------- DOM ---------------- */
  const tabList = h('div', { class: 'bt-list' });
  const newTabBtn = h('button', { class: 'icon-btn bt-new', title: 'New Tab', 'aria-label': 'New tab', html: icon('plus') });
  const tabsBar = h('div', { class: 'browser-tabs' }, tabList, newTabBtn);

  const backBtn = h('button', { class: 'icon-btn', title: 'Back', 'aria-label': 'Back', html: icon('chevron-left') });
  const fwdBtn = h('button', { class: 'icon-btn', title: 'Forward', 'aria-label': 'Forward', html: icon('chevron-right') });
  const reloadBtn = h('button', { class: 'icon-btn', title: 'Reload', 'aria-label': 'Reload', html: icon('refresh') });
  const homeBtn = h('button', { class: 'icon-btn', title: 'Home', 'aria-label': 'Home', html: icon('home') });

  const securityIcon = h('span', { html: icon('globe') });
  const urlInput = h('input', { type: 'text', spellcheck: 'false', placeholder: 'Search or enter website name', 'aria-label': 'Address' });
  const urlbar = h('div', { class: 'urlbar' }, securityIcon, urlInput);
  const progress = h('div', { class: 'browser-progress' }, h('span'));
  const progressBar = progress.firstElementChild;

  const starBtn = h('button', { class: 'icon-btn', title: 'Bookmark This Page', 'aria-label': 'Bookmark', html: icon('star') });
  const bookmarksBtn = h('button', { class: 'icon-btn', title: 'Bookmarks', 'aria-label': 'Bookmarks', html: icon('bookmark') });
  const historyBtn = h('button', { class: 'icon-btn', title: 'History', 'aria-label': 'History', html: icon('history') });
  const externalBtn = h('button', { class: 'icon-btn', title: 'Open in Your Browser', 'aria-label': 'Open externally', html: icon('external') });

  const bar = h('div', { class: 'browser-bar' },
    backBtn, fwdBtn, reloadBtn, homeBtn,
    urlbar,
    starBtn, bookmarksBtn, historyBtn, externalBtn,
    progress,
  );

  const startPage = h('div', { class: 'browser-start' });
  const view = h('div', { class: 'browser-view' }, startPage);
  let blockedEl = null;
  let tipEl = null;
  let tipTimer = 0;
  let tipShown = false;

  root.append(tabsBar, bar, view);

  /* ---------------- Start page ---------------- */
  function renderStart() {
    const hour = new Date().getHours();
    const greeting = hour < 5 ? 'Good night' : hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
    const recent = history.slice(0, 5);

    startPage.replaceChildren();
    const inner = h('div', { class: 'bs-inner' });
    inner.append(
      h('div', { class: 'bs-greeting' },
        h('h1', { text: `${greeting}.` }),
        h('p', { text: 'Where would you like to go? Nova only embeds sites that allow it.' }),
      ),
    );

    const searchForm = h('form', { class: 'bs-search' },
      h('span', { html: icon('search') }),
      h('input', { type: 'text', placeholder: 'Search the web or enter a URL', 'aria-label': 'Search the web' }),
      h('button', { class: 'btn btn-primary', type: 'submit', text: 'Go' }),
    );
    searchForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const value = searchForm.querySelector('input').value;
      navigateTab(activeTab(), resolveInput(value));
    });
    inner.append(searchForm);

    const favSection = h('div', {},
      h('div', { class: 'bs-section-title' }, 'Favorites'),
      h('div', { class: 'bs-grid' }, QUICK_LINKS.map((link) => {
        const btn = h('button', { class: 'bs-link', title: link.url });
        btn.append(
          h('span', { class: 'bs-fav', style: { background: link.color }, text: link.letter }),
          h('span', { style: { minWidth: 0 } },
            h('div', { class: 'bs-name', text: link.name }),
            h('div', { class: 'bs-host', text: link.host }),
          ),
        );
        btn.addEventListener('click', () => navigateTab(activeTab(), link.url));
        return btn;
      })),
    );
    inner.append(favSection);

    if (bookmarks.length) {
      inner.append(h('div', {},
        h('div', { class: 'bs-section-title' },
          'Bookmarks',
          h('button', { class: 'btn btn-plain', text: 'Manage', onclick: () => togglePanel('bookmarks') }),
        ),
        h('div', { class: 'bs-grid' }, bookmarks.slice(0, 6).map((bm) => {
          const btn = h('button', { class: 'bs-link', title: bm.url });
          btn.append(
            h('span', { class: 'bs-fav', style: { background: 'linear-gradient(150deg, rgb(var(--accent-rgb)), rgba(0,0,0,.45))' }, text: (bm.title || hostOf(bm.url))[0]?.toUpperCase() || '•' }),
            h('span', { style: { minWidth: 0 } },
              h('div', { class: 'bs-name', text: bm.title || hostOf(bm.url) }),
              h('div', { class: 'bs-host', text: hostOf(bm.url) }),
            ),
          );
          btn.addEventListener('click', () => navigateTab(activeTab(), bm.url));
          return btn;
        })),
      ));
    }

    if (recent.length) {
      const list = h('div', { class: 'bs-recent' });
      for (const entry of recent) {
        const btn = h('button', { class: 'bs-recent-item', title: entry.url });
        btn.append(
          h('span', { html: icon('clock') }),
          h('span', { class: 'bs-url', text: entry.title || hostOf(entry.url) }),
          h('span', { class: 'bs-host', text: hostOf(entry.url), style: { marginLeft: '6px', flex: 'none' } }),
          h('span', { class: 'bs-time', text: formatTime(entry.time) }),
        );
        btn.addEventListener('click', () => navigateTab(activeTab(), entry.url));
        list.append(btn);
      }
      inner.append(h('div', {},
        h('div', { class: 'bs-section-title' },
          'Recently Visited',
          h('button', { class: 'btn btn-plain', text: 'Clear', onclick: clearHistory }),
        ),
        list,
      ));
    }

    inner.append(h('div', { class: 'browser-blocked', style: { position: 'static', background: 'none', padding: '8px 0 20px', opacity: '.55' } },
      h('p', { style: { fontSize: '10.5px' }, text: 'Nova embeds pages in a sandboxed frame. Sites that send X-Frame-Options or frame-ancestors policies are not bypassed.' }),
    ));

    startPage.append(inner);
  }

  /* ---------------- Tabs ---------------- */
  function activeTab() {
    return tabs.find((t) => t.id === activeId) || tabs[0] || null;
  }

  function newTab(url = '', { activate = true } = {}) {
    const tab = {
      id: uid('tab'),
      url: '',
      title: 'New Tab',
      history: [],
      index: -1,
      iframe: null,
      loading: false,
      loadToken: 0,
      blocked: false,
    };
    tabs.push(tab);
    if (activate) activeId = tab.id;
    renderTabs();
    if (url) navigateTab(tab, url);
    else if (activate) showStart();
    sounds.click();
    return tab;
  }

  function closeTab(id) {
    const idx = tabs.findIndex((t) => t.id === id);
    if (idx < 0) return;
    const tab = tabs[idx];
    tab.iframe?.remove();
    tabs.splice(idx, 1);
    if (!tabs.length) {
      newTab('', { activate: true });
      return;
    }
    if (activeId === id) {
      activeId = tabs[Math.max(0, idx - 1)].id;
      activateTab(activeId);
    }
    renderTabs();
  }

  function activateTab(id) {
    activeId = id;
    const tab = activeTab();
    if (!tab) return;
    for (const t of tabs) {
      if (t.iframe) t.iframe.classList.toggle('hidden', t !== tab || !t.url);
    }
    hideBlocked();
    hideEmbedTip();
    if (!tab.url) { showStart(); } else { startPage.hidden = true; }
    if (tab.blocked && tab.url) showBlocked(tab, tab.url, tab.blockedReason || 'blocked');
    else if (tab.url) scheduleEmbedTip(tab);
    renderTabs();
    syncToolbar();
    urlInput.value = tab.url || '';
    starBtn.innerHTML = icon('star', isBookmarked(tab.url) ? 'fill' : '');
    starBtn.classList.toggle('active', isBookmarked(tab.url));
  }

  function renderTabs() {
    tabList.replaceChildren();
    for (const tab of tabs) {
      const el = h('div', {
        class: `bt-tab${tab.id === activeId ? ' active' : ''}`,
        title: tab.title,
        role: 'tab',
      });
      const fav = h('span', { class: 'bt-favicon' });
      if (tab.loading) {
        fav.innerHTML = `<span class="spinner" style="width:10px;height:10px;border:1.5px solid var(--text-3);border-top-color:var(--accent);border-radius:50%;display:block;animation:spin .7s linear infinite"></span>`;
      } else if (tab.url) {
        fav.textContent = (hostOf(tab.url)[0] || '•').toUpperCase();
        fav.style.background = 'linear-gradient(150deg, rgb(var(--accent-rgb)), rgba(0,0,0,.4))';
        fav.style.color = '#fff';
        fav.style.fontSize = '8px';
        fav.style.fontWeight = '700';
        fav.style.borderRadius = '3px';
      } else {
        fav.innerHTML = icon('globe');
      }
      const title = h('span', { class: 'bt-title', text: tab.title });
      const close = h('button', { class: 'bt-close', html: icon('x'), 'aria-label': 'Close tab' });
      close.addEventListener('click', (e) => { e.stopPropagation(); closeTab(tab.id); });
      el.append(fav, title, close);
      el.addEventListener('click', () => activateTab(tab.id));
      el.addEventListener('auxclick', (e) => { if (e.button === 1) closeTab(tab.id); });
      tabList.append(el);
    }
  }

  function syncToolbar() {
    const tab = activeTab();
    if (!tab) return;
    backBtn.disabled = tab.index <= 0;
    fwdBtn.disabled = !tab.history.length || tab.index >= tab.history.length - 1;
    securityIcon.innerHTML = tab.url?.startsWith('https:') ? icon('lock') : icon('globe');
    securityIcon.title = tab.url?.startsWith('https:') ? 'Secure connection (HTTPS)' : tab.url ? 'Not secure' : 'Start page';
  }

  function updateTabUI() {
    const tab = activeTab();
    if (!tab) return;
    renderTabs();
    syncToolbar();
    urlInput.value = tab.url || '';
    starBtn.classList.toggle('active', isBookmarked(tab.url));
    starBtn.innerHTML = icon('star', isBookmarked(tab.url) ? 'fill' : '');
  }

  function ensureIframe(tab) {
    if (!tab.iframe) {
      const frame = h('iframe', {
        src: 'about:blank',
        title: 'Browsing context',
        sandbox: 'allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-downloads allow-modals',
        referrerpolicy: 'strict-origin-when-cross-origin',
        allow: 'clipboard-write; fullscreen',
      });
      frame.classList.add('hidden');
      frame.addEventListener('load', () => onFrameLoad(tab));
      view.append(frame);
      tab.iframe = frame;
    }
    return tab.iframe;
  }

  function onFrameLoad(tab) {
    if (!tab.iframe) return;
    const token = tab.loadToken;
    clearTimeout(tab.failTimer);
    setTimeout(() => {
      if (token !== tab.loadToken) return;
      tab.ready = true;
      finishProgress();
      tab.loading = false;
      let blocked = false;
      try {
        const doc = tab.iframe.contentDocument;
        if (doc) {
          const href = doc.location?.href || '';
          const text = (doc.body?.innerText || '').trim();
          const hasMedia = doc.querySelector('img,video,canvas,iframe,object,embed');
          if (!href || href === 'about:blank' || (!text && !hasMedia)) blocked = true;
        }
      } catch {
        blocked = false; // cross-origin: assume it rendered
      }
      if (blocked && tab.id === activeId) {
        tab.blocked = true;
        showBlocked(tab, tab.url, 'blocked');
      }
      updateTabUI();
    }, 500);
  }

  /* ---------------- Navigation ---------------- */
  function navigateTab(tab, url, { push = true } = {}) {
    if (!tab) return;
    hideBlocked();
    hideEmbedTip();
    tab.blocked = false;
    if (!url) {
      tab.url = '';
      tab.title = 'New Tab';
      tab.iframe?.classList.add('hidden');
      startPage.hidden = false;
      renderStart();
      if (tab.id === activeId) updateTabUI();
      return;
    }
    tab.url = url;
    tab.title = hostOf(url) || 'Page';
    tab.loading = true;
    tab.ready = false;
    tab.loadToken += 1;

    if (push) {
      tab.history = tab.history.slice(0, tab.index + 1);
      tab.history.push(url);
      tab.index = tab.history.length - 1;
      recordHistory(url, tab.title);
    }

    startPage.hidden = true;
    const frame = ensureIframe(tab);
    tab.iframe?.classList.remove('hidden');
    if (tab.id === activeId) updateTabUI();
    startProgress();
    clearTimeout(tab.failTimer);
    tab.failTimer = setTimeout(() => {
      if (tab.loadToken === 0) return;
      finishProgress();
      tab.loading = false;
      if (tab.id === activeId && !tab.blocked) showBlocked(tab, url, 'slow');
      updateTabUI();
    }, 11000);
    frame.src = url;
    scheduleEmbedTip(tab);
  }

  function recordHistory(url, title) {
    if (!url) return;
    if (history[0]?.url === url) return;
    history.unshift({ url, title: title || hostOf(url), time: Date.now() });
    history = history.slice(0, 250);
    saveHistory();
  }

  function navigateCurrent(value) {
    const tab = activeTab();
    if (!tab) return;
    const url = resolveInput(value);
    if (!url) {
      tab.url = '';
      tab.title = 'New Tab';
      tab.history = [];
      tab.index = -1;
      tab.iframe?.classList.add('hidden');
      tab.blocked = false;
      hideBlocked();
      showStart();
      updateTabUI();
      return;
    }
    navigateTab(tab, url);
  }

  function showStart() {
    const tab = activeTab();
    if (tab) { tab.url = ''; tab.title = 'New Tab'; tab.blocked = false; }
    hideBlocked();
    hideEmbedTip();
    startPage.hidden = false;
    renderStart();
    updateTabUI();
  }

  function goBack() {
    const tab = activeTab();
    if (!tab || tab.index <= 0) return;
    tab.index -= 1;
    navigateTab(tab, tab.history[tab.index], { push: false });
  }
  function goForward() {
    const tab = activeTab();
    if (!tab || tab.index >= tab.history.length - 1) return;
    tab.index += 1;
    navigateTab(tab, tab.history[tab.index], { push: false });
  }
  function reload() {
    const tab = activeTab();
    if (!tab) return;
    if (!tab.url) { showStart(); return; }
    hideBlocked();
    tab.blocked = false;
    tab.loading = true;
    startProgress();
    tab.loadToken += 1;
    if (tab.iframe) tab.iframe.src = tab.url;
    updateTabUI();
  }

  /* ---------------- Progress ---------------- */
  let progressTimer = null;
  function startProgress() {
    clearTimeout(progressTimer);
    progressBar.style.transition = 'none';
    progressBar.style.width = '8%';
    progressBar.style.opacity = '1';
    progress.classList.remove('done');
    requestAnimationFrame(() => {
      progressBar.style.transition = 'width .5s var(--ease-out)';
      progressBar.style.width = '72%';
    });
  }
  function finishProgress() {
    clearTimeout(progressTimer);
    progressBar.style.width = '100%';
    progressTimer = setTimeout(() => {
      progress.classList.add('done');
      progressBar.style.width = '0%';
    }, 260);
  }

  /* ---------------- Blocked / slow overlay ---------------- */
  function hideEmbedTip() {
    clearTimeout(tipTimer);
    if (tipEl) { tipEl.remove(); tipEl = null; }
  }

  function scheduleEmbedTip(tab) {
    if (tipShown) return;
    hideEmbedTip();
    if (!tab?.url || !/^https?:/i.test(tab.url)) return;
    try {
      if (new URL(tab.url).origin === location.origin) return;
    } catch { return; }
    const token = tab.loadToken;
    tipTimer = setTimeout(() => {
      if (!tab || tab.blocked || token !== tab.loadToken) return;
      if (tab.id !== activeId) return;
      showEmbedTip(tab);
    }, 3200);
  }

  function showEmbedTip(tab) {
    hideEmbedTip();
    tipShown = true;
    const el = h('div', { class: 'browser-tip', role: 'status' },
      h('span', { html: icon('external') }),
      h('div', { class: 'bt-text' },
        h('b', { text: 'Viewing in an embedded frame' }),
        h('span', { text: 'If a page looks blank, the site may block embedding. You can open it in a real tab.' }),
      ),
      h('div', { style: { display: 'flex', alignItems: 'center', gap: '4px' } },
        h('button', {
          class: 'btn btn-primary',
          html: 'Open Externally',
          onclick: () => openExternal(tab.url),
        }),
        h('button', {
          class: 'icon-btn',
          title: 'Dismiss',
          'aria-label': 'Dismiss',
          html: icon('x'),
          onclick: hideEmbedTip,
        }),
      ),
    );
    view.append(el);
    tipEl = el;
    tipTimer = setTimeout(() => hideEmbedTip(), 12000);
  }

  function hideBlocked() {
    if (blockedEl) { blockedEl.remove(); blockedEl = null; }
  }

  function showBlocked(tab, url, reason) {
    hideBlocked();
    hideEmbedTip();
    tab.blocked = true;
    tab.blockedReason = reason;
    const host = hostOf(url || '');
    const el = h('div', { class: 'browser-blocked' });
    el.append(
      h('div', { class: 'bb-icon', html: icon(reason === 'slow' ? 'clock' : 'shield') }),
      h('h3', { text: reason === 'slow' ? 'This page is taking a while' : 'This site can’t be shown inside Nova' }),
      h('p', {
        text: reason === 'slow'
          ? 'The page has not finished loading. It may be slow, unreachable, or it may not allow embedding. Nova leaves the choice to you.'
          : `${host} refuses to be displayed in an embedded frame. The site is not broken — it simply sends security headers (X-Frame-Options or CSP frame-ancestors) that Nova respects.`,
      }),
      h('div', { class: 'bb-url', text: url || '' }),
    );
    const actions = h('div', { class: 'bb-actions' });
    const extBtn = h('button', { class: 'btn btn-primary', html: `${icon('external')} Open in Your Browser` });
    extBtn.addEventListener('click', () => openExternal(url));
    const retryBtn = h('button', { class: 'btn', html: `${icon('refresh')} Try Again` });
    retryBtn.addEventListener('click', () => reload());
    const homeBtn2 = h('button', { class: 'btn btn-plain', text: 'Go Home' });
    homeBtn2.addEventListener('click', showStart);
    actions.append(extBtn, retryBtn, homeBtn2);
    el.append(actions);
    el.append(h('div', { class: 'bb-note', text: 'Opening the site externally is the recommended option. Nova never tries to bypass embedding restrictions.' }));
    view.append(el);
    blockedEl = el;
  }

  /* ---------------- Panels ---------------- */
  function togglePanel(mode) {
    if (panel && panel.mode === mode) { closePanel(); return; }
    closePanel();
    panel = { mode, el: buildPanel(mode) };
    root.append(panel.el);
  }

  function closePanel() {
    if (panel) { panel.el.remove(); panel = null; }
  }

  function buildPanel(mode) {
    const el = h('div', { class: 'browser-panel' });
    const head = h('div', { class: 'bp-head' });
    head.append(
      h('span', { html: icon(mode === 'bookmarks' ? 'bookmark' : 'history') }),
      h('span', { text: mode === 'bookmarks' ? 'Bookmarks' : 'History' }),
    );
    if (mode === 'bookmarks') {
      const add = h('button', { class: 'btn', text: 'Add Page' });
      add.addEventListener('click', addBookmark);
      head.append(add);
    } else {
      const clear = h('button', { class: 'btn', text: 'Clear' });
      clear.addEventListener('click', clearHistory);
      head.append(clear);
    }
    const close = h('button', { class: 'icon-btn', html: icon('x'), style: { width: '22px', height: '22px' } });
    close.addEventListener('click', closePanel);
    head.append(close);
    el.append(head);

    const list = h('div', { class: 'bp-list' });
    const data = mode === 'bookmarks' ? bookmarks : history;
    if (!data.length) {
      list.append(emptyState(mode === 'bookmarks' ? 'bookmark' : 'history', 'Nothing here yet', mode === 'bookmarks' ? 'Visit a page and press the star to save it.' : 'Pages you visit will appear here.'));
    } else {
      for (const entry of data) {
        const row = h('div', { class: 'bp-item' });
        const ico = h('span', { class: 'bp-ico', text: (entry.title || hostOf(entry.url))[0]?.toUpperCase() || '•' });
        const text = h('div', { class: 'bp-text' },
          h('div', { class: 'bp-name', text: entry.title || hostOf(entry.url) }),
          h('div', { class: 'bp-url', text: entry.url }),
        );
        const del = h('button', { class: 'bp-del', html: icon('x'), title: 'Remove' });
        del.addEventListener('click', (e) => {
          e.stopPropagation();
          if (mode === 'bookmarks') { bookmarks = bookmarks.filter((b) => b !== entry); saveBookmarks(); }
          else { history = history.filter((x) => x !== entry); saveHistory(); }
          closePanel();
          togglePanel(mode);
        });
        row.append(ico, text, del);
        row.addEventListener('click', () => { navigateCurrent(entry.url); closePanel(); });
        list.append(row);
      }
    }
    el.append(list);
    return el;
  }

  function isBookmarked(url) {
    return !!url && bookmarks.some((b) => b.url === url);
  }

  function addBookmark() {
    const tab = activeTab();
    if (!tab?.url) { toast({ title: 'Nothing to bookmark', text: 'Open a page first.', icon: 'info' }); return; }
    if (isBookmarked(tab.url)) {
      bookmarks = bookmarks.filter((b) => b.url !== tab.url);
      saveBookmarks();
      toast({ title: 'Bookmark removed', text: hostOf(tab.url), icon: 'star' });
    } else {
      bookmarks.unshift({ id: uid('bm'), title: tab.title || hostOf(tab.url), url: tab.url });
      bookmarks = bookmarks.slice(0, 200);
      saveBookmarks();
      toast({ title: 'Bookmark added', text: tab.title || hostOf(tab.url), icon: 'star' });
    }
    updateTabUI();
  }

  async function clearHistory() {
    if (!history.length) return;
    const ok = await confirmDialog({
      title: 'Clear browsing history?',
      message: 'This removes every locally stored history entry. Bookmarks are kept.',
      confirmLabel: 'Clear History',
      danger: true,
      iconName: 'history',
    });
    if (!ok) return;
    history = [];
    saveHistory();
    toast({ title: 'History cleared', icon: 'check', text: 'Your browsing history is now empty.' });
    closePanel();
    renderStart();
  }

  /* ---------------- Wiring ---------------- */
  urlInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      navigateCurrent(urlInput.value);
      urlInput.blur();
    } else if (e.key === 'Escape') {
      urlInput.value = activeTab()?.url || '';
      urlInput.blur();
    }
  });
  urlInput.addEventListener('focus', () => urlInput.select());

  newTabBtn.addEventListener('click', () => newTab());
  backBtn.addEventListener('click', goBack);
  fwdBtn.addEventListener('click', goForward);
  reloadBtn.addEventListener('click', reload);
  homeBtn.addEventListener('click', showStart);
  starBtn.addEventListener('click', addBookmark);
  bookmarksBtn.addEventListener('click', () => togglePanel('bookmarks'));
  historyBtn.addEventListener('click', () => togglePanel('history'));
  externalBtn.addEventListener('click', () => {
    const url = activeTab()?.url;
    if (url) openExternal(url);
    else toast({ title: 'No page open', text: 'Open a website first.', icon: 'info' });
  });

  const onKey = (e) => {
    const meta = e.metaKey || e.ctrlKey;
    if (!meta) return;
    if (e.key.toLowerCase() === 't') { e.preventDefault(); newTab(); }
    else if (e.key.toLowerCase() === 'w') { e.preventDefault(); closeTab(activeId); }
    else if (e.key.toLowerCase() === 'l') { e.preventDefault(); urlInput.focus(); urlInput.select(); }
    else if (e.key.toLowerCase() === 'r') { e.preventDefault(); reload(); }
  };
  root.addEventListener('keydown', onKey);

  const onFS = null;

  /* ---------------- Boot ---------------- */
  renderTabs();
  const first = newTab(ctx.params?.url ? resolveInput(ctx.params.url) : '', { activate: true });
  if (!ctx.params?.url) showStart();

  ctx.onParams = (params) => {
    if (params?.url) {
      const tab = activeTab() || newTab('', { activate: true });
      navigateTab(tab, resolveInput(params.url));
    }
  };

  return {
    newTab: () => newTab(),
    closeTab: () => closeTab(activeId),
    reload,
    home: showStart,
    back: goBack,
    forward: goForward,
    focusURL: () => { urlInput.focus(); urlInput.select(); },
    togglePanel,
    addBookmark,
    openExternal: () => { const u = activeTab()?.url; if (u) openExternal(u); },
    getUrl: () => activeTab()?.url || '',
    navigate: (url) => navigateTab(activeTab(), resolveInput(url)),
    dispose() {
      for (const t of tabs) t.iframe?.remove();
      clearTimeout(progressTimer);
      hideEmbedTip();
    },
  };
}

export function menus(win) {
  const api = win.api || {};
  const recent = history.slice(0, 5);
  return {
    File: [
      { label: 'New Tab', shortcut: '⌘T', icon: 'plus', action: () => api.newTab?.() },
      { label: 'Close Tab', shortcut: '⌘W', action: () => api.closeTab?.() },
      { separator: true },
      { label: 'Open Location…', shortcut: '⌘L', icon: 'globe', action: () => api.focusURL?.() },
      { label: 'Open in Your Browser', icon: 'external', action: () => api.openExternal?.() },
      { separator: true },
      { label: 'Close Window', action: () => win.ctx.close() },
    ],
    Edit: [
      { label: 'Cut', shortcut: '⌘X', action: () => document.execCommand('cut') },
      { label: 'Copy', shortcut: '⌘C', action: () => document.execCommand('copy') },
      { label: 'Paste', shortcut: '⌘V', action: () => document.execCommand('paste') },
      { separator: true },
      { label: 'Select All', shortcut: '⌘A', action: () => document.execCommand('selectAll') },
    ],
    View: [
      { label: 'Reload Page', shortcut: '⌘R', icon: 'refresh', action: () => api.reload?.() },
      { label: 'Back', shortcut: '⌘[', action: () => api.back?.() },
      { label: 'Forward', shortcut: '⌘]', action: () => api.forward?.() },
      { separator: true },
      { label: 'Home', icon: 'home', action: () => api.home?.() },
      { label: 'Bookmarks', icon: 'bookmark', action: () => api.togglePanel?.('bookmarks') },
      { label: 'History', icon: 'history', action: () => api.togglePanel?.('history') },
    ],
    History: [
      ...recent.map((entry) => ({
        label: entry.title || hostOf(entry.url),
        icon: 'clock',
        action: () => api.navigate?.(entry.url),
      })),
      ...(recent.length ? [{ separator: true }] : []),
      { label: 'Show All History', icon: 'history', action: () => api.togglePanel?.('history') },
      { label: 'Clear History…', icon: 'trash', action: async () => {
        const ok = await confirmDialog({ title: 'Clear history?', message: 'All browsing history will be removed.', confirmLabel: 'Clear', danger: true, iconName: 'history' });
        if (ok) { history = []; saveHistory(); }
      } },
    ],
    Bookmarks: [
      { label: 'Add This Page', shortcut: '⌘D', icon: 'star', action: () => api.addBookmark?.() },
      { separator: true },
      ...(bookmarks.slice(0, 6).map((bm) => ({
        label: bm.title || hostOf(bm.url),
        icon: 'bookmark',
        action: () => api.navigate?.(bm.url),
      }))),
      ...(bookmarks.length ? [{ separator: true }] : []),
      { label: 'Show All Bookmarks', icon: 'bookmark', action: () => api.togglePanel?.('bookmarks') },
    ],
  };
}
