/* ============================================================
   Nova OS — Calculator
   Immediate-execution calculator with keyboard support and
   a persistent tape. All arithmetic is done locally.
   ============================================================ */

import { h, clamp, relativeTime } from '../core/util.js';
import { icon } from '../core/icons.js';
import { load, save } from '../core/storage.js';
import { toast } from '../core/ui.js';
import sounds from '../core/sound.js';

export const meta = {
  id: 'calculator',
  name: 'Calculator',
  icon: 'calculator',
  category: 'Utilities',
  description: 'A precise, keyboard-friendly calculator with a running tape.',
  defaultSize: { w: 320, h: 470 },
  minSize: { w: 260, h: 380 },
  singleton: true,
};

let tape = load('calc.tape', []);
if (!Array.isArray(tape)) tape = [];

const saveTape = () => save('calc.tape', tape.slice(0, 50));

const OPS = {
  '+': { symbol: '+', fn: (a, b) => a + b },
  '−': { symbol: '−', fn: (a, b) => a - b },
  '×': { symbol: '×', fn: (a, b) => a * b },
  '÷': { symbol: '÷', fn: (a, b) => (b === 0 ? NaN : a / b) },
};

function formatNumber(value) {
  if (!Number.isFinite(value)) return 'Error';
  const abs = Math.abs(value);
  if (abs !== 0 && (abs >= 1e12 || abs < 1e-7)) {
    return value.toExponential(6).replace(/\.?0+e/, 'e').replace('e+', 'e');
  }
  let out = String(Math.round(value * 1e10) / 1e10);
  if (out.includes('.') && out.length > 13) out = String(Number(value.toPrecision(10)));
  return out;
}

function groupDigits(text) {
  if (!/^-?\d/.test(text) || text.includes('e')) return text;
  const [int, dec] = text.split('.');
  const sign = int.startsWith('-') ? '-' : '';
  const digits = sign ? int.slice(1) : int;
  const grouped = digits.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return `${sign}${grouped}${dec !== undefined ? '.' + dec : ''}`;
}

export function mount(body, ctx) {
  const root = h('div');
  body.append(root);
  root.classList.add('app', 'calculator');

  /* ---------------- state ---------------- */
  let display = '0';
  let accumulator = null;
  let pendingOp = null;
  let overwrite = true;
  let lastOperand = null;
  let lastOp = null;
  let expression = '';
  let justEvaluated = false;

  /* ---------------- DOM ---------------- */
  const expressionEl = h('div', { class: 'calc-expr', text: '' });
  const valueEl = h('div', { class: 'calc-value', text: '0' });
  const historyBtn = h('button', {
    class: 'calc-history-btn',
    title: 'Show Tape',
    'aria-label': 'Show tape',
    html: icon('history'),
  });
  const displayEl = h('div', { class: 'calc-display' }, historyBtn, expressionEl, valueEl);

  const pad = h('div', { class: 'calc-pad' });

  const historyPanel = h('div', { class: 'calc-history', hidden: true });
  root.append(displayEl, pad);

  const keys = [
    { label: 'AC', cls: 'fn', action: () => clearAll(), id: 'clear' },
    { label: '+/−', cls: 'fn', action: () => negate(), id: 'negate' },
    { label: '%', cls: 'fn', action: () => percent(), id: 'percent' },
    { label: '÷', cls: 'op', action: () => setOperator('÷'), op: '÷' },
    { label: '7', action: () => inputDigit('7'), key: '7' },
    { label: '8', action: () => inputDigit('8'), key: '8' },
    { label: '9', action: () => inputDigit('9'), key: '9' },
    { label: '×', cls: 'op', action: () => setOperator('×'), op: '×' },
    { label: '4', action: () => inputDigit('4'), key: '4' },
    { label: '5', action: () => inputDigit('5'), key: '5' },
    { label: '6', action: () => inputDigit('6'), key: '6' },
    { label: '−', cls: 'op', action: () => setOperator('−'), op: '−' },
    { label: '1', action: () => inputDigit('1'), key: '1' },
    { label: '2', action: () => inputDigit('2'), key: '2' },
    { label: '3', action: () => inputDigit('3'), key: '3' },
    { label: '+', cls: 'op', action: () => setOperator('+'), op: '+' },
    { label: '0', cls: 'zero', action: () => inputDigit('0'), key: '0' },
    { label: '.', action: () => inputDecimal(), key: '.' },
    { label: '=', cls: 'equals', action: () => equals(), id: 'equals' },
  ];

  const opButtons = new Map();
  const buttonMap = new Map();

  for (const key of keys) {
    const btn = h('button', {
      class: `calc-key ${key.cls || ''}`.trim(),
      text: key.label,
      tabindex: '-1',
      'aria-label': key.label,
    });
    btn.addEventListener('click', () => { key.action(); sounds.click(); });
    if (key.op) opButtons.set(key.op, btn);
    if (key.id) buttonMap.set(key.id, btn);
    if (key.key) buttonMap.set(key.key, btn);
    pad.append(btn);
  }

  /* ---------------- rendering ---------------- */
  function render() {
    const text = display === 'Error' ? 'Error' : groupDigits(display);
    valueEl.textContent = text;
    valueEl.classList.toggle('error', display === 'Error');
    let size = 40;
    if (text.length > 9) size = 34;
    if (text.length > 12) size = 28;
    if (text.length > 16) size = 23;
    valueEl.style.fontSize = `${size}px`;
    expressionEl.textContent = expression;
    buttonMap.get('clear').textContent = display === '0' && accumulator === null ? 'AC' : 'C';
    for (const [op, btn] of opButtons) btn.classList.toggle('active', pendingOp === op);
  }

  function setDisplay(value) {
    const num = Number(value);
    display = Number.isFinite(num) ? formatNumber(num) : 'Error';
  }

  function currentValue() {
    return Number(display.replace(/,/g, '')) || 0;
  }

  /* ---------------- actions ---------------- */
  function clearAll() {
    display = '0';
    accumulator = null;
    pendingOp = null;
    overwrite = true;
    lastOperand = null;
    lastOp = null;
    expression = '';
    justEvaluated = false;
    render();
  }

  function clearEntry() {
    display = '0';
    overwrite = true;
    render();
  }

  function inputDigit(digit) {
    if (display === 'Error') clearAll();
    if (overwrite) {
      display = digit;
      overwrite = false;
    } else {
      if (display.replace(/[-.]/g, '').length >= 12) return;
      display = display === '0' ? digit : display + digit;
    }
    justEvaluated = false;
    if (!pendingOp) expression = '';
    render();
  }

  function inputDecimal() {
    if (display === 'Error') clearAll();
    if (overwrite) {
      display = '0.';
      overwrite = false;
    } else if (!display.includes('.')) {
      display += '.';
    }
    justEvaluated = false;
    render();
  }

  function negate() {
    if (display === 'Error' || display === '0') return;
    display = display.startsWith('-') ? display.slice(1) : `-${display}`;
    render();
  }

  function percent() {
    if (display === 'Error') return;
    const value = currentValue();
    const next = pendingOp === '+' || pendingOp === '−'
      ? (accumulator ?? 0) * value / 100
      : value / 100;
    setDisplay(next);
    overwrite = true;
    render();
  }

  function compute(a, op, b) {
    const def = OPS[op];
    if (!def) return b;
    return def.fn(a, b);
  }

  function setOperator(op) {
    if (display === 'Error') { clearAll(); return; }
    const value = currentValue();
    if (pendingOp && !overwrite) {
      const result = compute(accumulator, pendingOp, value);
      if (!Number.isFinite(result)) { showError(); return; }
      accumulator = result;
      setDisplay(result);
      expression = `${formatNumber(accumulator)} ${OPS[op].symbol}`;
    } else if (pendingOp && overwrite) {
      expression = `${formatNumber(accumulator ?? value)} ${OPS[op].symbol}`;
    } else {
      accumulator = value;
      expression = `${formatNumber(value)} ${OPS[op].symbol}`;
    }
    pendingOp = op;
    overwrite = true;
    justEvaluated = false;
    lastOp = null;
    render();
  }

  function equals() {
    if (display === 'Error') return;
    let left;
    let op;
    let right;
    if (pendingOp) {
      left = accumulator ?? 0;
      op = pendingOp;
      right = overwrite ? (lastOperand ?? currentValue()) : currentValue();
    } else if (lastOp && lastOperand !== null) {
      left = currentValue();
      op = lastOp;
      right = lastOperand;
    } else {
      return;
    }
    const result = compute(left, op, right);
    if (!Number.isFinite(result)) { showError(); return; }

    const expr = `${formatNumber(left)} ${OPS[op].symbol} ${formatNumber(right)}`;
    setDisplay(result);
    expression = expr;
    tape.unshift({ expr, result: formatNumber(result), time: Date.now() });
    tape = tape.slice(0, 50);
    saveTape();
    if (historyPanel.isConnected) renderHistory();

    lastOp = op;
    lastOperand = right;
    pendingOp = null;
    accumulator = null;
    overwrite = true;
    justEvaluated = true;
    render();
    sounds.success();
  }

  function showError() {
    display = 'Error';
    expression = 'Cannot divide by zero';
    pendingOp = null;
    accumulator = null;
    overwrite = true;
    render();
    sounds.error();
  }

  /* ---------------- history ---------------- */
  function renderHistory() {
    historyPanel.replaceChildren();
    const head = h('div', { class: 'ch-head' },
      h('span', { html: icon('history'), style: { display: 'contents' } }),
      h('span', { text: 'Tape' }),
    );
    const clearBtn = h('button', { class: 'btn btn-plain', text: 'Clear' });
    clearBtn.addEventListener('click', () => {
      tape = [];
      saveTape();
      renderHistory();
    });
    const closeBtn = h('button', { class: 'icon-btn', html: icon('x'), style: { width: '22px', height: '22px' } });
    closeBtn.addEventListener('click', () => { historyPanel.hidden = true; historyPanel.remove(); });
    head.append(clearBtn, closeBtn);
    const list = h('div', { class: 'ch-list' });
    if (!tape.length) {
      list.append(h('div', { class: 'empty-state', style: { padding: '26px 10px' } },
        h('div', { html: icon('calculator') }),
        h('b', { text: 'No calculations yet' }),
        h('span', { text: 'Results appear here as you calculate.' }),
      ));
    } else {
      for (const entry of tape) {
        const item = h('div', { class: 'ch-item', title: 'Click to reuse result' },
          h('div', { class: 'ch-expr', text: entry.expr }),
          h('div', { class: 'ch-res', text: entry.result }),
        );
        item.addEventListener('click', () => {
          display = entry.result;
          overwrite = true;
          justEvaluated = false;
          pendingOp = null;
          accumulator = null;
          expression = entry.expr;
          render();
          historyPanel.hidden = true;
        });
        list.append(item);
      }
    }
    historyPanel.append(head, list);
  }

  function toggleHistory() {
    if (historyPanel.isConnected) {
      historyPanel.remove();
      return;
    }
    renderHistory();
    root.append(historyPanel);
    historyPanel.hidden = false;
  }

  historyBtn.addEventListener('click', toggleHistory);

  /* ---------------- keyboard ---------------- */
  const onKeyDown = (e) => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    const k = e.key;
    if (/^[0-9]$/.test(k)) { e.preventDefault(); inputDigit(k); flash(k); }
    else if (k === '.' || k === ',') { e.preventDefault(); inputDecimal(); flash('.'); }
    else if (k === '+' || k === '-') {
      e.preventDefault();
      const op = k === '-' ? '−' : '+';
      setOperator(op); flash(op);
    } else if (k === '*' || k === 'x' || k === 'X') { e.preventDefault(); setOperator('×'); flash('×'); }
    else if (k === '/') { e.preventDefault(); setOperator('÷'); flash('÷'); }
    else if (k === 'Enter' || k === '=') { e.preventDefault(); equals(); flash('equals'); }
    else if (k === 'Escape' || k === 'c' || k === 'C') {
      e.preventDefault();
      if (display !== '0' || accumulator !== null) clearEntry(); else clearAll();
      flash('clear');
    } else if (k === 'Backspace') {
      e.preventDefault();
      if (overwrite) clearEntry();
      else {
        display = display.length > 1 ? display.slice(0, -1) : '0';
        if (display === '-') display = '0';
        render();
      }
    } else if (k === '%') { e.preventDefault(); percent(); flash('percent'); }
    else if (k === 'Delete') { e.preventDefault(); clearAll(); flash('clear'); }
  };

  function flash(id) {
    const btn = buttonMap.get(id);
    if (!btn) return;
    btn.classList.add('active');
    setTimeout(() => btn.classList.remove('active'), 110);
  }

  root.addEventListener('keydown', onKeyDown);
  root.tabIndex = 0;
  setTimeout(() => root.focus({ preventScroll: true }), 30);

  render();

  const api = {
    input: (value) => {
      for (const ch of String(value)) {
        if (/[0-9]/.test(ch)) inputDigit(ch);
        else if (ch === '.') inputDecimal();
        else if ('+-*/'.includes(ch)) setOperator({ '+': '+', '-': '−', '*': '×', '/': '÷' }[ch]);
        else if (ch === '=') equals();
      }
    },
    clear: clearAll,
    equals,
    getValue: () => display,
    setValue: (value) => { display = formatNumber(Number(value)); overwrite = true; render(); },
    toggleHistory,
  };

  return api;
}

export function menus(win) {
  const api = win.api || {};
  return {
    File: [
      { label: 'Clear', shortcut: '⌫', icon: 'refresh', action: () => api.clear?.() },
      { label: 'Show Tape', icon: 'history', action: () => api.toggleHistory?.() },
      { separator: true },
      { label: 'Close Window', shortcut: '⌘W', action: () => win.ctx.close() },
    ],
    Edit: [
      { label: 'Copy Result', shortcut: '⌘C', action: async () => {
        try {
          await navigator.clipboard.writeText(api.getValue?.() || '0');
          toast({ title: 'Copied', text: api.getValue?.() || '0', icon: 'copy' });
        } catch {
          toast({ title: 'Could not copy', text: 'Clipboard access was blocked.', icon: 'alert' });
        }
      } },
      { separator: true },
      { label: 'Clear Tape', icon: 'trash', action: () => { tape = []; saveTape(); toast({ title: 'Tape cleared', icon: 'check' }); } },
    ],
    View: [
      { label: 'Basic', checked: true, disabled: true },
      { label: 'Show Tape', icon: 'history', action: () => api.toggleHistory?.() },
    ],
  };
}
