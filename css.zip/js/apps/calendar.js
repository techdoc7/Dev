/* ============================================================
   Nova OS — Calendar
   Month view, mini calendar, day panel and event editing.
   ============================================================ */

import { h, uid, clamp, formatDate, escapeHTML } from '../core/util.js';
import { icon } from '../core/icons.js';
import { load, save } from '../core/storage.js';
import { showModal, confirmDialog, toast, emptyState } from '../core/ui.js';
import sounds from '../core/sound.js';

export const meta = {
  id: 'calendar',
  name: 'Calendar',
  icon: 'calendar',
  category: 'Productivity',
  description: 'Plan your month with multiple calendars and a daily agenda.',
  defaultSize: { w: 1000, h: 640 },
  minSize: { w: 680, h: 420 },
  singleton: false,
};

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const DOW = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const DOW_SHORT = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

const pad2 = (n) => String(n).padStart(2, '0');
const dateKey = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const parseKey = (key) => {
  const [y, m, d] = String(key).split('-').map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
};
const sameDay = (a, b) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const startOfDay = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());

function timeLabel(hhmm) {
  const [h, m] = String(hhmm || '09:00').split(':').map(Number);
  const suffix = h >= 12 ? 'PM' : 'AM';
  const hour = h % 12 || 12;
  return `${hour}:${pad2(m || 0)} ${suffix}`;
}

function addMinutes(hhmm, minutes) {
  const [h, m] = String(hhmm || '09:00').split(':').map(Number);
  const total = clamp(h * 60 + m + minutes, 0, 23 * 60 + 59);
  return `${pad2(Math.floor(total / 60))}:${pad2(total % 60)}`;
}

/* ------------------------------------------------------------
   Data
   ------------------------------------------------------------ */

const DEFAULT_CALENDARS = [
  { id: 'personal', name: 'Personal', color: '#0a84ff', enabled: true },
  { id: 'work', name: 'Work', color: '#ff9f0a', enabled: true },
  { id: 'ideas', name: 'Ideas', color: '#bf5af2', enabled: true },
  { id: 'health', name: 'Health', color: '#30d158', enabled: true },
];

function seedEvents() {
  const today = startOfDay(new Date());
  const monday = addDays(today, ((8 - today.getDay()) % 7) || 7);
  const make = (offset, title, time, calendar = 'personal', notes = '') => ({
    id: uid('ev'),
    title,
    date: dateKey(addDays(today, offset)),
    time,
    duration: 60,
    calendar,
    notes,
    created: Date.now(),
  });
  return [
    make(0, 'Morning run', '07:00', 'health', '5 km around the park'),
    make(0, 'Design review', '10:30', 'work', 'Window chrome + dock polish'),
    make(0, 'Lunch with the team', '12:30', 'personal', 'The place on 5th'),
    make(0, 'Ship Nova 1.0', '16:00', 'work', 'Tag the release and write notes'),
    make(1, 'Dentist appointment', '09:15', 'health', 'Bring the insurance card'),
    make(1, 'Prototype lab', '14:00', 'ideas', 'Try the new motion curves'),
    make(2, '1:1 with Sam', '11:00', 'work'),
    make(3, 'Farmers market', '09:30', 'personal', 'Get coffee beans'),
    make(4, 'Write the release post', '15:00', 'ideas', 'Keep it under 600 words'),
    make(6, 'Sprint planning', '10:00', 'work', 'Roadmap for the next cycle'),
    { ...make(0, 'Team offsite', '09:00', 'work'), date: dateKey(monday), duration: 480, notes: 'All day at the studio' },
  ];
}

let stored = load('calendar.v2', null);
let calendars = Array.isArray(stored?.calendars) && stored.calendars.length ? stored.calendars : [...DEFAULT_CALENDARS];
let events = Array.isArray(stored?.events) ? stored.events : seedEvents();

const persist = () => save('calendar.v2', { calendars, events });

const calendarById = (id) => calendars.find((c) => c.id === id) || calendars[0];

/* ------------------------------------------------------------
   Mount
   ------------------------------------------------------------ */

export function mount(body, ctx) {
  const root = h('div');
  body.append(root);
  root.classList.add('app', 'calendar-app');

  const today = startOfDay(new Date());
  let selected = today;
  let viewYear = selected.getFullYear();
  let viewMonth = selected.getMonth();

  /* ---------------- sidebar ---------------- */
  const miniHead = h('div', { class: 'cal-mini-head' });
  const miniGrid = h('div', { class: 'cal-mini-grid' });
  const mini = h('div', { class: 'cal-mini' }, miniHead, miniGrid);

  const listWrap = h('div', { class: 'cal-lists' });
  const sidebar = h('aside', { class: 'app-sidebar sidebar' },
    h('div', { class: 'sidebar-scroll', style: { padding: '0 4px 8px' } }, mini, listWrap),
  );

  /* ---------------- toolbar ---------------- */
  const prevBtn = h('button', { class: 'icon-btn', title: 'Previous Month', html: icon('chevron-left') });
  const nextBtn = h('button', { class: 'icon-btn', title: 'Next Month', html: icon('chevron-right') });
  const titleEl = h('div', { class: 'cal-title' });
  const todayBtn = h('button', { class: 'btn', text: 'Today' });
  const newBtn = h('button', { class: 'btn btn-primary', html: `${icon('plus')} New Event` });
  const toolbar = h('div', { class: 'cal-toolbar' },
    prevBtn,
    nextBtn,
    titleEl,
    h('div', { class: 'spacer' }),
    todayBtn,
    newBtn,
  );

  /* ---------------- month ---------------- */
  const dowRow = h('div', { class: 'cal-dow-row' }, DOW.map((d, i) => h('div', { text: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][i] })));
  const cells = h('div', { class: 'cal-cells' });
  const month = h('div', { class: 'cal-month' }, dowRow, cells);

  /* ---------------- day panel ---------------- */
  const dayPanel = h('aside', { class: 'cal-day-panel' });
  const calBody = h('div', { class: 'cal-body' }, month, dayPanel);
  const main = h('div', { class: 'cal-main' }, toolbar, calBody);

  root.append(sidebar, main);

  /* ---------------- data helpers ---------------- */
  function enabledCalendarIds() {
    return new Set(calendars.filter((c) => c.enabled).map((c) => c.id));
  }

  function eventsFor(key) {
    const enabled = enabledCalendarIds();
    return events
      .filter((e) => e.date === key && enabled.has(e.calendar))
      .sort((a, b) => (a.time || '').localeCompare(b.time || ''));
  }

  function eventsOnDay(date) {
    return eventsFor(dateKey(date));
  }

  /* ---------------- month render ---------------- */
  function render() {
    titleEl.replaceChildren(
      h('span', { text: MONTHS[viewMonth] + ' ' }),
      h('span', { text: String(viewYear) }),
    );
    renderMini();
    renderCells();
    renderDayPanel();
    renderCalendars();
  }

  function renderCells() {
    cells.replaceChildren();
    const first = new Date(viewYear, viewMonth, 1);
    const startOffset = first.getDay();
    const gridStart = addDays(first, -startOffset);
    const todayKey = dateKey(today);
    const selectedKey = dateKey(selected);

    for (let i = 0; i < 42; i++) {
      const date = addDays(gridStart, i);
      const key = dateKey(date);
      const isOther = date.getMonth() !== viewMonth;
      const isWeekend = date.getDay() === 0 || date.getDay() === 6;
      const cell = h('div', {
        class: `cal-cell${isOther ? ' other' : ''}${key === selectedKey ? ' selected' : ''}${key === todayKey ? ' today' : ''}${isWeekend ? ' weekend' : ''}`,
        dataset: { date: key },
      });
      cell.append(h('div', { class: 'cc-day', text: String(date.getDate()) }));
      const eventsWrap = h('div', { class: 'cc-events' });
      const dayEvents = eventsFor(key);
      for (const ev of dayEvents.slice(0, 3)) {
        const cal = calendarById(ev.calendar);
        const pill = h('div', {
          class: 'cal-ev-pill',
          title: `${ev.title} · ${timeLabel(ev.time)}`,
          style: { background: `${cal.color}2e`, color: cal.color, borderLeft: `2px solid ${cal.color}` },
        },
          ev.time ? h('span', { class: 'ev-time', text: timeLabel(ev.time).replace(':00', '') }) : null,
          h('span', { class: 'ev-name', text: ev.title, style: { overflow: 'hidden', textOverflow: 'ellipsis' } }),
        );
        pill.addEventListener('click', (e) => { e.stopPropagation(); openEvent(ev); });
        eventsWrap.append(pill);
      }
      if (dayEvents.length > 3) {
        eventsWrap.append(h('div', { class: 'cal-ev-more', text: `+${dayEvents.length - 3} more` }));
      }
      cell.append(eventsWrap);
      cell.addEventListener('click', () => {
        selected = date;
        if (isOther) { viewYear = date.getFullYear(); viewMonth = date.getMonth(); }
        render();
      });
      cell.addEventListener('dblclick', () => {
        selected = date;
        newEvent(key);
      });
      cells.append(cell);
    }
  }

  function renderMini() {
    miniHead.replaceChildren();
    const title = h('div', { class: 'cm-title', text: `${MONTHS[viewMonth].slice(0, 3)} ${viewYear}` });
    const back = h('button', { class: 'icon-btn', html: icon('chevron-left'), title: 'Previous month' });
    const fwd = h('button', { class: 'icon-btn', html: icon('chevron-right'), title: 'Next month' });
    back.addEventListener('click', () => shiftMonth(-1));
    fwd.addEventListener('click', () => shiftMonth(1));
    miniHead.append(title, back, fwd);

    miniGrid.replaceChildren();
    for (const d of DOW_SHORT) miniGrid.append(h('div', { class: 'cm-dow', text: d }));
    const first = new Date(viewYear, viewMonth, 1);
    const gridStart = addDays(first, -first.getDay());
    for (let i = 0; i < 42; i++) {
      const date = addDays(gridStart, i);
      const isOther = date.getMonth() !== viewMonth;
      const isToday = sameDay(date, today);
      const isSelected = sameDay(date, selected);
      const btn = h('button', {
        class: `cal-mini-day${isOther ? ' other' : ''}${isToday ? ' today' : ''}${isSelected ? ' selected' : ''}`,
        text: String(date.getDate()),
        title: formatDate(date, { weekday: true }),
      });
      btn.addEventListener('click', () => {
        selected = date;
        viewYear = date.getFullYear();
        viewMonth = date.getMonth();
        render();
      });
      miniGrid.append(btn);
    }
  }

  function renderCalendars() {
    listWrap.replaceChildren();
    listWrap.append(h('div', { class: 'sidebar-label', text: 'My Calendars' }));
    for (const cal of calendars) {
      const item = h('div', { class: `cal-list-item${cal.enabled ? '' : ' off'}` });
      const check = h('span', { class: 'cl-check', style: { background: cal.color }, html: icon('check') });
      item.append(check, h('span', { text: cal.name, style: { flex: '1' } }));
      const count = events.filter((e) => e.calendar === cal.id).length;
      item.append(h('span', { class: 'si-count', text: String(count), style: { fontSize: '10px', color: 'var(--text-3)' } }));
      item.addEventListener('click', () => {
        cal.enabled = !cal.enabled;
        persist();
        render();
      });
      item.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        showModal({
          title: cal.name,
          icon: 'calendar',
          width: 380,
          body: `<p class="muted">${count} event${count === 1 ? '' : 's'} in this calendar.</p>`,
          actions: [
            { label: 'Delete Calendar', value: 'delete', danger: true },
            { label: 'Toggle Visibility', value: 'toggle' },
            { label: 'Cancel', value: null, primary: true },
          ],
        }).then((res) => {
          if (res === 'toggle') { cal.enabled = !cal.enabled; persist(); render(); }
          if (res === 'delete') {
            calendars = calendars.filter((c) => c.id !== cal.id);
            events = events.filter((e) => e.calendar !== cal.id);
            persist();
            render();
            toast({ title: 'Calendar deleted', text: cal.name, icon: 'calendar' });
          }
        });
      });
      listWrap.append(item);
    }
    const add = h('button', { class: 'sidebar-item', style: { marginTop: '6px', width: '100%' } },
      h('span', { html: icon('plus') }),
      h('span', { class: 'si-text', text: 'Add Calendar' }),
    );
    add.addEventListener('click', addCalendar);
    listWrap.append(add);
  }

  function renderDayPanel() {
    dayPanel.replaceChildren();
    const key = dateKey(selected);
    const isToday = sameDay(selected, today);
    const head = h('div', { class: 'cal-day-head' },
      h('div', { class: 'cd-dow', text: isToday ? 'Today' : DOW[selected.getDay()] }),
      h('div', { class: 'cd-date', text: selected.toLocaleDateString(undefined, { month: 'long', day: 'numeric' }) }),
      h('div', { class: 'cd-sub', text: `${selected.getFullYear()}${isToday ? ' · Today' : ''}` }),
    );
    const list = h('div', { class: 'cal-day-events' });
    const dayEvents = eventsOnDay(selected);
    if (!dayEvents.length) {
      const empty = emptyState('calendar', 'No events', 'Enjoy the open space, or add something.');
      empty.style.padding = '26px 8px';
      list.append(empty);
    } else {
      for (const ev of dayEvents) {
        const cal = calendarById(ev.calendar);
        const card = h('div', { class: 'cal-day-event', style: { borderLeftColor: cal.color } },
          h('div', { class: 'cde-time', text: `${timeLabel(ev.time)} – ${timeLabel(addMinutes(ev.time, ev.duration || 60))}` }),
          h('div', { class: 'cde-title', text: ev.title }),
          ev.notes ? h('div', { class: 'cde-notes', text: ev.notes }) : null,
        );
        card.addEventListener('click', () => openEvent(ev));
        list.append(card);
      }
    }
    const foot = h('div', { class: 'cal-day-foot' },
      h('button', { class: 'btn', html: `${icon('plus')} Add Event`, onclick: () => newEvent(key) }),
    );
    dayPanel.append(head, list, foot);
  }

  /* ---------------- navigation ---------------- */
  function shiftMonth(delta) {
    const d = new Date(viewYear, viewMonth + delta, 1);
    viewYear = d.getFullYear();
    viewMonth = d.getMonth();
    const lastDay = new Date(viewYear, viewMonth + 1, 0).getDate();
    if (selected.getMonth() !== viewMonth || selected.getFullYear() !== viewYear) {
      selected = new Date(viewYear, viewMonth, Math.min(selected.getDate(), lastDay));
    }
    render();
  }

  function goToday() {
    selected = today;
    viewYear = today.getFullYear();
    viewMonth = today.getMonth();
    render();
  }

  prevBtn.addEventListener('click', () => shiftMonth(-1));
  nextBtn.addEventListener('click', () => shiftMonth(1));
  todayBtn.addEventListener('click', goToday);
  newBtn.addEventListener('click', () => newEvent(dateKey(selected)));

  /* ---------------- event editor ---------------- */
  function newEvent(key = dateKey(selected)) {
    openEventForm(null, key || dateKey(selected));
  }

  function openEvent(ev) {
    if (!ev) return;
    const cal = calendarById(ev.calendar);
    showModal({
      title: ev.title,
      icon: 'calendar',
      width: 430,
      body: `
        <div class="pv-row"><span class="k">When</span><span class="v">${escapeHTML(formatDate(parseKey(ev.date), { weekday: true }))} · ${escapeHTML(timeLabel(ev.time))} – ${escapeHTML(timeLabel(addMinutes(ev.time, ev.duration || 60)))}</span></div>
        <div class="pv-row"><span class="k">Calendar</span><span class="v"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${cal.color};margin-right:5px"></span>${escapeHTML(cal.name)}</span></div>
        ${ev.notes ? `<div class="pv-row"><span class="k">Notes</span><span class="v">${escapeHTML(ev.notes)}</span></div>` : ''}
      `,
      actions: [
        { label: 'Delete', value: 'delete', danger: true },
        { label: 'Edit', value: 'edit' },
        { label: 'Done', value: null, primary: true },
      ],
    }).then(async (res) => {
      if (res === 'edit') openEventForm(ev);
      if (res === 'delete') {
        const ok = await confirmDialog({
          title: `Delete “${ev.title}”?`,
          message: 'This event will be removed from your calendar.',
          confirmLabel: 'Delete',
          danger: true,
          iconName: 'calendar',
        });
        if (!ok) return;
        events = events.filter((e) => e.id !== ev.id);
        persist();
        render();
        toast({ title: 'Event deleted', text: ev.title, icon: 'trash' });
      }
    });
  }

  function openEventForm(ev = null, dateOverride = null) {
    const draft = ev ? { ...ev } : {
      id: null,
      title: '',
      date: dateOverride || dateKey(selected),
      time: '09:00',
      duration: 60,
      calendar: calendars.find((c) => c.enabled)?.id || calendars[0]?.id || 'personal',
      notes: '',
    };
    const form = h('div', { class: 'form-grid' });
    const titleInput = h('input', { class: 'input', placeholder: 'Event title', value: draft.title });
    const dateInput = h('input', { class: 'input', type: 'date', value: draft.date });
    const timeInput = h('input', { class: 'input', type: 'time', value: draft.time });
    const durationSelect = h('select', { class: 'input select' },
      [15, 30, 45, 60, 90, 120, 180, 240, 480].map((m) => h('option', { value: String(m), text: m >= 60 ? `${m / 60} hour${m > 60 ? 's' : ''}` : `${m} minutes`, selected: (draft.duration || 60) === m })),
    );
    const calSelect = h('select', { class: 'input select' },
      calendars.map((c) => h('option', { value: c.id, text: c.name, selected: draft.calendar === c.id })),
    );
    const notesInput = h('textarea', { class: 'textarea input', rows: '3', placeholder: 'Notes', style: { height: '66px' } }, draft.notes || '');

    form.append(
      h('div', { class: 'form-row-col' }, h('label', { text: 'Title' }), titleInput),
      h('div', { class: 'form-row' },
        h('label', { text: 'Date' }), dateInput,
      ),
      h('div', { class: 'form-row' },
        h('label', { text: 'Starts' }), timeInput,
      ),
      h('div', { class: 'form-row' },
        h('label', { text: 'Duration' }), durationSelect,
      ),
      h('div', { class: 'form-row' },
        h('label', { text: 'Calendar' }), calSelect,
      ),
      h('div', { class: 'form-row-col' }, h('label', { text: 'Notes' }), notesInput),
    );

    showModal({
      title: ev ? 'Edit Event' : 'New Event',
      icon: 'calendar',
      width: 440,
      body: form,
      actions: [
        { label: 'Cancel', value: null },
        { label: ev ? 'Save' : 'Add Event', value: 'save', primary: true },
      ],
      onMount: (bodyEl, close) => {
        const saveBtn = bodyEl.parentElement.querySelector('.btn-primary');
        saveBtn?.addEventListener('click', (e) => {
          const title = titleInput.value.trim();
          if (!title) {
            e.preventDefault();
            e.stopImmediatePropagation();
            titleInput.focus();
            titleInput.style.boxShadow = '0 0 0 3px rgba(255,69,58,.3)';
            setTimeout(() => { titleInput.style.boxShadow = ''; }, 1200);
          }
        }, true);
        setTimeout(() => titleInput.focus(), 40);
      },
    }).then((res) => {
      if (res !== 'save') return;
      const title = titleInput.value.trim();
      if (!title) return;
      const next = {
        id: ev?.id || uid('ev'),
        title,
        date: dateInput.value || dateKey(selected),
        time: timeInput.value || '09:00',
        duration: Number(durationSelect.value) || 60,
        calendar: calSelect.value,
        notes: notesInput.value.trim(),
        created: ev?.created || Date.now(),
      };
      if (ev) {
        events = events.map((e) => (e.id === ev.id ? next : e));
        toast({ title: 'Event updated', text: next.title, icon: 'calendar' });
      } else {
        events.push(next);
        toast({ title: 'Event added', text: next.title, icon: 'calendar-check' });
      }
      persist();
      selected = parseKey(next.date);
      viewYear = selected.getFullYear();
      viewMonth = selected.getMonth();
      render();
      sounds.success();
    });
  }

  function addCalendar() {
    const body = h('div', { class: 'form-grid' });
    const nameInput = h('input', { class: 'input', placeholder: 'Calendar name', value: '' });
    let color = '#0a84ff';
    const swatches = h('div', { class: 'accent-swatches' });
    const COLORS = ['#0a84ff', '#ff9f0a', '#bf5af2', '#30d158', '#ff453a', '#ffd60a', '#64d2ff', '#8e8e93'];
    for (const c of COLORS) {
      const dot = h('button', {
        class: `accent-swatch${c === color ? ' selected' : ''}`,
        style: { background: c, color: c },
        title: c,
      });
      dot.addEventListener('click', () => {
        color = c;
        swatches.querySelectorAll('.accent-swatch').forEach((n) => n.classList.toggle('selected', n === dot));
      });
      swatches.append(dot);
    }
    body.append(
      h('div', { class: 'form-row-col' }, h('label', { text: 'Name' }), nameInput),
      h('div', { class: 'form-row-col' }, h('label', { text: 'Color' }), swatches),
    );
    showModal({
      title: 'New Calendar',
      icon: 'calendar',
      width: 380,
      body,
      actions: [
        { label: 'Cancel', value: null },
        { label: 'Create', value: 'ok', primary: true },
      ],
      onMount: (bodyEl) => setTimeout(() => bodyEl.querySelector('input')?.focus(), 40),
    }).then((res) => {
      if (res !== 'ok') return;
      const name = nameInput.value.trim();
      if (!name) return;
      calendars.push({ id: uid('cal'), name, color, enabled: true });
      persist();
      render();
      toast({ title: 'Calendar created', text: name, icon: 'calendar' });
    });
  }

  /* ---------------- keyboard ---------------- */
  root.addEventListener('keydown', (e) => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') return;
    if (e.key === 'ArrowLeft') { e.preventDefault(); selected = addDays(selected, -1); if (selected.getMonth() !== viewMonth) { viewMonth = selected.getMonth(); viewYear = selected.getFullYear(); } render(); }
    else if (e.key === 'ArrowRight') { e.preventDefault(); selected = addDays(selected, 1); if (selected.getMonth() !== viewMonth) { viewMonth = selected.getMonth(); viewYear = selected.getFullYear(); } render(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); selected = addDays(selected, -7); if (selected.getMonth() !== viewMonth) { viewMonth = selected.getMonth(); viewYear = selected.getFullYear(); } render(); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); selected = addDays(selected, 7); if (selected.getMonth() !== viewMonth) { viewMonth = selected.getMonth(); viewYear = selected.getFullYear(); } render(); }
    else if (e.key === 't' || e.key === 'T') { e.preventDefault(); goToday(); }
    else if (e.key === 'n' || e.key === 'N') { e.preventDefault(); newEvent(); }
    else if (e.key === 'Delete' || e.key === 'Backspace') {
      const list = eventsOnDay(selected);
      if (list.length === 1 && selected) {
        e.preventDefault();
        events = events.filter((x) => x.id !== list[0].id);
        persist(); render();
        toast({ title: 'Event deleted', text: list[0].title, icon: 'trash' });
      }
    }
  });
  root.tabIndex = 0;

  if (ctx.params?.date) {
    const parsed = parseKey(ctx.params.date);
    if (!Number.isNaN(parsed.getTime())) { selected = parsed; viewYear = parsed.getFullYear(); viewMonth = parsed.getMonth(); }
  }
  if (ctx.params?.new) setTimeout(() => newEvent(dateKey(selected)), 220);

  render();

  return {
    newEvent: (date) => newEvent(date || dateKey(selected)),
    openEventForm,
    goToday,
    getEvents: () => events.map((e) => ({ ...e })),
    deleteEvent: (id) => {
      const before = events.length;
      events = events.filter((e) => e.id !== id);
      if (events.length === before) return false;
      persist();
      render();
      return true;
    },
    getSelectedDate: () => dateKey(selected),
    refresh: render,
    dispose() { /* nothing external */ },
  };
}

/* ------------------------------------------------------------ */

export function menus(win) {
  const api = win.api || {};
  return {
    File: [
      { label: 'New Event', shortcut: '⌘N', icon: 'calendar-plus', action: () => api.newEvent?.() },
      { label: 'Go to Today', shortcut: '⌘T', icon: 'calendar', action: () => api.goToday?.() },
      { separator: true },
      { label: 'Close Window', shortcut: '⌘W', action: () => win.ctx.close() },
    ],
    View: [
      { label: 'Previous Month', shortcut: '⌘[', icon: 'chevron-left', action: () => win.el.querySelector('.cal-toolbar .icon-btn')?.click() },
      { label: 'Next Month', shortcut: '⌘]', icon: 'chevron-right', action: () => win.el.querySelectorAll('.cal-toolbar .icon-btn')[1]?.click() },
      { separator: true },
      { label: 'Today', shortcut: '⌘T', action: () => api.goToday?.() },
    ],
    Help: [
      { label: 'Keyboard Shortcuts', icon: 'keyboard', action: () => {
        showModal({
          title: 'Calendar Shortcuts',
          icon: 'keyboard',
          width: 390,
          body: `<div class="pv-row"><span class="k">← → ↑ ↓</span><span class="v">Move selection</span></div>
                 <div class="pv-row"><span class="k">T</span><span class="v">Jump to today</span></div>
                 <div class="pv-row"><span class="k">N</span><span class="v">New event</span></div>
                 <div class="pv-row"><span class="k">Delete</span><span class="v">Delete the day's only event</span></div>`,
          actions: [{ label: 'OK', value: true, primary: true }],
        });
      } },
    ],
  };
}
