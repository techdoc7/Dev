/* ============================================================
   Nova OS — Text Editor
   A proper little code editor with syntax highlighting, line
   numbers, save / save-as and unsaved-change protection.
   ============================================================ */

import { h, basename, dirname, extname, formatBytes, escapeHTML, isEditable, debounce } from '../core/util.js';
import { icon } from '../core/icons.js';
import { fs, HOME, WORKSPACE, editorFor } from '../core/fs.js';
import { showModal, promptDialog, confirmDialog, toast, emptyState } from '../core/ui.js';
import { on } from '../core/bus.js';
import sounds from '../core/sound.js';

export const meta = {
  id: 'editor',
  name: 'Text Editor',
  icon: 'editor',
  category: 'Productivity',
  description: 'Write and edit text files with syntax highlighting and live status.',
  defaultSize: { w: 900, h: 620 },
  minSize: { w: 520, h: 340 },
  singleton: false,
};

const LANGUAGES = [
  { id: 'plain', name: 'Plain Text', exts: ['txt', 'log', ''] },
  { id: 'markdown', name: 'Markdown', exts: ['md', 'markdown'] },
  { id: 'javascript', name: 'JavaScript', exts: ['js', 'mjs', 'jsx'] },
  { id: 'typescript', name: 'TypeScript', exts: ['ts', 'tsx'] },
  { id: 'json', name: 'JSON', exts: ['json'] },
  { id: 'css', name: 'CSS', exts: ['css', 'scss'] },
  { id: 'html', name: 'HTML', exts: ['html', 'htm', 'svg'] },
  { id: 'csv', name: 'CSV', exts: ['csv'] },
  { id: 'shell', name: 'Shell Script', exts: ['sh', 'bash', 'zsh'] },
  { id: 'yaml', name: 'YAML', exts: ['yml', 'yaml'] },
];

const languageFor = (path) => {
  const ext = extname(path);
  return LANGUAGES.find((l) => l.exts.includes(ext)) || LANGUAGES[0];
};

/* ------------------------------------------------------------
   Syntax highlighting (escaped, token-based)
   ------------------------------------------------------------ */

const esc = (s) => escapeHTML(s);
const span = (cls, text) => `<span class="${cls}">${esc(text)}</span>`;

function highlightJS(code) {
  const rx = /(\/\/[^\n]*|\/\*[\s\S]*?\*\/)|(`(?:\\[\s\S]|[^`\\])*`|"(?:\\[\s\S]|[^"\\\n])*"|'(?:\\[\s\S]|[^'\\\n])*')|\b(const|let|var|function|return|if|else|for|while|do|switch|case|break|continue|default|import|from|export|class|extends|new|await|async|try|catch|finally|throw|typeof|instanceof|yield|delete|void|this|super|in|of|static|get|set)\b|\b(true|false|null|undefined|NaN|Infinity)\b|\b(\d[\d_]*(?:\.\d+)?(?:[eE][+-]?\d+)?)\b|([A-Za-z_$][\w$]*)(?=\s*\()|([{}[\]();,.:])/g;
  let out = '';
  let last = 0;
  let m;
  while ((m = rx.exec(code))) {
    out += esc(code.slice(last, m.index));
    if (m[1]) out += span('tok-com', m[1]);
    else if (m[2]) out += span('tok-str', m[2]);
    else if (m[3]) out += span('tok-kw', m[3]);
    else if (m[4]) out += span('tok-const', m[4]);
    else if (m[5]) out += span('tok-num', m[5]);
    else if (m[6]) out += span('tok-fn', m[6]);
    else if (m[7]) out += span('tok-punc', m[7]);
    last = rx.lastIndex;
  }
  out += esc(code.slice(last));
  return out;
}

function highlightCSS(code) {
  const rx = /(\/\*[\s\S]*?\*\/)|("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')|(@[\w-]+)|([a-zA-Z-]+)(?=\s*:)|(#[0-9a-fA-F]{3,8}\b)|(\b\d+(?:\.\d+)?(?:px|rem|em|%|vh|vw|s|ms|deg|fr)?\b)|([{}();:,])/g;
  let out = '';
  let last = 0;
  let m;
  while ((m = rx.exec(code))) {
    out += esc(code.slice(last, m.index));
    if (m[1]) out += span('tok-com', m[1]);
    else if (m[2]) out += span('tok-str', m[2]);
    else if (m[3]) out += span('tok-const', m[3]);
    else if (m[4]) out += span('tok-attr', m[4]);
    else if (m[5]) out += span('tok-num', m[5]);
    else if (m[6]) out += span('tok-num', m[6]);
    else if (m[7]) out += span('tok-punc', m[7]);
    last = rx.lastIndex;
  }
  out += esc(code.slice(last));
  return out;
}

function highlightHTML(code) {
  const rx = /(<!--[\s\S]*?-->)|(<![^>]*>)|(<\/?)([a-zA-Z][\w:-]*)([^>]*?)(\/?>)/g;
  let out = '';
  let last = 0;
  let m;
  while ((m = rx.exec(code))) {
    out += esc(code.slice(last, m.index));
    if (m[1]) out += span('tok-com', m[1]);
    else if (m[2]) out += span('tok-punc', m[2]);
    else {
      out += `<span class="tok-punc">${esc(m[3])}</span>`;
      out += span('tok-tag', m[4]);
      out += highlightAttrs(m[5]);
      out += span('tok-punc', m[6]);
    }
    last = rx.lastIndex;
  }
  out += esc(code.slice(last));
  return out;
}

function highlightAttrs(raw) {
  const rx = /([^\s=/>]+)(\s*=\s*)("(?:[^"]*)"|'(?:[^']*)'|[^\s>]+)|([^\s=/>]+)|\s+/g;
  let out = '';
  let last = 0;
  let m;
  while ((m = rx.exec(raw))) {
    out += esc(raw.slice(last, m.index));
    if (m[1] && m[2] && m[3]) {
      out += span('tok-attr', m[1]);
      out += `<span class="tok-punc">${esc(m[2])}</span>`;
      out += span('tok-str', m[3]);
    } else if (m[4]) {
      out += span('tok-attr', m[4]);
    } else if (m[0].trim()) {
      out += esc(m[0]);
    } else {
      out += esc(m[0]);
    }
    last = rx.lastIndex;
  }
  out += esc(raw.slice(last));
  return out;
}

function highlightMarkdown(code) {
  const lines = code.split('\n');
  let inFence = false;
  const out = [];
  for (const line of lines) {
    if (/^\s*(```|~~~)/.test(line)) {
      inFence = !inFence;
      out.push(`<span class="tok-str">${esc(line)}</span>`);
      continue;
    }
    if (inFence) {
      out.push(`<span class="tok-str">${esc(line)}</span>`);
      continue;
    }
    if (/^#{1,6}\s/.test(line)) {
      out.push(`<span class="tok-kw">${esc(line)}</span>`);
      continue;
    }
    if (/^\s*>/.test(line)) {
      out.push(`<span class="tok-com">${esc(line)}</span>`);
      continue;
    }
    let html = esc(line);
    html = html.replace(/(`[^`]+`)/g, '<span class="tok-str">$1</span>');
    html = html.replace(/(\*\*[^*]+\*\*)/g, '<span class="tok-const">$1</span>');
    html = html.replace(/(\[[^\]]+\]\([^)]+\))/g, '<span class="tok-fn">$1</span>');
    html = html.replace(/^(\s*[-*+] )/g, '<span class="tok-punc">$1</span>');
    html = html.replace(/^(\s*\d+\. )/g, '<span class="tok-punc">$1</span>');
    out.push(html);
  }
  return out.join('\n');
}

function highlightYAML(code) {
  return code.split('\n').map((line) => {
    if (/^\s*#/.test(line)) return span('tok-com', line);
    const m = line.match(/^(\s*)([\w.-]+)(:)(.*)$/);
    if (m) return esc(m[1]) + span('tok-attr', m[2]) + span('tok-punc', m[3]) + (m[4] ? span('tok-str', m[4]) : '');
    return esc(line);
  }).join('\n');
}

function highlight(code, language) {
  switch (language) {
    case 'javascript':
    case 'typescript':
    case 'json':
      return highlightJS(code);
    case 'css':
      return highlightCSS(code);
    case 'html':
      return highlightHTML(code);
    case 'markdown':
      return highlightMarkdown(code);
    case 'yaml':
      return highlightYAML(code);
    case 'shell':
      return code.split('\n').map((line) => (line.trim().startsWith('#') ? span('tok-com', line) : esc(line))).join('\n');
    default:
      return esc(code);
  }
}

/* ------------------------------------------------------------
   File picker
   ------------------------------------------------------------ */

function collectTextFiles() {
  const out = [];
  const walk = (path) => {
    let items = [];
    try { items = fs.list(path); } catch { return; }
    for (const item of items) {
      if (item.type === 'dir') {
        if (item.path === '/System' || item.path === '/Applications') continue;
        if (item.path.split('/').length > 6) continue;
        walk(item.path);
      } else if (item.type === 'file' && editorFor(item.path)) {
        out.push(item);
      }
    }
  };
  walk(HOME);
  walk('/System');
  return out.sort((a, b) => b.modified - a.modified);
}

async function pickFile() {
  const files = collectTextFiles();
  const list = h('div', { style: { maxHeight: '320px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '1px' } });
  const search = h('input', { class: 'input', placeholder: 'Search files', style: { marginBottom: '8px' } });
  const body = h('div', {}, search, list);

  const render = (query = '') => {
    list.replaceChildren();
    const q = query.toLowerCase().trim();
    const filtered = q
      ? files.filter((f) => f.name.toLowerCase().includes(q) || f.path.toLowerCase().includes(q))
      : files;
    if (!filtered.length) {
      list.append(emptyState('search', 'No files', 'Nothing matches that search.'));
      return;
    }
    for (const file of filtered.slice(0, 80)) {
      const row = h('button', {
        class: 'bp-item',
        style: { display: 'flex', width: '100%', textAlign: 'left', cursor: 'default' },
      });
      row.append(
        h('span', { class: 'bp-ico', html: icon(file.readonly ? 'lock' : 'file-text') }),
        h('span', { class: 'bp-text' },
          h('div', { class: 'bp-name', text: file.name }),
          h('div', { class: 'bp-url', text: file.path }),
        ),
        h('span', { style: { fontSize: '9.5px', color: 'var(--text-3)', flex: 'none' }, text: formatBytes(file.size) }),
      );
      row.addEventListener('click', () => close(file.path));
      list.append(row);
    }
  };

  let close = null;
  return showModal({
    title: 'Open File',
    icon: 'folder-open',
    width: 520,
    body,
    actions: [{ label: 'Cancel', value: null }],
    onMount: (bodyEl, closeFn) => {
      close = closeFn;
      render();
      search.addEventListener('input', () => render(search.value));
      setTimeout(() => search.focus(), 40);
    },
  }).then((res) => res || null);
}

/* ------------------------------------------------------------
   Mount
   ------------------------------------------------------------ */

export function mount(body, ctx) {
  const root = h('div');
  body.append(root);
  root.classList.add('app', 'editor-app');

  let path = null;
  let savedContent = '';
  let content = '';
  let dirty = false;
  let language = 'plain';
  let wrap = false;
  let fontSize = 12;

  /* ---------------- DOM ---------------- */
  const newBtn = h('button', { class: 'icon-btn', title: 'New File', 'aria-label': 'New file', html: icon('file-plus') });
  const openBtn = h('button', { class: 'icon-btn', title: 'Open File (⌘O)', 'aria-label': 'Open file', html: icon('folder-open') });
  const saveBtn = h('button', { class: 'btn', html: `${icon('save')} Save`, title: 'Save (⌘S)' });
  const unsavedDot = h('div', { class: 'unsaved-dot', title: 'No unsaved changes' });
  const langSelect = h('select', { class: 'select', title: 'Language' },
    LANGUAGES.map((l) => h('option', { value: l.id, text: l.name })),
  );
  const sizeSelect = h('select', { class: 'select', title: 'Font size' },
    [11, 12, 13, 14, 16].map((s) => h('option', { value: String(s), text: `${s} px`, selected: s === 12 })),
  );
  const wrapBtn = h('button', { class: 'btn', text: 'Wrap', title: 'Toggle word wrap' });
  const pathLabel = h('div', { class: 'toolbar-sub', style: { marginLeft: '4px', fontSize: '10.5px', color: 'var(--text-3)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '240px' } });

  const toolbar = h('div', { class: 'editor-toolbar' },
    newBtn, openBtn, saveBtn, unsavedDot,
    h('div', { class: 'et-sep' }),
    langSelect, sizeSelect, wrapBtn,
    pathLabel,
    h('div', { class: 'spacer' }),
  );

  const gutterInner = h('div');
  const gutter = h('div', { class: 'editor-gutter' }, gutterInner);
  const codeEl = h('code');
  const pre = h('pre', { 'aria-hidden': 'true' }, codeEl);
  const textarea = h('textarea', {
    spellcheck: 'false',
    autocomplete: 'off',
    autocapitalize: 'off',
    wrap: 'off',
    'aria-label': 'Editor',
  });
  const codeWrap = h('div', { class: 'editor-code' }, pre, textarea);
  const area = h('div', { class: 'editor-area' }, gutter, codeWrap);

  const posEl = h('span', { text: 'Ln 1, Col 1' });
  const wordsEl = h('span', { text: '0 words' });
  const langEl = h('span', { text: 'Plain Text' });
  const status = h('div', { class: 'editor-status' },
    posEl,
    h('span', { text: 'UTF-8' }),
    h('div', { class: 'es-right' }, wordsEl, langEl),
  );

  root.append(toolbar, area, status);

  /* ---------------- rendering ---------------- */
  function updateTitle() {
    const name = path ? basename(path) : 'Untitled';
    ctx.setTitle(dirty ? `${name} — Edited` : name);
    pathLabel.textContent = path || 'Untitled document';
    pathLabel.title = path || '';
  }

  function renderGutter() {
    const lines = content.split('\n').length;
    if (gutterInner.childElementCount === lines) return;
    gutterInner.replaceChildren();
    for (let i = 1; i <= lines; i++) gutterInner.append(h('div', { text: String(i) }));
  }

  const refreshHighlight = debounce(() => {
    codeEl.innerHTML = highlight(content, language) + '\n';
    renderGutter();
    syncScroll();
  }, 30);

  function syncScroll() {
    pre.scrollTop = textarea.scrollTop;
    pre.scrollLeft = textarea.scrollLeft;
    gutterInner.style.transform = `translateY(${-textarea.scrollTop}px)`;
  }

  function caretInfo() {
    const pos = textarea.selectionStart;
    const before = content.slice(0, pos);
    const line = before.split('\n').length;
    const col = pos - before.lastIndexOf('\n');
    const selected = textarea.selectionEnd - textarea.selectionStart;
    posEl.textContent = selected > 0
      ? `Ln ${line}, Col ${col} (${selected} selected)`
      : `Ln ${line}, Col ${col}`;
    const words = content.trim() ? content.trim().split(/\s+/).length : 0;
    wordsEl.textContent = `${words} word${words === 1 ? '' : 's'} · ${content.length} chars`;
  }

  function markDirty() {
    const next = content !== savedContent;
    if (next === dirty) return;
    dirty = next;
    unsavedDot.classList.toggle('on', dirty);
    unsavedDot.title = dirty ? 'Unsaved changes' : 'No unsaved changes';
    saveBtn.classList.toggle('btn-primary', dirty);
    updateTitle();
  }

  function setContent(next) {
    content = next;
    textarea.value = next;
    refreshHighlight();
    renderGutter();
    markDirty();
    caretInfo();
    syncScroll();
  }

  function setLanguage(next) {
    language = next;
    langSelect.value = next;
    langEl.textContent = LANGUAGES.find((l) => l.id === next)?.name || 'Plain Text';
    refreshHighlight();
  }

  /* ---------------- file operations ---------------- */
  function loadFile(target) {
    try {
      const stat = fs.stat(target);
      if (stat.type === 'dir') { toast({ title: 'That is a folder', text: target, icon: 'folder' }); return; }
      const text = fs.readFile(target);
      path = stat.path;
      savedContent = text;
      setContent(text);
      setLanguage(languageFor(target).id);
      markDirty();
      updateTitle();
      textarea.scrollTop = 0;
      syncScroll();
      caretInfo();
      setTimeout(() => textarea.focus(), 20);
    } catch (err) {
      toast({ title: 'Could not open file', text: err.message, icon: 'alert' });
    }
  }

  function neutralPath() {
    return dirname(path || `${WORKSPACE}/untitled.md`);
  }

  async function saveFile({ saveAs = false } = {}) {
    if (!path || saveAs) {
      const suggested = path || `${WORKSPACE}/untitled.md`;
      const target = await promptDialog({
        title: saveAs ? 'Save As' : 'Save File',
        message: 'Enter a virtual path for this file. Folders are created automatically.',
        label: 'Path',
        value: suggested,
        confirmLabel: 'Save',
        validate: (value) => {
          if (!value.trim()) return 'Enter a path.';
          try {
            const full = fs.normalize(value.trim(), HOME);
            if (full === '/' || ['/Users', HOME, '/System', '/Applications'].includes(full)) return 'That location is protected.';
            if (full.startsWith('/System/') || full.startsWith('/Applications/')) return 'That location is read-only.';
            if (fs.exists(full) && fs.isDir(full)) return 'That path is a folder.';
            if (!editorFor(full)) return 'Use a text file extension such as .md or .txt.';
            return null;
          } catch (err) {
            return err.message;
          }
        },
      });
      if (!target) return false;
      path = fs.normalize(target.trim(), HOME);
      setLanguage(languageFor(path).id);
    }
    try {
      const stat = fs.writeFile(path, content);
      savedContent = content;
      markDirty();
      updateTitle();
      toast({ title: 'Saved', text: `${basename(path)} · ${formatBytes(stat.size)}`, icon: 'save' });
      sounds.success();
      return true;
    } catch (err) {
      toast({ title: 'Could not save', text: err.message, icon: 'alert' });
      sounds.error();
      return false;
    }
  }

  async function newFile() {
    if (dirty) {
      const res = await showModal({
        title: 'Discard unsaved changes?',
        icon: 'alert',
        tone: 'warn',
        width: 400,
        body: `<p><strong>${escapeHTML(path ? basename(path) : 'Untitled')}</strong> has changes that have not been saved.</p>`,
        actions: [
          { label: 'Cancel', value: null },
          { label: 'Save First', value: 'save' },
          { label: 'Discard', value: 'discard', danger: true },
        ],
      });
      if (res === 'save') { if (!(await saveFile())) return; }
      else if (res !== 'discard') return;
    }
    path = null;
    savedContent = '';
    setContent('');
    setLanguage('plain');
    markDirty();
    updateTitle();
    textarea.focus();
  }

  async function openFile() {
    if (dirty) {
      const res = await showModal({
        title: 'Save changes first?',
        icon: 'alert',
        tone: 'warn',
        width: 400,
        body: `<p>Open another file and lose the changes to <strong>${escapeHTML(path ? basename(path) : 'Untitled')}</strong>?</p>`,
        actions: [
          { label: 'Cancel', value: null },
          { label: 'Save First', value: 'save' },
          { label: 'Open Anyway', value: 'discard' },
        ],
      });
      if (res === 'save') { if (!(await saveFile())) return; }
      else if (res !== 'discard') return;
    }
    const picked = await pickFile();
    if (picked) loadFile(picked);
  }

  /* ---------------- wiring ---------------- */
  newBtn.addEventListener('click', newFile);
  openBtn.addEventListener('click', openFile);
  saveBtn.addEventListener('click', () => saveFile());
  wrapBtn.addEventListener('click', () => {
    wrap = !wrap;
    codeWrap.classList.toggle('wrap', wrap);
    wrapBtn.classList.toggle('btn-primary', wrap);
    syncScroll();
  });
  langSelect.addEventListener('change', () => setLanguage(langSelect.value));
  sizeSelect.addEventListener('change', () => {
    fontSize = Number(sizeSelect.value);
    textarea.style.fontSize = `${fontSize}px`;
    pre.style.fontSize = `${fontSize}px`;
    gutter.style.fontSize = `${Math.max(10, fontSize - 0.5)}px`;
    const lineHeight = fontSize * 1.6;
    gutterInner.querySelectorAll('div').forEach((d) => { d.style.height = `${lineHeight}px`; });
    syncScroll();
  });

  textarea.addEventListener('input', () => {
    content = textarea.value;
    markDirty();
    refreshHighlight();
    caretInfo();
  });
  textarea.addEventListener('scroll', syncScroll);
  textarea.addEventListener('click', caretInfo);
  textarea.addEventListener('keyup', caretInfo);
  textarea.addEventListener('select', caretInfo);

  textarea.addEventListener('keydown', (e) => {
    const meta = e.metaKey || e.ctrlKey;
    if (meta && e.key.toLowerCase() === 's') {
      e.preventDefault();
      saveFile({ saveAs: e.shiftKey });
      return;
    }
    if (meta && e.key.toLowerCase() === 'o') { e.preventDefault(); openFile(); return; }
    if (meta && e.key.toLowerCase() === 'n') { e.preventDefault(); newFile(); return; }
    if (e.key === 'Tab') {
      e.preventDefault();
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const value = textarea.value;
      if (start !== end && value.slice(start, end).includes('\n')) {
        const lineStart = value.lastIndexOf('\n', start - 1) + 1;
        const block = value.slice(lineStart, end);
        const shifted = e.shiftKey
          ? block.replace(/^ {1,2}/gm, '')
          : block.replace(/^/gm, '  ');
        textarea.value = value.slice(0, lineStart) + shifted + value.slice(end);
        textarea.selectionStart = lineStart;
        textarea.selectionEnd = lineStart + shifted.length;
      } else {
        textarea.value = value.slice(0, start) + '  ' + value.slice(end);
        textarea.selectionStart = textarea.selectionEnd = start + 2;
      }
      content = textarea.value;
      markDirty();
      refreshHighlight();
      caretInfo();
    }
  });

  // drag a file from Finder onto the editor
  root.addEventListener('dragover', (e) => {
    if (e.dataTransfer?.types?.includes('text/nova-path')) {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
      root.style.outline = '2px solid var(--accent)';
      root.style.outlineOffset = '-2px';
    }
  });
  root.addEventListener('dragleave', () => { root.style.outline = ''; });
  root.addEventListener('drop', (e) => {
    const dropped = e.dataTransfer?.getData('text/nova-path');
    root.style.outline = '';
    if (!dropped) return;
    e.preventDefault();
    if (dirty) {
      showModal({
        title: 'Open this file?',
        icon: 'alert',
        tone: 'warn',
        width: 380,
        body: '<p>Unsaved changes will be lost.</p>',
        actions: [{ label: 'Cancel', value: null }, { label: 'Open', value: 'ok', primary: true }],
      }).then((res) => { if (res === 'ok') loadFile(dropped); });
    } else {
      loadFile(dropped);
    }
  });

  ctx.onBeforeClose = async () => {
    if (!dirty) return true;
    const res = await showModal({
      title: 'Save changes before closing?',
      icon: 'alert',
      tone: 'warn',
      width: 420,
      body: `<p>Your changes to <strong>${escapeHTML(path ? basename(path) : 'Untitled')}</strong> will be lost if you close without saving.</p>`,
      actions: [
        { label: 'Cancel', value: null },
        { label: "Don't Save", value: 'discard' },
        { label: 'Save', value: 'save', primary: true },
      ],
    });
    if (res === 'discard') return true;
    if (res === 'save') return saveFile();
    return false;
  };

  ctx.onParams = (params) => {
    if (params?.path) loadFile(params.path);
  };

  const unsubs = [];
  unsubs.push(on('fs:change', ({ path: changed }) => {
    if (!path || changed !== path) return;
    if (!fs.exists(path)) return;
    if (dirty) return;
    try {
      const next = fs.readFile(path);
      if (next !== content) {
        savedContent = next;
        setContent(next);
      }
    } catch { /* ignore */ }
  }));

  /* ---------------- boot ---------------- */
  if (ctx.params?.path) {
    loadFile(ctx.params.path);
  } else {
    setContent('');
    setLanguage('plain');
    updateTitle();
    // Place the caret in the document on first paint
    setTimeout(() => textarea.focus(), 40);
  }
  if (ctx.params?.content) setContent(String(ctx.params.content));

  return {
    save: () => saveFile(),
    saveAs: () => saveFile({ saveAs: true }),
    open: openFile,
    newFile,
    getContent: () => content,
    setContent: (text) => setContent(String(text)),
    getPath: () => path,
    isDirty: () => dirty,
    dispose() {
      unsubs.forEach((fn) => fn());
      refreshHighlight.cancel?.();
    },
  };
}

/* ------------------------------------------------------------ */

export function menus(win) {
  const api = win.api || {};
  return {
    File: [
      { label: 'New', shortcut: '⌘N', icon: 'file-plus', action: () => api.newFile?.() },
      { label: 'Open…', shortcut: '⌘O', icon: 'folder-open', action: () => api.open?.() },
      { separator: true },
      { label: 'Save', shortcut: '⌘S', icon: 'save', action: () => api.save?.() },
      { label: 'Save As…', shortcut: '⇧⌘S', icon: 'save', action: () => api.saveAs?.() },
      { separator: true },
      { label: 'Close Window', shortcut: '⌘W', action: () => win.ctx.close() },
    ],
    Edit: [
      { label: 'Undo', shortcut: '⌘Z', action: () => document.execCommand('undo') },
      { label: 'Redo', shortcut: '⇧⌘Z', action: () => document.execCommand('redo') },
      { separator: true },
      { label: 'Cut', shortcut: '⌘X', action: () => document.execCommand('cut') },
      { label: 'Copy', shortcut: '⌘C', action: () => document.execCommand('copy') },
      { label: 'Paste', shortcut: '⌘V', action: () => document.execCommand('paste') },
      { separator: true },
      { label: 'Select All', shortcut: '⌘A', action: () => document.execCommand('selectAll') },
    ],
    View: [
      { label: 'Bigger Text', action: () => bumpFont(win, 1) },
      { label: 'Smaller Text', action: () => bumpFont(win, -1) },
      { label: 'Toggle Word Wrap', action: () => win.el.querySelector('.editor-toolbar .btn[title="Toggle word wrap"]')?.click() },
    ],
  };
}

function bumpFont(win, delta) {
  const select = win.el.querySelector('.editor-toolbar select[title="Font size"]');
  if (!select) return;
  const options = Array.from(select.options).map((o) => Number(o.value));
  const current = Number(select.value);
  const idx = options.indexOf(current);
  const next = options[Math.max(0, Math.min(options.length - 1, idx + delta))];
  select.value = String(next);
  select.dispatchEvent(new Event('change'));
}
