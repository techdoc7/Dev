/* ============================================================
   Nova OS — Files (list-first file manager)
   ============================================================ */

import { createFileBrowser, menus as finderMenus } from './finder.js';
import { HOME } from '../core/fs.js';

export const meta = {
  id: 'files',
  name: 'Files',
  icon: 'files',
  category: 'Utilities',
  description: 'A compact list view of your virtual disk, volumes and system folders.',
  defaultSize: { w: 880, h: 560 },
  minSize: { w: 540, h: 340 },
  singleton: false,
};

export function mount(body, ctx) {
  return createFileBrowser(body, ctx, {
    start: ctx.params?.path || '/',
    variant: 'files',
    defaultView: 'list',
    title: 'Files',
  });
}

export function menus(win) {
  const base = finderMenus(win);
  return {
    File: [
      { label: 'New Files Window', shortcut: '⌘N', icon: 'files', action: () => window.OS?.openApp('files') },
      { label: 'New Folder', shortcut: '⇧⌘N', icon: 'folder-plus', action: () => win.api?.newFolder() },
      { separator: true },
      { label: 'Open', shortcut: '⌘O', action: () => win.api?.openSelected() },
      { label: 'Rename…', icon: 'pencil', action: () => win.api?.renameSelected() },
      { label: 'Move to Trash', icon: 'trash', danger: true, action: () => win.api?.deleteSelected() },
      { separator: true },
      { label: 'Close Window', shortcut: '⌘W', action: () => win.ctx.close() },
    ],
    Edit: base.Edit,
    View: [
      { label: 'As Icons', shortcut: '⌘1', action: () => win.api?.setView('grid') },
      { label: 'As List', shortcut: '⌘2', checked: true, action: () => win.api?.setView('list') },
      { separator: true },
      { label: 'Show Preview', action: () => win.api?.togglePreview() },
    ],
    Go: [
      { label: 'Computer', shortcut: '⇧⌘C', action: () => win.api?.navigate('/') },
      { label: 'Home', shortcut: '⇧⌘H', action: () => win.api?.navigate(HOME) },
      { separator: true },
      { label: 'Applications', action: () => win.api?.navigate('/Applications') },
      { label: 'System', action: () => win.api?.navigate('/System') },
    ],
  };
}
