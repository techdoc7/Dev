/* ============================================================
   Nova OS — Finder (and the shared file browser used by Files)
   ============================================================ */

import { h, clamp, debounce, basename, dirname, extname, formatBytes, formatDate, isEditable, escapeHTML } from '../core/util.js';
import { icon, appIcon } from '../core/icons.js';
import { fs, HOME, WORKSPACE, APPLICATIONS, editorFor } from '../core/fs.js';
import { on, emit } from '../core/bus.js';
import { showMenu, confirmDialog, promptDialog, showModal, toast, emptyState, copyToClipboard } from '../core/ui.js';
import { get } from '../core/state.js';
import sounds from '../core/sound.js';

export const meta = {
  id: 'finder',
  name: 'Finder',
  icon: 'finder',
  category: 'System',
  description: 'Browse the virtual filesystem, preview files and organize folders.',
  defaultSize: { w: 960, h: 620 },
  minSize: { w: 600, h: 380 },
  singleton: false,
};

const prefs = { view: 'grid', preview: false, sort: 'name' };

function fileGlyph(item) {
  if (item.type === 'dir') {
    return `<span class="folder-tile"><span class="folder-shape"></span>${icon('folder')}</span>`;
  }
  const ext = extname(item.name);
  let glyph = 'file';
  if (['js', 'mjs', 'ts', 'json', 'css', 'html', 'sh'].includes(ext)) glyph = 'file-code';
  else if (['md', 'txt', 'csv', 'log'].includes(ext)) glyph = 'file-text';
  else if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'].includes(ext)) glyph = 'image';
  return `<span class="file-glyph type-${ext || 'txt'}">${icon(glyph)}</span>`;
}

function rowIcon(item) {
  if (item.type === 'app') return `<span class="fr-icon app">${icon('bag')}</span>`;
  if (item.type === 'dir') return `<span class="fr-icon">${icon('folder')}</span>`;
  return `<span class="fr-icon file">${icon('file')}</span>`;
}

function uniqueName(destDir, name, isDir = false) {
  const ext = isDir ? '' : (name.includes('.') ? '.' + name.split('.').pop() : '');
  const base = ext ? name.slice(0, -ext.length) : name;
  let candidate = `${destDir === '/' ? '' : destDir}/${name}`;
  let n = 2;
  while (fs.exists(candidate)) {
    candidate = `${destDir === '/' ? '' : destDir}/${base} ${n}${ext}`;
    n++;
    if (n > 99) break;
  }
  return candidate;
}

export function createFileBrowser(host, ctx, options = {}) {
  const opts = {
    start: HOME,
    variant: 'finder',
    defaultView: prefs.view,
    sidebar: 'full',
    title: 'Finder',
    ...options,
  };

  let cwd = fs.exists(opts.start) ? opts.start : HOME;
  let view = opts.defaultView;
  let sort = prefs.sort;
  let selected = null;
  let showPreview = prefs.preview;
  let query = '';
  let backStack = [];
  let forwardStack = [];
  let clipboard = null;
  let items = [];

  host.innerHTML = '';
  const root = h('div', { class: 'app finder' });
  root.tabIndex = 0;
  host.append(root);

  /* ---------------- Sidebar ---------------- */
  const sidebar = h('aside', { class: 'app-sidebar sidebar' });
  const sidebarScroll = h('div', { class: 'sidebar-scroll' });
  const sidebarFooter = h('div', { class: 'sidebar-footer' });

  const favorites = [
    { label: 'Home', path: HOME, icon: 'home' },
    { label: 'Desktop', path: `${HOME}/Desktop`, icon: 'monitor' },
    { label: 'Documents', path: `${HOME}/Documents`, icon: 'file-text' },
    { label: 'Downloads', path: `${HOME}/Downloads`, icon: 'download' },
    { label: 'Projects', path: `${HOME}/Projects`, icon: 'code' },
    { label: 'Workspace', path: WORKSPACE, icon: 'terminal', hint: 'working directory' },
    { label: 'Pictures', path: `${HOME}/Pictures`, icon: 'image' },
    { label: 'Music', path: `${HOME}/Music`, icon: 'music' },
  ];
  const locations = [
    { label: 'Nova SSD', path: '/', icon: 'hard-drive' },
    { label: 'Applications', path: APPLICATIONS, icon: 'layout' },
  ];

  function renderSidebar() {
    sidebarScroll.replaceChildren();
    const addSection = (label, list) => {
      sidebarScroll.append(h('div', { class: 'sidebar-label', text: label }));
      for (const item of list) {
        if (!fs.exists(item.path)) continue;
        const btn = h('button', {
          class: `sidebar-item${cwd === item.path ? ' active' : ''}`,
          title: item.hint || item.path,
        });
        btn.append(h('span', { html: icon(item.icon), style: { display: 'contents' } }));
        btn.append(h('span', { class: 'si-text', text: item.label }));
        btn.addEventListener('click', () => navigate(item.path));
        makeDropTarget(btn, item.path);
        sidebarScroll.append(btn);
      }
    };
    addSection('Favorites', favorites);
    addSection('Locations', locations);
    if (opts.variant === 'files') {
      addSection('This Computer', [
        { label: 'Users', path: '/Users', icon: 'user' },
        { label: 'System', path: '/System', icon: 'shield' },
      ]);
    }
    sidebarScroll.append(h('div', { style: { height: '10px' } }));
  }

  function renderFooter() {
    const used = fs.sizeOf('/');
    const capacity = 512 * 1024 * 1024;
    const pct = clamp((used / capacity) * 100, 1, 100);
    sidebarFooter.replaceChildren(
      h('div', { style: { display: 'flex', justifyContent: 'space-between' } },
        h('span', { text: 'Nova SSD' }),
        h('span', { text: `${formatBytes(used)} used` }),
      ),
      h('div', { class: 'storage-bar' }, h('span', { style: { width: `${pct}%` } })),
      h('div', { text: 'Virtual disk · stored in this browser' }),
    );
  }

  /* ---------------- Toolbar ---------------- */
  const backBtn = h('button', { class: 'icon-btn', title: 'Back', 'aria-label': 'Back', html: icon('chevron-left') });
  const forwardBtn = h('button', { class: 'icon-btn', title: 'Forward', 'aria-label': 'Forward', html: icon('chevron-right') });
  const titleEl = h('div', { class: 'toolbar-title' });
  const viewSeg = h('div', { class: 'segmented' });
  const gridBtn = h('button', { class: 'active', title: 'As Icons', 'aria-label': 'Icon view', html: icon('grid') });
  const listBtn = h('button', { title: 'As List', 'aria-label': 'List view', html: icon('list') });
  viewSeg.append(gridBtn, listBtn);

  const newFolderBtn = h('button', { class: 'icon-btn', title: 'New Folder', 'aria-label': 'New folder', html: icon('folder-plus') });
  const previewBtn = h('button', { class: 'icon-btn', title: 'Show Preview', 'aria-label': 'Toggle preview', html: icon('sidebar') });
  const searchInput = h('input', { type: 'search', placeholder: 'Search', spellcheck: 'false', 'aria-label': 'Search files' });
  const searchBox = h('div', { class: 'search-field' }, h('span', { html: icon('search') }), searchInput);
  const toolbar = h('div', { class: 'toolbar' },
    h('div', { class: 'nav-btns' }, backBtn, forwardBtn),
    titleEl,
    h('div', { class: 'toolbar-spacer' }),
    viewSeg,
    newFolderBtn,
    previewBtn,
    searchBox,
  );

  /* ---------------- Content ---------------- */
  const gridEl = h('div', { class: 'file-grid', role: 'list' });
  const listEl = h('div', { class: 'file-list', role: 'list' });
  const browser = h('div', { class: 'finder-browser' });
  const previewEl = h('aside', { class: 'finder-preview' });
  const content = h('div', { class: 'finder-content' }, browser, previewEl);

  const pathbar = h('div', { class: 'pathbar' });
  const statusLeft = h('div', { style: { display: 'flex', alignItems: 'center', gap: '9px', minWidth: '0' } });
  const statusRight = h('div', { style: { marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '10px' } });
  const statusbar = h('div', { class: 'statusbar' }, statusLeft, statusRight);

  const pane = h('div', { class: 'pane' }, toolbar, content, pathbar, statusbar);
  sidebar.append(sidebarScroll, sidebarFooter);
  root.append(sidebar, pane);

  /* ---------------- Navigation ---------------- */
  function navigate(path, { push = true, keepSelection = false } = {}) {
    try {
      const full = fs.normalize(path);
      const stat = fs.stat(full);
      if (stat.type !== 'dir') return;
      if (push && full !== cwd) {
        backStack.push(cwd);
        forwardStack = [];
      }
      cwd = full;
      query = '';
      searchInput.value = '';
      if (!keepSelection) selected = null;
      render();
      sounds.click();
    } catch (err) {
      toast({ title: 'Cannot open folder', text: err.message, icon: 'alert' });
    }
  }

  function goBack() {
    if (!backStack.length) return;
    forwardStack.push(cwd);
    cwd = backStack.pop();
    selected = null;
    render();
  }
  function goForward() {
    if (!forwardStack.length) return;
    backStack.push(cwd);
    cwd = forwardStack.pop();
    selected = null;
    render();
  }

  backBtn.addEventListener('click', goBack);
  forwardBtn.addEventListener('click', goForward);

  /* ---------------- Rendering ---------------- */
  function currentItems() {
    if (query) return fs.search(query, cwd);
    return fs.list(cwd);
  }

  function sortItems(list) {
    const sorted = list.slice();
    sorted.sort((a, b) => {
      if (query) return 0;
      const ad = a.type === 'dir';
      const bd = b.type === 'dir';
      if (ad !== bd) return ad ? -1 : 1;
      if (sort === 'modified') return b.modified - a.modified;
      if (sort === 'size') return b.size - a.size;
      return a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' });
    });
    return sorted;
  }

  function render() {
    items = sortItems(currentItems());
    const stat = fs.stat(cwd);
    const name = cwd === '/' ? 'Nova SSD' : basename(cwd);
    titleEl.textContent = query ? `Searching “${query}”` : (opts.variant === 'files' && cwd === '/' ? 'Files' : name);
    titleEl.title = cwd;

    backBtn.disabled = !backStack.length;
    forwardBtn.disabled = !forwardStack.length;
    gridBtn.classList.toggle('active', view === 'grid');
    listBtn.classList.toggle('active', view === 'list');
    previewBtn.classList.toggle('active', showPreview);

    gridEl.hidden = view !== 'grid';
    listEl.hidden = view !== 'list';
    browser.replaceChildren(view === 'grid' ? gridEl : listEl);

    if (view === 'grid') renderGrid();
    else renderList();

    renderBreadcrumb();
    renderSelection();
    renderStatus();
    renderSidebar();
    renderFooter();
    if (showPreview) renderPreview();
    else previewEl.remove();
    if (query) searchInput.focus();
  }

  function iconMarkup(item) {
    if (item.type === 'app') return appIcon(item.appId);
    if (item.type === 'dir') {
      return `<span class="folder-tile"><span class="folder-shape"></span>${icon('folder')}</span>`;
    }
    return fileGlyph(item);
  }

  function makeDrag(item) {
    return (e) => {
      if (!e.dataTransfer) return;
      e.dataTransfer.setData('text/nova-path', item.path);
      e.dataTransfer.setData('text/plain', item.path);
      e.dataTransfer.effectAllowed = 'copyMove';
      e.currentTarget.classList.add('dragging');
    };
  }

  function renderGrid() {
    gridEl.replaceChildren();
    if (!items.length) {
      gridEl.append(searchEmptyState());
      return;
    }
    for (const item of items) {
      const tile = h('div', {
        class: `file-tile${selected === item.path ? ' selected' : ''}`,
        draggable: 'true',
        role: 'listitem',
        tabindex: '-1',
        title: item.name,
      });
      tile.dataset.path = item.path;
      const iconWrap = h('div', { class: 'ft-icon', html: iconMarkup(item) });
      const label = h('div', { class: 'ft-name', text: item.name });
      tile.append(iconWrap, label);
      tile.addEventListener('pointerdown', (e) => { root.focus({ preventScroll: true }); });
      tile.addEventListener('click', (e) => {
        e.stopPropagation();
        if (e.metaKey || e.ctrlKey) {
          selected = selected === item.path ? null : item.path;
        } else {
          selected = item.path;
        }
        renderSelection();
        if (showPreview) renderPreview();
      });
      tile.addEventListener('dblclick', (e) => { e.stopPropagation(); openItem(item); });
      tile.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (selected !== item.path) { selected = item.path; renderSelection(); if (showPreview) renderPreview(); }
        itemMenu(e.clientX, e.clientY, item);
      });
      tile.addEventListener('dragstart', makeDrag(item));
      tile.addEventListener('dragend', (e) => e.currentTarget.classList.remove('dragging'));
      if (item.type === 'dir') makeDropTarget(tile, item.path);
      gridEl.append(tile);
    }
  }

  function renderList() {
    const head = h('div', { class: 'file-list-head' },
      h('div', { onclick: () => setSort('name') }, 'Name', sort === 'name' ? h('span', { class: 'sort-arrow', text: '▲' }) : null),
      h('div', { onclick: () => setSort('modified') }, 'Date Modified', sort === 'modified' ? h('span', { class: 'sort-arrow', text: '▲' }) : null),
      h('div', { onclick: () => setSort('size') }, 'Size', sort === 'size' ? h('span', { class: 'sort-arrow', text: '▲' }) : null),
      h('div', {}, 'Kind'),
    );
    listEl.replaceChildren(head);
    if (!items.length) {
      listEl.append(searchEmptyState());
      return;
    }
    for (const item of items) {
      const row = h('div', {
        class: `file-row${selected === item.path ? ' selected' : ''}`,
        draggable: 'true',
        role: 'listitem',
      });
      row.dataset.path = item.path;
      row.append(
        h('div', { class: 'fr-name' }, h('span', { html: rowIcon(item), style: { display: 'contents' } }), h('span', { text: item.name })),
        h('div', { class: 'fr-col', text: formatDate(item.modified, { short: true }) }),
        h('div', { class: 'fr-col', text: item.type === 'dir' ? '—' : formatBytes(item.size) }),
        h('div', { class: 'fr-col', text: item.kind }),
      );
      row.addEventListener('pointerdown', () => root.focus({ preventScroll: true }));
      row.addEventListener('click', (e) => {
        e.stopPropagation();
        if (e.metaKey || e.ctrlKey) selected = selected === item.path ? null : item.path;
        else selected = item.path;
        renderSelection();
        if (showPreview) renderPreview();
      });
      row.addEventListener('dblclick', (e) => { e.stopPropagation(); openItem(item); });
      row.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (selected !== item.path) { selected = item.path; renderSelection(); if (showPreview) renderPreview(); }
        itemMenu(e.clientX, e.clientY, item);
      });
      row.addEventListener('dragstart', makeDrag(item));
      row.addEventListener('dragend', (e) => e.currentTarget.classList.remove('dragging'));
      if (item.type === 'dir') makeDropTarget(row, item.path);
      listEl.append(row);
    }
  }

  function searchEmptyState() {
    const node = query
      ? emptyState('search', 'No results', `Nothing matched “${query}” in this folder.`)
      : emptyState('folder', 'Folder is empty', 'Create a folder or save a file here to get started.');
    node.style.gridColumn = '1 / -1';
    return node;
  }

  function renderSelection() {
    if (view === 'grid') {
      gridEl.querySelectorAll('.file-tile').forEach((tile) => tile.classList.toggle('selected', tile.dataset.path === selected));
    } else {
      listEl.querySelectorAll('.file-row').forEach((row) => row.classList.toggle('selected', row.dataset.path === selected));
    }
  }

  function renderStatus() {
    const total = items.length;
    const folders = items.filter((i) => i.type === 'dir').length;
    statusLeft.replaceChildren(
      h('span', { text: `${total} item${total === 1 ? '' : 's'}${folderCountLabel(folders)}` }),
      h('span', { class: 'dot-sep' }),
      h('span', { text: selected ? basename(selected) : 'Virtual disk' }),
    );
    statusRight.replaceChildren(
      h('span', { text: 'Stored in your browser' }),
      h('span', { class: 'dot-sep' }),
      h('span', { text: `${formatBytes(fs.sizeOf(cwd))}` }),
    );
  }

  function folderCountLabel(n) {
    return n ? ` · ${n} folder${n === 1 ? '' : 's'}` : '';
  }

  function renderBreadcrumb() {
    pathbar.replaceChildren();
    const parts = cwd.split('/').filter(Boolean);
    const rootBtn = h('button', { class: `path-seg${parts.length === 0 ? ' current' : ''}`, title: 'Nova SSD' });
    rootBtn.append(h('span', { html: icon('hard-drive') }), h('span', { text: 'Nova SSD' }));
    rootBtn.addEventListener('click', () => navigate('/'));
    pathbar.append(rootBtn);
    let acc = '';
    parts.forEach((part, i) => {
      acc += '/' + part;
      const segPath = acc;
      pathbar.append(h('span', { class: 'path-arrow', text: '›' }));
      const seg = h('button', {
        class: `path-seg${i === parts.length - 1 ? ' current' : ''}`,
        text: part,
        title: segPath,
      });
      seg.addEventListener('click', () => navigate(segPath));
      makeDropTarget(seg, segPath);
      pathbar.append(seg);
    });
  }

  function renderPreview() {
    if (!showPreview) { previewEl.remove(); return; }
    if (!content.contains(previewEl)) content.append(previewEl);
    previewEl.replaceChildren();
    const item = selected && items.find((i) => i.path === selected);
    if (!item) {
      previewEl.append(emptyState('eye', 'Nothing selected', 'Select a file to see its details here.'));
      return;
    }
    const head = h('div', { class: 'preview-head' });
    if (item.type === 'app') head.append(h('div', { html: appIcon(item.appId, 'lg') }));
    else if (item.type === 'dir') head.append(h('div', { class: 'pv-glyph', html: icon('folder') }));
    else head.append(h('div', { class: 'pv-glyph', html: icon(extname(item.name) ? 'file-text' : 'file') }));
    head.append(
      h('div', { class: 'pv-name', text: item.name }),
      h('div', { class: 'pv-kind', text: item.kind }),
    );
    const body = h('div', { class: 'preview-body' });
    body.append(
      pvRow('Size', item.type === 'dir' ? `${items.filter((i) => i.path.startsWith(item.path + '/')).length} items` : formatBytes(item.size)),
      pvRow('Created', formatDate(item.created)),
      pvRow('Modified', formatDate(item.modified)),
      pvRow('Where', dirname(item.path)),
      pvRow('Kind', item.kind),
    );
    if (item.type === 'file' && item.size < 40000) {
      try {
        const text = fs.readFile(item.path);
        if (text && /\.(md|txt|js|mjs|ts|json|css|html|csv|log|sh|yml|yaml)$/i.test(item.name)) {
          body.append(h('div', { class: 'pv-text', text: text.slice(0, 1400) }));
        }
      } catch { /* ignore */ }
    }
    const actions = h('div', { class: 'preview-actions' });
    const openBtn = h('button', { class: 'btn btn-primary', text: 'Open' });
    openBtn.addEventListener('click', () => openItem(item));
    const revealBtn = h('button', { class: 'btn', text: 'Rename' });
    revealBtn.addEventListener('click', () => renameSelected());
    actions.append(openBtn, revealBtn);
    previewEl.append(head, body, actions);
  }

  function pvRow(k, v) {
    return h('div', { class: 'pv-row' }, h('span', { class: 'k', text: k }), h('span', { class: 'v', text: v }));
  }

  /* ---------------- Actions ---------------- */
  function openItem(item) {
    if (!item) return;
    if (item.type === 'dir') { navigate(item.path); return; }
    if (item.type === 'app') {
      window.OS?.openApp(item.appId, {}, { source: 'finder' });
      return;
    }
    if (editorFor(item.path)) {
      window.OS?.openApp('editor', { path: item.path });
    } else {
      quickLook(item);
    }
  }

  function quickLook(item) {
    let content = '';
    try { content = fs.readFile(item.path); } catch { content = ''; }
    showModal({
      title: item.name,
      icon: 'file-text',
      width: 560,
      body: `<p class="muted">${escapeHTML(item.kind)} · ${formatBytes(item.size)}</p><pre style="max-height:56vh;overflow:auto;background:var(--field);padding:12px;border-radius:8px;font-family:var(--font-mono);font-size:11px;white-space:pre-wrap;word-break:break-word">${escapeHTML(content.slice(0, 8000))}</pre>`,
      actions: [{ label: 'Open in Editor', value: 'edit' }, { label: 'Close', value: null, primary: true }],
    }).then((res) => {
      if (res === 'edit') window.OS?.openApp('editor', { path: item.path });
    });
  }

  function openSelected() {
    if (!selected) return;
    const item = items.find((i) => i.path === selected);
    if (item) openItem(item);
  }

  async function newFolder() {
    const name = await promptDialog({
      title: 'New Folder',
      message: `Create a folder in <strong>${escapeHTML(cwd)}</strong>.`,
      label: 'Name',
      value: 'untitled folder',
      confirmLabel: 'Create',
      validate: (v) => {
        if (!v.trim()) return 'Please enter a name.';
        if (!v.trim().length) return 'Please enter a name.';
        if (/[\\/]/.test(v)) return 'Names cannot contain slashes.';
        if (fs.exists(`${cwd === '/' ? '' : cwd}/${v.trim()}`)) return 'An item with that name already exists.';
        return null;
      },
    });
    if (name === null) return;
    try {
      const folder = fs.mkdir(`${cwd === '/' ? '' : cwd}/${name}`);
      selected = folder.path;
      toast({ title: 'Folder created', text: name, icon: 'folder-plus' });
      sounds.success();
      render();
    } catch (err) {
      toast({ title: 'Could not create folder', text: err.message, icon: 'alert' });
    }
  }

  async function renameSelected() {
    if (!selected) return;
    const item = items.find((i) => i.path === selected);
    if (!item) return;
    if (item.readonly) {
      toast({ title: 'Read-only item', text: 'This item belongs to the system and cannot be renamed.', icon: 'lock' });
      return;
    }
    const next = await promptDialog({
      title: 'Rename',
      message: `Rename <strong>${escapeHTML(item.name)}</strong>.`,
      label: 'New name',
      value: item.name,
      confirmLabel: 'Rename',
      validate: (v) => {
        if (!v.trim()) return 'Please enter a name.';
        if (/[\\/]/.test(v)) return 'Names cannot contain slashes.';
        const target = `${dirname(item.path) === '/' ? '' : dirname(item.path)}/${v.trim()}`;
        if (target !== item.path && fs.exists(target)) return 'An item with that name already exists.';
        return null;
      },
    });
    if (next === null || next === item.name) return;
    try {
      const res = fs.rename(item.path, next);
      selected = res.path;
      toast({ title: 'Renamed', text: `${item.name} → ${next}`, icon: 'pencil' });
      render();
    } catch (err) {
      toast({ title: 'Could not rename', text: err.message, icon: 'alert' });
    }
  }

  async function deleteSelected() {
    if (!selected) return;
    const item = items.find((i) => i.path === selected);
    if (!item) return;
    const ok = await confirmDialog({
      title: `Delete “${item.name}”?`,
      message: item.type === 'dir'
        ? 'This folder and everything inside it will be permanently removed from the virtual filesystem.'
        : 'This file will be permanently removed from the virtual filesystem.',
      confirmLabel: 'Delete',
      danger: true,
      iconName: 'trash',
    });
    if (!ok) return;
    try {
      fs.remove(item.path);
      selected = null;
      toast({ title: 'Moved to Trash', text: item.name, icon: 'trash' });
      sounds.close();
      render();
    } catch (err) {
      toast({ title: 'Could not delete', text: err.message, icon: 'alert' });
    }
  }

  function copySelected() {
    if (!selected) return;
    clipboard = selected;
    toast({ title: 'Copied', text: basename(selected), icon: 'copy' });
  }

  function paste() {
    if (!clipboard) return;
    const src = clipboard;
    if (!fs.exists(src)) { clipboard = null; return; }
    try {
      const dest = uniqueName(cwd, basename(src), fs.isDir(src));
      fs.copy(src, dest);
      selected = dest;
      toast({ title: 'Pasted', text: basename(dest), icon: 'clipboard' });
      sounds.success();
      render();
    } catch (err) {
      toast({ title: 'Could not paste', text: err.message, icon: 'alert' });
    }
  }

  function setSort(next) {
    sort = next;
    prefs.sort = next;
    render();
  }

  function setView(next) {
    view = next;
    prefs.view = next;
    render();
  }

  function togglePreview() {
    showPreview = !showPreview;
    prefs.preview = showPreview;
    render();
  }

  function duplicateSelected() {
    if (!selected) return;
    try {
      const dest = uniqueName(cwd, basename(selected), fs.isDir(selected));
      fs.copy(selected, dest);
      selected = dest;
      render();
      toast({ title: 'Duplicated', text: basename(dest), icon: 'copy' });
    } catch (err) {
      toast({ title: 'Could not duplicate', text: err.message, icon: 'alert' });
    }
  }

  function getInfo() {
    if (!selected) return;
    const item = items.find((i) => i.path === selected);
    if (!item) return;
    showModal({
      title: item.name,
      icon: item.type === 'dir' ? 'folder' : 'file-text',
      width: 440,
      body: `
        <div style="display:flex;flex-direction:column;gap:2px">
          ${[['Kind', item.kind], ['Size', item.type === 'dir' ? '—' : formatBytes(item.size)], ['Created', formatDate(item.created)], ['Modified', formatDate(item.modified)], ['Location', dirname(item.path)], ['Virtual path', item.path], ['Permissions', item.readonly ? 'Read only' : 'Read & Write']]
            .map(([k, v]) => `<div class="pv-row"><span class="k">${k}</span><span class="v">${escapeHTML(v)}</span></div>`).join('')}
        </div>`,
      actions: [
        { label: 'Copy Path', value: 'copy' },
        { label: 'Close', value: null, primary: true },
      ],
    }).then((res) => {
      if (res === 'copy') copyToClipboard(item.path);
    });
  }

  /* ---------------- Context menu ---------------- */
  function itemMenu(x, y, item) {
    showMenu({
      x, y,
      items: [
        { label: 'Open', icon: 'external', action: () => openItem(item) },
        { label: 'Open in Text Editor', icon: 'file-code', disabled: item.type !== 'file' || !editorFor(item.path), action: () => window.OS?.openApp('editor', { path: item.path }) },
        { separator: true },
        { label: 'Copy', icon: 'copy', shortcut: '⌘C', action: copySelected },
        { label: 'Duplicate', icon: 'files', action: duplicateSelected },
        { label: 'Paste', icon: 'clipboard', shortcut: '⌘V', disabled: !clipboard, action: paste },
        { separator: true },
        { label: 'Rename…', icon: 'pencil', action: renameSelected, disabled: item.readonly },
        { label: 'Move to Trash', icon: 'trash', danger: true, shortcut: '⌘⌫', disabled: item.readonly, action: deleteSelected },
        { separator: true },
        { label: 'Get Info', icon: 'info', action: getInfo },
        { label: 'Copy Path', icon: 'clipboard-check', action: () => copyToClipboard(item.path) },
      ],
    });
  }

  function backgroundMenu(x, y) {
    showMenu({
      x, y,
      items: [
        { label: 'New Folder', icon: 'folder-plus', shortcut: '⇧⌘N', action: newFolder },
        { label: 'Paste Item', icon: 'clipboard', shortcut: '⌘V', disabled: !clipboard, action: paste },
        { separator: true },
        { label: 'View as Icons', icon: 'grid', checked: view === 'grid', action: () => setView('grid') },
        { label: 'View as List', icon: 'list', checked: view === 'list', action: () => setView('list') },
        { label: 'Show Preview', icon: 'sidebar', checked: showPreview, action: togglePreview },
        { separator: true },
        { label: 'Sort by Name', checked: sort === 'name', action: () => setSort('name') },
        { label: 'Sort by Date Modified', checked: sort === 'modified', action: () => setSort('modified') },
        { label: 'Sort by Size', checked: sort === 'size', action: () => setSort('size') },
        { separator: true },
        { label: 'Refresh', icon: 'refresh', action: render },
        { label: 'Open Terminal Here', icon: 'terminal', action: () => window.OS?.openApp('terminal', { cwd }) },
        { label: 'Get Info', icon: 'info', action: () => {
          const stat = fs.stat(cwd);
          showModal({
            title: cwd === '/' ? 'Nova SSD' : basename(cwd),
            icon: 'folder',
            body: `<div class="pv-row"><span class="k">Items</span><span class="v">${items.length}</span></div>
                   <div class="pv-row"><span class="k">Size</span><span class="v">${formatBytes(stat.size)}</span></div>
                   <div class="pv-row"><span class="k">Path</span><span class="v">${escapeHTML(cwd)}</span></div>`,
            actions: [{ label: 'Close', value: null, primary: true }],
          });
        } },
      ],
    });
  }

  function makeDropTarget(element, destDir) {
    const over = (e) => {
      if (!e.dataTransfer?.types?.includes('text/nova-path')) return;
      e.preventDefault();
      e.stopPropagation();
      e.dataTransfer.dropEffect = 'move';
      element.classList.add('drag-over');
    };
    const leave = () => element.classList.remove('drag-over');
    const drop = (e) => {
      const src = e.dataTransfer?.getData('text/nova-path');
      element.classList.remove('drag-over');
      if (!src) return;
      e.preventDefault();
      e.stopPropagation();
      if (src === destDir || destDir.startsWith(src + '/')) return;
      if (dirname(src) === destDir) return;
      try {
        const target = uniqueName(destDir, basename(src), fs.isDir(src));
        fs.move(src, target);
        selected = target;
        toast({ title: 'Moved', text: `${basename(src)} → ${destDir}`, icon: 'folder' });
        render();
      } catch (err) {
        toast({ title: 'Could not move item', text: err.message, icon: 'alert' });
      }
    };
    element.addEventListener('dragover', over);
    element.addEventListener('dragleave', leave);
    element.addEventListener('drop', drop);
  }

  /* ---------------- Events ---------------- */
  root.addEventListener('pointerdown', () => root.focus({ preventScroll: true }));
  gridEl.addEventListener('contextmenu', (e) => {
    if (e.target.closest('.file-tile')) return;
    e.preventDefault();
    selected = null;
    renderSelection();
    if (showPreview) renderPreview();
    backgroundMenu(e.clientX, e.clientY);
  });
  listEl.addEventListener('contextmenu', (e) => {
    if (e.target.closest('.file-row')) return;
    e.preventDefault();
    backgroundMenu(e.clientX, e.clientY);
  });
  pathbar.addEventListener('contextmenu', (e) => e.preventDefault());

  gridBtn.addEventListener('click', () => setView('grid'));
  listBtn.addEventListener('click', () => setView('list'));
  newFolderBtn.addEventListener('click', newFolder);
  previewBtn.addEventListener('click', togglePreview);

  const onSearch = debounce(() => {
    query = searchInput.value.trim();
    selected = null;
    render();
  }, 180);
  searchInput.addEventListener('input', onSearch);
  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { searchInput.value = ''; query = ''; render(); }
    if (e.key === 'Enter') {
      const first = items[0];
      if (first) { selected = first.path; renderSelection(); }
    }
  });

  root.addEventListener('keydown', (e) => {
    if (isEditable(e.target)) return;
    const meta = e.metaKey || e.ctrlKey;
    if (e.key === 'Delete' || (e.key === 'Backspace' && meta)) {
      e.preventDefault();
      deleteSelected();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      openSelected();
    } else if (e.key === 'F2') {
      e.preventDefault();
      renameSelected();
    } else if (meta && e.key.toLowerCase() === 'c') {
      e.preventDefault();
      copySelected();
    } else if (meta && e.key.toLowerCase() === 'v') {
      e.preventDefault();
      paste();
    } else if (meta && e.key.toLowerCase() === 'a') {
      e.preventDefault();
    } else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      const idx = items.findIndex((i) => i.path === selected);
      const next = e.key === 'ArrowDown' ? Math.min(items.length - 1, idx + 1) : Math.max(0, idx - 1);
      if (items[next]) { selected = items[next].path; renderSelection(); renderPreview(); }
    }
  });

  const unsubFS = on('fs:change', debounce(() => {
    if (!document.body.contains(root)) return;
    if (!fs.exists(cwd)) { cwd = HOME; backStack = []; forwardStack = []; }
    render();
  }, 120));

  /* ---------------- Boot ---------------- */
  render();
  if (cwd === HOME && opts.variant === 'finder') {
    // keep focus subtle; render already shows home
  }

  const api = {
    navigate,
    refresh: render,
    newFolder,
    renameSelected,
    deleteSelected,
    copySelected,
    paste,
    openSelected,
    setView,
    togglePreview,
    setSort,
    getPath: () => cwd,
    getSelection: () => selected,
    dispose() { unsubFS(); },
  };
  return api;
}

/* ---------------- Finder menus ---------------- */
export function menus(win) {
  const api = win.api || {};
  const cmd = (fn) => () => { try { fn(); } catch (err) { console.error(err); } };
  return {
    File: [
      { label: 'New Finder Window', shortcut: '⌘N', icon: 'folder', action: () => window.OS?.openApp('finder') },
      { label: 'New Folder', shortcut: '⇧⌘N', icon: 'folder-plus', action: cmd(api.newFolder) },
      { separator: true },
      { label: 'Open', shortcut: '⌘O', icon: 'external', action: cmd(api.openSelected) },
      { label: 'Rename…', icon: 'pencil', action: cmd(api.renameSelected) },
      { label: 'Move to Trash', icon: 'trash', danger: true, action: cmd(api.deleteSelected) },
      { separator: true },
      { label: 'Close Window', shortcut: '⌘W', action: () => win.ctx.close() },
    ],
    Edit: [
      { label: 'Copy', shortcut: '⌘C', action: cmd(api.copySelected) },
      { label: 'Paste', shortcut: '⌘V', action: cmd(api.paste) },
      { separator: true },
      { label: 'Select All', shortcut: '⌘A', disabled: true },
    ],
    View: [
      { label: 'As Icons', shortcut: '⌘1', checked: prefs.view === 'grid', action: () => api.setView?.('grid') },
      { label: 'As List', shortcut: '⌘2', checked: prefs.view === 'list', action: () => api.setView?.('list') },
      { separator: true },
      { label: 'Show Preview', checked: prefs.preview, action: cmd(api.togglePreview) },
      { label: 'Sort by Name', checked: prefs.sort === 'name', action: () => api.setSort?.('name') },
      { label: 'Sort by Date Modified', checked: prefs.sort === 'modified', action: () => api.setSort?.('modified') },
      { label: 'Sort by Size', checked: prefs.sort === 'size', action: () => api.setSort?.('size') },
    ],
    Go: [
      { label: 'Home', shortcut: '⇧⌘H', icon: 'home', action: () => window.OS?.openApp('finder', { path: HOME }) },
      { label: 'Desktop', action: () => api.navigate?.(`${HOME}/Desktop`) },
      { label: 'Documents', action: () => api.navigate?.(`${HOME}/Documents`) },
      { label: 'Downloads', action: () => api.navigate?.(`${HOME}/Downloads`) },
      { label: 'Projects', action: () => api.navigate?.(`${HOME}/Projects`) },
      { label: 'Workspace', icon: 'terminal', action: () => api.navigate?.(WORKSPACE) },
      { separator: true },
      { label: 'Applications', action: () => api.navigate?.(APPLICATIONS) },
      { label: 'Computer', shortcut: '⇧⌘C', action: () => api.navigate?.('/') },
    ],
  };
}

/* ---------------- Mount ---------------- */
export function mount(body, ctx) {
  const start = ctx.params?.path || HOME;
  return createFileBrowser(body, ctx, { start, variant: 'finder', defaultView: prefs.view });
}
