/* ============================================================
   Nova OS — Notes
   ============================================================ */

import { h, uid, debounce, relativeTime, escapeHTML } from '../core/util.js';
import { icon } from '../core/icons.js';
import { load, save } from '../core/storage.js';
import { showModal, confirmDialog, toast, emptyState } from '../core/ui.js';
import { on } from '../core/bus.js';
import sounds from '../core/sound.js';

export const meta = {
  id: 'notes',
  name: 'Notes',
  icon: 'notes',
  category: 'Productivity',
  description: 'Write, search and pin notes. Everything saves automatically.',
  defaultSize: { w: 820, h: 560 },
  minSize: { w: 480, h: 320 },
  singleton: true,
};

const SEED = [
  {
    id: 'note_welcome',
    title: 'Welcome to Notes',
    body: `Nova Notes saves everything automatically — there is no Save button to forget.

Try this:
• Press ⌘N / Ctrl+N for a new note
• Search from the field above the list
• Pin a note to keep it at the top

Notes are stored in your browser alongside the rest of the virtual OS.`,
    created: Date.now() - 86_400_000 * 2,
    updated: Date.now() - 86_400_000,
    pinned: true,
  },
  {
    id: 'note_ideas',
    title: 'Weekend ideas',
    body: `- Rebuild the shelf
- Finish the book on typography
- Try the new ramen place
- Sketch a poster for the release

Small things, done well.`,
    created: Date.now() - 86_400_000 * 4,
    updated: Date.now() - 3_600_000 * 5,
    pinned: false,
  },
];

let notes = load('notes.v1', SEED);
if (!Array.isArray(notes) || !notes.length) notes = JSON.parse(JSON.stringify(SEED));

const persist = debounce(() => save('notes.v1', notes), 250);

export function mount(body, ctx) {
  const root = h('div');
  body.append(root);
  root.classList.add('app', 'notes');

  let activeId = notes[0]?.id || null;
  let query = '';

  /* ---------------- list pane ---------------- */
  const searchInput = h('input', { type: 'search', placeholder: 'Search notes', spellcheck: 'false', 'aria-label': 'Search notes' });
  const newBtn = h('button', { class: 'icon-btn', title: 'New Note', 'aria-label': 'New note', html: icon('plus') });
  const toolbar = h('div', { class: 'notes-toolbar' },
    newBtn,
    h('div', { class: 'search-field' }, h('span', { html: icon('search') }), searchInput),
  );
  const listEl = h('div', { class: 'notes-list' });
  const listPane = h('div', { class: 'notes-list-pane' }, toolbar, listEl);

  /* ---------------- editor ---------------- */
  const dateEl = h('div', { class: 'nh-date' });
  const pinBtn = h('button', { class: 'icon-btn', title: 'Pin Note', 'aria-label': 'Pin note', html: icon('pin') });
  const deleteBtn = h('button', { class: 'icon-btn', title: 'Delete Note', 'aria-label': 'Delete note', html: icon('trash') });
  const titleInput = h('input', { class: 'note-title', placeholder: 'Title', spellcheck: 'false' });
  const bodyInput = h('textarea', { class: 'note-body', placeholder: 'Start writing…', spellcheck: 'true' });
  const editor = h('section', { class: 'notes-editor' },
    h('div', { class: 'note-head' }, dateEl, pinBtn, deleteBtn),
    titleInput,
    bodyInput,
  );
  const emptyEl = h('div', { class: 'note-empty' },
    h('div', { html: icon('note') }),
    h('div', { text: 'Select a note, or create a new one.' }),
    h('button', { class: 'btn btn-primary', text: 'New Note', onclick: () => newNote() }),
  );
  const editorWrap = h('div', { class: 'notes-editor', style: { display: 'none' } });

  root.append(listPane, editor, editorWrap);

  const unsub = on('notes:open', (id) => { if (id) selectNote(id); });

  function sorted() {
    return notes.slice().sort((a, b) => {
      if (!!a.pinned !== !!b.pinned) return a.pinned ? -1 : 1;
      return b.updated - a.updated;
    });
  }

  function filtered() {
    const list = sorted();
    if (!query) return list;
    const q = query.toLowerCase();
    return list.filter((n) => (n.title || '').toLowerCase().includes(q) || (n.body || '').toLowerCase().includes(q));
  }

  function renderList() {
    listEl.replaceChildren();
    const list = filtered();
    if (!list.length) {
      listEl.append(h('div', { style: { padding: '28px 16px', textAlign: 'center', color: 'var(--text-3)', fontSize: '11.5px' }, text: query ? 'No notes match your search.' : 'No notes yet.' }));
      return;
    }
    for (const note of list) {
      const item = h('div', { class: `note-item${note.id === activeId ? ' active' : ''}` });
      item.append(
        h('div', { class: 'ni-title', text: note.title || 'New Note' }),
        h('div', { class: 'ni-preview', text: (note.body || '').trim().slice(0, 120) || 'No additional text' }),
        h('div', { class: 'ni-meta' },
          note.pinned ? h('span', { class: 'pin', html: icon('pin') }) : null,
          h('span', { text: relativeTime(note.updated) }),
        ),
      );
      item.addEventListener('click', () => selectNote(note.id));
      item.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        e.stopPropagation();
        selectNote(note.id);
        showModal({
          title: note.title || 'New Note',
          icon: 'note',
          width: 380,
          body: `<p class="muted">${escapeHTML((note.body || '').slice(0, 240) || 'No additional text')}</p>`,
          actions: [
            { label: 'Delete', value: 'delete', danger: true },
            { label: note.pinned ? 'Unpin' : 'Pin', value: 'pin' },
            { label: 'Cancel', value: null, primary: true },
          ],
        }).then(async (res) => {
          if (res === 'delete') await deleteNote(note.id);
          else if (res === 'pin') togglePin(note.id);
        });
      });
      listEl.append(item);
    }
  }

  function activeNote() {
    return notes.find((n) => n.id === activeId) || null;
  }

  function selectNote(id) {
    activeId = id;
    const note = activeNote();
    if (!note) return;
    editor.style.display = 'none';
    editorWrap.style.display = 'none';
    editor.style.display = 'flex';
    titleInput.value = note.title || '';
    bodyInput.value = note.body || '';
    dateEl.textContent = `Edited ${relativeTime(note.updated)}`;
    pinBtn.classList.toggle('active', !!note.pinned);
    pinBtn.title = note.pinned ? 'Unpin Note' : 'Pin Note';
    renderList();
    updatePlaceholder();
  }

  function updatePlaceholder() {
    const note = activeNote();
    if (!note) return;
    editorWrap.replaceChildren();
  }

  function renderEmpty() {
    editor.style.display = 'none';
    editorWrap.style.display = 'block';
    editorWrap.replaceChildren(emptyEl);
  }

  function newNote() {
    const note = {
      id: uid('note'),
      title: '',
      body: '',
      created: Date.now(),
      updated: Date.now(),
      pinned: false,
    };
    notes.unshift(note);
    activeId = note.id;
    persist();
    selectNote(note.id);
    requestAnimationFrame(() => titleInput.focus());
    sounds.click();
  }

  function removeNote(id) {
    const note = notes.find((n) => n.id === id);
    if (!note) return false;
    notes = notes.filter((n) => n.id !== id);
    persist();
    if (activeId === id) {
      activeId = filtered()[0]?.id || null;
      if (activeId) selectNote(activeId);
      else renderEmpty();
    }
    renderList();
    return true;
  }

  async function deleteNote(id = activeId) {
    const note = notes.find((n) => n.id === id);
    if (!note) return;
    const ok = await confirmDialog({
      title: 'Delete this note?',
      message: `“${escapeHTML(note.title || 'New Note')}” will be permanently deleted.`,
      confirmLabel: 'Delete',
      danger: true,
      iconName: 'trash',
    });
    if (!ok) return;
    removeNote(id);
    toast({ title: 'Note deleted', icon: 'trash' });
    sounds.close();
  }

  function togglePin(id = activeId) {
    const note = notes.find((n) => n.id === id);
    if (!note) return;
    note.pinned = !note.pinned;
    note.updated = Date.now();
    persist();
    selectNote(activeId);
  }

  /* ---------------- editing ---------------- */
  const touch = () => {
    const note = activeNote();
    if (!note) return;
    note.title = titleInput.value;
    note.body = bodyInput.value;
    note.updated = Date.now();
    dateEl.textContent = 'Edited just now';
    persist();
    renderListSoon();
  };

  const renderListSoon = debounce(() => {
    renderList();
    dateEl.textContent = `Edited ${relativeTime(activeNote()?.updated || Date.now())}`;
  }, 400);

  titleInput.addEventListener('input', touch);
  bodyInput.addEventListener('input', touch);
  titleInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); bodyInput.focus(); }
  });

  newBtn.addEventListener('click', newNote);
  pinBtn.addEventListener('click', () => togglePin());
  deleteBtn.addEventListener('click', () => deleteNote());

  const onSearch = debounce(() => {
    query = searchInput.value.trim();
    renderList();
  }, 150);
  searchInput.addEventListener('input', onSearch);

  root.addEventListener('keydown', (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'n') {
      e.preventDefault();
      newNote();
    }
  });

  // expose notes for the automation API
  const notesApi = {
    list: () => notes.map((n) => ({ ...n })),
    create: (title = '', content = '') => {
      const note = { id: uid('note'), title, body: content, created: Date.now(), updated: Date.now(), pinned: false };
      notes.unshift(note);
      persist();
      activeId = note.id;
      selectNote(note.id);
      return note;
    },
    update: (id, patch) => {
      const note = notes.find((n) => n.id === id);
      if (!note) return null;
      Object.assign(note, patch, { updated: Date.now() });
      persist();
      if (id === activeId) selectNote(id);
      else renderList();
      return note;
    },
    remove: (id) => removeNote(id),
  };

  if (activeId && activeNote()) selectNote(activeId);
  else if (notes.length) { activeId = sorted()[0].id; selectNote(activeId); }
  else renderEmpty();
  renderList();

  return {
    newNote,
    deleteNote,
    selectNote,
    getActive: () => activeNote(),
    ...notesApi,
    dispose() { unsub(); },
  };
}

export function menus(win) {
  const api = win.api || {};
  return {
    File: [
      { label: 'New Note', shortcut: '⌘N', icon: 'plus', action: () => api.newNote?.() },
      { label: 'Delete Note', icon: 'trash', danger: true, action: () => api.deleteNote?.() },
      { separator: true },
      { label: 'Close Window', shortcut: '⌘W', action: () => win.ctx.close() },
    ],
    Edit: [
      { label: 'Undo', shortcut: '⌘Z', action: () => document.execCommand('undo') },
      { label: 'Redo', shortcut: '⇧⌘Z', action: () => document.execCommand('redo') },
      { separator: true },
      { label: 'Cut', shortcut: '⌘X', action: () => document.execCommand('cut') },
      { label: 'Copy', shortcut: '⌘C', action: () => document.execCommand('copy') },
      { label: 'Paste', shortcut: '⌘V', action: () => document.execCommand('paste') },
      { separator: true },
      { label: 'Select All', shortcut: '⌘A', action: () => document.execCommand('selectAll') },
    ],
    View: [
      { label: 'Pin Note', icon: 'pin', action: () => {
        const el = win.el.querySelector('.icon-btn[title="Pin Note"], .icon-btn[title="Unpin Note"]');
        el?.click();
      } },
      { label: 'Focus Search', icon: 'search', action: () => win.el.querySelector('.notes-toolbar input')?.focus() },
    ],
  };
}
