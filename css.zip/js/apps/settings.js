/* ============================================================
   Nova OS — System Settings
   Appearance, desktop & dock, sound, network, notifications,
   storage and system information.
   ============================================================ */

import { h, clamp, formatBytes, formatDate, formatTime, escapeHTML, getStoreStats } from '../core/util.js';
import { icon, appIcon } from '../core/icons.js';
import { get, set, getSettings, resetSettings, setTheme, setWallpaper, resolvedTheme, SYSTEM, ACCENTS, notificationsAPI } from '../core/state.js';
import { wallpapers } from '../core/wallpapers.js';
import { fs, HOME } from '../core/fs.js';
import { on } from '../core/bus.js';
import { switchControl, slider, showModal, confirmDialog, toast, emptyState, copyToClipboard } from '../core/ui.js';
import sounds from '../core/sound.js';

export const meta = {
  id: 'settings',
  name: 'Settings',
  icon: 'settings',
  category: 'System',
  description: 'Personalize Nova — appearance, dock, sound, network and storage.',
  defaultSize: { w: 860, h: 620 },
  minSize: { w: 620, h: 420 },
  singleton: true,
};

const SECTIONS = [
  { id: 'appearance', name: 'Appearance', icon: 'palette' },
  { id: 'desktop', name: 'Desktop & Dock', icon: 'monitor' },
  { id: 'displays', name: 'Displays', icon: 'brightness' },
  { id: 'sound', name: 'Sound', icon: 'volume' },
  { id: 'network', name: 'Network', icon: 'wifi' },
  { id: 'notifications', name: 'Notifications', icon: 'bell' },
  { id: 'keyboard', name: 'Keyboard', icon: 'keyboard' },
  { id: 'storage', name: 'Storage', icon: 'hard-drive' },
  { id: 'about', name: 'About', icon: 'info' },
];

/* ------------------------------------------------------------ */
/* Small building blocks                                        */
/* ------------------------------------------------------------ */

function row(label, sub, control, extra = null) {
  const labelEl = h('div', { class: 'settings-label' },
    h('b', { text: label }),
    sub ? h('span', { text: sub }) : null,
  );
  const controlEl = h('div', { class: 'settings-control' }, control, extra);
  return h('div', { class: 'setting-row' }, labelEl, controlEl);
}

function group(...rows) {
  return h('div', { class: 'card settings-group', style: { marginBottom: '14px' } }, rows.flat(3).filter(Boolean));
}

function sectionTitle(text) {
  return h('h3', { text });
}

function heading(text) {
  return h('h2', { text });
}

function note(text) {
  return h('div', { class: 'settings-note', text });
}

function bindSwitch(path, label, sub) {
  const control = switchControl(!!get(path, false), (next) => {
    set(path, next);
    if (path === 'wifi' || path === 'bluetooth' || path === 'dnd') {
      toast({ title: `${label} ${next ? 'on' : 'off'}`, icon: path === 'wifi' ? 'wifi' : path === 'bluetooth' ? 'bluetooth' : 'bell-off' });
    }
  });
  return row(label, sub, control);
}

function selectControl(options, value, onChange) {
  const select = h('select', { class: 'select', style: { width: '150px' } },
    options.map((opt) => h('option', {
      value: opt.value,
      text: opt.label,
      selected: String(opt.value) === String(value),
    })),
  );
  select.addEventListener('change', () => onChange(select.value));
  return select;
}

/* ------------------------------------------------------------ */
/* Sections                                                     */
/* ------------------------------------------------------------ */

function appearanceSection(rerender) {
  const wrap = h('div');
  wrap.append(heading('Appearance'));

  const themeCards = h('div', { class: 'theme-cards' });
  for (const t of [
    { id: 'light', label: 'Light' },
    { id: 'dark', label: 'Dark' },
    { id: 'auto', label: 'Auto' },
  ]) {
    const card = h('button', {
      class: `theme-card${get('theme') === t.id ? ' selected' : ''}`,
      'aria-label': `${t.label} appearance`,
    },
      h('div', { class: `tc-preview tc-${t.id}` }, h('div', { class: 'tc-mini' })),
      h('div', { class: 'tc-label', text: t.label }),
    );
    card.addEventListener('click', () => {
      setTheme(t.id);
      sounds.theme();
      rerender();
    });
    themeCards.append(card);
  }
  wrap.append(themeCards, note('Auto follows the operating system appearance.'));
  wrap.append(sectionTitle('Accent Color'));
  const swatches = h('div', { class: 'accent-swatches' });
  for (const accent of ACCENTS) {
    const dot = h('button', {
      class: `accent-swatch${get('accent') === accent.id ? ' selected' : ''}`,
      style: { background: accent.hex, color: accent.hex },
      title: accent.name,
      'aria-label': `${accent.name} accent`,
    });
    dot.addEventListener('click', () => {
      set('accent', accent.id);
      sounds.click();
      rerender();
    });
    swatches.append(dot);
  }
  wrap.append(swatches);

  wrap.append(sectionTitle('Wallpaper'));
  const grid = h('div', { class: 'wallpaper-grid' });
  for (const wp of wallpapers) {
    const card = h('button', {
      class: `wallpaper-card${get('wallpaper') === wp.id ? ' selected' : ''}`,
      title: wp.name,
    },
      h('div', { class: 'wp-thumb', style: { background: wp.css } }),
      h('span', { class: 'wp-name', text: wp.name }),
    );
    card.addEventListener('click', () => {
      setWallpaper(wp.id);
      rerender();
    });
    grid.append(card);
  }
  wrap.append(grid, note('Wallpapers are generated with CSS gradients, so Nova stays entirely self-contained.'));

  wrap.append(sectionTitle('Options'));
  wrap.append(group(
    row('Transparency', 'Use translucent glass for windows and menus.', switchControl(get('transparency', true), (v) => set('transparency', v))),
    row('Reduce Motion', 'Minimize window and dock animations.', switchControl(get('reduceMotion', false), (v) => set('reduceMotion', v))),
  ));
  return wrap;
}

function desktopSection(rerender) {
  const wrap = h('div');
  wrap.append(heading('Desktop & Dock'));

  wrap.append(sectionTitle('Dock'));
  const dockPos = h('div', { class: 'segmented' },
    ['bottom', 'left', 'right'].map((pos) => {
      const btn = h('button', {
        class: get('dock.position') === pos ? 'active' : '',
        text: pos[0].toUpperCase() + pos.slice(1),
        title: `${pos} of screen`,
      });
      btn.addEventListener('click', () => { set('dock.position', pos); rerender(); });
      return btn;
    }),
  );
  wrap.append(group(
    row('Position on screen', 'Place the Dock along a screen edge.', dockPos),
    row('Size', 'Scale the icons in the Dock.', slider({
      min: 38, max: 74, value: get('dock.size', 52), width: '160px',
      onInput: (v) => { document.documentElement.style.setProperty('--dock-icon', `${v}px`); },
      onChange: (v) => { set('dock.size', v); rerender(); },
    })),
    row('Magnification', 'Enlarge icons as the pointer moves across the Dock.', switchControl(get('dock.magnification', true), (v) => set('dock.magnification', v))),
    row('Automatically hide and show the Dock', 'Reveal the Dock by moving the pointer to the screen edge.', switchControl(get('dock.autohide', false), (v) => set('dock.autohide', v))),
    row('Show recent applications', 'Keep recently used apps in the Dock.', switchControl(get('dock.showRecents', true), (v) => set('dock.showRecents', v))),
  ));

  wrap.append(sectionTitle('Desktop'));
  wrap.append(group(
    row('Show items on desktop', 'Display files, folders and the volume on the desktop.', switchControl(get('desktop.showIcons', true), (v) => { set('desktop.showIcons', v); rerender(); })),
    row('Icon size', 'Adjust the size of desktop labels and icons.', slider({
      min: 42, max: 78, value: get('desktop.iconSize', 56), width: '160px',
      onInput: (v) => document.documentElement.style.setProperty('--desk-icon-size', `${v}px`),
      onChange: (v) => { set('desktop.iconSize', v); rerender(); },
    })),
    row('Sort desktop by', 'Arrange icons automatically when they change.', selectControl([
      { value: 'name', label: 'Name' },
      { value: 'kind', label: 'Kind' },
      { value: 'date', label: 'Date Modified' },
    ], get('desktop.sort', 'name'), (v) => { set('desktop.sort', v); rerender(); })),
  ));

  wrap.append(sectionTitle('Menu Bar & Clock'));
  wrap.append(group(
    row('Use a 24-hour clock', 'Show the time in 24-hour format.', switchControl(get('clock.format24', false), (v) => { set('clock.format24', v); rerender(); })),
    row('Show seconds', 'Include seconds in the menu bar clock.', switchControl(get('clock.seconds', false), (v) => { set('clock.seconds', v); rerender(); })),
    row('Show date', 'Display the weekday and date next to the time.', switchControl(get('clock.showDate', true), (v) => { set('clock.showDate', v); rerender(); })),
  ));

  const resetBtn = h('button', { class: 'btn', text: 'Reset Dock Layout' });
  resetBtn.addEventListener('click', () => {
    set('dock.items', ['finder', 'browser', 'terminal', 'settings', 'notes', 'calculator', 'calendar', 'files', 'editor', 'appstore']);
    toast({ title: 'Dock reset', text: 'The default set of apps is back.', icon: 'layout' });
    rerender();
  });
  wrap.append(h('div', { class: 'settings-actions' }, resetBtn));
  return wrap;
}

function displaysSection(rerender) {
  const wrap = h('div');
  wrap.append(heading('Displays'));
  const brightnessLabel = h('span', { text: `${get('brightness', 100)}%`, style: { width: '38px', textAlign: 'right', fontSize: '11px', color: 'var(--text-3)' } });
  wrap.append(group(
    row('Brightness', 'Dim or brighten the display.', h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px' } },
      slider({
        min: 35, max: 100, value: get('brightness', 100), width: '170px',
        onInput: (v) => {
          const overlay = document.getElementById('brightnessOverlay');
          if (overlay) overlay.style.opacity = String((100 - v) / 100 * 0.72);
          brightnessLabel.textContent = `${v}%`;
        },
        onChange: (v) => { set('brightness', v); rerender(); },
      }),
      brightnessLabel,
    )),
    row('True Tone', 'Adapt colors to the ambient light (simulated).', switchControl(true, () => toast({ title: 'Simulated display', text: 'Hardware color sensors are not exposed to the browser.', icon: 'monitor' }))),
  ));

  wrap.append(sectionTitle('Display'));
  const spec = h('div', { class: 'specs' });
  spec.append(
    h('div', { class: 'spec-row' }, h('div', { class: 'k', text: 'Resolution' }), h('div', { class: 'v', text: `${window.innerWidth} × ${window.innerHeight}` })),
    h('div', { class: 'spec-row' }, h('div', { class: 'k', text: 'Pixel density' }), h('div', { class: 'v', text: `${window.devicePixelRatio.toFixed(1)}×` })),
    h('div', { class: 'spec-row' }, h('div', { class: 'k', text: 'Color profile' }), h('div', { class: 'v', text: 'sRGB' })),
    h('div', { class: 'spec-row' }, h('div', { class: 'k', text: 'Refresh rate' }), h('div', { class: 'v', text: '60 Hz' })),
  );
  wrap.append(h('div', { class: 'card', style: { padding: '8px 14px' } }, spec));

  const themeBtn = h('button', { class: 'btn', html: `${icon(resolvedTheme() === 'dark' ? 'sun' : 'moon')} Switch to ${resolvedTheme() === 'dark' ? 'Light' : 'Dark'} Appearance`, onclick: () => { setTheme(resolvedTheme() === 'dark' ? 'light' : 'dark'); rerender(); } });
  wrap.append(h('div', { class: 'settings-actions' }, themeBtn));
  return wrap;
}

function soundSection(rerender) {
  const wrap = h('div');
  wrap.append(heading('Sound'));
  const volLabel = h('span', { text: `${get('volume', 62)}%`, style: { width: '38px', textAlign: 'right', fontSize: '11px', color: 'var(--text-3)' } });
  wrap.append(group(
    row('Output volume', 'System alerts and interface sounds.', h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px' } },
      slider({
        min: 0, max: 100, value: get('volume', 62), width: '160px',
        onInput: (v) => { volLabel.textContent = `${v}%`; },
        onChange: (v) => { set('volume', v); rerender(); },
      }),
      volLabel,
    )),
    row('Mute all sounds', 'Silence alerts and interface sounds.', switchControl(get('dnd', false), (v) => set('dnd', v))),
    row('Play user interface sound effects', 'Clicks, opening windows and notifications.', switchControl(true, (v) => toast({ title: v ? 'Interface sounds on' : 'Interface sounds off', icon: 'volume' }))),
    row('Alert sound', 'The tone used for notifications.', selectControl([
      { value: 'nova', label: 'Nova' },
      { value: 'chime', label: 'Chime' },
      { value: 'pulse', label: 'Pulse' },
      { value: 'none', label: 'None' },
    ], 'nova', () => {}), h('button', { class: 'btn', text: 'Test', style: { height: '26px' }, onclick: () => sounds.notify() })),
  ));

  wrap.append(sectionTitle('Output'));
  wrap.append(group(
    row('Nova Speakers', 'Built-in · Selected output device.', h('span', { class: 'badge accent', text: 'Default' })),
    row('Spatial audio', 'Simulated stereo widening (no hardware access).', switchControl(false, () => toast({ title: 'Simulated feature', text: 'Audio devices are not exposed to the browser.', icon: 'volume' }))),
  ));
  wrap.append(note('All interface sounds are generated with the Web Audio API. Nova never records audio.'));
  return wrap;
}

function nameEditor(label, path, current, placeholder, onDone) {
  const input = h('input', { class: 'input', value: current, placeholder, style: { width: '170px' } });
  const apply = h('button', { class: 'btn', text: 'Apply', style: { height: '26px' } });
  const commit = () => {
    const value = input.value.trim();
    if (!value) { input.focus(); return; }
    set(path, value);
    toast({ title: 'Saved', text: `${label}: ${value}`, icon: 'check' });
    onDone?.(value);
  };
  apply.addEventListener('click', commit);
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') commit(); });
  return h('div', { style: { display: 'flex', gap: '6px' } }, input, apply);
}

function networkSection(rerender) {
  const wrap = h('div');
  wrap.append(heading('Network'));
  wrap.append(group(
    bindSwitch('wifi', 'Wi-Fi', get('wifi', true) ? 'Connected to NovaNet · simulated' : 'Wi-Fi is turned off'),
    row('Network', 'The network used by the Browser app.', h('span', { text: get('wifi', true) ? 'NovaNet' : 'Off', style: { fontSize: '12px', color: 'var(--text-2)' } })),
    row('Bluetooth', 'Pair accessories (simulated).', switchControl(get('bluetooth', true), (v) => set('bluetooth', v))),
  ));

  wrap.append(sectionTitle('Device'));
  wrap.append(group(
    row('Computer name', 'The name shown on the network and in Terminal.', nameEditor('Computer name', 'computerName', get('computerName', 'Nova Studio'), 'Nova Studio')),
    row('User name', 'Shown in the Terminal prompt and lock screen.', nameEditor('User name', 'userName', get('userName', 'nova'), 'nova')),
    row('Local hostname', 'Used by the virtual shell.', h('code', { text: `${String(get('computerName', 'Nova Studio')).toLowerCase().replace(/[^a-z0-9]+/g, '-')}.local`, style: { fontSize: '11px', color: 'var(--text-3)' } })),
  ));

  wrap.append(sectionTitle('Firewall'));
  wrap.append(group(
    row('Firewall', 'Restrict incoming connections (simulated).', switchControl(true, () => toast({ title: 'Firewall is on', text: 'Nova runs in a single browser tab.', icon: 'shield' }))),
    row('Block all incoming connections', 'No external service can reach Nova.', switchControl(true, () => toast({ title: 'Already isolated', text: 'Everything runs inside this tab.', icon: 'shield' }))),
  ));
  wrap.append(note('Networking controls are part of the simulation. Nova cannot change your real Wi-Fi or Bluetooth adapter.'));
  return wrap;
}

function notificationsSection(rerender) {
  const wrap = h('div');
  wrap.append(heading('Notifications'));
  wrap.append(group(
    row('Do Not Disturb', 'Silence banners and sounds until you turn it off.', switchControl(get('dnd', false), (v) => set('dnd', v))),
    row('Show previews', 'Show the text of notifications on the lock screen.', switchControl(true, () => {})),
  ));

  wrap.append(sectionTitle('Recent Notifications'));
  const list = notificationsAPI.list();
  const wrapCard = h('div', { class: 'card', style: { padding: '4px 14px' } });
  if (!list.length) {
    const empty = emptyState('bell', 'No notifications', 'Alerts from apps will appear here.');
    empty.style.padding = '22px 0';
    wrapCard.append(empty);
  } else {
    for (const n of list.slice(0, 8)) {
      const item = h('div', { class: 'np-item', style: { display: 'flex', gap: '10px', alignItems: 'flex-start', padding: '9px 0', borderBottom: '0.5px solid var(--hairline)' } },
        h('span', { html: icon(n.icon || 'bell'), style: { color: 'var(--accent)', display: 'contents' } }),
        h('div', { style: { flex: '1', minWidth: '0' } },
          h('div', { style: { fontSize: '12px', fontWeight: '600' }, text: n.title }),
          n.text ? h('div', { style: { fontSize: '11px', color: 'var(--text-2)', marginTop: '1px' }, text: n.text }) : null,
          h('div', { style: { fontSize: '10px', color: 'var(--text-3)', marginTop: '3px' }, text: `${formatDate(n.time, { short: true })} · ${formatTime(n.time)}` }),
        ),
      );
      wrapCard.append(item);
    }
  }
  wrap.append(wrapCard);

  const clearBtn = h('button', { class: 'btn', html: `${icon('trash')} Clear All`, onclick: () => {
    notificationsAPI.clear();
    toast({ title: 'Notifications cleared', icon: 'check' });
    rerender();
  } });
  wrap.append(h('div', { class: 'settings-actions' }, clearBtn));
  return wrap;
}

const SHORTCUTS = [
  ['Spotlight', '⌘ / Ctrl + Space'],
  ['Close window', '⌘ / Ctrl + W'],
  ['Minimize window', '⌘ / Ctrl + M'],
  ['Cycle windows', '⌘ / Ctrl + `'],
  ['Settings', '⌘ / Ctrl + ,'],
  ['Lock screen', '⌃⌘Q'],
  ['New terminal session', '⌘ / Ctrl + T'],
  ['Save in editor', '⌘ / Ctrl + S'],
  ['Close menu or dialog', 'Esc'],
  ['Clear terminal', '⌃L'],
  ['Delete desktop item', '⌘ / Ctrl + ⌫'],
  ['Rename (Finder)', 'F2'],
];

function keyboardSection() {
  const wrap = h('div');
  wrap.append(heading('Keyboard'));
  wrap.append(sectionTitle('Keyboard Shortcuts'));
  const card = h('div', { class: 'card', style: { padding: '4px 14px' } });
  for (const [label, keys] of SHORTCUTS) {
    card.append(h('div', { class: 'setting-row', style: { minHeight: '38px' } },
      h('div', { class: 'settings-label' }, h('b', { text: label, style: { fontSize: '12px' } })),
      h('div', { class: 'settings-control' }, h('kbd', {
        text: keys,
        style: { fontSize: '10.5px', padding: '2px 7px', borderRadius: '5px', border: '0.5px solid var(--line)', background: 'var(--field)', color: 'var(--text-2)', fontFamily: 'var(--font-ui)' },
      })),
    ));
  }
  wrap.append(card);
  wrap.append(sectionTitle('Keyboard'));
  const repeatCard = h('div', { class: 'card', style: { padding: '0 14px' } });
  const repeatLabel = h('span', { text: 'Fast', style: { fontSize: '11px', color: 'var(--text-3)' } });
  repeatCard.append(h('div', { class: 'setting-row' },
    h('div', { class: 'settings-label' }, h('b', { text: 'Key repeat rate' }), h('span', { text: 'How quickly a held key repeats.' })),
    h('div', { class: 'settings-control' }, slider({ min: 0, max: 4, step: 1, value: 3, width: '150px', onInput: (v) => { repeatLabel.textContent = ['Off', 'Slow', 'Medium', 'Fast', 'Very fast'][v]; } }), repeatLabel),
  ));
  wrap.append(repeatCard);
  return wrap;
}

function storageSection(rerender) {
  const wrap = h('div');
  wrap.append(heading('Storage'));
  const stats = getStoreStats();
  const fsBytes = fs.sizeOf('/');
  const capacity = 512 * 1024 * 1024;

  wrap.append(sectionTitle('Nova SSD'));
  wrap.append(h('div', { class: 'card', style: { padding: '13px 14px' } },
    h('div', { style: { display: 'flex', justifyContent: 'space-between', fontSize: '11.5px', marginBottom: '8px' } },
      h('span', { text: 'Virtual disk' }),
      h('span', { style: { color: 'var(--text-3)' }, text: `${formatBytes(fsBytes)} of ${formatBytes(capacity)} used` }),
    ),
    h('div', { style: { height: '8px', borderRadius: '5px', background: 'var(--field)', overflow: 'hidden' } },
      h('span', { style: { display: 'block', height: '100%', width: `${Math.max(2, (fsBytes / capacity) * 100)}%`, background: 'var(--accent)', borderRadius: '5px' } }),
    ),
    note('Files you create in Finder, Files, Terminal and the Editor live here. They never touch your real disk.'),
  ));

  wrap.append(sectionTitle('Browser Storage'));
  const rows = [
    { name: 'Filesystem', value: fsBytes },
    { name: 'Local storage', value: stats.total },
    { name: 'Applications', value: 0 },
  ];
  const card = h('div', { class: 'card', style: { padding: '12px 14px' } });
  const storageRows = h('div', { class: 'storage-rows' });
  for (const r of rows) {
    const pct = clamp((r.value / Math.max(1, stats.total)) * 100, 0, 100);
    storageRows.append(h('div', { class: 'storage-row' },
      h('span', { class: 'sr-name', text: r.name }),
      h('div', { class: 'sr-bar' }, h('span', { style: { width: `${r.value ? Math.max(2, pct) : 0}%` } })),
      h('span', { class: 'sr-val', text: formatBytes(r.value) }),
    ));
  }
  card.append(storageRows);
  wrap.append(card);

  const copyBtn = h('button', { class: 'btn', html: `${icon('clipboard')} Copy Diagnostics`, onclick: () => {
    const diag = {
      os: `${SYSTEM.name} ${SYSTEM.version} (${SYSTEM.codename})`,
      build: SYSTEM.build,
      theme: resolvedTheme(),
      accent: get('accent'),
      wallpaper: get('wallpaper'),
      viewport: `${window.innerWidth}×${window.innerHeight}`,
      storage: stats.total,
      filesystem: fsBytes,
      files: fs.tree('/', '/', 2).length,
      time: new Date().toISOString(),
    };
    copyToClipboard(JSON.stringify(diag, null, 2), 'Diagnostics copied');
  } });
  wrap.append(h('div', { class: 'settings-actions' }, copyBtn));

  wrap.append(sectionTitle('Reset'));
  const resetFs = h('button', { class: 'btn', text: 'Reset Filesystem…' });
  resetFs.addEventListener('click', async () => {
    const ok = await confirmDialog({
      title: 'Reset the virtual filesystem?',
      message: 'Every file and folder you created will be removed and the sample files restored. This cannot be undone.',
      confirmLabel: 'Reset Files',
      danger: true,
      iconName: 'hard-drive',
    });
    if (!ok) return;
    fs.reset();
    toast({ title: 'Filesystem reset', text: 'The sample files are back.', icon: 'hard-drive' });
    rerender();
  });
  const resetAll = h('button', { class: 'btn btn-danger', text: 'Reset All Settings…' });
  resetAll.addEventListener('click', async () => {
    const ok = await confirmDialog({
      title: 'Reset all settings?',
      message: 'Appearance, dock, clock, network and notification preferences return to their defaults. Your files are kept.',
      confirmLabel: 'Reset Settings',
      danger: true,
      iconName: 'settings',
    });
    if (!ok) return;
    resetSettings();
    toast({ title: 'Settings reset', text: 'Nova is back to its defaults.', icon: 'check' });
    rerender();
  });
  wrap.append(h('div', { class: 'settings-actions' }, resetFs, resetAll));
  return wrap;
}

function aboutSection(rerender) {
  const wrap = h('div');
  const about = h('div', { class: 'settings-about' },
    h('div', { html: appIcon('settings', 'lg') }),
    h('h2', { text: SYSTEM.name }),
    h('div', { class: 'ver', text: `Version ${SYSTEM.version} · ${SYSTEM.codename}` }),
    h('div', { class: 'ver', text: `Build ${SYSTEM.build}` }),
  );
  wrap.append(about);

  const specs = h('div', { class: 'specs card', style: { padding: '6px 14px' } });
  const specRows = [
    ['Computer', get('computerName', 'Nova Studio')],
    ['User', get('fullName', 'Nova User')],
    ['Kernel', SYSTEM.kernel],
    ['Shell', 'nova-sh 1.0'],
    ['Window server', 'Nova Window Server'],
    ['Memory', '8 GB (simulated)'],
    ['Storage', `${formatBytes(fs.sizeOf('/'))} virtual`],
    ['Browser', navigator.userAgent.includes('Edg') ? 'Microsoft Edge' : navigator.userAgent.includes('Chrome') ? 'Google Chrome' : navigator.userAgent.includes('Firefox') ? 'Mozilla Firefox' : navigator.userAgent.includes('Safari') ? 'Safari' : 'Web Browser'],
    ['Uptime', `${Math.max(1, Math.round((Date.now() - SYSTEM.bootTime) / 60000))} min`],
  ];
  for (const [k, v] of specRows) {
    specs.append(h('div', { class: 'spec-row' }, h('div', { class: 'k', text: k }), h('div', { class: 'v', text: String(v) })));
  }
  wrap.append(specs);

  const updateBtn = h('button', { class: 'btn', html: `${icon('refresh')} Check for Updates`, onclick: () => {
    const btn = updateBtn;
    btn.disabled = true;
    btn.textContent = 'Checking…';
    setTimeout(() => {
      btn.disabled = false;
      btn.innerHTML = `${icon('check')} Up to Date`;
      toast({ title: 'Nova OS is up to date', text: `Version ${SYSTEM.version} is the latest available.`, icon: 'check' });
      setTimeout(() => { btn.innerHTML = `${icon('refresh')} Check for Updates`; }, 3200);
    }, 1100);
  } });
  const docsBtn = h('button', { class: 'btn', html: `${icon('file-text')} Release Notes`, onclick: () => window.OS?.openApp('editor', { path: '/System/Release Notes.md' }) });
  wrap.append(h('div', { class: 'settings-actions' }, updateBtn, docsBtn));

  wrap.append(sectionTitle('Automation API'));
  wrap.append(h('div', { class: 'api-list card', style: { padding: '6px' } },
    ...[
      ['OS.openApp(id, params?)', 'Launch or focus an application'],
      ['OS.createFile(path, text)', 'Write a file to the virtual disk'],
      ['OS.exec("command")', 'Run a Terminal command'],
      ['OS.windows.list()', 'Inspect open windows'],
      ['OS.setTheme("dark")', 'Change the appearance'],
      ['OS.notify(title, text)', 'Post a notification'],
    ].map(([sig, desc]) => h('div', { class: 'api-sig', style: { display: 'flex', gap: '12px', padding: '5px 8px', borderRadius: '5px', fontSize: '10.5px' } },
      h('code', { class: 'api-name', text: sig }),
      h('span', { class: 'api-desc', text: desc }),
    )),
  ));
  wrap.append(note('Open the Browser console and use window.OS to drive the desktop programmatically.'));

  wrap.append(sectionTitle('Legal'));
  wrap.append(h('div', { class: 'card', style: { padding: '12px 14px', fontSize: '11px', lineHeight: '1.6', color: 'var(--text-2)' } },
    h('div', { text: 'Nova OS is an original browser desktop environment. It is not affiliated with, endorsed by, or a copy of Apple macOS or any other operating system.' }),
    h('div', { style: { marginTop: '6px', color: 'var(--text-3)' }, text: 'Icons and wallpapers are original vector and gradient artwork created for this project. No third-party assets are bundled.' }),
  ));
  return wrap;
}

/* ------------------------------------------------------------ */

export function mount(body, ctx) {
  const root = h('div');
  body.append(root);
  root.classList.add('app', 'settings-app');

  const sections = new Map();
  sections.set('appearance', appearanceSection);
  sections.set('desktop', desktopSection);
  sections.set('displays', displaysSection);
  sections.set('sound', soundSection);
  sections.set('network', networkSection);
  sections.set('notifications', notificationsSection);
  sections.set('keyboard', keyboardSection);
  sections.set('storage', storageSection);
  sections.set('about', aboutSection);

  let active = SECTIONS.some((s) => s.id === ctx.params?.section) ? ctx.params.section : 'appearance';

  const sidebar = h('aside', { class: 'app-sidebar sidebar settings-sidebar' });
  const sidebarScroll = h('div', { class: 'sidebar-scroll' });
  sidebar.append(sidebarScroll);
  const content = h('div', { class: 'settings-content' });
  const scroll = h('div', { class: 'settings-scroll' }, content);
  root.append(sidebar, scroll);

  const unsubs = [];

  function rerender() {
    renderSidebar();
    renderContent();
  }

  function renderSidebar() {
    sidebarScroll.replaceChildren();
    for (const section of SECTIONS) {
      const item = h('button', { class: `sidebar-item${active === section.id ? ' active' : ''}` },
        h('span', { html: icon(section.icon), style: { display: 'contents' } }),
        h('span', { class: 'si-text', text: section.name }),
      );
      item.addEventListener('click', () => {
        active = section.id;
        renderSidebar();
        renderContent();
        scroll.scrollTop = 0;
      });
      sidebarScroll.append(item);
    }
  }

  function renderContent() {
    content.replaceChildren();
    const fn = sections.get(active);
    if (!fn) return;
    const section = fn(rerender);
    section.style.animation = 'fadeIn .16s var(--ease-out)';
    content.append(section);
  }

  ctx.onParams = (params) => {
    if (params?.section && sections.has(params.section)) {
      active = params.section;
      rerender();
    }
  };

  // Keep open Settings windows in sync with system changes
  unsubs.push(on('settings:change', () => {
    if (active === 'desktop' || active === 'appearance' || active === 'notifications') {
      // avoid clobbering input focus in text fields
      if (document.activeElement && root.contains(document.activeElement) && document.activeElement.tagName === 'INPUT') return;
      renderSidebar();
    }
  }));

  rerender();

  return {
    open: (section) => {
      if (sections.has(section)) {
        active = section;
        rerender();
      }
    },
    getSection: () => active,
    dispose() {
      unsubs.forEach((fn) => fn());
    },
  };
}

/* ------------------------------------------------------------ */

export function menus(win) {
  const api = win.api || {};
  return {
    View: SECTIONS.map((section) => ({
      label: section.name,
      icon: section.icon,
      checked: api.getSection?.() === section.id,
      action: () => api.open?.(section.id),
    })),
  };
}
