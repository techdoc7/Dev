/* ============================================================
   Nova OS — Terminal
   A real command interpreter wired to the OS API and the
   virtual filesystem. Nothing is executed on the host machine.
   ============================================================ */

import { h, uid, debounce, basename, dirname, formatBytes, formatDate, formatTime, formatDuration, clamp, escapeHTML, isEditable } from '../core/util.js';
import { icon } from '../core/icons.js';
import { fs, HOME, WORKSPACE, SYSTEM_DIR } from '../core/fs.js';
import { get, SYSTEM, resolvedTheme } from '../core/state.js';
import { wallpapers } from '../core/wallpapers.js';
import { toast } from '../core/ui.js';
import sounds from '../core/sound.js';

export const meta = {
  id: 'terminal',
  name: 'Terminal',
  icon: 'terminal',
  category: 'Utilities',
  description: 'A command line wired into the OS, apps, windows and virtual filesystem.',
  defaultSize: { w: 820, h: 520 },
  minSize: { w: 480, h: 280 },
  singleton: false,
};

/* ------------------------------------------------------------
   Command registry
   ------------------------------------------------------------ */

const commands = new Map();

export function registerCommand(def) {
  commands.set(def.name, def);
  for (const alias of def.aliases || []) commands.set(alias, def);
}

export function listCommands() {
  const seen = new Set();
  const out = [];
  for (const cmd of commands.values()) {
    if (seen.has(cmd.name)) continue;
    seen.add(cmd.name);
    out.push(cmd);
  }
  return out.sort((a, b) => a.name.localeCompare(b.name));
}

const APP_IDS = () => (window.OS?.apps.list() || []).map((a) => a.id);
const APP_NAME = (id) => window.OS?.apps.list().find((a) => a.id === id)?.name || id;

function expandPath(input, cwd) {
  let p = String(input || '');
  if (!p) return cwd;
  if (p === '~') return HOME;
  if (p.startsWith('~/')) p = HOME + p.slice(1);
  return fs.normalize(p, cwd);
}

function tildePath(path) {
  if (path === HOME) return '~';
  if (path.startsWith(HOME + '/')) return '~' + path.slice(HOME.length);
  return path;
}

function pad(str, len) {
  return String(str).padEnd(len, ' ');
}

function printTable(rows, ctx) {
  const widths = [];
  for (const row of rows) {
    row.forEach((cell, i) => { widths[i] = Math.max(widths[i] || 0, String(cell).length); });
  }
  for (const row of rows) {
    ctx.print(row.map((cell, i) => pad(cell, widths[i])).join('  ').trimEnd(), row.__cls || '');
  }
}

function error(ctx, msg) {
  ctx.print(`nova: ${msg}`, 't-err');
}

function requireArgs(ctx, n, usage) {
  if (ctx.args.length < n) {
    error(ctx, `missing operand${n > 1 ? 's' : ''}`);
    ctx.print(`usage: ${usage}`, 't-dim');
    return false;
  }
  return true;
}

function appList() {
  return window.OS?.apps.list() || [];
}

function resolveApp(arg) {
  if (!arg) return null;
  const apps = appList();
  const q = arg.toLowerCase().replace(/\.app$/, '');
  return apps.find((a) => a.id === q) || apps.find((a) => a.name.toLowerCase() === q) || null;
}

/* ------------------------------------------------------------
   System commands
   ------------------------------------------------------------ */

registerCommand({
  name: 'help',
  group: 'System',
  description: 'Show available commands, or details for one command.',
  usage: 'help [command]',
  run(ctx) {
    if (ctx.args[0]) {
      const cmd = commands.get(ctx.args[0]);
      if (!cmd) { error(ctx, `no help entry for "${ctx.args[0]}"`); return; }
      ctx.print(cmd.name, 't-head');
      ctx.print(`  ${cmd.description || ''}`, 't-dim');
      ctx.print(`  usage: ${cmd.usage || cmd.name}`, 't-dim');
      if (cmd.group) ctx.print(`  group: ${cmd.group}`, 't-dim');
      return;
    }
    ctx.print('Nova Shell — command reference', 't-head');
    ctx.print('', '');
    const groups = new Map();
    for (const cmd of listCommands()) {
      if (!groups.has(cmd.group || 'Other')) groups.set(cmd.group || 'Other', []);
      groups.get(cmd.group || 'Other').push(cmd);
    }
    for (const [group, list] of groups) {
      ctx.print(group.toUpperCase(), 't-accent');
      for (const cmd of list) {
        ctx.print(`  ${pad(cmd.name, 16)} ${cmd.description || ''}`, 't-dim');
      }
      ctx.print('', '');
    }
    ctx.print('Tip: press Tab to autocomplete, ↑ ↓ for history, ⌃L to clear.', 't-dim');
  },
});

registerCommand({
  name: 'clear',
  group: 'System',
  description: 'Clear the terminal screen.',
  usage: 'clear',
  run(ctx) { ctx.clearScreen?.(); },
});

registerCommand({
  name: 'neofetch',
  group: 'System',
  description: 'Print system information with a little art.',
  usage: 'neofetch',
  run(ctx) {
    const art = [
      "          .+#+.          ",
      "       .+#######+.       ",
      "      +###########+      ",
      "     ###############     ",
      "     ###############     ",
      "      +###########+      ",
      "       '+#######+'       ",
      "          '-+-'          ",
    ];
    const theme = resolvedTheme();
    const info = [
      ['', ''],
      ['OS', `${SYSTEM.name} ${SYSTEM.version} ${SYSTEM.codename}`],
      ['Host', get('computerName', 'Nova Studio')],
      ['Kernel', SYSTEM.kernel],
      ['Uptime', formatDuration(Date.now() - SYSTEM.bootTime)],
      ['Shell', 'nova-sh 1.0'],
      ['Resolution', `${window.innerWidth}×${window.innerHeight} @ ${window.devicePixelRatio}×`],
      ['WM', 'Nova Window Server'],
      ['Terminal', 'Nova Terminal'],
      ['Theme', `${theme[0].toUpperCase()}${theme.slice(1)} · ${get('accent', 'blue')}`],
      ['Disk', `${formatBytes(fs.sizeOf('/'))} / 512 MB (virtual)`],
      ['', ''],
    ];
    info.forEach(([k, v], i) => {
      const left = art[i] || '';
      if (!k) { ctx.print(`${left}`, 't-accent'); return; }
      ctx.print(`${left}  ${pad(k, 12)} ${v}`, i === 1 ? 't-head' : 't-dim');
    });
  },
});

registerCommand({
  name: 'date',
  group: 'System',
  description: 'Print the current date.',
  usage: 'date',
  run(ctx) {
    ctx.print(new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }));
  },
});

registerCommand({
  name: 'time',
  group: 'System',
  description: 'Print the current time.',
  usage: 'time',
  run(ctx) { ctx.print(formatTime(new Date(), { seconds: true, h24: true })); },
});

registerCommand({
  name: 'hostname',
  group: 'System',
  description: 'Print the computer name.',
  usage: 'hostname',
  run(ctx) { ctx.print(get('computerName', 'Nova Studio')); },
});

registerCommand({
  name: 'uptime',
  group: 'System',
  description: 'Show how long the OS has been running.',
  usage: 'uptime',
  run(ctx) {
    ctx.print(`up ${formatDuration(Date.now() - SYSTEM.bootTime)}, 1 user, load average: 0.24 0.18 0.12`);
  },
});

registerCommand({
  name: 'version',
  group: 'System',
  description: 'Print the OS version.',
  usage: 'version',
  run(ctx) {
    ctx.print(`${SYSTEM.name} ${SYSTEM.version} (${SYSTEM.codename})`, 't-head');
    ctx.print(`Build ${SYSTEM.build} · ${SYSTEM.kernel}`, 't-dim');
  },
});

registerCommand({
  name: 'whoami',
  group: 'System',
  description: 'Print the current user.',
  usage: 'whoami',
  run(ctx) { ctx.print(get('userName', 'nova')); },
});

registerCommand({
  name: 'history',
  group: 'System',
  description: 'Show command history for this session.',
  usage: 'history',
  run(ctx) {
    if (!ctx.session.history.length) { ctx.print('No commands in history.', 't-dim'); return; }
    ctx.session.history.forEach((cmd, i) => ctx.print(`  ${pad(i + 1, 4)} ${cmd}`, 't-dim'));
  },
});

registerCommand({
  name: 'sudo',
  group: 'System',
  description: 'Not available in the sandbox (but amusing).',
  usage: 'sudo <command>',
  run(ctx) {
    ctx.print(`${get('userName', 'nova')} is not in the sudoers file. This incident has been reported.`, 't-err');
  },
});

/* ------------------------------------------------------------
   Filesystem
   ------------------------------------------------------------ */

registerCommand({
  name: 'pwd',
  group: 'Filesystem',
  description: 'Print the working directory.',
  usage: 'pwd',
  run(ctx) { ctx.print(ctx.session.cwd); },
});

registerCommand({
  name: 'ls',
  group: 'Filesystem',
  description: 'List directory contents.',
  usage: 'ls [-l] [-a] [path]',
  run(ctx) {
    const flags = ctx.args.filter((a) => a.startsWith('-')).join('');
    const paths = ctx.args.filter((a) => !a.startsWith('-'));
    const target = expandPath(paths[0] || '.', ctx.session.cwd);
    let entries;
    try { entries = fs.list(target); }
    catch (err) { error(ctx, err.message); return; }
    if (!entries.length) { ctx.print('(empty)', 't-dim'); return; }
    const long = flags.includes('l');
    if (!long) {
      const names = entries.map((e) => e.type === 'dir' ? `${e.name}/` : e.name);
      const width = Math.max(...names.map((n) => n.length)) + 3;
      const cols = Math.max(1, Math.floor(72 / width));
      for (let i = 0; i < names.length; i += cols) {
        ctx.print(names.slice(i, i + cols).map((n) => pad(n, width)).join(''), entries[i].type === 'dir' ? 't-accent' : '');
      }
      return;
    }
    ctx.print(`total ${entries.length}`, 't-dim');
    for (const e of entries) {
      const perms = e.readonly ? 'r--r--r--' : e.type === 'dir' ? 'drwxr-xr-x' : '-rw-r--r--';
      const size = e.type === 'dir' ? `${entries.length}` : formatBytes(e.size);
      const stamp = formatDate(e.modified, { short: true }) + ' ' + formatTime(e.modified);
      ctx.print(`${pad(perms, 11)} ${pad(size, 7)} ${pad(stamp, 18)} ${e.name}${e.type === 'dir' ? '/' : ''}`,
        e.type === 'dir' ? 't-accent' : e.type === 'app' ? 't-value' : '');
    }
  },
});

registerCommand({
  name: 'cd',
  group: 'Filesystem',
  description: 'Change directory.',
  usage: 'cd [path]',
  run(ctx) {
    const target = expandPath(ctx.args[0] || HOME, ctx.session.cwd);
    try {
      const stat = fs.stat(target);
      if (stat.type !== 'dir') { error(ctx, `not a directory: ${target}`); return; }
      ctx.session.cwd = target;
      ctx.print(`→ ${target}`, 't-dim');
    } catch (err) {
      error(ctx, err.message);
    }
  },
});

registerCommand({
  name: 'mkdir',
  group: 'Filesystem',
  description: 'Create a directory.',
  usage: 'mkdir [-p] <path>',
  run(ctx) {
    const paths = ctx.args.filter((a) => !a.startsWith('-'));
    if (!requireArgs({ ...ctx, args: paths }, 1, 'mkdir [-p] <path>')) return;
    for (const p of paths) {
      try {
        const target = expandPath(p, ctx.session.cwd);
        fs.mkdir(target);
        ctx.print(`created ${target}`, 't-ok');
      } catch (err) { error(ctx, err.message); }
    }
  },
});

registerCommand({
  name: 'touch',
  group: 'Filesystem',
  description: 'Create an empty file or update its timestamp.',
  usage: 'touch <file>',
  run(ctx) {
    if (!requireArgs(ctx, 1, 'touch <file>')) return;
    const target = expandPath(ctx.args[0], ctx.session.cwd);
    try {
      if (fs.exists(target)) {
        fs.writeFile(target, fs.readFile(target));
        ctx.print(`updated ${target}`, 't-dim');
      } else {
        fs.writeFile(target, '');
        ctx.print(`created ${target}`, 't-ok');
      }
    } catch (err) { error(ctx, err.message); }
  },
});

registerCommand({
  name: 'cat',
  group: 'Filesystem',
  description: 'Print file contents.',
  usage: 'cat <file>',
  run(ctx) {
    if (!requireArgs(ctx, 1, 'cat <file>')) return;
    const target = expandPath(ctx.args[0], ctx.session.cwd);
    try {
      const content = fs.readFile(target);
      if (!content) { ctx.print('(empty file)', 't-dim'); return; }
      content.split('\n').forEach((line) => ctx.print(line));
    } catch (err) { error(ctx, err.message); }
  },
});

registerCommand({
  name: 'echo',
  group: 'Filesystem',
  description: 'Print text, or write it to a file with >.',
  usage: 'echo <text> [> file]',
  run(ctx) {
    if (!ctx.raw.includes('>')) {
      const raw = ctx.args.join(' ');
      ctx.print(raw);
      return;
    }
    const [left, right] = ctx.raw.split('>');
    const text = left.replace(/^echo\s+/, '').replace(/^["']|["']$/g, '');
    const target = expandPath(right.trim(), ctx.session.cwd);
    if (!target) { error(ctx, 'no output file specified'); return; }
    try {
      fs.writeFile(target, text + '\n');
      ctx.print(`wrote ${text.length + 1} bytes to ${target}`, 't-ok');
    } catch (err) { error(ctx, err.message); }
  },
});

registerCommand({
  name: 'rm',
  group: 'Filesystem',
  description: 'Remove a file or folder.',
  usage: 'rm [-r] <path>',
  run(ctx) {
    const paths = ctx.args.filter((a) => !a.startsWith('-'));
    if (!requireArgs({ ...ctx, args: paths }, 1, 'rm [-r] <path>')) return;
    for (const p of paths) {
      try {
        const target = expandPath(p, ctx.session.cwd);
        fs.remove(target, { recursive: true });
        ctx.print(`removed ${target}`, 't-ok');
      } catch (err) { error(ctx, err.message); }
    }
  },
});

registerCommand({
  name: 'mv',
  group: 'Filesystem',
  description: 'Move or rename a file.',
  usage: 'mv <source> <destination>',
  run(ctx) {
    if (!requireArgs(ctx, 2, 'mv <source> <destination>')) return;
    try {
      const src = expandPath(ctx.args[0], ctx.session.cwd);
      const dest = expandPath(ctx.args[1], ctx.session.cwd);
      fs.move(src, dest);
      ctx.print(`${src} → ${dest}`, 't-ok');
    } catch (err) { error(ctx, err.message); }
  },
});

registerCommand({
  name: 'cp',
  group: 'Filesystem',
  description: 'Copy a file or folder.',
  usage: 'cp [-r] <source> <destination>',
  run(ctx) {
    if (!requireArgs(ctx, 2, 'cp <source> <destination>')) return;
    try {
      const src = expandPath(ctx.args[0], ctx.session.cwd);
      const dest = expandPath(ctx.args[1], ctx.session.cwd);
      fs.copy(src, dest);
      ctx.print(`${src} → ${dest}`, 't-ok');
    } catch (err) { error(ctx, err.message); }
  },
});

registerCommand({
  name: 'tree',
  group: 'Filesystem',
  description: 'Print a directory tree.',
  usage: 'tree [path]',
  run(ctx) {
    const target = expandPath(ctx.args[0] || '.', ctx.session.cwd);
    try {
      const lines = fs.tree(target, ctx.session.cwd, 4);
      lines.forEach((line, i) => ctx.print(line, i === 0 ? 't-head' : 't-dim'));
    } catch (err) { error(ctx, err.message); }
  },
});

/* ------------------------------------------------------------
   Applications & windows
   ------------------------------------------------------------ */

registerCommand({
  name: 'apps',
  group: 'Applications',
  description: 'List applications and whether they are running.',
  usage: 'apps',
  run(ctx) {
    const running = new Set(window.OS?.runningApps?.() || []);
    ctx.print('APPLICATION        STATE', 't-dim');
    for (const app of appList()) {
      ctx.print(`${pad(app.id, 18)} ${running.has(app.id) ? 'running' : 'idle'}`,
        running.has(app.id) ? 't-ok' : '');
    }
  },
});

registerCommand({
  name: 'open',
  aliases: ['launch', 'start'],
  group: 'Applications',
  description: 'Open an app, URL or file path.',
  usage: 'open <app|url|path>',
  run(ctx) {
    if (!requireArgs(ctx, 1, 'open <app|url|path>')) return;
    const arg = ctx.args.join(' ');
    const app = resolveApp(arg);
    if (app) {
      window.OS?.openApp(app.id);
      ctx.print(`launching ${app.name}…`, 't-ok');
      return;
    }
    if (/^(https?:\/\/|www\.)/i.test(arg) || /^[\w-]+(\.[\w-]+)+(\/.*)?$/.test(arg)) {
      window.OS?.openWebsite(arg.startsWith('http') ? arg : `https://${arg}`);
      ctx.print(`opening ${arg} in Browser…`, 't-ok');
      return;
    }
    if (arg.startsWith('/') || arg.startsWith('~') || arg.startsWith('.')) {
      const target = expandPath(arg, ctx.session.cwd);
      try {
        const stat = fs.stat(target);
        if (stat.type === 'dir') { window.OS?.openApp('finder', { path: target }); ctx.print(`opening ${target} in Finder…`, 't-ok'); }
        else if (stat.type === 'app') { window.OS?.openApp(stat.appId); ctx.print(`launching ${APP_NAME(stat.appId)}…`, 't-ok'); }
        else { window.OS?.openApp('editor', { path: target }); ctx.print(`opening ${target}…`, 't-ok'); }
      } catch (err) { error(ctx, err.message); }
      return;
    }
    error(ctx, `unknown application or location: ${arg}`);
    ctx.print(`try: apps`, 't-dim');
  },
});

registerCommand({
  name: 'close',
  group: 'Applications',
  description: 'Close all windows of an application.',
  usage: 'close <app>',
  run(ctx) {
    if (!requireArgs(ctx, 1, 'close <app>')) return;
    const app = resolveApp(ctx.args[0]);
    if (!app) { error(ctx, `no such application: ${ctx.args[0]}`); return; }
    window.OS?.closeApp(app.id);
    ctx.print(`closed ${app.name}`, 't-ok');
  },
});

registerCommand({
  name: 'windows',
  group: 'Windows',
  description: 'List open windows.',
  usage: 'windows',
  run(ctx) {
    const list = window.OS?.windows.list() || [];
    if (!list.length) { ctx.print('No windows open.', 't-dim'); return; }
    ctx.print('ID        APP          STATE       TITLE', 't-dim');
    for (const w of list) {
      ctx.print(`${pad(w.appId, 12)} ${pad(w.state, 12)} ${w.title}`,
        w.state === 'minimized' ? 't-warn' : w.focused ? 't-ok' : '');
    }
  },
});

function windowAction(ctx, action, verb) {
  const list = window.OS?.windows.list() || [];
  const arg = ctx.args[0];
  if (arg) {
    const app = resolveApp(arg);
    const win = app ? list.find((w) => w.appId === app.id) : null;
    if (!win) { error(ctx, `no window found for "${arg}"`); return; }
    action(win.id);
    ctx.print(`${verb} ${win.title}`, 't-ok');
    return;
  }
  const focused = list.find((w) => w.focused);
  if (!focused) { error(ctx, 'no focused window'); return; }
  action(focused.id);
  ctx.print(`${verb} ${focused.title}`, 't-ok');
}

registerCommand({
  name: 'minimize',
  group: 'Windows',
  description: 'Minimize a window.',
  usage: 'minimize [app]',
  run(ctx) { windowAction(ctx, (id) => window.OS.windows.minimize(id), 'minimized'); },
});

registerCommand({
  name: 'maximize',
  group: 'Windows',
  description: 'Zoom a window to fill the screen.',
  usage: 'maximize [app]',
  run(ctx) { windowAction(ctx, (id) => window.OS.windows.maximize(id), 'maximized'); },
});

registerCommand({
  name: 'restore',
  group: 'Windows',
  description: 'Restore a minimized window.',
  usage: 'restore [app]',
  run(ctx) { windowAction(ctx, (id) => window.OS.windows.restore(id), 'restored'); },
});

/* ------------------------------------------------------------
   Settings, network, session
   ------------------------------------------------------------ */

registerCommand({
  name: 'theme',
  group: 'Settings',
  description: 'Set the theme: dark, light or auto.',
  usage: 'theme [dark|light|auto|toggle]',
  run(ctx) {
    const arg = (ctx.args[0] || '').toLowerCase();
    if (!arg) { ctx.print(`current theme: ${resolvedTheme()}`, 't-dim'); return; }
    if (arg === 'toggle') { const next = window.OS.toggleTheme(); ctx.print(`theme → ${next}`, 't-ok'); return; }
    if (!['dark', 'light', 'auto'].includes(arg)) { error(ctx, `unknown theme "${arg}"`); ctx.print('usage: theme [dark|light|auto|toggle]', 't-dim'); return; }
    const resolved = window.OS.setTheme(arg);
    ctx.print(`theme set to ${arg}${arg === 'auto' ? ` (${resolved})` : ''}`, 't-ok');
  },
});

registerCommand({
  name: 'wallpaper',
  group: 'Settings',
  description: 'List or set the desktop wallpaper.',
  usage: 'wallpaper [id|list]',
  run(ctx) {
    const arg = ctx.args[0];
    if (!arg || arg === 'list') {
      ctx.print('Available wallpapers:', 't-head');
      for (const wp of wallpapers) {
        ctx.print(`  ${pad(wp.id, 12)} ${wp.name}${get('wallpaper') === wp.id ? '  ← current' : ''}`, get('wallpaper') === wp.id ? 't-ok' : 't-dim');
      }
      return;
    }
    if (window.OS.setWallpaper(arg)) ctx.print(`wallpaper → ${arg}`, 't-ok');
    else error(ctx, `unknown wallpaper "${arg}"`);
  },
});

registerCommand({
  name: 'settings',
  group: 'Settings',
  description: 'Open System Settings, optionally at a section.',
  usage: 'settings [section]',
  run(ctx) {
    window.OS.openApp('settings', { section: ctx.args[0] || 'appearance' });
    ctx.print('opening System Settings…', 't-ok');
  },
});

registerCommand({
  name: 'notifications',
  group: 'Settings',
  description: 'Show or clear notifications.',
  usage: 'notifications [clear]',
  run(ctx) {
    if (ctx.args[0] === 'clear') {
      window.OS.clearNotifications();
      ctx.print('notifications cleared', 't-ok');
      return;
    }
    const list = window.OS.notifications.list();
    if (!list.length) { ctx.print('No notifications.', 't-dim'); return; }
    for (const n of list.slice(0, 10)) {
      ctx.print(`${formatTime(n.time)}  ${n.title}${n.text ? ' — ' + n.text : ''}`, 't-dim');
    }
  },
});

registerCommand({
  name: 'browser',
  group: 'Network',
  description: 'Open the Browser, optionally at a URL.',
  usage: 'browser [url]',
  run(ctx) {
    if (ctx.args[0]) {
      window.OS.openWebsite(ctx.args.join(' '));
      ctx.print(`opening ${ctx.args[0]} in Browser…`, 't-ok');
    } else {
      window.OS.openApp('browser');
      ctx.print('launching Browser…', 't-ok');
    }
  },
});

registerCommand({
  name: 'exit',
  aliases: ['logout'],
  group: 'Session',
  description: 'Close this terminal window.',
  usage: 'exit',
  run(ctx) { ctx.closeWindow?.(); },
});

registerCommand({
  name: 'edit',
  aliases: ['nano', 'vim', 'code'],
  group: 'Filesystem',
  description: 'Open a file in the Text Editor.',
  usage: 'edit <file>',
  run(ctx) {
    if (!requireArgs(ctx, 1, 'edit <file>')) return;
    const target = expandPath(ctx.args[0], ctx.session.cwd);
    window.OS?.openApp('editor', { path: target });
    ctx.print(`opening ${target}…`, 't-ok');
  },
});

/* ------------------------------------------------------------
   Execution engine
   ------------------------------------------------------------ */

function tokenize(input) {
  const tokens = [];
  let cur = '';
  let quote = null;
  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    if (quote) {
      if (ch === quote) quote = null;
      else cur += ch;
    } else if (ch === '"' || ch === "'") {
      quote = ch;
    } else if (/\s/.test(ch)) {
      if (cur) { tokens.push(cur); cur = ''; }
    } else {
      cur += ch;
    }
  }
  if (cur) tokens.push(cur);
  return tokens;
}

export async function executeLine(raw, session, print, extra = {}) {
  const line = String(raw || '').trim();
  if (!line) return;
  const tokens = tokenize(line);
  const name = tokens[0];
  const args = tokens.slice(1);
  const cmd = commands.get(name);
  const ctx = {
    raw: line,
    args,
    session,
    print: (text, cls) => print(text, cls || ''),
    clearScreen: extra.clearScreen,
    closeWindow: extra.closeWindow,
  };
  if (!cmd) {
    error(ctx, `command not found: ${name}`);
    const guess = closestCommand(name);
    if (guess) ctx.print(`did you mean "${guess}"?`, 't-dim');
    return;
  }
  try {
    await cmd.run(ctx);
  } catch (err) {
    error(ctx, err.message || String(err));
  }
}

function closestCommand(name) {
  const all = listCommands().map((c) => c.name);
  let best = null;
  let bestScore = 3;
  for (const candidate of all) {
    const score = levenshtein(name, candidate);
    if (score < bestScore) { bestScore = score; best = candidate; }
  }
  return best;
}

function levenshtein(a, b) {
  const dp = Array.from({ length: a.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= b.length; j++) dp[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    }
  }
  return dp[a.length][b.length];
}

/* ------------------------------------------------------------
   UI
   ------------------------------------------------------------ */

export function mount(body, ctx) {
  const root = h('div');
  body.append(root);
  root.classList.add('app', 'terminal');

  const storedHistory = (() => {
    try { const v = JSON.parse(localStorage.getItem('nova.terminal.history') || '[]'); return Array.isArray(v) ? v : []; }
    catch { return []; }
  })();

  const sessions = [];
  let activeId = null;
  let sessionCounter = 0;

  const tabList = h('div', { style: { display: 'flex', gap: '2px', alignItems: 'center', flex: '0 1 auto', overflow: 'hidden' } });
  const newTabBtn = h('button', { class: 'icon-btn', title: 'New Session', 'aria-label': 'New session', html: icon('plus'), style: { width: '24px', height: '24px', flex: 'none' } });
  const tabsBar = h('div', { class: 'term-tabs' }, tabList, newTabBtn);
  const wrap = h('div', { class: 'term-wrap' });
  const suggestBox = h('div', { class: 'term-suggest', hidden: true });
  wrap.append(suggestBox);
  root.append(tabsBar, wrap);

  function promptHTML(session) {
    const user = get('userName', 'nova');
    return `<span class="tp-user">${escapeHTML(user)}</span><span class="tp-at">@</span><span class="tp-host">nova</span><span class="tp-path"> ${escapeHTML(tildePath(session.cwd))}</span> <span class="tp-sign">%</span> `;
  }

  function updatePrompt(session) {
    if (session.promptEl) session.promptEl.innerHTML = promptHTML(session);
    if (session.tabEl) {
      const label = session.tabLabel;
      if (label) label.textContent = tildePath(session.cwd);
    }
  }

  function createSession(cwd = HOME, { activate = true, announce = true } = {}) {
    sessionCounter += 1;
    const session = {
      id: uid('sh'),
      cwd: fs.exists(cwd) && fs.isDir(cwd) ? cwd : HOME,
      history: [...storedHistory],
      historyIndex: storedHistory.length,
      tabLabel: null,
      screen: null,
      output: null,
      promptEl: null,
      inputEl: null,
      tabEl: null,
      sessionNo: sessionCounter,
    };

    const output = h('div', {});
    const input = h('input', {
      class: 'term-input',
      type: 'text',
      spellcheck: 'false',
      autocomplete: 'off',
      'aria-label': 'Terminal input',
    });
    const prompt = h('span', { class: 'term-prompt', html: promptHTML(session) });
    const inputRow = h('div', { class: 'term-input-row' }, prompt, input);
    const screen = h('div', { class: 'term-screen' }, output, inputRow);
    screen.hidden = sessions.length > 0;

    session.output = output;
    session.screen = screen;
    session.promptEl = prompt;
    session.inputEl = input;
    wrap.append(screen);
    sessions.push(session);

    const print = (text = '', cls = '') => {
      const value = String(text ?? '');
      const lines = value.split('\n');
      for (const line of lines) {
        const div = h('div', { class: `term-line ${cls}`.trim() });
        div.textContent = line || '\u00a0';
        output.append(div);
      }
      while (output.childElementCount > 2200) output.firstElementChild.remove();
      screen.scrollTop = screen.scrollHeight;
    };

    const clearScreen = () => { output.replaceChildren(); };

    const echo = (line) => {
      const el = h('div', { class: 'term-line t-cmd' });
      el.innerHTML = promptHTML(session) + escapeHTML(line);
      output.append(el);
    };

    const complete = () => {
      const value = input.value;
      const parts = value.split(/\s+/);
      if (parts.length <= 1) {
        const prefix = value;
        const names = listCommands().map((c) => c.name);
        const matches = Array.from(new Set(names.filter((n) => n.startsWith(prefix))));
        if (!matches.length) return;
        if (matches.length === 1) input.value = matches[0] + ' ';
        else input.value = longestCommonPrefix(matches);
      } else {
        const token = parts[parts.length - 1];
        const expanded = token.startsWith('~') ? token.replace('~', HOME) : token;
        const dir = expanded.includes('/') ? dirname(fs.normalize(expanded, session.cwd)) : session.cwd;
        const prefix = expanded.includes('/') ? basename(expanded) : expanded;
        let entries = [];
        try { entries = fs.list(dir); } catch { return; }
        const matches = entries.filter((e) => e.name.toLowerCase().startsWith(prefix.toLowerCase()));
        if (!matches.length) return;
        let completion;
        if (matches.length === 1) {
          const item = matches[0];
          completion = item.name + (item.type === 'dir' ? '/' : '');
        } else {
          completion = longestCommonPrefix(matches.map((m) => m.name));
        }
        parts[parts.length - 1] = (expanded.includes('/') ? expanded.slice(0, expanded.length - prefix.length) : '') + completion;
        input.value = parts.join(' ');
      }
      updateSuggestions();
    };

    input.addEventListener('keydown', async (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        const raw = input.value;
        input.value = '';
        hideSuggestions();
        echo(raw);
        if (raw.trim()) {
          session.history.push(raw.trim());
          if (session.history.length > 500) session.history.shift();
          session.historyIndex = session.history.length;
          saveHistory(session.history);
          await executeLine(raw, session, print, {
            clearScreen,
            closeWindow: () => ctx.close(),
          });
        }
        updatePrompt(session);
        screen.scrollTop = screen.scrollHeight;
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        if (!session.history.length) return;
        session.historyIndex = clamp(session.historyIndex - 1, 0, session.history.length - 1);
        input.value = session.history[session.historyIndex] || '';
        setTimeout(() => input.setSelectionRange(input.value.length, input.value.length), 0);
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (!session.history.length) return;
        session.historyIndex = clamp(session.historyIndex + 1, 0, session.history.length);
        input.value = session.history[session.historyIndex] || '';
      } else if (e.key === 'Tab') {
        e.preventDefault();
        complete();
      } else if (e.key === 'l' && e.ctrlKey) {
        e.preventDefault();
        clearScreen();
      } else if (e.key === 'c' && e.ctrlKey) {
        e.preventDefault();
        if (input.value) {
          print(`${input.value}^C`, 't-dim');
          input.value = '';
        }
        hideSuggestions();
      } else if (e.key === 'Escape') {
        hideSuggestions();
      }
    });

    input.addEventListener('input', () => updateSuggestions());
    screen.addEventListener('click', (e) => {
      if (window.getSelection()?.toString()) return;
      if (e.target.closest('.term-line')) return;
      input.focus();
    });

    screen.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      if (e.target.closest('.term-line')) return;
      input.focus();
    });

    // tab
    const tab = h('div', { class: 'term-tab' });
    const dot = h('span', { class: 'tt-dot' });
    const label = h('span', { class: 'tt-title', text: tildePath(session.cwd) });
    const close = h('button', { class: 'tt-close', html: icon('x'), title: 'Close session' });
    close.addEventListener('click', (e) => { e.stopPropagation(); closeSession(session.id); });
    tab.append(dot, label, close);
    tab.addEventListener('click', () => activateSession(session.id));
    session.tabEl = tab;
    session.tabLabel = label;

    if (activate) activateSession(session.id);
    else tabList.append(tab);

    if (announce) {
      print(`${SYSTEM.name} ${SYSTEM.version} · nova-sh 1.0`, 't-head');
      print(`Type "help" for a list of commands. Virtual filesystem only — your real disk is never touched.`, 't-dim');
      print('', '');
    }
    setTimeout(() => input.focus(), 30);
    return session;
  }

  function activateSession(id) {
    activeId = id;
    for (const s of sessions) {
      const active = s.id === id;
      s.screen.hidden = !active;
      s.tabEl.classList.toggle('active', active);
      if (active) {
        tabList.append(s.tabEl);
        s.inputEl.focus();
        s.screen.scrollTop = s.screen.scrollHeight;
      }
    }
    updateSuggestions();
  }

  function closeSession(id) {
    const idx = sessions.findIndex((s) => s.id === id);
    if (idx < 0) return;
    const session = sessions[idx];
    session.screen.remove();
    session.tabEl.remove();
    sessions.splice(idx, 1);
    if (!sessions.length) { ctx.close(); return; }
    if (activeId === id) activateSession(sessions[Math.max(0, idx - 1)].id);
    sounds.close();
  }

  function renderTabs() {
    tabList.replaceChildren();
    for (const s of sessions) {
      if (s.id === activeId) s.tabEl.classList.add('active');
      tabList.append(s.tabEl);
    }
  }

  /* ---------------- suggestions ---------------- */
  function hideSuggestions() {
    suggestBox.hidden = true;
    suggestBox.replaceChildren();
    suggestSelected = 0;
    suggestItems = [];
  }

  let suggestSelected = 0;
  let suggestItems = [];

  function updateSuggestions() {
    const session = sessions.find((s) => s.id === activeId);
    if (!session) return;
    const value = session.inputEl.value;
    if (!value || value.includes(' ')) { hideSuggestions(); return; }
    const matches = listCommands().filter((c) => c.name.startsWith(value.toLowerCase())).slice(0, 6);
    if (!matches.length || (matches.length === 1 && matches[0].name === value)) {
      hideSuggestions();
      return;
    }
    suggestItems = matches;
    suggestSelected = 0;
    suggestBox.replaceChildren(...matches.map((cmd, i) => {
      const row = h('div', { class: `ts-item${i === 0 ? ' active' : ''}` },
        h('span', { text: cmd.name }),
        h('span', { class: 'ts-desc', text: cmd.group || '' }),
      );
      row.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        session.inputEl.value = cmd.name + ' ';
        session.inputEl.focus();
        hideSuggestions();
      });
      return row;
    }));
    suggestBox.hidden = false;
  }

  newTabBtn.addEventListener('click', () => createSession(HOME, { activate: true }));

  const onKey = (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 't') {
      e.preventDefault();
      createSession(HOME, { activate: true });
    }
  };
  root.addEventListener('keydown', onKey);

  /* boot */
  createSession(ctx.params?.cwd || HOME, { activate: true });
  renderTabs();

  ctx.onParams = (params) => {
    if (params?.cwd && fs.isDir(params.cwd)) {
      const s = sessions.find((x) => x.id === activeId);
      if (s) { s.cwd = fs.normalize(params.cwd); updatePrompt(s); }
    }
  };

  return {
    newSession: () => createSession(HOME, { activate: true }),
    run: async (line) => {
      const s = sessions.find((x) => x.id === activeId);
      if (!s) return;
      const echoLine = line;
      const el = h('div', { class: 'term-line t-cmd' });
      el.innerHTML = promptHTML(s) + escapeHTML(echoLine);
      s.output.append(el);
      await executeLine(line, s, (text, cls) => {
        const div = h('div', { class: `term-line ${cls}`.trim() });
        div.textContent = text;
        s.output.append(div);
      }, { clearScreen: () => s.output.replaceChildren(), closeWindow: () => ctx.close() });
    },
    getSession: () => {
      const s = sessions.find((x) => x.id === activeId);
      return s ? { cwd: s.cwd } : null;
    },
    clear: () => {
      const s = sessions.find((x) => x.id === activeId);
      if (s) s.output.replaceChildren();
      s?.inputEl.focus();
    },
    dispose() { /* sessions hold no external resources */ },
  };
}

function saveHistory(history) {
  try { localStorage.setItem('nova.terminal.history', JSON.stringify(history.slice(-500))); } catch { /* ignore */ }
}

function longestCommonPrefix(strings) {
  if (!strings.length) return '';
  let prefix = strings[0];
  for (const s of strings.slice(1)) {
    let i = 0;
    while (i < prefix.length && i < s.length && prefix[i] === s[i]) i++;
    prefix = prefix.slice(0, i);
    if (!prefix) break;
  }
  return prefix;
}

/* ------------------------------------------------------------
   Menus
   ------------------------------------------------------------ */

export function menus(win) {
  const api = win.api || {};
  return {
    Shell: [
      { label: 'New Window', shortcut: '⌘N', icon: 'terminal', action: () => window.OS?.openApp('terminal') },
      { label: 'New Session', shortcut: '⌘T', icon: 'plus', action: () => api.newSession?.() },
      { separator: true },
      { label: 'Clear Screen', shortcut: '⌃L', icon: 'refresh', action: () => api.clear?.() },
      { separator: true },
      { label: 'Close Window', shortcut: '⌘W', action: () => win.ctx.close() },
    ],
    Edit: [
      { label: 'Copy', shortcut: '⌘C', action: () => document.execCommand('copy') },
      { label: 'Paste', shortcut: '⌘V', action: () => document.execCommand('paste') },
      { separator: true },
      { label: 'Select All', shortcut: '⌘A', action: () => document.execCommand('selectAll') },
    ],
    View: [
      { label: 'Bigger Text', action: () => adjustFont(win, 1) },
      { label: 'Smaller Text', action: () => adjustFont(win, -1) },
      { label: 'Default Size', action: () => setFont(win, 12) },
    ],
    Help: [
      { label: 'Command Reference', icon: 'info', action: () => {
        win.ctx.close();
        window.OS?.openApp('terminal');
      } },
    ],
  };
}

function setFont(win, px) {
  const screen = win.el.querySelector('.term-screen');
  if (screen) {
    screen.style.fontSize = `${px}px`;
    win.el.querySelectorAll('.term-input, .term-prompt').forEach((el) => { el.style.fontSize = `${px}px`; });
  }
  win._fontSize = px;
}

function adjustFont(win, delta) {
  const current = win._fontSize || 12;
  setFont(win, clamp(current + delta, 9, 18));
}
