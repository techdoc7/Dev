/* ============================================================
   Nova OS — Weather
   A calm, locally generated forecast. No network requests are
   made; the data is a deterministic sample for the chosen city.
   ============================================================ */

import { h, clamp, formatTime } from '../core/util.js';
import { icon } from '../core/icons.js';
import { get, set } from '../core/state.js';
import { showMenu, showModal, toast } from '../core/ui.js';
import sounds from '../core/sound.js';

export const meta = {
  id: 'weather',
  name: 'Weather',
  icon: 'weather',
  category: 'Utilities',
  description: 'A quiet, generated forecast for a handful of cities.',
  defaultSize: { w: 380, h: 620 },
  minSize: { w: 300, h: 400 },
  singleton: true,
};

const CITIES = [
  { id: 'nova', name: 'Nova City', region: 'Aurora Bay', base: 21, humid: 0.52, southern: false },
  { id: 'sf', name: 'San Francisco', region: 'California', base: 17, humid: 0.68, southern: false },
  { id: 'ny', name: 'New York', region: 'New York', base: 15, humid: 0.6, southern: false },
  { id: 'london', name: 'London', region: 'United Kingdom', base: 13, humid: 0.73, southern: false },
  { id: 'tokyo', name: 'Tokyo', region: 'Japan', base: 18, humid: 0.66, southern: false },
  { id: 'sydney', name: 'Sydney', region: 'Australia', base: 22, humid: 0.6, southern: true },
  { id: 'reykjavik', name: 'Reykjavík', region: 'Iceland', base: 5, humid: 0.78, southern: false },
  { id: 'marrakech', name: 'Marrakech', region: 'Morocco', base: 26, humid: 0.3, southern: false },
];

const CONDITIONS = {
  clear: { label: 'Clear', icon: 'sun', nightIcon: 'moon' },
  mostly: { label: 'Mostly Clear', icon: 'sun', nightIcon: 'moon' },
  partly: { label: 'Partly Cloudy', icon: 'cloud-sun', nightIcon: 'cloud' },
  cloudy: { label: 'Cloudy', icon: 'cloud' },
  rain: { label: 'Rain', icon: 'cloud-rain' },
  drizzle: { label: 'Drizzle', icon: 'cloud-rain' },
  storm: { label: 'Thunderstorms', icon: 'zap' },
  snow: { label: 'Snow', icon: 'cloud-snow' },
  fog: { label: 'Fog', icon: 'cloud' },
  wind: { label: 'Windy', icon: 'wind' },
};

const DOW_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function hash(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a += 0x6D2B79F5;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function seasonOffset(city, month) {
  const phase = city.southern ? Math.PI : 0;
  const seasonal = Math.cos(((month - 6) / 12) * Math.PI * 2 + phase);
  return seasonal * (city.southern ? -8 : 8) * 0.75;
}

function conditionFor(rand, { night = false, base = 20 } = {}) {
  const r = rand();
  if (base < 3) return r < 0.5 ? 'snow' : r < 0.75 ? 'cloudy' : 'clear';
  if (base > 30) return r < 0.72 ? 'clear' : r < 0.9 ? 'mostly' : 'wind';
  if (r < 0.3) return night ? 'clear' : 'clear';
  if (r < 0.46) return 'mostly';
  if (r < 0.62) return 'partly';
  if (r < 0.74) return 'cloudy';
  if (r < 0.86) return 'rain';
  if (r < 0.92) return 'drizzle';
  if (r < 0.97) return 'storm';
  return 'wind';
}

function makeForecast(cityId, seedBump = 0) {
  const city = CITIES.find((c) => c.id === cityId) || CITIES[0];
  const now = new Date();
  const daySeed = Math.floor(now.getTime() / 86_400_000) + seedBump;
  const rand = rng(hash(`${city.id}:${daySeed}`));
  const baseTemp = city.base + seasonOffset(city, now.getMonth());
  const isNight = now.getHours() < 6 || now.getHours() >= 20;
  const condition = conditionFor(rand, { night: isNight, base: baseTemp });
  const current0 = Math.round(baseTemp + (rand() * 6 - 2) + (isNight ? -3 : 2));
  const humidity = Math.round(clamp(city.humid * 100 + (rand() * 22 - 10), 20, 98));

  const hourly = [];
  for (let i = 0; i < 12; i++) {
    const hour = (now.getHours() + i) % 24;
    const daylight = Math.sin(((hour - 6) / 12) * Math.PI);
    const temp = Math.round(baseTemp + 4 * daylight + (rand() * 3 - 1.5));
    const night = hour < 6 || hour >= 20;
    const hCond = conditionFor(rand, { night, base: baseTemp });
    const hInfo = CONDITIONS[hCond] || CONDITIONS.clear;
    hourly.push({
      hour,
      label: i === 0 ? 'Now' : hour === 0 ? '12 AM' : hour < 12 ? `${hour} AM` : hour === 12 ? '12 PM' : `${hour - 12} PM`,
      temp,
      icon: night && hInfo.nightIcon ? hInfo.nightIcon : hInfo.icon,
    });
  }

  const daily = [];
  let minHigh = Infinity;
  let maxHigh = -Infinity;
  for (let i = 0; i < 7; i++) {
    const date = new Date(now.getFullYear(), now.getMonth(), now.getDate() + i);
    const high = Math.round(baseTemp + 5 + (rand() * 6 - 2));
    const low = Math.round(high - 6 - rand() * 4);
    const cond = i === 0 ? condition : conditionFor(rand, { base: baseTemp });
    daily.push({ date, high, low, condition: cond });
    minHigh = Math.min(minHigh, low);
    maxHigh = Math.max(maxHigh, high);
  }

  /* Keep the reading physically consistent with today's range. */
  const current = clamp(current0, daily[0].low, daily[0].high);
  hourly[0].temp = current;
  const cInfo = CONDITIONS[condition] || CONDITIONS.clear;
  hourly[0].icon = isNight && cInfo.nightIcon ? cInfo.nightIcon : cInfo.icon;

  const feels = Math.round(current + (humidity > 70 ? 1 : 0) - (condition === 'wind' ? 2 : 0));
  const wind = Math.round(4 + rand() * 22);
  const uv = Math.round(clamp((10 - Math.abs(now.getMonth() - 6)) * 0.9 + rand() * 2, 0, 11));
  const visibility = Math.round(clamp(16 - (condition === 'fog' ? 9 : 0) - (condition === 'rain' ? 4 : 0) + rand() * 2, 1, 20));
  const pressure = Math.round(1008 + rand() * 22);
  const sunrise = 6 + Math.round(rand() * 0.8 * 10) / 10;
  const sunset = 18 + Math.round(rand() * 1.2 * 10) / 10;

  return {
    city,
    now,
    current,
    condition,
    isNight,
    humidity,
    hourly,
    daily,
    minHigh,
    maxHigh,
    feels,
    wind,
    uv,
    visibility,
    pressure,
    sunrise,
    sunset,
    seedBump,
  };
}

const toDisplay = (c, unit) => unit === 'F' ? Math.round(c * 9 / 5 + 32) : Math.round(c);
const fmtHour = (decimal) => {
  const h = Math.floor(decimal);
  const m = Math.round((decimal - h) * 60);
  const suffix = h >= 12 ? 'PM' : 'AM';
  const hh = h % 12 || 12;
  return `${hh}:${String(m).padStart(2, '0')} ${suffix}`;
};

export function mount(body, ctx) {
  const root = h('div');
  body.append(root);
  root.classList.add('app', 'weather-app');

  let cityId = ctx.params?.city || get('weather.city', 'nova');
  let unit = get('weather.unit', 'C');
  if (!CITIES.some((c) => c.id === cityId)) cityId = 'nova';
  let seedBump = 0;
  let data = makeForecast(cityId, seedBump);
  let scroll = null;

  function applyThemeClass() {
    root.classList.toggle('night', data.isNight);
  }

  function conditionInfo(cond, night = false) {
    const base = CONDITIONS[cond] || CONDITIONS.clear;
    return {
      label: base.label,
      icon: night && base.nightIcon ? base.nightIcon : base.icon,
    };
  }

  function render() {
    data = makeForecast(cityId, seedBump);
    applyThemeClass();
    root.replaceChildren();

    scroll = h('div', { class: 'weather-scroll' });
    root.append(scroll);

    /* Header */
    const cityBtn = h('button', { class: 'wx-city', style: { display: 'flex', alignItems: 'center', gap: '4px' }, title: 'Change city' },
      h('span', { html: icon('map-pin'), style: { display: 'contents' } }),
      h('span', { text: data.city.name }),
      h('span', { html: icon('chevron-down'), style: { display: 'contents' } }),
    );
    cityBtn.addEventListener('click', (e) => {
      showMenu({
        anchor: cityBtn,
        align: 'left',
        items: [
          { header: 'Choose a City' },
          ...CITIES.map((c) => ({
            label: c.name,
            icon: c.id === cityId ? 'check' : 'map-pin',
            action: () => {
              cityId = c.id;
              set('weather.city', cityId);
              render();
              toast({ title: `Weather for ${c.name}`, icon: 'cloud-sun' });
            },
          })),
          { separator: true },
          { label: 'Refresh Forecast', icon: 'refresh', action: refresh },
        ],
      });
    });

    const unitToggle = h('div', { class: 'wx-unit' },
      ['C', 'F'].map((u) => {
        const btn = h('button', { class: unit === u ? 'active' : '', text: `°${u}` });
        btn.addEventListener('click', () => {
          unit = u;
          set('weather.unit', u);
          render();
        });
        return btn;
      }),
    );

    const refreshBtn = h('button', {
      class: 'icon-btn',
      title: 'Refresh',
      html: icon('refresh'),
      style: { color: 'rgba(255,255,255,.8)', width: '24px', height: '24px' },
    });
    refreshBtn.addEventListener('click', refresh);

    const top = h('div', { class: 'weather-top' },
      cityBtn,
      h('span', { class: 'wx-updated', text: 'Updated just now' }),
      h('div', { class: 'wx-spacer' }),
      unitToggle,
      refreshBtn,
    );
    scroll.append(top);

    /* Hero */
    const cond = conditionInfo(data.condition, data.isNight);
    const hero = h('div', { class: 'wx-hero' },
      h('div', { class: 'wx-icon', html: icon(cond.icon) }),
      h('div', { class: 'wx-temp' }, `${toDisplay(data.current, unit)}`, h('sup', { text: `°${unit}` })),
      h('div', { class: 'wx-cond', text: cond.label }),
      h('div', { class: 'wx-range', text: `H:${toDisplay(data.daily[0].high, unit)}°  L:${toDisplay(data.daily[0].low, unit)}°` }),
    );
    scroll.append(hero);

    /* Hourly */
    const hours = h('div', { class: 'wx-card wx-hours' },
      h('div', { class: 'wx-hours-title', text: 'Hourly Forecast' }),
    );
    const hourly = h('div', { class: 'wx-hourly' });
    for (const hour of data.hourly) {
      hourly.append(h('div', { class: 'wx-hour' },
        h('span', { class: 'h-label', text: hour.label }),
        h('span', { html: icon(hour.icon) }),
        h('span', { class: 'h-temp', text: `${toDisplay(hour.temp, unit)}°` }),
      ));
    }
    hours.append(hourly);
    scroll.append(hours);

    /* Daily */
    const daysCard = h('div', { class: 'wx-card wx-days' });
    for (let i = 0; i < data.daily.length; i++) {
      const day = data.daily[i];
      const d = day.date;
      const name = i === 0 ? 'Today' : DOW_NAMES[d.getDay()].slice(0, 3);
      const ci = conditionInfo(day.condition);
      const lowPct = clamp(((day.low - data.minHigh) / Math.max(1, data.maxHigh - data.minHigh)) * 100, 0, 100);
      const highPct = clamp(((day.high - data.minHigh) / Math.max(1, data.maxHigh - data.minHigh)) * 100, 0, 100);
      daysCard.append(h('div', { class: 'wx-day' },
        h('span', { class: 'd-name', text: i === 0 ? 'Today' : DOW_NAMES[d.getDay()] }),
        h('span', { class: 'd-icon', html: icon(ci.icon), title: ci.label }),
        h('span', { class: 'd-low', text: `${toDisplay(day.low, unit)}°` }),
        h('span', { class: 'd-bar' }, h('span', { style: { left: `${lowPct}%`, width: `${Math.max(8, highPct - lowPct)}%` } })),
        h('span', { class: 'd-high', text: `${toDisplay(day.high, unit)}°` }),
      ));
    }
    scroll.append(daysCard);

    /* Details */
    const details = h('div', { class: 'wx-details' });
    const detail = (label, ico, value, small = '') => h('div', { class: 'wx-card wx-detail' },
      h('div', { class: 'wd-label' }, h('span', { html: icon(ico), style: { display: 'contents' } }), h('span', { text: label })),
      h('div', { class: 'wd-value' }, value, small ? h('small', { text: small }) : null),
    );
    details.append(
      detail('Feels Like', 'thermometer', `${toDisplay(data.feels, unit)}°`),
      detail('Humidity', 'droplet', `${data.humidity}%`),
      detail('Wind', 'wind', `${data.wind}`, ' km/h'),
      detail('UV Index', 'sun', `${data.uv}`, data.uv >= 8 ? ' high' : data.uv >= 4 ? ' moderate' : ' low'),
      detail('Visibility', 'eye', `${data.visibility}`, ' km'),
      detail('Pressure', 'gauge', `${data.pressure}`, ' hPa'),
      detail('Sunrise', 'sun', fmtHour(data.sunrise), ''),
      detail('Sunset', 'moon', fmtHour(data.sunset), ''),
    );
    scroll.append(details);

    scroll.append(h('div', { class: 'wx-night', text: 'Sample forecast generated locally · no network access' }));
  }

  function refresh() {
    seedBump += 1;
    render();
    setTimeout(() => {
      const label = scroll?.querySelector('.wx-updated');
      if (label) label.textContent = `Updated ${formatTime(new Date())}`;
    }, 40);
    sounds.click();
  }

  ctx.onParams = (params) => {
    if (params?.city && CITIES.some((c) => c.id === params.city)) {
      cityId = params.city;
      set('weather.city', cityId);
      render();
    }
    if (params?.unit === 'C' || params?.unit === 'F') {
      unit = params.unit;
      set('weather.unit', unit);
      render();
    }
  };

  render();

  return {
    refresh,
    setCity: (id) => {
      if (!CITIES.some((c) => c.id === id)) return false;
      cityId = id;
      set('weather.city', id);
      render();
      return true;
    },
    setUnit: (u) => {
      if (u !== 'C' && u !== 'F') return false;
      unit = u;
      set('weather.unit', u);
      render();
      return true;
    },
    getForecast: () => ({ ...data, city: { ...data.city } }),
    dispose() { /* nothing external */ },
  };
}

/* ------------------------------------------------------------ */

export function menus(win) {
  const api = win.api || {};
  return {
    Location: [
      { label: 'Refresh Forecast', shortcut: '⌘R', icon: 'refresh', action: () => api.refresh?.() },
      { separator: true },
      { label: '°C Celsius', checked: get('weather.unit', 'C') === 'C', action: () => api.setUnit?.('C') },
      { label: '°F Fahrenheit', checked: get('weather.unit', 'C') === 'F', action: () => api.setUnit?.('F') },
      { separator: true },
      { label: 'Close Window', shortcut: '⌘W', action: () => win.ctx.close() },
    ],
    View: CITIES.map((city) => ({
      label: `${city.name}`,
      checked: get('weather.city', 'nova') === city.id,
      action: () => api.setCity?.(city.id),
    })),
    Help: [
      { label: 'About This Forecast', icon: 'info', action: () => {
        showModal({
          title: 'About the Forecast',
          icon: 'cloud-sun',
          width: 400,
          body: `<p>Nova’s Weather app generates a calm, deterministic sample forecast from your chosen city and the current date.</p>
                 <p class="muted">No network requests are made, no location is requested, and no data leaves this tab. It is a design showcase rather than a meteorological service.</p>`,
          actions: [{ label: 'OK', value: true, primary: true }],
        });
      } },
    ],
  };
}
