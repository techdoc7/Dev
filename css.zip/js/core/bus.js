/* ============================================================
   Nova OS — event bus
   ============================================================ */

const listeners = new Map();

export function on(event, fn) {
  if (!listeners.has(event)) listeners.set(event, new Set());
  listeners.get(event).add(fn);
  return () => off(event, fn);
}

export function once(event, fn) {
  const un = on(event, (payload) => { un(); fn(payload); });
  return un;
}

export function off(event, fn) {
  const set = listeners.get(event);
  if (set) {
    set.delete(fn);
    if (!set.size) listeners.delete(event);
  }
}

export function emit(event, payload) {
  const set = listeners.get(event);
  if (!set) return;
  for (const fn of Array.from(set)) {
    try { fn(payload); }
    catch (err) { console.error(`[bus] listener for "${event}" failed`, err); }
  }
}

export const bus = { on, once, off, emit };
export default bus;
