/* ============================================================
   Nova OS — Desktop
   Desktop icons, selection, marquee, drag placement, context
   menus and dropping files from other apps.
   ============================================================ */

import { h, clamp, basename, formatBytes, formatDate, escapeHTML, extname } from '../core/util.js';
import { icon } from '../core/icons.js';
import { getApp, launch } from '../core/registry.js';
import { get, set } from '../core/state.js';
import { fs, HOME, editorFor } from '../core/fs.js';
import { on } from '../core/bus.js';
import { showMenu, showModal, promptDialog, confirmDialog, toast } from '../core/ui.js';
import sounds from '../core/sound.js';

const DESKTOP = `${HOME}/Desktop`;
const LAYOUT_KEY = 'desktop.layout';
const CELL_W = 96;
const CELL_H = 96;

let desktopEl = null;
let iconsEl = null;
let marqueeEl = null;
let items = [];
let selected = new Set();
let layout = {};
let drag = null;
let marquee = null;

/* ------------------------------------------------------------
   Persistence helpers
   ------------------------------------------------------------ */

function loadLayout() {
  try {
    const raw = localStorage.getItem(`nova.${LAYOUT_KEY}`);
    const parsed = raw ? JSON.parse(raw) : {};
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch { return {}; }
}

function saveLayout() {
  try { localStorage.setItem(`nova.${LAYOUT_KEY}`, JSON.stringify(layout)); } catch { /* ignore */ }
}

/* ------------------------------------------------------------
   Entry helpers
   ------------------------------------------------------------ */

function kindOf(entry) {
  if (entry.type === 'dir') return 'Folder';
  if (entry.type === 'app') return 'Application';
  const ext = extname(entry.name);
  if (['md', 'txt', 'log', 'json', 'js', 'ts', 'css', 'html', 'csv'].includes(ext)) return `${ext.toUpperCase()} Document`;
  return 'File';
}

function displayIcon(entry) {
  if (entry.type === 'volume') {
    return `<span class="drive-tile">${icon('hard-drive')}</span>`;
  }
  if (entry.type === 'dir') {
    return `<span class="folder-tile"><span class="folder-shape"></span>${icon('folder')}</span>`;
  }
  if (entry.type === 'app') {
    return `<span class="file-glyph type-app">${icon('app-window')}</span>`;
  }
  const ext = extname(entry.name);
  const glyph = ext === 'md' || ext === 'txt' ? 'file-text'
    : ['js', 'ts', 'json', 'html', 'css'].includes(ext) ? 'file-code'
      : ext === 'csv' ? 'table'
        : 'file';
  return `<span class="file-glyph type-${ext || 'txt'}">${icon(glyph)}</span>`;
}

function volumeEntry() {
  return { type: 'volume', name: 'Nova SSD', path: '/', size: fs.sizeOf('/'), modified: Date.now(), readonly: true };
}

function entries() {
  let list = [];
  try { list = fs.list(DESKTOP); } catch { list = []; }
  const sort = get('desktop.sort', 'name');
  list.sort((a, b) => {
    if (a.type === 'dir' && b.type !== 'dir') return -1;
    if (b.type === 'dir' && a.type !== 'dir') return 1;
    if (sort === 'kind') return kindOf(a).localeCompare(kindOf(b)) || a.name.localeCompare(b.name);
    if (sort === 'date') return b.modified - a.modified;
    return a.name.localeCompare(b.name, undefined, { numeric: true });
  });
  return [...list, volumeEntry()];
}

/* ------------------------------------------------------------
   Layout
   ------------------------------------------------------------ */

function defaultSlot(index) {
  const rect = iconsEl.getBoundingClientRect();
  const rows = Math.max(1, Math.floor((rect.height || window.innerHeight - 160) / CELL_H));
  const col = Math.floor(index / rows);
  const row = index % rows;
  return { right: 12 + col * CELL_W, top: 6 + row * CELL_H };
}

function positionFor(entry, index) {
  const saved = layout[entry.path];
  if (saved && Number.isFinite(saved.right) && Number.isFinite(saved.top)) {
    const rect = iconsEl.getBoundingClientRect();
    return {
      right: clamp(saved.right, 0, Math.max(0, (rect.width || window.innerWidth) - 92)),
      top: clamp(saved.top, 0, Math.max(0, (rect.height || window.innerHeight) - 100)),
    };
  }
  return defaultSlot(index);
}

/* ------------------------------------------------------------
   Selection
   ------------------------------------------------------------ */

function applySelection() {
  for (const item of iconsEl.querySelectorAll('.desk-item')) {
    item.classList.toggle('selected', selected.has(item.dataset.path));
  }
}

function clearSelection() {
  selected.clear();
  applySelection();
}

function selectOnly(path) {
  selected.clear();
  if (path) selected.add(path);
  applySelection();
}

function toggleSelected(path) {
  if (selected.has(path)) selected.delete(path);
  else selected.add(path);
  applySelection();
}

/* ------------------------------------------------------------
   Actions
   ------------------------------------------------------------ */

function openEntry(entry) {
  if (!entry) return;
  if (entry.type === 'dir' || entry.type === 'volume') {
    window.OS?.openApp('finder', { path: entry.path });
    return;
  }
  if (entry.type === 'app') {
    launch(entry.appId);
    return;
  }
  if (editorFor(entry.path)) {
    window.OS?.openApp('editor', { path: entry.path });
    return;
  }
  showModal({
    title: entry.name,
    icon: 'file',
    width: 420,
    body: `<p class="muted">This file type has no preview in Nova.</p>
           <div class="pv-row"><span class="k">Kind</span><span class="v">${escapeHTML(kindOf(entry))}</span></div>
           <div class="pv-row"><span class="k">Size</span><span class="v">${formatBytes(entry.size)}</span></div>
           <div class="pv-row"><span class="k">Where</span><span class="v">${escapeHTML(entry.path)}</span></div>`,
    actions: [{ label: 'Show in Finder', value: 'finder' }, { label: 'OK', value: null, primary: true }],
  }).then((res) => { if (res === 'finder') window.OS?.openApp('finder', { path: DESKTOP }); });
}

async function newFolder() {
  const name = await promptDialog({
    title: 'New Folder',
    message: 'Create a folder on the Desktop.',
    label: 'Name',
    value: 'New Folder',
    confirmLabel: 'Create',
    validate: (v) => {
      const value = String(v || '').trim();
      if (!value) return 'Enter a name.';
      if (value.includes('/')) return 'Names cannot contain a slash.';
      if (fs.exists(`${DESKTOP}/${value}`)) return 'An item with that name already exists.';
      return null;
    },
  });
  if (!name) return;
  try {
    fs.mkdir(`${DESKTOP}/${name}`);
    toast({ title: 'Folder created', text: name, icon: 'folder' });
    sounds.success();
  } catch (err) {
    toast({ title: 'Could not create folder', text: err.message, icon: 'alert' });
  }
}

async function newFile() {
  const name = await promptDialog({
    title: 'New File',
    message: 'Create an empty text file on the Desktop.',
    label: 'Name',
    value: 'Untitled.md',
    confirmLabel: 'Create',
    validate: (v) => {
      const value = String(v || '').trim();
      if (!value) return 'Enter a name.';
      if (value.includes('/')) return 'Names cannot contain a slash.';
      if (!editorFor(value)) return 'Use a text extension such as .md or .txt.';
      if (fs.exists(`${DESKTOP}/${value}`)) return 'An item with that name already exists.';
      return null;
    },
  });
  if (!name) return;
  try {
    fs.writeFile(`${DESKTOP}/${name}`, '');
    toast({ title: 'File created', text: name, icon: 'file-plus' });
    window.OS?.openApp('editor', { path: `${DESKTOP}/${name}` });
  } catch (err) {
    toast({ title: 'Could not create file', text: err.message, icon: 'alert' });
  }
}

async function renameEntry(entry) {
  if (!entry || !entry.path || entry.type === 'volume') return;
  const current = basename(entry.path);
  const next = await promptDialog({
    title: 'Rename',
    label: 'New name',
    value: current,
    confirmLabel: 'Rename',
    validate: (v) => {
      const value = String(v || '').trim();
      if (!value) return 'Enter a name.';
      if (value.includes('/')) return 'Names cannot contain a slash.';
      return null;
    },
  });
  if (!next || next === current) return;
  try {
    fs.rename(entry.path, next);
    toast({ title: 'Renamed', text: `${current} → ${next}`, icon: 'pencil' });
  } catch (err) {
    toast({ title: 'Could not rename', text: err.message, icon: 'alert' });
  }
}

function uniqueName(dirPath, name) {
  if (!fs.exists(`${dirPath}/${name}`)) return name;
  const ext = extname(name);
  const stem = ext ? name.slice(0, -(ext.length + 1)) : name;
  let i = 2;
  while (fs.exists(`${dirPath}/${stem} copy${i > 2 ? ` ${i}` : ''}${ext ? '.' + ext : ''}`)) i += 1;
  return `${stem} copy${i > 2 ? ` ${i}` : ''}${ext ? '.' + ext : ''}`;
}

function duplicateEntry(entry) {
  if (!entry || !entry.path || entry.type === 'volume') return;
  try {
    const target = `${DESKTOP}/${uniqueName(DESKTOP, basename(entry.path))}`;
    fs.copy(entry.path, target);
    toast({ title: 'Duplicated', text: basename(target), icon: 'copy' });
  } catch (err) {
    toast({ title: 'Could not duplicate', text: err.message, icon: 'alert' });
  }
}

async function trashEntry(entry) {
  if (!entry || !entry.path || entry.type === 'volume') return;
  const ok = await confirmDialog({
    title: `Move “${entry.name}” to the Trash?`,
    message: 'You can still find it inside the virtual filesystem under .Trash.',
    confirmLabel: 'Move to Trash',
    danger: true,
    iconName: 'trash',
  });
  if (!ok) return;
  try {
    const trash = `${HOME}/.Trash`;
    try { fs.mkdir(trash); } catch { /* exists */ }
    fs.move(entry.path, `${trash}/${uniqueName(trash, basename(entry.path))}`);
    toast({ title: 'Moved to Trash', text: entry.name, icon: 'trash' });
    sounds.trash?.();
  } catch (err) {
    toast({ title: 'Could not move to Trash', text: err.message, icon: 'alert' });
  }
}

function infoEntry(entry) {
  showModal({
    title: `${entry.name} Info`,
    icon: entry.type === 'dir' ? 'folder' : entry.type === 'volume' ? 'hard-drive' : 'file',
    width: 400,
    body: `
      <div class="pv-row"><span class="k">Kind</span><span class="v">${escapeHTML(kindOf(entry))}</span></div>
      <div class="pv-row"><span class="k">Size</span><span class="v">${formatBytes(entry.size || 0)}</span></div>
      <div class="pv-row"><span class="k">Where</span><span class="v">${escapeHTML(entry.path)}</span></div>
      <div class="pv-row"><span class="k">Modified</span><span class="v">${formatDate(new Date(entry.modified || Date.now()), { full: true })}</span></div>
      ${entry.readonly ? '<p class="muted" style="font-size:11px;margin-top:10px">This item is protected by Nova and cannot be renamed or deleted.</p>' : ''}
    `,
    actions: [{ label: 'OK', value: true, primary: true }],
  });
}

/* ------------------------------------------------------------
   Menus
   ------------------------------------------------------------ */

function itemMenu(entry, x, y) {
  const isVolume = entry.type === 'volume';
  showMenu({
    x,
    y,
    minWidth: 220,
    items: [
      { label: 'Open', icon: entry.type === 'dir' || entry.type === 'volume' ? 'folder-open' : 'app-window', action: () => openEntry(entry) },
      { label: 'Open in Text Editor', icon: 'file-code', disabled: isVolume || entry.type === 'dir' || !editorFor(entry.path), action: () => window.OS?.openApp('editor', { path: entry.path }) },
      { separator: true },
      { label: 'Rename…', icon: 'pencil', shortcut: 'F2', disabled: isVolume, action: () => renameEntry(entry) },
      { label: 'Duplicate', icon: 'copy', shortcut: '⌘D', disabled: isVolume, action: () => duplicateEntry(entry) },
      { separator: true },
      { label: 'Move to Trash', icon: 'trash', shortcut: '⌘⌫', danger: true, disabled: isVolume, action: () => trashEntry(entry) },
      { separator: true },
      { label: 'Get Info', icon: 'info', shortcut: '⌘I', action: () => infoEntry(entry) },
    ],
  });
}

function desktopMenu(x, y) {
  showMenu({
    x,
    y,
    minWidth: 232,
    items: [
      { header: 'Desktop' },
      { label: 'New Folder', icon: 'folder-plus', action: newFolder },
      { label: 'New File', icon: 'file-plus', action: newFile },
      { separator: true },
      { header: 'Sort By' },
      { label: 'Name', checked: get('desktop.sort', 'name') === 'name', action: () => set('desktop.sort', 'name') },
      { label: 'Kind', checked: get('desktop.sort', 'name') === 'kind', action: () => set('desktop.sort', 'kind') },
      { label: 'Date Modified', checked: get('desktop.sort', 'name') === 'date', action: () => set('desktop.sort', 'date') },
      { separator: true },
      { label: 'Clean Up', icon: 'grid', action: () => {
        layout = {};
        saveLayout();
        render();
        toast({ title: 'Desktop cleaned up', icon: 'grid' });
      } },
      { label: 'Show Desktop Icons', icon: 'grid', checked: get('desktop.showIcons', true), action: () => set('desktop.showIcons', !get('desktop.showIcons', true)) },
      { label: 'Change Wallpaper…', icon: 'image', action: () => window.OS?.openApp('settings', { section: 'appearance' }) },
      { separator: true },
      { label: 'Refresh', icon: 'refresh', shortcut: '⌘R', action: () => render() },
    ],
  });
}

/* ------------------------------------------------------------
   Drag + marquee
   ------------------------------------------------------------ */

function startItemPointer(e, entry, node) {
  if (e.button !== 0) return;
  const shift = e.shiftKey || e.metaKey || e.ctrlKey;
  if (shift) toggleSelected(entry.path);
  else if (!selected.has(entry.path)) selectOnly(entry.path);

  const startX = e.clientX;
  const startY = e.clientY;
  const rect = node.getBoundingClientRect();
  const parentRect = iconsEl.getBoundingClientRect();
  const startRight = parentRect.right - rect.right;
  const startTop = rect.top - parentRect.top;
  let moved = false;
  let targetFolder = null;

  drag = { entry, node, path: entry.path };

  const onMove = (ev) => {
    const dx = ev.clientX - startX;
    const dy = ev.clientY - startY;
    if (!moved && Math.hypot(dx, dy) < 5) return;
    if (!moved) {
      moved = true;
      node.classList.add('dragging');
    }
    if (entry.type === 'volume') return;
    const right = clamp(startRight - dx, 0, parentRect.width - 92);
    const top = clamp(startTop + dy, 0, parentRect.height - 100);
    node.style.right = `${right}px`;
    node.style.top = `${top}px`;

    // highlight a folder under the pointer
    node.style.pointerEvents = 'none';
    const under = document.elementFromPoint(ev.clientX, ev.clientY);
    node.style.pointerEvents = '';
    const folderNode = under?.closest?.('.desk-item');
    let nextTarget = null;
    if (folderNode && folderNode !== node) {
      const targetPath = folderNode.dataset.path;
      try {
        const stat = fs.stat(targetPath);
        if (stat.type === 'dir' && !targetPath.startsWith(entry.path) && targetPath !== entry.path) nextTarget = folderNode;
      } catch { /* not a folder */ }
    }
    if (targetFolder && targetFolder !== nextTarget) targetFolder.style.outline = '';
    targetFolder = nextTarget;
    if (targetFolder) targetFolder.style.outline = '2px solid var(--accent)';
  };

  const onUp = (ev) => {
    document.removeEventListener('pointermove', onMove);
    document.removeEventListener('pointerup', onUp);
    drag = null;
    if (targetFolder) targetFolder.style.outline = '';
    node.classList.remove('dragging');

    if (!moved) {
      if (ev.shiftKey || ev.metaKey || ev.ctrlKey) return;
      if (Date.now() - (node._lastClick || 0) < 340) {
        node._lastClick = 0;
        openEntry(entry);
        return;
      }
      node._lastClick = Date.now();
      return;
    }

    if (entry.type === 'volume') return;

    if (targetFolder) {
      const dest = `${targetFolder.dataset.path}/${basename(entry.path)}`;
      try {
        fs.move(entry.path, dest);
        toast({ title: 'Moved', text: `${entry.name} → ${targetFolder.querySelector('.desk-label').textContent}`, icon: 'folder' });
      } catch (err) {
        toast({ title: 'Could not move item', text: err.message, icon: 'alert' });
      }
      return;
    }

    const rectNow = node.getBoundingClientRect();
    layout[entry.path] = {
      right: Math.round(parentRect.right - rectNow.right),
      top: Math.round(rectNow.top - parentRect.top),
    };
    saveLayout();
  };

  document.addEventListener('pointermove', onMove);
  document.addEventListener('pointerup', onUp);
}

function startMarquee(e) {
  if (e.button !== 0) return;
  if (e.target.closest('.desk-item')) return;

  const desktopRect = desktopEl.getBoundingClientRect();
  const startX = e.clientX;
  const startY = e.clientY;
  const additive = e.shiftKey || e.metaKey || e.ctrlKey;
  const base = additive ? new Set(selected) : new Set();
  if (!additive) clearSelection();

  let active = false;
  marquee = {};

  const onMove = (ev) => {
    const dx = ev.clientX - startX;
    const dy = ev.clientY - startY;
    if (!active && Math.hypot(dx, dy) < 4) return;
    active = true;
    const x = Math.min(startX, ev.clientX) - desktopRect.left;
    const y = Math.min(startY, ev.clientY) - desktopRect.top;
    const w = Math.abs(dx);
    const ht = Math.abs(dy);
    marqueeEl.hidden = false;
    Object.assign(marqueeEl.style, {
      left: `${x}px`, top: `${y}px`, width: `${w}px`, height: `${ht}px`,
    });
    const rect = { left: Math.min(startX, ev.clientX), right: Math.max(startX, ev.clientX), top: Math.min(startY, ev.clientY), bottom: Math.max(startY, ev.clientY) };
    selected = new Set(base);
    for (const node of iconsEl.querySelectorAll('.desk-item')) {
      const r = node.getBoundingClientRect();
      const hit = !(r.right < rect.left || r.left > rect.right || r.bottom < rect.top || r.top > rect.bottom);
      if (hit) selected.add(node.dataset.path);
    }
    applySelection();
  };

  const onUp = () => {
    document.removeEventListener('pointermove', onMove);
    document.removeEventListener('pointerup', onUp);
    marquee = null;
    marqueeEl.hidden = true;
    marqueeEl.style.width = '0px';
    marqueeEl.style.height = '0px';
  };

  document.addEventListener('pointermove', onMove);
  document.addEventListener('pointerup', onUp);
}

/* ------------------------------------------------------------
   Rendering
   ------------------------------------------------------------ */

export function renderDesktop() {
  if (!iconsEl) return;
  const show = get('desktop.showIcons', true);
  iconsEl.style.display = show ? '' : 'none';
  if (!show) return;

  const previous = new Set(selected);
  iconsEl.replaceChildren();
  items = entries();

  items.forEach((entry, index) => {
    const pos = positionFor(entry, index);
    const node = h('div', {
      class: `desk-item${entry.type === 'volume' ? ' volume' : ''}`,
      dataset: { path: entry.path, kind: entry.type },
      tabindex: '0',
      title: entry.name,
      style: { right: `${pos.right}px`, top: `${pos.top}px` },
    },
      h('div', { class: 'desk-icon', html: displayIcon(entry) }),
      h('div', { class: 'desk-label', text: entry.name }),
    );

    if (previous.has(entry.path)) node.classList.add('selected');

    node.addEventListener('pointerdown', (e) => startItemPointer(e, entry, node));
    node.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!selected.has(entry.path)) selectOnly(entry.path);
      itemMenu(entry, e.clientX, e.clientY);
    });
    node.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); openEntry(entry); }
      else if (e.key === 'F2') { e.preventDefault(); renameEntry(entry); }
      else if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); trashEntry(entry); }
    });

    iconsEl.append(node);
  });
}

/* ------------------------------------------------------------
   Init
   ------------------------------------------------------------ */

export function initDesktop() {
  desktopEl = document.getElementById('desktop');
  iconsEl = document.getElementById('desktop-icons');
  marqueeEl = document.getElementById('marquee');
  if (!desktopEl || !iconsEl) return { refresh: () => {} };

  layout = loadLayout();

  desktopEl.addEventListener('pointerdown', startMarquee);
  desktopEl.addEventListener('contextmenu', (e) => {
    if (e.target.closest('.desk-item')) return;
    e.preventDefault();
    clearSelection();
    desktopMenu(e.clientX, e.clientY);
  });

  // Clicking empty desktop clears the selection
  desktopEl.addEventListener('pointerdown', (e) => {
    if (!e.target.closest('.desk-item') && !e.shiftKey) clearSelection();
  });

  // Drop files dragged from Finder
  desktopEl.addEventListener('dragover', (e) => {
    if (!e.dataTransfer?.types?.includes('text/nova-path')) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
  });
  desktopEl.addEventListener('drop', (e) => {
    const source = e.dataTransfer?.getData('text/nova-path');
    if (!source) return;
    e.preventDefault();
    try {
      const name = uniqueName(DESKTOP, basename(source));
      fs.copy(source, `${DESKTOP}/${name}`);
      toast({ title: 'Copied to Desktop', text: name, icon: 'monitor' });
    } catch (err) {
      toast({ title: 'Could not copy to Desktop', text: err.message, icon: 'alert' });
    }
  });

  // Keyboard
  document.addEventListener('keydown', (e) => {
    const target = e.target;
    if (target && (target.closest('input, textarea, select, [contenteditable="true"]'))) return;
    if (document.querySelector('.modal-backdrop, .spotlight-backdrop')) return;
    const active = document.activeElement;
    const onDesktop = !active || active === document.body || active === desktopEl || active === iconsEl
      || (active.closest && active.closest('#desktop-icons'));
    if (!onDesktop) return;
    if (e.key === 'Escape') { clearSelection(); return; }
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'a') {
      e.preventDefault();
      selected = new Set(items.map((entry) => entry.path));
      applySelection();
    }
  });

  const unsubs = [
    on('fs:change', () => renderDesktop()),
    on('settings:change', ({ path }) => {
      if (!path || path === '*' || path.startsWith('desktop')) renderDesktop();
    }),
    on('window:close', () => { /* no-op, keeps desktop in sync */ }),
  ];

  window.addEventListener('resize', () => renderDesktop());

  renderDesktop();

  return {
    refresh: renderDesktop,
    clearSelection,
    dispose() { unsubs.forEach((fn) => fn()); },
  };
}

export default { initDesktop, renderDesktop };
