/* ============================================================
   Nova OS — Dock
   A magnifying, reorderable dock with running indicators,
   context menus and auto-hide.
   ============================================================ */

import { h, clamp } from '../core/util.js';
import { getApp } from '../core/registry.js';
import { get, set, DEFAULT_DOCK } from '../core/state.js';
import { on } from '../core/bus.js';
import wm from '../core/windowManager.js';
import { appIcon, icon } from '../core/icons.js';
import { showMenu, toast } from '../core/ui.js';
import sounds from '../core/sound.js';

const MAX_SCALE = 1.44;

let layer = null;
let dockEl = null;
let hotzone = null;
let items = [];
let dragId = null;
let hideTimer = null;
let raf = 0;

const buildOrder = () => {
  const pinned = get('dock.items', DEFAULT_DOCK);
  const list = Array.isArray(pinned) ? pinned.filter((id) => getApp(id)) : [];
  return list.length ? list : [...DEFAULT_DOCK];
};

function ping() {
  sounds.click();
}

/* ------------------------------------------------------------
   Rendering
   ------------------------------------------------------------ */

function createItem(appId, { extra = false } = {}) {
  const app = getApp(appId);
  if (!app) return null;

  const iconWrap = h('div', { class: 'dock-icon-wrap', html: appIcon(appId) });
  const dot = h('span', { class: 'dock-dot' });
  const tip = h('div', { class: 'dock-tip', text: app.name });

  const item = h('div', {
    class: 'dock-item',
    dataset: { app: appId },
    role: 'button',
    tabindex: '0',
    'aria-label': app.name,
    title: '',
  }, tip, iconWrap, dot);

  item.addEventListener('click', (e) => {
    if (item.dataset.moved === '1') { delete item.dataset.moved; return; }
    if (e.metaKey || e.ctrlKey) {
      launch(appId, true);
      return;
    }
    activateApp(appId);
  });

  item.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); activateApp(appId); }
  });

  item.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    e.stopPropagation();
    openItemMenu(appId, item, extra);
  });

  if (!extra) {
    item.draggable = true;
    item.addEventListener('dragstart', (e) => {
      dragId = appId;
      item.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
      try { e.dataTransfer.setData('text/nova-dock', appId); } catch { /* ignore */ }
      e.dataTransfer.setData('text/plain', appId);
    });
    item.addEventListener('dragend', () => {
      dragId = null;
      item.classList.remove('dragging');
      clearDropMarks();
    });
  }

  item.addEventListener('dragover', (e) => {
    if (!dragId || extra) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    const r = item.getBoundingClientRect();
    const vertical = layer.classList.contains('left') || layer.classList.contains('right');
    const after = vertical ? (e.clientY - r.top) > r.height / 2 : (e.clientX - r.left) > r.width / 2;
    clearDropMarks();
    item.classList.add(after ? 'drop-after' : 'drop-before');
  });
  item.addEventListener('dragleave', () => {
    item.classList.remove('drop-before', 'drop-after');
  });
  item.addEventListener('drop', (e) => {
    if (!dragId || extra) return;
    e.preventDefault();
    const moving = dragId;
    dragId = null;
    const vertical = layer.classList.contains('left') || layer.classList.contains('right');
    const r = item.getBoundingClientRect();
    const after = vertical ? (e.clientY - r.top) > r.height / 2 : (e.clientX - r.left) > r.width / 2;
    const order = buildOrder().filter((id) => id !== moving);
    const targetIndex = order.indexOf(appId);
    if (targetIndex < 0) return;
    order.splice(after ? targetIndex + 1 : targetIndex, 0, moving);
    set('dock.items', order);
    toast({ title: 'Dock rearranged', text: getApp(moving)?.name || moving, icon: 'layout' });
  });

  return item;
}

function clearDropMarks() {
  if (!dockEl) return;
  dockEl.querySelectorAll('.dock-item').forEach((n) => n.classList.remove('drop-before', 'drop-after'));
}

function render() {
  if (!dockEl) return;
  const order = buildOrder();
  const running = runningApps();

  dockEl.replaceChildren();
  items = [];

  order.forEach((appId, index) => {
    const item = createItem(appId);
    if (!item) return;
    dockEl.append(item);
    items.push(item);
  });

  const extras = get('dock.showRecents', true)
    ? running.filter((id) => !order.includes(id))
    : [];

  if (extras.length) {
    dockEl.append(h('div', { class: 'dock-sep' }));
    for (const appId of extras) {
      const item = createItem(appId, { extra: true });
      if (item) { dockEl.append(item); items.push(item); }
    }
  }

  applyPosition();
  updateRunning();
  if (get('dock.magnification', true)) dockEl.classList.add('magnify');
  else dockEl.classList.remove('magnify');
  dockEl.style.transform = '';
}

function applyPosition() {
  if (!layer) return;
  const pos = get('dock.position', 'bottom');
  layer.classList.remove('left', 'right', 'bottom');
  if (pos === 'left' || pos === 'right') layer.classList.add(pos);
  layer.classList.toggle('autohide', !!get('dock.autohide', false));
  if (!get('dock.autohide', false)) layer.classList.remove('revealed');
}

/* ------------------------------------------------------------
   Running state
   ------------------------------------------------------------ */

function runningApps() {
  const list = wm.getWindows();
  const seen = [];
  for (const win of list) {
    if (!seen.includes(win.appId)) seen.push(win.appId);
  }
  return seen;
}

function updateRunning() {
  if (!dockEl) return;
  const wins = wm.getWindows();
  for (const item of dockEl.querySelectorAll('.dock-item')) {
    const appId = item.dataset.app;
    const appWins = wins.filter((w) => w.appId === appId);
    const minimized = appWins.length > 0 && appWins.every((w) => w.state === 'minimized');
    item.classList.toggle('running', appWins.length > 0);
    item.classList.toggle('minimized', minimized);
    item.setAttribute('aria-label', `${getApp(appId)?.name || appId}${appWins.length ? ' — running' : ''}`);
  }
}

/* ------------------------------------------------------------
   Actions
   ------------------------------------------------------------ */

function launch(appId, allowMultiple = false) {
  const item = dockEl.querySelector(`.dock-item[data-app="${appId}"]`);
  bounce(item);
  const app = getApp(appId);
  try {
    const wins = wm.getWindowsForApp(appId);
    if (wins.length && !allowMultiple && app?.singleton) {
      wm.focusWindow(wins[0].id);
      return wins[0];
    }
    return wm.createWindow({
      appId,
      app,
      title: app?.name || appId,
      width: app?.defaultSize?.w,
      height: app?.defaultSize?.h,
      minWidth: app?.minSize?.w,
      minHeight: app?.minSize?.h,
      singleton: app?.singleton || false,
      center: true,
    });
  } catch (err) {
    toast({ title: 'Could not open app', text: err.message, icon: 'alert' });
    return null;
  }
}

function activateApp(appId) {
  const wins = wm.getWindowsForApp(appId);
  if (!wins.length) {
    ping();
    launch(appId);
    return;
  }
  const minimized = wins.filter((w) => w.state === 'minimized');
  if (minimized.length === wins.length) {
    ping();
    wm.focusWindow(minimized[0].id);
    bounce(dockEl.querySelector(`.dock-item[data-app="${appId}"]`));
    return;
  }
  const active = wm.getActiveWindow();
  if (active && active.appId === appId) {
    // Cycle through the app's visible windows
    const visible = wins.filter((w) => w.state !== 'minimized');
    if (visible.length > 1) {
      const sorted = visible.sort((a, b) => Number(b.el.style.zIndex) - Number(a.el.style.zIndex));
      const next = sorted[1] || sorted[0];
      wm.focusWindow(next.id);
      return;
    }
  }
  const visible = wins.filter((w) => w.state !== 'minimized');
  const top = visible.sort((a, b) => Number(b.el.style.zIndex) - Number(a.el.style.zIndex))[0];
  if (top) { ping(); wm.focusWindow(top.id); }
}

function bounce(item) {
  if (!item) return;
  item.classList.remove('bouncing');
  void item.offsetWidth;
  item.classList.add('bouncing');
  const done = () => { item.classList.remove('bouncing'); item.removeEventListener('animationend', done); };
  item.addEventListener('animationend', done);
  setTimeout(done, 900);
}

function openItemMenu(appId, item, extra) {
  const app = getApp(appId);
  if (!app) return;
  const wins = wm.getWindowsForApp(appId);
  const pinned = buildOrder().includes(appId);

  const windowItems = wins.slice(0, 6).map((win) => ({
    label: win.title || app.name,
    icon: win.state === 'minimized' ? 'minus' : 'app-window',
    checked: wm.getActiveWindow()?.id === win.id,
    action: () => wm.focusWindow(win.id),
  }));

  showMenu({
    anchor: item,
    align: 'center',
    minWidth: 220,
    items: [
      { header: app.name },
      { label: wins.length ? 'Show' : 'Open', icon: 'app-window', action: () => activateApp(appId) },
      { label: 'New Window', icon: 'plus', disabled: !!app.singleton, action: () => launch(appId, true) },
      ...(windowItems.length ? [{ separator: true }, ...windowItems] : []),
      { separator: true },
      {
        label: pinned ? 'Remove from Dock' : 'Keep in Dock',
        icon: pinned ? 'x' : 'plus',
        action: () => {
          const order = buildOrder();
          if (pinned) {
            if (order.length <= 1) { toast({ title: 'Keep at least one app', icon: 'alert' }); return; }
            set('dock.items', order.filter((id) => id !== appId));
          } else {
            set('dock.items', [...order, appId]);
          }
          toast({ title: pinned ? 'Removed from Dock' : 'Kept in Dock', text: app.name, icon: 'layout' });
        },
      },
      { separator: true },
      {
        label: 'Quit',
        icon: 'power',
        shortcut: '⌘Q',
        danger: true,
        disabled: !wins.length,
        action: () => {
          wm.closeAllForApp(appId);
          toast({ title: `Quit ${app.name}`, icon: 'power' });
        },
      },
    ],
  });
}

/* ------------------------------------------------------------
   Magnification
   ------------------------------------------------------------ */

function magnify(clientX, clientY) {
  if (!dockEl || !get('dock.magnification', true)) return;
  const vertical = layer.classList.contains('left') || layer.classList.contains('right');
  const nodes = Array.from(dockEl.querySelectorAll('.dock-item'));
  for (const node of nodes) {
    const r = node.getBoundingClientRect();
    const center = vertical ? r.top + r.height / 2 : r.left + r.width / 2;
    const pointer = vertical ? clientY : clientX;
    const dist = Math.abs(pointer - center);
    const falloff = 92;
    const scale = 1 + (MAX_SCALE - 1) * Math.exp(-Math.pow(dist / falloff, 2));
    const lift = vertical ? 0 : -(scale - 1) * 22;
    const shift = vertical ? (scale - 1) * 10 : 0;
    node.style.transform = `translate(${shift}px, ${lift}px) scale(${scale})`;
    node.style.zIndex = String(Math.round(scale * 10));
  }
}

function resetMagnify() {
  if (!dockEl) return;
  dockEl.querySelectorAll('.dock-item').forEach((node) => {
    node.style.transform = '';
    node.style.zIndex = '';
  });
}

function onPointerMove(e) {
  if (raf) return;
  raf = requestAnimationFrame(() => {
    raf = 0;
    magnify(e.clientX, e.clientY);
  });
}

/* ------------------------------------------------------------
   Auto-hide
   ------------------------------------------------------------ */

function reveal() {
  if (!layer) return;
  clearTimeout(hideTimer);
  layer.classList.add('revealed');
}

function scheduleHide() {
  if (!layer || !get('dock.autohide', false)) return;
  clearTimeout(hideTimer);
  hideTimer = setTimeout(() => {
    if (!dockEl.matches(':hover')) layer.classList.remove('revealed');
  }, 420);
}

/* ------------------------------------------------------------
   Init
   ------------------------------------------------------------ */

export function initDock() {
  layer = document.getElementById('dock-layer');
  dockEl = document.getElementById('dock');
  hotzone = document.getElementById('dock-hotzone');
  if (!layer || !dockEl) return { refresh: () => {} };

  dockEl.classList.add('magnify');
  dockEl.addEventListener('pointermove', onPointerMove);
  dockEl.addEventListener('pointerleave', () => { resetMagnify(); scheduleHide(); });
  dockEl.addEventListener('pointerdown', () => reveal());

  if (hotzone) {
    hotzone.addEventListener('pointerenter', reveal);
    hotzone.addEventListener('pointerdown', reveal);
  }
  layer.addEventListener('pointerenter', reveal);
  layer.addEventListener('pointerleave', scheduleHide);

  // Close open menus when the dock re-renders
  const unsubs = [
    on('window:open', updateRunning),
    on('window:close', updateRunning),
    on('window:state', updateRunning),
    on('settings:change', ({ path }) => {
      if (path === '*' || path.startsWith('dock')) {
        render();
        applyPosition();
      }
      if (path === '*' || path === 'dock.magnification') {
        dockEl.classList.toggle('magnify', !!get('dock.magnification', true));
        resetMagnify();
      }
    }),
    on('os:transfer-complete', updateRunning),
  ];

  // Keep tooltips from remaining stale after window titles change
  unsubs.push(on('window:title', () => { /* tooltip is the app name */ }));

  render();
  applyPosition();

  // Strip any inline transform left over after a drag
  dockEl.addEventListener('dragend', resetMagnify);

  return {
    refresh: render,
    getItems: () => items.slice(),
    dispose() { unsubs.forEach((fn) => fn()); },
  };
}

export default { initDock };
