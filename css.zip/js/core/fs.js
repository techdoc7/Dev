/* ============================================================
   Nova OS — virtual filesystem
   A sandboxed tree persisted in localStorage. Nothing here touches
   the host filesystem.
   ============================================================ */

import { load, save } from './storage.js';
import { emit } from './bus.js';
import { basename, dirname, extname } from './util.js';

export const HOME = '/Users/nova';
export const WORKSPACE = '/Users/nova/Workspace';
export const ROOT = '/';
export const SYSTEM_DIR = '/System';
export const APPLICATIONS = '/Applications';

const FS_VERSION = 3;
const PROTECTED = new Set(['/', '/Users', HOME, SYSTEM_DIR, APPLICATIONS]);

export class FSError extends Error {
  constructor(message, code = 'EINVAL') {
    super(message);
    this.name = 'FSError';
    this.code = code;
  }
}

const now = () => Date.now();

function dir(name, children = [], extra = {}) {
  return { type: 'dir', name, children, created: now(), modified: now(), ...extra };
}
function file(name, content = '', extra = {}) {
  return { type: 'file', name, content, created: now(), modified: now(), size: content.length, ...extra };
}
function app(name, appId) {
  return { type: 'app', name, appId, created: now(), modified: now(), size: 0 };
}

const WELCOME = [
  '# Welcome to Nova',
  '',
  'You are running a complete desktop environment inside your browser.',
  'Everything you create here lives in a virtual, sandboxed filesystem — it',
  'never touches your real computer.',
  '',
  '## Things to try',
  '',
  '1. Open Terminal from the Dock and type `neofetch`.',
  '2. Use the Browser to visit a site that allows embedding.',
  '3. Create a note, then find it under Documents after exporting? No — Notes',
  '   has its own database, but files you make in the Text Editor live here.',
  '4. Right-click the desktop to change the wallpaper.',
  '5. Press Cmd/Ctrl + Space for Spotlight.',
  '',
  '## Working directory',
  '',
  'Automation and AI agents should use `/Users/nova/Workspace`. That is the',
  'authorized sandboxed working directory for this OS. Paths that try to climb',
  'above the filesystem root are rejected.',
  '',
  'Enjoy your new desktop.',
].join('\n');

const IDEAS = [
  '# Project ideas',
  '',
  '- A tiny synthesizer that runs entirely in the browser',
  '- Visualise the virtual filesystem as a solar system',
  '- A focus timer that dims every window except the active one',
  '- A collaborative scratchpad using the OS automation API',
  '',
  '## Notes on the OS',
  '',
  'The window manager handles z-index, focus, minimizing and resizing.',
  'Every app is a module that mounts into a window body. The OS API is the',
  'only supported way for automation to drive the desktop.',
].join('\n');

const BUDGET = [
  'category,planned,actual',
  'Design,1200,1180',
  'Engineering,3400,3520',
  'Infrastructure,420,398',
  'Marketing,800,640',
  'Coffee,90,142',
].join('\n');

const README = [
  '# Nova Sample Project',
  '',
  'This folder exists so the terminal, editor and filesystem have something',
  'real to work with.',
  '',
  'Try:',
  '',
  '    cd ~/Projects/nova-sample',
  '    ls -l',
  '    cat README.md',
  '',
  'Files are stored in localStorage, so they survive a reload.',
].join('\n');

const MAIN_JS = [
  "import { createApp } from './core.js';",
  '',
  'const app = createApp({',
  "  name: 'Sample',",
  '  theme: { accent: "#0a84ff", radius: 12 },',
  '});',
  '',
  'export function greet(name) {',
  '  const message = `Hello, ${name}!`;',
  '  return message;',
  '}',
  '',
  'app.start();',
].join('\n');

const STYLES_CSS = [
  ':root {',
  '  --accent: #0a84ff;',
  '  --radius: 12px;',
  '}',
  '',
  '.card {',
  '  border-radius: var(--radius);',
  '  background: rgba(255, 255, 255, 0.08);',
  '  padding: 16px 18px;',
  '  box-shadow: 0 12px 30px -18px rgba(0, 0, 0, 0.5);',
  '}',
].join('\n');

const NOTES_MD = [
  '# Scratchpad',
  '',
  'Meeting on Thursday. Bring the roadmap and the updated metrics.',
  '',
  '- [x] Draft the outline',
  '- [ ] Review with the team',
  '- [ ] Ship the prototype',
].join('\n');

const ABOUT_TXT = [
  'Nova OS',
  'Version 1.0.0 "Aurora"',
  '',
  'A browser-based desktop environment built with HTML, CSS and JavaScript.',
  '',
  'This system directory is read-only. Everything here is virtual.',
].join('\n');

const RELEASE = [
  '# Nova OS 1.0.0',
  '',
  'The first release of the Nova desktop environment.',
  '',
  '## Highlights',
  '',
  '- Window manager with dragging, resizing, snapping and focus handling',
  '- Finder, Files, Browser, Terminal, Notes, Calculator, Calendar, Settings,',
  '  Text Editor, App Store and Weather',
  '- A sandboxed virtual filesystem with path traversal protection',
  '- A documented automation API exposed as window.OS',
  '',
  '## Known limitations',
  '',
  'Some websites refuse to be embedded in a frame. Nova never tries to bypass',
  'their security headers; open those sites in your real browser instead.',
].join('\n');

function seed() {
  const t = now();
  const ago = (mins) => t - mins * 60_000;

  return {
    _version: FS_VERSION,
    type: 'dir',
    name: '/',
    created: ago(5000),
    modified: t,
    children: [
      dir('Applications', [
        app('Finder.app', 'finder'),
        app('Browser.app', 'browser'),
        app('Terminal.app', 'terminal'),
        app('Files.app', 'files'),
        app('Notes.app', 'notes'),
        app('Calculator.app', 'calculator'),
        app('Calendar.app', 'calendar'),
        app('Text Editor.app', 'editor'),
        app('App Store.app', 'appstore'),
        app('Settings.app', 'settings'),
        app('Weather.app', 'weather'),
      ], { readonly: true }),
      dir('System', [
        file('About.txt', ABOUT_TXT, { readonly: true, modified: ago(3000) }),
        file('Release Notes.md', RELEASE, { readonly: true, modified: ago(3000) }),
      ], { readonly: true }),
      dir('Users', [
        dir('nova', [
          dir('Desktop', [
            file('Welcome.md', WELCOME, { modified: ago(28) }),
          ]),
          dir('Documents', [
            file('Ideas.md', IDEAS, { modified: ago(180) }),
            file('Scratchpad.md', NOTES_MD, { modified: ago(1400) }),
            file('Budget.csv', BUDGET, { modified: ago(2600) }),
          ]),
          dir('Downloads', []),
          dir('Projects', [
            dir('nova-sample', [
              file('README.md', README, { modified: ago(320) }),
              dir('src', [
                file('main.js', MAIN_JS, { modified: ago(340) }),
                file('styles.css', STYLES_CSS, { modified: ago(350) }),
              ]),
            ]),
          ]),
          dir('Pictures', [
            dir('Wallpapers', [
              file('README.txt', 'Wallpapers in Nova are rendered with CSS gradients.\nNo image files are required, which keeps the OS fully self-contained.', { modified: ago(4000) }),
            ]),
          ]),
          dir('Music', []),
          dir('Workspace', [
            file('README.md', [
              '# Workspace',
              '',
              'This is the authorized working directory for automation and AI agents.',
              'Create files here, read them back, and keep experiments contained.',
            ].join('\n'), { modified: ago(60) }),
            dir('sandbox', []),
          ]),
        ], { created: ago(5000) }),
      ], { created: ago(5000) }),
    ],
  };
}

function validName(name) {
  if (typeof name !== 'string') return false;
  if (!name.length || name.length > 120) return false;
  if (name === '.' || name === '..') return false;
  return !/[\\/\0]/.test(name);
}

export class VirtualFS {
  constructor() {
    const stored = load('fs', null);
    if (stored && stored._version === FS_VERSION && stored.type === 'dir') {
      this.root = stored;
    } else {
      this.root = seed();
      this.persistNow();
    }
    this.timer = null;
  }

  persistNow() {
    this.root._version = FS_VERSION;
    save('fs', this.root);
  }

  persist() {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.persistNow(), 140);
  }

  changed(path, type = 'change') {
    this.persist();
    emit('fs:change', { path, type });
  }

  /* ---------- path helpers ---------- */

  normalize(p, cwd = HOME) {
    if (p === undefined || p === null || p === '') return cwd;
    let value = String(p).replace(/\\/g, '/');
    if (!value.startsWith('/')) value = `${cwd}/${value}`;
    const parts = [];
    for (const seg of value.split('/')) {
      if (!seg || seg === '.') continue;
      if (seg === '..') {
        if (!parts.length) throw new FSError('Permission denied: path escapes the filesystem root', 'EACCES');
        parts.pop();
        continue;
      }
      if (seg.includes('\0') || seg.length > 255) throw new FSError('Invalid path', 'EINVAL');
      parts.push(seg);
    }
    return '/' + parts.join('/');
  }

  #node(path) {
    if (path === '/') return this.root;
    const parts = path.split('/').filter(Boolean);
    let cur = this.root;
    for (const part of parts) {
      if (!cur || cur.type !== 'dir') return null;
      const next = (cur.children || []).find((c) => c.name === part);
      if (!next) return null;
      cur = next;
    }
    return cur;
  }

  node(path, cwd = HOME) {
    return this.#node(this.normalize(path, cwd));
  }

  exists(path, cwd = HOME) {
    return !!this.node(path, cwd);
  }

  isDir(path, cwd = HOME) {
    const n = this.node(path, cwd);
    return !!n && n.type === 'dir';
  }

  isProtected(path) {
    return PROTECTED.has(path);
  }

  #nodeFromRoot(path) {
    return this.#node(path);
  }

  /* ---------- reads ---------- */

  list(path = HOME, cwd = HOME) {
    const full = this.normalize(path, cwd);
    const node = this.#node(full);
    if (!node) throw new FSError(`No such file or directory: ${full}`, 'ENOENT');
    if (node.type !== 'dir') throw new FSError(`Not a directory: ${full}`, 'ENOTDIR');
    return (node.children || [])
      .map((child) => this.statParts(full, child))
      .sort((a, b) => {
        if ((a.type === 'dir') !== (b.type === 'dir')) return a.type === 'dir' ? -1 : 1;
        return a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' });
      });
  }

  statParts(parentPath, child) {
    const path = parentPath === '/' ? `/${child.name}` : `${parentPath}/${child.name}`;
    return {
      name: child.name,
      path,
      type: child.type,
      appId: child.appId,
      readonly: !!child.readonly,
      size: child.type === 'dir' ? this.sizeOfNode(child) : (child.content ? child.content.length : 0),
      created: child.created || child.modified || now(),
      modified: child.modified || child.created || now(),
      kind: kindOf(child),
    };
  }

  stat(path, cwd = HOME) {
    const full = this.normalize(path, cwd);
    const node = this.#node(full);
    if (!node) throw new FSError(`No such file or directory: ${full}`, 'ENOENT');
    if (full === '/') {
      return { name: '/', path: '/', type: 'dir', readonly: false, size: this.sizeOfNode(node), created: node.created, modified: node.modified, kind: 'Volume' };
    }
    return this.statParts(dirname(full), node);
  }

  readFile(path, cwd = HOME) {
    const full = this.normalize(path, cwd);
    const node = this.#node(full);
    if (!node) throw new FSError(`No such file or directory: ${full}`, 'ENOENT');
    if (node.type === 'dir') throw new FSError(`Is a directory: ${full}`, 'EISDIR');
    if (node.type === 'app') throw new FSError(`Cannot read application bundle: ${full}`, 'EISDIR');
    return node.content ?? '';
  }

  readJSON(path, cwd = HOME) {
    return JSON.parse(this.readFile(path, cwd));
  }

  search(query, from = HOME) {
    const q = String(query || '').toLowerCase().trim();
    if (!q) return [];
    const start = this.normalize(from);
    const results = [];
    const walk = (node, path, depth) => {
      if (results.length >= 120 || depth > 12) return;
      for (const child of node.children || []) {
        const childPath = path === '/' ? `/${child.name}` : `${path}/${child.name}`;
        if (child.name.toLowerCase().includes(q)) {
          results.push(this.statParts(path, child));
        }
        if (child.type === 'dir') walk(child, childPath, depth + 1);
      }
    };
    const rootNode = this.#node(start);
    if (!rootNode) throw new FSError(`No such file or directory: ${start}`, 'ENOENT');
    // include direct children of start, then recurse
    walk(rootNode, start, 0);
    return results;
  }

  sizeOfNode(node) {
    if (!node) return 0;
    if (node.type === 'dir') return (node.children || []).reduce((sum, c) => sum + this.sizeOfNode(c), 0);
    return node.content ? new Blob([node.content]).size : 0;
  }

  sizeOf(path, cwd = HOME) {
    const n = this.node(path, cwd);
    return n ? this.sizeOfNode(n) : 0;
  }

  tree(path = HOME, cwd = HOME, maxDepth = 4) {
    const full = this.normalize(path, cwd);
    const node = this.#node(full);
    if (!node) throw new FSError(`No such file or directory: ${full}`, 'ENOENT');
    const lines = [full];
    const walk = (n, prefix, depth) => {
      if (depth >= maxDepth) return;
      const kids = (n.children || []).slice().sort((a, b) => {
        if ((a.type === 'dir') !== (b.type === 'dir')) return a.type === 'dir' ? -1 : 1;
        return a.name.localeCompare(b.name);
      });
      kids.forEach((child, i) => {
        const last = i === kids.length - 1;
        lines.push(`${prefix}${last ? '└── ' : '├── '}${child.name}${child.type === 'dir' ? '/' : ''}`);
        if (child.type === 'dir') walk(child, `${prefix}${last ? '    ' : '│   '}`, depth + 1);
      });
    };
    walk(node, '', 0);
    return lines;
  }

  /* ---------- writes ---------- */

  mkdir(path, { recursive = true, cwd = HOME } = {}) {
    const full = this.normalize(path, cwd);
    if (full === '/') return this.stat('/');
    if (this.#node(full)) throw new FSError(`File exists: ${full}`, 'EEXIST');
    const parentPath = dirname(full);
    let parent = this.#node(parentPath);
    if (!parent) {
      if (!recursive) throw new FSError(`No such file or directory: ${parentPath}`, 'ENOENT');
      this.mkdir(parentPath, { recursive: true });
      parent = this.#node(parentPath);
    }
    if (!parent || parent.type !== 'dir') throw new FSError(`Not a directory: ${parentPath}`, 'ENOTDIR');
    if (parent.readonly) throw new FSError(`Read-only filesystem: ${parentPath}`, 'EROFS');
    const name = basename(full);
    if (!validName(name)) throw new FSError(`Invalid name: ${name}`, 'EINVAL');
    const node = dir(name);
    parent.children.push(node);
    parent.modified = now();
    this.changed(full, 'create');
    return this.stat(full);
  }

  writeFile(path, content = '', { cwd = HOME, mkdirs = true } = {}) {
    const full = this.normalize(path, cwd);
    if (PROTECTED.has(full) || full === '/') throw new FSError(`Permission denied: ${full}`, 'EACCES');
    let node = this.#node(full);
    if (node) {
      if (node.type === 'dir') throw new FSError(`Is a directory: ${full}`, 'EISDIR');
      if (node.type === 'app') throw new FSError(`Cannot modify application bundle: ${full}`, 'EACCES');
      if (node.readonly) throw new FSError(`Read-only file: ${full}`, 'EROFS');
      node.content = String(content);
      node.modified = now();
      node.size = node.content.length;
      this.changed(full, 'write');
      return this.stat(full);
    }
    const parentPath = dirname(full);
    let parent = this.#node(parentPath);
    if (!parent) {
      if (!mkdirs) throw new FSError(`No such file or directory: ${parentPath}`, 'ENOENT');
      this.mkdir(parentPath, { recursive: true });
      parent = this.#node(parentPath);
    }
    if (parent.readonly) throw new FSError(`Read-only filesystem: ${parentPath}`, 'EROFS');
    const name = basename(full);
    if (!validName(name)) throw new FSError(`Invalid name: ${name}`, 'EINVAL');
    const created = file(name, String(content));
    parent.children.push(created);
    parent.modified = now();
    this.changed(full, 'create');
    return this.stat(full);
  }

  appendFile(path, text, opts) {
    const existing = this.exists(path, opts?.cwd) ? this.readFile(path, opts?.cwd) : '';
    return this.writeFile(path, existing + text, opts);
  }

  createFolder(path, opts) {
    return this.mkdir(path, opts);
  }

  createFile(path, content = '', opts) {
    return this.writeFile(path, content, opts);
  }

  remove(path, { recursive = true, cwd = HOME } = {}) {
    const full = this.normalize(path, cwd);
    if (PROTECTED.has(full)) throw new FSError(`Permission denied: ${full} is a protected system location`, 'EACCES');
    const node = this.#node(full);
    if (!node) throw new FSError(`No such file or directory: ${full}`, 'ENOENT');
    if (node.readonly) throw new FSError(`Read-only: ${full}`, 'EROFS');
    if (node.type === 'dir' && (node.children || []).length && !recursive) throw new FSError(`Directory not empty: ${full}`, 'ENOTEMPTY');
    const parent = this.#node(dirname(full));
    if (!parent) throw new FSError(`No such file or directory: ${dirname(full)}`, 'ENOENT');
    parent.children = parent.children.filter((c) => c.name !== node.name);
    parent.modified = now();
    this.changed(full, 'delete');
    return true;
  }

  rename(path, newName, { cwd = HOME } = {}) {
    if (!validName(newName)) throw new FSError('Invalid file name', 'EINVAL');
    const full = this.normalize(path, cwd);
    if (PROTECTED.has(full)) throw new FSError(`Permission denied: ${full}`, 'EACCES');
    const node = this.#node(full);
    if (!node) throw new FSError(`No such file or directory: ${full}`, 'ENOENT');
    if (node.readonly) throw new FSError(`Read-only: ${full}`, 'EROFS');
    const parent = this.#node(dirname(full));
    if (!parent) throw new FSError('No such file or directory', 'ENOENT');
    if (parent.children.some((c) => c !== node && c.name === newName)) throw new FSError(`File exists: ${newName}`, 'EEXIST');
    node.name = newName;
    node.modified = now();
    parent.modified = now();
    const next = dirname(full) === '/' ? `/${newName}` : `${dirname(full)}/${newName}`;
    this.changed(next, 'rename');
    return this.stat(next);
  }

  #clone(node, name = node.name) {
    if (node.type === 'dir') {
      return {
        ...node,
        name,
        created: now(),
        modified: now(),
        children: (node.children || []).map((c) => this.#clone(c)),
        readonly: false,
      };
    }
    return { ...node, name, created: now(), modified: now(), readonly: false };
  }

  copy(src, dest, { cwd = HOME, overwrite = false } = {}) {
    const from = this.normalize(src, cwd);
    let to = this.normalize(dest, cwd);
    const node = this.#node(from);
    if (!node) throw new FSError(`No such file or directory: ${from}`, 'ENOENT');
    if (from === to) throw new FSError('Source and destination are the same', 'EINVAL');
    if (to === from || to.startsWith(from + '/')) throw new FSError('Cannot copy a folder into itself', 'EINVAL');

    const destNode = this.#node(to);
    if (destNode && destNode.type === 'dir') to = `${to}/${node.name}`;
    else if (destNode && !overwrite) throw new FSError(`File exists: ${to}`, 'EEXIST');

    const parentPath = dirname(to);
    let parent = this.#node(parentPath);
    if (!parent) {
      this.mkdir(parentPath, { recursive: true, cwd });
      parent = this.#node(parentPath);
    }
    if (parent.readonly) throw new FSError(`Read-only filesystem: ${parentPath}`, 'EROFS');
    const name = basename(to);
    if (!validName(name)) throw new FSError('Invalid file name', 'EINVAL');

    const existing = (parent.children || []).find((c) => c.name === name);
    if (existing) {
      if (existing.type !== 'dir' || node.type !== 'dir') parent.children = parent.children.filter((c) => c !== existing);
      else throw new FSError(`File exists: ${to}`, 'EEXIST');
    }
    parent.children.push(this.#clone(node, name));
    parent.modified = now();
    this.changed(to, 'copy');
    return this.stat(to);
  }

  move(src, dest, { cwd = HOME } = {}) {
    const from = this.normalize(src, cwd);
    let to = this.normalize(dest, cwd);
    if (PROTECTED.has(from)) throw new FSError(`Permission denied: ${from}`, 'EACCES');
    const node = this.#node(from);
    if (!node) throw new FSError(`No such file or directory: ${from}`, 'ENOENT');
    if (node.readonly) throw new FSError(`Read-only: ${from}`, 'EROFS');
    const destNode = this.#node(to);
    if (destNode && destNode.type === 'dir') to = `${to}/${node.name}`;
    if (from === to) return this.stat(to);
    if (to.startsWith(from + '/')) throw new FSError('Cannot move a folder into itself', 'EINVAL');
    const target = this.#node(to);
    if (target) throw new FSError(`File exists: ${to}`, 'EEXIST');

    const parentPath = dirname(to);
    let parent = this.#node(parentPath);
    if (!parent) {
      this.mkdir(parentPath, { recursive: true, cwd });
      parent = this.#node(parentPath);
    }
    if (parent.readonly) throw new FSError(`Read-only filesystem: ${parentPath}`, 'EROFS');
    const name = basename(to);
    if (!validName(name)) throw new FSError('Invalid file name', 'EINVAL');

    const oldParent = this.#node(dirname(from));
    oldParent.children = oldParent.children.filter((c) => c !== node);
    oldParent.modified = now();
    node.name = name;
    node.modified = now();
    parent.children.push(node);
    parent.modified = now();
    this.changed(to, 'move');
    return this.stat(to);
  }

  reset() {
    this.root = seed();
    this.persistNow();
    emit('fs:change', { path: '/', type: 'reset' });
    emit('fs:reset');
  }

  exportTree() {
    return JSON.parse(JSON.stringify(this.root));
  }
}

export function kindOf(node) {
  if (!node) return 'Unknown';
  if (node.type === 'dir') return 'Folder';
  if (node.type === 'app') return 'Application';
  const ext = extname(node.name);
  const map = {
    md: 'Markdown Document',
    txt: 'Plain Text',
    js: 'JavaScript',
    mjs: 'JavaScript',
    ts: 'TypeScript',
    json: 'JSON Document',
    css: 'Style Sheet',
    html: 'HTML Document',
    csv: 'Comma Separated Values',
    log: 'Log File',
    sh: 'Shell Script',
  };
  return map[ext] || (ext ? `${ext.toUpperCase()} Document` : 'Document');
}

export function editorFor(path) {
  const ext = extname(path);
  return ['md', 'txt', 'js', 'mjs', 'ts', 'json', 'css', 'html', 'csv', 'log', 'sh', 'yml', 'yaml', ''].includes(ext);
}

export const fs = new VirtualFS();
export default fs;
