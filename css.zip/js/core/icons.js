/* ============================================================
   Nova OS — icon set (original, Lucide-style stroke glyphs)
   ============================================================ */

const P = {
  'plus': '<path d="M12 5v14M5 12h14"/>',
  'minus': '<path d="M5 12h14"/>',
  'x': '<path d="M6 6l12 12M18 6L6 18"/>',
  'check': '<path d="M20 6L9 17l-5-5"/>',
  'chevron-left': '<path d="M15 18l-6-6 6-6"/>',
  'chevron-right': '<path d="M9 18l6-6-6-6"/>',
  'chevron-up': '<path d="M18 15l-6-6-6 6"/>',
  'chevron-down': '<path d="M6 9l6 6 6-6"/>',
  'chevron-up-down': '<path d="M8 9l4-4 4 4M8 15l4 4 4-4"/>',
  'arrow-left': '<path d="M19 12H5M12 19l-7-7 7-7"/>',
  'arrow-right': '<path d="M5 12h14M12 5l7 7-7 7"/>',
  'arrow-up': '<path d="M12 19V5M5 12l7-7 7 7"/>',
  'arrow-down': '<path d="M12 5v14M19 12l-7 7-7-7"/>',
  'arrow-up-right': '<path d="M7 17L17 7M9 7h8v8"/>',
  'search': '<circle cx="11" cy="11" r="7"/><path d="M16.5 16.5L21 21"/>',
  'folder': '<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5h3.2a2 2 0 0 1 1.5.7l1.2 1.4a2 2 0 0 0 1.5.7H19a2 2 0 0 1 2 2v7.7a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17.5z"/>',
  'folder-open': '<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5h3.2a2 2 0 0 1 1.5.7l1.2 1.4a2 2 0 0 0 1.5.7H19a2 2 0 0 1 2 2v1.2H3z"/><path d="M3 11h18l-2.1 7.2a2 2 0 0 1-1.9 1.4H6.1a2 2 0 0 1-1.9-1.4z"/>',
  'folder-plus': '<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5h3.4l2 2.4H19a2 2 0 0 1 2 2v8.1a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17.5z"/><path d="M12 11.5v6M9 14.5h6"/>',
  'file': '<path d="M6.5 3h7L18 7.5v13a1 1 0 0 1-1 1H6.5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M13 3v5h5"/>',
  'file-text': '<path d="M6.5 3h7L18 7.5v13a1 1 0 0 1-1 1H6.5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M13 3v5h5"/><path d="M9 13h6M9 16.5h6M9 9.5h2"/>',
  'file-code': '<path d="M6.5 3h7L18 7.5v13a1 1 0 0 1-1 1H6.5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M13 3v5h5"/><path d="M10.5 12.5L8.5 14.5l2 2M14 12.5l2 2-2 2"/>',
  'file-plus': '<path d="M6.5 3h7L18 7.5v13a1 1 0 0 1-1 1H6.5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M13 3v5h5"/><path d="M12 12v6M9 15h6"/>',
  'files': '<rect x="3" y="6.5" width="10.5" height="14" rx="2"/><path d="M7 3.5h9.5A3 3 0 0 1 19.5 6.5v10"/><path d="M6 11h4.5M6 14.5h4.5M6 18h2.5"/>',
  'trash': '<path d="M4 7h16M9.5 7V5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v2"/><path d="M6.5 7l.9 12.3a1.6 1.6 0 0 0 1.6 1.5h6a1.6 1.6 0 0 0 1.6-1.5L17.5 7"/><path d="M10.5 11v5.5M13.5 11v5.5"/>',
  'pencil': '<path d="M4 20l.9-3.8L15.6 5.5a2.1 2.1 0 0 1 3 0l.9.9a2.1 2.1 0 0 1 0 3L8.3 20z"/><path d="M13.6 6.4l4 4"/>',
  'copy': '<rect x="9" y="9" width="11.5" height="11.5" rx="2"/><path d="M15 9V5.5A1.5 1.5 0 0 0 13.5 4H5.5A1.5 1.5 0 0 0 4 5.5v8A1.5 1.5 0 0 0 5.5 15H9"/>',
  'clipboard': '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V3h6v1"/><path d="M9 11h6M9 15h4"/>',
  'clipboard-check': '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V3h6v1"/><path d="M8.5 12.5l2.5 2.5 4.5-4.5"/>',
  'rotate': '<path d="M20.5 12a8.5 8.5 0 1 1-2.6-6.1L21 9"/><path d="M21 4v5h-5"/>',
  'refresh': '<path d="M20 11a8 8 0 1 0-2.2 6.5M20 4v7h-7"/>',
  'grid': '<rect x="3.5" y="3.5" width="7" height="7" rx="1.8"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.8"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.8"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.8"/>',
  'list': '<path d="M8.5 6h12M8.5 12h12M8.5 18h12"/><path d="M4 6h.01M4 12h.01M4 18h.01"/>',
  'home': '<path d="M3.5 10.5L12 3l8.5 7.5V20a1 1 0 0 1-1 1h-5V15h-5v6h-5a1 1 0 0 1-1-1z"/>',
  'star': '<path d="M12 3.6l2.6 5.3 5.9.9-4.3 4.1 1 5.9-5.2-2.8-5.2 2.8 1-5.9L3.5 9.8l5.9-.9z"/>',
  'clock': '<circle cx="12" cy="12" r="9"/><path d="M12 7.2v5.3l3.6 2.1"/>',
  'wifi': '<path d="M2.5 8.6a15 15 0 0 1 19 0"/><path d="M5.6 12.2a10.5 10.5 0 0 1 12.8 0"/><path d="M8.7 15.7a6 6 0 0 1 6.6 0"/><path d="M12 19.2h.01"/>',
  'battery': '<rect x="2" y="8" width="17.5" height="8.5" rx="2.4"/><path d="M22 11v3"/><path d="M4.5 10.5h9v3.5h-9z" fill="currentColor" stroke="none"/>',
  'moon': '<path d="M20.5 14.7A8.6 8.6 0 0 1 9.3 3.5a8.6 8.6 0 1 0 11.2 11.2z"/>',
  'sun': '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M19.1 4.9l-1.4 1.4M6.3 17.7l-1.4 1.4"/>',
  'bell': '<path d="M18 9a6 6 0 1 0-12 0c0 4.6-1.8 5.8-1.8 5.8h15.6S18 13.6 18 9z"/><path d="M10.3 19.5a2 2 0 0 0 3.4 0"/>',
  'bell-off': '<path d="M18 9a6 6 0 0 0-9.3-5.1M6 9c0 4.6-1.8 5.8-1.8 5.8h12.4"/><path d="M10.3 19.5a2 2 0 0 0 3.4 0"/><path d="M3 3l18 18"/>',
  'volume': '<path d="M11 5L6.5 9H3v6h3.5L11 19z"/><path d="M15.5 8.7a4.7 4.7 0 0 1 0 6.6M18.4 6a8.6 8.6 0 0 1 0 12"/>',
  'volume-x': '<path d="M11 5L6.5 9H3v6h3.5L11 19z"/><path d="M22 9.5l-5 5M17 9.5l5 5"/>',
  'brightness': '<circle cx="12" cy="12" r="4.2"/><path d="M12 2.2v2.2M12 19.6v2.2M2.2 12h2.2M19.6 12h2.2M4.9 4.9l1.6 1.6M17.5 17.5l1.6 1.6M19.1 4.9l-1.6 1.6M6.5 17.5l-1.6 1.6"/>',
  'bluetooth': '<path d="M7 7.5l10 9L12 21V3l5 4.5-10 9"/>',
  'lock': '<rect x="4.5" y="10" width="15" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/><path d="M12 14.5v2.5"/>',
  'unlock': '<rect x="4.5" y="10" width="15" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 7.5-2"/><path d="M12 14.5v2.5"/>',
  'external': '<path d="M13.5 4H20v6.5"/><path d="M20 4l-8.5 8.5"/><path d="M18 14v5.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 4 19.5v-11A1.5 1.5 0 0 1 5.5 7H11"/>',
  'maximize': '<path d="M8.5 3.5H5.5a2 2 0 0 0-2 2v3M15.5 3.5h3a2 2 0 0 1 2 2v3M20.5 15.5v3a2 2 0 0 1-2 2h-3M3.5 15.5v3a2 2 0 0 0 2 2h3"/>',
  'restore': '<path d="M8 8V5.5a2 2 0 0 1 2-2h8.5a2 2 0 0 1 2 2V14a2 2 0 0 1-2 2H16"/><rect x="3.5" y="8" width="12.5" height="12.5" rx="2"/>',
  'more': '<circle cx="5.5" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="18.5" cy="12" r="1.4" fill="currentColor" stroke="none"/>',
  'globe': '<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3c2.4 2.6 3.7 5.6 3.7 9S14.4 18.4 12 21c-2.4-2.6-3.7-5.6-3.7-9S9.6 5.6 12 3z"/>',
  'terminal': '<path d="M4.5 17.5l6-5.5-6-5.5"/><path d="M12.5 19h8"/>',
  'settings': '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
  'command': '<path d="M18 3a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3 3 3 0 0 0 0-6H6a3 3 0 0 0-3 3 3 3 0 0 0 6 0V6a3 3 0 0 0-3-3 3 3 0 0 0 0 6h12a3 3 0 0 0 3-3 3 3 0 0 0-3-3z"/>',
  'bookmark': '<path d="M6.5 3.5h11a1 1 0 0 1 1 1v16l-6.5-3.8L5.5 20.5v-16a1 1 0 0 1 1-1z"/>',
  'history': '<path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1L3 8.6"/><path d="M3 3.5v5.2h5.2"/><path d="M12 7.5v4.8l3.3 2"/>',
  'image': '<rect x="3" y="4" width="18" height="16" rx="2.5"/><circle cx="8.5" cy="9.5" r="1.6"/><path d="M20.5 15.5l-4.6-4.6L5 21"/>',
  'music': '<path d="M9 18V5.5l11-2v12"/><ellipse cx="6.4" cy="18" rx="2.7" ry="2.4"/><ellipse cx="17.4" cy="15.5" rx="2.7" ry="2.4"/>',
  'monitor': '<rect x="2.5" y="4" width="19" height="13" rx="2.2"/><path d="M8 21h8M12 17v4"/>',
  'cpu': '<rect x="6" y="6" width="12" height="12" rx="2"/><rect x="9.5" y="9.5" width="5" height="5" rx="1"/><path d="M9.5 2.5V6M14.5 2.5V6M9.5 18v3.5M14.5 18v3.5M2.5 9.5H6M2.5 14.5H6M18 9.5h3.5M18 14.5h3.5"/>',
  'hard-drive': '<path d="M3.5 12.5h17"/><path d="M3.5 12.5l2.6-7a1.5 1.5 0 0 1 1.4-1h9a1.5 1.5 0 0 1 1.4 1l2.6 7v5.5a1.5 1.5 0 0 1-1.5 1.5h-15a1.5 1.5 0 0 1-1.5-1.5z"/><path d="M7 16h.01M10.5 16h.01"/>',
  'palette': '<path d="M12 3a9 9 0 1 0 0 18h1.8a2.2 2.2 0 0 0 0-4.4h-1a2.1 2.1 0 0 1 0-4.2h3.4A4.3 4.3 0 0 0 20.5 8C20.5 5 16.7 3 12 3z"/><circle cx="7.5" cy="10" r="1.2" fill="currentColor" stroke="none"/><circle cx="10.5" cy="6.8" r="1.2" fill="currentColor" stroke="none"/><circle cx="15" cy="7" r="1.2" fill="currentColor" stroke="none"/>',
  'keyboard': '<rect x="2" y="6" width="20" height="12" rx="2.4"/><path d="M6 10h.01M9.5 10h.01M13 10h.01M16.5 10h.01M6 13.5h.01M9.5 13.5h.01M13 13.5h.01M16.5 13.5h.01M7.5 16.5h9"/>',
  'shield': '<path d="M12 3l8 3v6c0 4.8-3.3 7.9-8 9-4.7-1.1-8-4.2-8-9V6z"/><path d="M8.8 11.8l2.2 2.2 4.2-4.2"/>',
  'zap': '<path d="M13.5 2.5L4 14h7l-1 7.5L19 10h-7z"/>',
  'sparkles': '<path d="M12 3.5l1.7 4.6 4.6 1.7-4.6 1.7L12 16.1l-1.7-4.6-4.6-1.7 4.6-1.7z"/><path d="M18.5 15.5l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z"/>',
  'play': '<path d="M7 4.5l13 7.5-13 7.5z"/>',
  'pause': '<path d="M8.5 4.5v15M15.5 4.5v15"/>',
  'cloud': '<path d="M7 18.5a4.5 4.5 0 0 1-.6-8.96A6.2 6.2 0 0 1 18 8.7a4.4 4.4 0 0 1 .4 8.8z"/>',
  'cloud-sun': '<path d="M8 9.5a4 4 0 0 1 3.6-4A5.5 5.5 0 0 1 21 8.2a3.8 3.8 0 0 1-.3 7.5"/><path d="M3 13.5a3.5 3.5 0 0 1 3.5-3.5c1.6 0 3 1 3.4 2.5"/><path d="M4 17.5a2.5 2.5 0 0 0 2.5 2.5h8a2.5 2.5 0 0 0 0-5"/><path d="M5.5 7.5l-1-1M9.5 5V3.5M3 10.5H1.5"/>',
  'cloud-rain': '<path d="M7 15.5a4.5 4.5 0 0 1-.6-8.96A6.2 6.2 0 0 1 18 5.7a4.4 4.4 0 0 1 .4 8.8z"/><path d="M8 18.5l-.7 2.5M12 18.5l-.7 2.5M16 18.5l-.7 2.5"/>',
  'cloud-snow': '<path d="M7 15.5a4.5 4.5 0 0 1-.6-8.96A6.2 6.2 0 0 1 18 5.7a4.4 4.4 0 0 1 .4 8.8z"/><path d="M8 19h.01M12 20.5h.01M16 19h.01"/>',
  'droplet': '<path d="M12 3.2s6 6.1 6 10.3a6 6 0 0 1-12 0C6 9.3 12 3.2 12 3.2z"/>',
  'thermometer': '<path d="M10 13.6V5a2 2 0 0 1 4 0v8.6a4.5 4.5 0 1 1-4 0z"/><path d="M12 7v8.5"/>',
  'gauge': '<path d="M4 18a9 9 0 1 1 16 0"/><path d="M12 14l3.5-4"/><circle cx="12" cy="15" r="1.6"/>',
  'compass': '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',
  'wind': '<path d="M3 8h9.5a3 3 0 1 0-3-3"/><path d="M3 12h13.5a3 3 0 1 1-3 3"/><path d="M3 16h6"/>',
  'map-pin': '<path d="M12 21.5s7-5.8 7-11.2a7 7 0 1 0-14 0C5 15.7 12 21.5 12 21.5z"/><circle cx="12" cy="10" r="2.6"/>',
  'bag': '<path d="M5.5 8h13l1 12a1.2 1.2 0 0 1-1.2 1.3H5.7A1.2 1.2 0 0 1 4.5 20z"/><path d="M9 8V6.2a3 3 0 0 1 6 0V8"/>',
  'user': '<circle cx="12" cy="8" r="4"/><path d="M4.5 21a7.5 7.5 0 0 1 15 0"/>',
  'info': '<circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.8h.01"/>',
  'alert': '<path d="M12 3.2l9.3 16.2a1.5 1.5 0 0 1-1.3 2.2H4a1.5 1.5 0 0 1-1.3-2.2z"/><path d="M12 9v5M12 17.3h.01"/>',
  'sidebar': '<rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="M9 4v16"/>',
  'eye': '<path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  'share': '<path d="M12 3v12M8 7l4-4 4 4"/><path d="M5 12.5v6A1.5 1.5 0 0 0 6.5 20h11a1.5 1.5 0 0 0 1.5-1.5v-6"/>',
  'download': '<path d="M12 3.5v11.5M8 11l4 4 4-4"/><path d="M4 19v1.5h16V19"/>',
  'save': '<path d="M5 3.5h11L19.5 7v12a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 19V5A1.5 1.5 0 0 1 5 3.5z"/><path d="M7.5 3.5v5h8v-5"/><path d="M7.5 20.5v-6h9v6"/>',
  'app-window': '<rect x="3.5" y="4.5" width="17" height="15" rx="2.5"/><path d="M3.5 9h17"/><path d="M7 6.7h.01M10 6.7h.01"/>',
  'help': '<circle cx="12" cy="12" r="8.8"/><path d="M9.6 9.4a2.5 2.5 0 0 1 4.8 1c0 1.7-2.4 1.9-2.4 3.6"/><path d="M12 17.2h.01"/>',
  'layers': '<path d="M12 3.6l8.4 4.5-8.4 4.5L3.6 8.1z"/><path d="M3.6 12.2l8.4 4.5 8.4-4.5"/><path d="M3.6 16.1l8.4 4.4 8.4-4.4"/>',
  'table': '<rect x="3.5" y="4.5" width="17" height="15" rx="2"/><path d="M3.5 9.5h17M9.5 9.5v10M15 9.5v10"/>',
  'corner-down-left': '<path d="M19 6v6a3 3 0 0 1-3 3H5"/><path d="M9 11l-4 4 4 4"/>',
  'volume-x': '<path d="M11 5.5L6.5 9.5H3.5v5h3l4.5 4z"/><path d="M16 9.5l4 5M20 9.5l-4 5"/>',
  'wifi-off': '<path d="M3 5l18 14"/><path d="M8.5 12.4a5 5 0 0 1 4.6-.6"/><path d="M5 9.2a11 11 0 0 1 3.2-1.6"/><path d="M15.8 7.6a11 11 0 0 1 3.2 1.6"/><path d="M12 18.5h.01"/>',
  'log-out': '<path d="M9.5 4.5H6A2 2 0 0 0 4 6.5v11a2 2 0 0 0 2 2h3.5"/><path d="M15 8l4 4-4 4"/><path d="M19 12H9.5"/>',
  'calendar-check': '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M8 3v4M16 3v4M3.5 10h17"/><path d="M9 14.5l2 2 4-4"/>',
  'upload': '<path d="M12 15V3.5M8 7.5l4-4 4 4"/><path d="M4 15v5.5h16V15"/>',
  'mouse': '<path d="M4.5 3.5l6.8 16.2 2.4-7.1 7.1-2.4z"/>',
  'move': '<path d="M12 3v18M3 12h18M9 6l3-3 3 3M9 18l3 3 3-3M6 9l-3 3 3 3M18 9l3 3-3 3"/>',
  'calendar': '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M8 3v4M16 3v4M3.5 10h17"/>',
  'calendar-plus': '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M8 3v4M16 3v4M3.5 10h17M12 12.8v5M9.5 15.3h5"/>',
  'calculator': '<rect x="5" y="2.5" width="14" height="19" rx="2.5"/><path d="M8.5 6.5h7"/><path d="M8.5 11h.01M12 11h.01M15.5 11h.01M8.5 14.5h.01M12 14.5h.01M15.5 14.5h.01M8.5 18h.01M12 18h.01M15.5 18h.01"/>',
  'note': '<path d="M5 4.5A1.5 1.5 0 0 1 6.5 3h7.7L19 7.8v11.7a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 5 19.5z"/><path d="M14.2 3v4.8H19"/><path d="M8.5 12h7M8.5 15.5h4.5"/>',
  'layout': '<rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="M9 4v16M9 12h12"/>',
  'sliders': '<path d="M4 21v-6M4 11V3M12 21v-9M12 8V3M20 21v-4M20 13V3"/><circle cx="4" cy="13" r="2"/><circle cx="12" cy="10" r="2"/><circle cx="20" cy="15" r="2"/>',
  'send': '<path d="M21 3L3 10.5l7 2.5 2.5 7z"/><path d="M21 3l-9.5 9.5"/>',
  'logout': '<path d="M9 21H5.5A1.5 1.5 0 0 1 4 19.5v-15A1.5 1.5 0 0 1 5.5 3H9"/><path d="M16 16l4-4-4-4M20 12H9"/>',
  'power': '<path d="M12 3v9"/><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/>',
  'sleep': '<path d="M20 14.5A8.5 8.5 0 0 1 9.5 4 8.5 8.5 0 1 0 20 14.5z"/><path d="M17 4h4l-4 4h4"/>',
  'fullscreen': '<path d="M8 3H4a1 1 0 0 0-1 1v4M16 3h4a1 1 0 0 1 1 1v4M21 16v4a1 1 0 0 1-1 1h-4M3 16v4a1 1 0 0 0 1 1h4"/>',
  'notebook': '<path d="M6 3.5h12a1.5 1.5 0 0 1 1.5 1.5v14a1.5 1.5 0 0 1-1.5 1.5H6z"/><path d="M6 3.5A1.5 1.5 0 0 0 4.5 5v14A1.5 1.5 0 0 0 6 20.5"/><path d="M9 8h6M9 12h6M9 16h3"/>',
  'pin': '<path d="M9 3h6l-1 6 4 4H6l4-4z"/><path d="M12 13v8"/>',
  'menu': '<path d="M4 7h16M4 12h16M4 17h16"/>',
  'dnd': '<path d="M20 14.7A8.6 8.6 0 0 1 9.3 3.5a8.6 8.6 0 1 0 11.2 11.2z"/><path d="M15 6h6"/>',
  'airdrop': '<path d="M12 3v12"/><path d="M8.5 11.5a5 5 0 1 1 7 0"/><path d="M5.8 8.6a8.8 8.8 0 1 1 12.4 0"/>',
  'bluetooth-search': '<path d="M7 7.5l7 6.5-5 4V3l5 4-7 6.5"/>',
  'grid-plus': '<rect x="3.5" y="3.5" width="7" height="7" rx="1.8"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.8"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.8"/><path d="M17 13.5v7M13.5 17h7"/>',
};

const APP_ICONS = {
  finder:     { glyph: 'folder', cls: 'ai-finder' },
  browser:    { glyph: 'globe', cls: 'ai-browser' },
  terminal:   { glyph: 'terminal', cls: 'ai-terminal' },
  files:      { glyph: 'files', cls: 'ai-files' },
  notes:      { glyph: 'note', cls: 'ai-notes' },
  calculator: { glyph: 'calculator', cls: 'ai-calculator' },
  calendar:   { glyph: null, cls: 'ai-calendar-day' },
  editor:     { glyph: 'file-code', cls: 'ai-editor' },
  appstore:   { glyph: 'bag', cls: 'ai-appstore' },
  settings:   { glyph: 'settings', cls: 'ai-settings' },
  weather:    { glyph: 'cloud-sun', cls: 'ai-weather' },
  about:      { glyph: 'info', cls: 'ai-help' },
};

const MONTHS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

export function icon(name, cls = '') {
  const body = P[name] || P.file;
  return `<svg class="icon ${cls}" viewBox="0 0 24 24" aria-hidden="true" focusable="false">${body}</svg>`;
}

export function iconEl(name, cls = '') {
  const t = document.createElement('template');
  t.innerHTML = icon(name, cls).trim();
  return t.content.firstElementChild;
}

export function logo(size = 16, cls = '') {
  return `<svg class="${cls}" width="${size}" height="${size}" viewBox="0 0 24 24" aria-hidden="true">
    <defs><linearGradient id="novaLogoGrad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#a8dcff"/><stop offset="0.55" stop-color="#7bb8ff"/><stop offset="1" stop-color="#8b7bff"/>
    </linearGradient></defs>
    <path d="M12 1.6l2.3 6.1 6.1 2.3-6.1 2.3L12 18.4l-2.3-6.1L3.6 10l6.1-2.3z" fill="url(#novaLogoGrad)"/>
    <path d="M18.6 15.2l1 2.6 2.6 1-2.6 1-1 2.6-1-2.6-2.6-1 2.6-1z" fill="#ffffff" opacity=".92"/>
  </svg>`;
}

export function appIcon(appId, cls = '') {
  const meta = APP_ICONS[appId] || APP_ICONS.about;
  if (appId === 'calendar') {
    const now = new Date();
    return `<span class="app-icon ${meta.cls} ${cls}" aria-hidden="true">
      <span class="cal-tile-month">${MONTHS[now.getMonth()]}</span>
      <span class="cal-tile-day">${now.getDate()}</span>
    </span>`;
  }
  return `<span class="app-icon ${meta.cls} ${cls}" aria-hidden="true">${icon(meta.glyph)}</span>`;
}

export function appIconEl(appId, cls = '') {
  const t = document.createElement('template');
  t.innerHTML = appIcon(appId, cls).trim();
  return t.content.firstElementChild;
}

export const iconNames = Object.freeze(Object.keys(P));
