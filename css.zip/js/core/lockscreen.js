/* ============================================================
   Nova OS — Lock screen
   ============================================================ */

import { h, formatDate, formatTime, escapeHTML } from '../core/util.js';
import { icon } from '../core/icons.js';
import { get, resolvedTheme } from '../core/state.js';
import { getWallpaper } from '../core/wallpapers.js';
import { emit } from '../core/bus.js';
import sounds from '../core/sound.js';

let el = null;
let timeEl = null;
let dateEl = null;
let inputEl = null;
let clockTimer = null;
let locked = false;
let busy = false;

function updateClock() {
  if (!timeEl) return;
  const now = new Date();
  timeEl.textContent = formatTime(now, { h24: !!get('clock.format24', false) });
  dateEl.textContent = formatDate(now, { weekday: true });
}

function paintBackground() {
  if (!el) return;
  const bg = el.querySelector('.lock-bg');
  if (bg) bg.style.background = getWallpaper(get('wallpaper', 'aurora')).css;
}

function initials() {
  const full = String(get('fullName', 'Nova User')).trim();
  const parts = full.split(/\s+/).filter(Boolean);
  if (!parts.length) return 'N';
  return (parts[0][0] + (parts[1]?.[0] || '')).toUpperCase();
}

export function lockScreen() {
  if (!el) initLockScreen();
  if (locked || busy) return;
  locked = true;
  paintBackground();
  updateClock();
  el.hidden = false;
  el.classList.remove('unlocking');
  el.style.opacity = '';
  inputEl.value = '';
  document.getElementById('menubar')?.classList.add('locked');
  setTimeout(() => inputEl.focus(), 120);
  if (sounds.lock) sounds.lock(); else sounds.minimize();
  emit('os:lock');
}

export function unlockScreen() {
  if (!el || !locked || busy) return false;
  busy = true;
  locked = false;
  sounds.open();
  el.classList.add('unlocking');
  setTimeout(() => {
    el.hidden = true;
    el.classList.remove('unlocking');
    document.getElementById('menubar')?.classList.remove('locked');
    busy = false;
    emit('os:unlock');
  }, 430);
  return true;
}

export function isLocked() {
  return locked;
}

export function initLockScreen() {
  if (el) return { lock: lockScreen, unlock: unlockScreen, isLocked };

  const bg = h('div', { class: 'lock-bg' });
  timeEl = h('div', { class: 'lock-time', text: '' });
  dateEl = h('div', { class: 'lock-date', text: '' });

  const avatar = h('div', { class: 'lock-avatar', text: initials() });
  const user = h('div', { class: 'lock-user', text: get('fullName', 'Nova User') });

  inputEl = h('input', {
    type: 'password',
    placeholder: 'Enter password',
    autocomplete: 'off',
    'aria-label': 'Password',
  });

  const goBtn = h('button', { title: 'Unlock', 'aria-label': 'Unlock', html: icon('arrow-right') });
  goBtn.addEventListener('click', (e) => { e.stopPropagation(); unlockScreen(); });

  const row = h('div', { class: 'lock-input-row' }, inputEl, goBtn);

  const hint = h('div', { class: 'lock-hint', text: 'Press Return to unlock' });

  const content = h('div', { class: 'lock-content' },
    timeEl,
    dateEl,
    avatar,
    user,
    row,
    hint,
    h('div', {
      style: { marginTop: '18px', fontSize: '10px', opacity: '.4', letterSpacing: '.04em', textTransform: 'uppercase' },
      text: `Nova OS · ${resolvedTheme() === 'dark' ? 'Dark' : 'Light'}`,
    }),
  );

  el = h('div', { class: 'lock-screen', hidden: true }, bg, content);
  // Keep the lock screen above every other surface
  el.style.zIndex = '15000';

  document.getElementById('os')?.append(el);

  inputEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); unlockScreen(); }
  });

  el.addEventListener('pointerdown', (e) => {
    if (e.target.closest('.lock-input-row')) return;
    inputEl.focus();
  });

  el.addEventListener('contextmenu', (e) => e.preventDefault());

  clockTimer = setInterval(() => { if (locked) updateClock(); }, 1000);

  return { lock: lockScreen, unlock: unlockScreen, isLocked };
}

export default { initLockScreen, lockScreen, unlockScreen, isLocked };
