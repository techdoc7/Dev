/* ============================================================
   Nova OS — Menu bar
   System menu, per-app menus, status items, Control Center
   and Notification Center.
   ============================================================ */

import { h, formatDate, formatTime, relativeTime, escapeHTML } from '../core/util.js';
import { icon, logo } from '../core/icons.js';
import { getApp } from '../core/registry.js';
import { get, set, setTheme, resolvedTheme, SYSTEM, notificationsAPI } from '../core/state.js';
import { on } from '../core/bus.js';
import wm from '../core/windowManager.js';
import { showMenu, showModal, switchControl, slider, toast, closeMenu } from '../core/ui.js';
import sounds from '../core/sound.js';

let bar = null;
let appNameEl = null;
let menusEl = null;
let statusEl = null;
let clockEl = null;
let wifiBtn = null;
let batteryFill = null;
let batteryPct = null;
let unreadDot = null;

let panel = null;
let clockTimer = null;

const BATTERY = { level: 82, charging: true };

/* ------------------------------------------------------------
   Helpers
   ------------------------------------------------------------ */

function openSettings(section = 'appearance') {
  window.OS?.openApp('settings', { section });
}

function aboutNova() {
  showModal({
    title: `About ${SYSTEM.name}`,
    icon: 'info',
    width: 430,
    body: `
      <div style="display:flex;align-items:center;gap:14px;margin-bottom:12px">
        <span class="app-icon ai-help" style="--size:52px">${icon('sparkles')}</span>
        <div>
          <div style="font-size:16px;font-weight:650;color:var(--text)">${SYSTEM.name}</div>
          <div class="muted" style="font-size:11px">Version ${SYSTEM.version} · ${SYSTEM.codename}</div>
          <div class="muted" style="font-size:11px">Build ${SYSTEM.build}</div>
        </div>
      </div>
      <div class="pv-row"><span class="k">Computer</span><span class="v">${escapeHTML(get('computerName', 'Nova Studio'))}</span></div>
      <div class="pv-row"><span class="k">User</span><span class="v">${escapeHTML(get('fullName', 'Nova User'))}</span></div>
      <div class="pv-row"><span class="k">Kernel</span><span class="v">${SYSTEM.kernel}</span></div>
      <div class="pv-row"><span class="k">Display</span><span class="v">${window.innerWidth} × ${window.innerHeight}</span></div>
      <p class="muted" style="font-size:11px;margin-top:12px">An original desktop environment that runs entirely in your browser. Not affiliated with Apple or macOS.</p>
    `,
    actions: [
      { label: 'Automation API', value: 'api' },
      { label: 'OK', value: null, primary: true },
    ],
  }).then((res) => {
    if (res === 'api') openApiDocs();
  });
}

function openApiDocs() {
  showModal({
    title: 'Automation API',
    icon: 'terminal',
    width: 500,
    body: `
      <p>Drive the desktop from the browser console with <code>window.OS</code>.</p>
      <div class="pv-row"><span class="k">OS.openApp(id, params)</span><span class="v">Launch or focus an app</span></div>
      <div class="pv-row"><span class="k">OS.closeApp(id)</span><span class="v">Close every window of an app</span></div>
      <div class="pv-row"><span class="k">OS.createFile(path, text)</span><span class="v">Write inside the virtual disk</span></div>
      <div class="pv-row"><span class="k">OS.readFile(path)</span><span class="v">Read a text file</span></div>
      <div class="pv-row"><span class="k">OS.listDir(path)</span><span class="v">List a folder</span></div>
      <div class="pv-row"><span class="k">OS.exec(command)</span><span class="v">Run a Terminal command</span></div>
      <div class="pv-row"><span class="k">OS.setTheme(theme)</span><span class="v">dark, light or auto</span></div>
      <div class="pv-row"><span class="k">OS.notify(title, text)</span><span class="v">Post a notification</span></div>
      <div class="pv-row"><span class="k">OS.windows.list()</span><span class="v">Inspect open windows</span></div>
      <p class="muted" style="font-size:11px;margin-top:10px">All filesystem methods are confined to the sandboxed virtual disk. The OS never touches your host filesystem.</p>
    `,
    actions: [{ label: 'OK', value: true, primary: true }],
  });
}

function openHelp() {
  showModal({
    title: 'Nova Help',
    icon: 'help',
    width: 470,
    body: `
      <p><strong>Welcome to ${SYSTEM.name}.</strong> Everything runs locally in this browser tab.</p>
      <div class="pv-row"><span class="k">Spotlight</span><span class="v">⌘ / Ctrl + Space</span></div>
      <div class="pv-row"><span class="k">Settings</span><span class="v">⌘ / Ctrl + ,</span></div>
      <div class="pv-row"><span class="k">Lock screen</span><span class="v">⌃⌘Q</span></div>
      <div class="pv-row"><span class="k">Close window</span><span class="v">⌘ / Ctrl + W</span></div>
      <div class="pv-row"><span class="k">Terminal</span><span class="v">Type <code>help</code> for every command</span></div>
      <p class="muted" style="font-size:11px;margin-top:10px">Right-click the desktop, the Dock or a file for contextual actions. Double-click a window title bar to zoom it.</p>
    `,
    actions: [{ label: 'OK', value: true, primary: true }],
  });
}

/* ------------------------------------------------------------
   System menu
   ------------------------------------------------------------ */

function systemMenu(anchor) {
  showMenu({
    anchor,
    minWidth: 240,
    items: [
      { label: `About ${SYSTEM.name}`, icon: 'info', action: aboutNova },
      { separator: true },
      { label: 'System Settings…', icon: 'settings', shortcut: '⌘,', action: () => openSettings('appearance') },
      { label: 'App Store…', icon: 'bag', action: () => window.OS?.openApp('appstore') },
      { separator: true },
      { label: 'Sleep', icon: 'moon', action: sleepDisplay },
      { label: 'Restart…', icon: 'refresh', action: restartSystem },
      { label: 'Shut Down…', icon: 'power', action: shutdownSystem },
      { separator: true },
      { label: 'Lock Screen', icon: 'lock', shortcut: '⌃⌘Q', action: () => window.OS?.lock() },
      { label: `Log Out ${escapeHTML(get('userName', 'nova'))}…`, icon: 'log-out', action: () => {
        showModal({
          title: 'Log out of Nova?',
          icon: 'log-out',
          width: 380,
          body: '<p>Your files and settings are saved in this browser. The desktop will reload.</p>',
          actions: [{ label: 'Cancel', value: null }, { label: 'Log Out', value: 'ok', primary: true }],
        }).then((res) => { if (res === 'ok') location.reload(); });
      } },
    ],
  });
}

function sleepDisplay() {
  const overlay = h('div', {
    style: {
      position: 'absolute', inset: '0', zIndex: '14000', background: '#000',
      display: 'grid', placeItems: 'center', color: 'rgba(255,255,255,.36)',
      fontSize: '12px', letterSpacing: '.02em', opacity: '0', transition: 'opacity .45s',
      cursor: 'default',
    },
    text: 'Nova is asleep — move the pointer to wake',
  });
  document.getElementById('overlay-layer').append(overlay);
  requestAnimationFrame(() => { overlay.style.opacity = '1'; });
  sounds.minimize();
  const wake = () => {
    overlay.style.opacity = '0';
    setTimeout(() => overlay.remove(), 460);
    document.removeEventListener('pointermove', wake);
    document.removeEventListener('keydown', wake);
    document.removeEventListener('pointerdown', wake);
    sounds.open();
  };
  setTimeout(() => {
    document.addEventListener('pointermove', wake, { once: true });
    document.addEventListener('keydown', wake, { once: true });
    document.addEventListener('pointerdown', wake, { once: true });
  }, 700);
}

function restartSystem() {
  showModal({
    title: 'Restart Nova?',
    icon: 'refresh',
    width: 380,
    body: '<p>Open windows will close. Your files and settings are kept.</p>',
    actions: [{ label: 'Cancel', value: null }, { label: 'Restart', value: 'ok', primary: true }],
  }).then((res) => {
    if (res !== 'ok') return;
    document.getElementById('boot')?.classList.add('show');
    setTimeout(() => location.reload(), 420);
  });
}

function shutdownSystem() {
  showModal({
    title: 'Shut down Nova?',
    icon: 'power',
    tone: 'danger',
    width: 380,
    body: '<p>The desktop will close. Click the power button to start again.</p>',
    actions: [{ label: 'Cancel', value: null }, { label: 'Shut Down', value: 'ok', danger: true }],
  }).then((res) => {
    if (res !== 'ok') return;
    wm.minimizeAll();
    sounds.close();
    const screen = h('div', {
      style: {
        position: 'absolute', inset: '0', zIndex: '14500', background: '#050506',
        display: 'grid', placeItems: 'center', opacity: '0', transition: 'opacity .5s',
      },
    });
    const inner = h('div', { style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '18px' } });
    const powerBtn = h('button', {
      class: 'icon-btn',
      title: 'Power on',
      style: {
        width: '56px', height: '56px', borderRadius: '50%', color: 'rgba(255,255,255,.7)',
        background: 'rgba(255,255,255,.06)', boxShadow: 'inset 0 0 0 1px rgba(255,255,255,.1)',
      },
      html: icon('power'),
    });
    powerBtn.addEventListener('click', () => location.reload());
    inner.append(
      h('div', { html: `<div style="opacity:.7">${logo(44)}</div>` }),
      h('div', { style: { color: 'rgba(255,255,255,.4)', fontSize: '11px', letterSpacing: '.08em', textTransform: 'uppercase' }, text: 'Nova OS' }),
      powerBtn,
      h('div', { style: { color: 'rgba(255,255,255,.3)', fontSize: '11px' }, text: 'Click to power on' }),
    );
    screen.append(inner);
    document.getElementById('overlay-layer').append(screen);
    requestAnimationFrame(() => { screen.style.opacity = '1'; });
  });
}

/* ------------------------------------------------------------
   App menus
   ------------------------------------------------------------ */

function windowMenu() {
  const active = wm.getActiveWindow();
  const list = wm.getWindows().filter((w) => w.state !== 'minimized');
  return [
    { label: 'Minimize', shortcut: '⌘M', icon: 'minus', disabled: !active, action: () => active && wm.minimizeWindow(active.id) },
    { label: active?.state === 'maximized' ? 'Unzoom' : 'Zoom', icon: 'maximize', disabled: !active, action: () => active && wm.toggleMaximize(active.id) },
    { separator: true },
    { label: 'Bring All to Front', icon: 'layers', disabled: !list.length, action: () => {
      for (const win of wm.getWindows()) if (win.state === 'minimized') wm.restoreWindow(win.id);
      const top = list[list.length - 1];
      if (top) wm.focusWindow(top.id);
    } },
    ...(list.length ? [
      { separator: true },
      ...list.map((win) => ({
        label: win.title,
        checked: active?.id === win.id,
        action: () => wm.focusWindow(win.id),
      })),
    ] : []),
  ];
}

function helpMenu() {
  return [
    { label: `Nova Help`, icon: 'help', action: openHelp },
    { label: 'Keyboard Shortcuts', icon: 'keyboard', action: () => openSettings('keyboard') },
    { separator: true },
    { label: 'Automation API', icon: 'terminal', action: openApiDocs },
    { label: `About ${SYSTEM.name}`, icon: 'info', action: aboutNova },
  ];
}

function appMenuItems(win, app) {
  let custom = {};
  try {
    custom = app?.menus?.(win) || {};
  } catch (err) {
    console.error('[menubar] app menus failed', err);
    custom = {};
  }
  const out = [];

  // App menu (named after the app, like a classic desktop)
  out.push({
    label: app?.name || 'Application',
    icon: app?.icon,
    items: [
      { label: `About ${app?.name || 'Application'}`, icon: 'info', action: () => toast({ title: app?.name || 'Application', text: 'Part of Nova OS', icon: app?.icon || 'app-window' }) },
      { separator: true },
      { label: 'Preferences…', icon: 'settings', action: () => openSettings('appearance') },
      { separator: true },
      { label: 'Hide Others', icon: 'minus', action: () => {
        for (const other of wm.getWindows()) {
          if (other.id !== win?.id && other.state !== 'minimized') wm.minimizeWindow(other.id);
        }
      } },
      { separator: true },
      { label: `Quit ${app?.name || 'Application'}`, icon: 'power', shortcut: '⌘Q', danger: true, action: () => {
        if (win) wm.closeAllForApp(win.appId);
      } },
    ],
  });

  for (const [name, items] of Object.entries(custom)) {
    if (!Array.isArray(items) || !items.length) continue;
    out.push({
      label: name,
      items: items.map((item) => {
        if (item.separator) return { separator: true };
        if (item.header) return { header: item.header };
        return {
          label: item.label,
          shortcut: item.shortcut,
          icon: item.icon,
          disabled: item.disabled,
          checked: item.checked,
          danger: item.danger,
          action: item.action,
        };
      }),
    });
  }

  const existing = new Set(Object.keys(custom).map((name) => name.toLowerCase()));
  if (!existing.has('window')) {
    const group = { label: 'Window', items: windowMenu() };
    const helpIndex = out.findIndex((g) => g.label.toLowerCase() === 'help');
    if (helpIndex >= 0) out.splice(helpIndex, 0, group);
    else out.push(group);
  }
  if (!existing.has('help')) out.push({ label: 'Help', items: helpMenu() });
  return out;
}

function fallbackMenus() {
  return [
    {
      label: 'File',
      items: [
        { label: 'New Finder Window', shortcut: '⌘N', icon: 'folder', action: () => wm.createWindow({ appId: 'finder', app: getApp('finder'), title: 'Finder', width: 940, height: 600, minWidth: 560, minHeight: 360 }) },
        { label: 'New Terminal Window', icon: 'terminal', action: () => window.OS?.openApp('terminal') },
        { separator: true },
        { label: 'Close Window', shortcut: '⌘W', disabled: !wm.getActiveWindow(), action: () => { const w = wm.getActiveWindow(); if (w) wm.closeWindow(w.id); } },
      ],
    },
    { label: 'Edit', items: [
      { label: 'Undo', shortcut: '⌘Z', disabled: true },
      { label: 'Redo', shortcut: '⇧⌘Z', disabled: true },
      { separator: true },
      { label: 'Cut', shortcut: '⌘X', disabled: true },
      { label: 'Copy', shortcut: '⌘C', disabled: true },
      { label: 'Paste', shortcut: '⌘V', disabled: true },
    ] },
    { label: 'View', items: [
      { label: 'Change Wallpaper…', icon: 'image', action: () => openSettings('appearance') },
      { label: 'Show Desktop Icons', icon: 'grid', checked: get('desktop.showIcons', true), action: () => set('desktop.showIcons', !get('desktop.showIcons', true)) },
    ] },
    { label: 'Window', items: windowMenu() },
    { label: 'Help', items: helpMenu() },
  ];
}

/* ------------------------------------------------------------
   Status / Control Center
   ------------------------------------------------------------ */

function closePanel() {
  if (!panel) return;
  panel.el.remove();
  panel = null;
  document.removeEventListener('pointerdown', panelOutside, true);
}

function panelOutside(e) {
  if (!panel) return;
  if (panel.el.contains(e.target)) return;
  if (e.target.closest('#menubar')) return;
  closePanel();
}

function openPanel(kind, build) {
  if (panel?.kind === kind) { closePanel(); return; }
  closePanel();
  closeMenu();
  const el = build();
  document.getElementById('overlay-layer').append(el);
  panel = { kind, el };
  setTimeout(() => document.addEventListener('pointerdown', panelOutside, true), 0);
}

export function controlCenter() {
  openPanel('cc', () => {
    const el = h('div', { class: 'control-center' });

    const render = () => {
      el.replaceChildren();
      const grid = h('div', { class: 'cc-grid' });

      const tile = (key, label, sub, iconName, on) => {
        const t = h('button', { class: `cc-tile${on ? ' on' : ''}` },
          h('span', { class: 'cc-knob', html: icon(iconName) }),
          h('span', { class: 'cc-label', text: label }),
          h('span', { class: 'cc-sub', text: sub }),
        );
        t.addEventListener('click', () => {
          set(key, !on);
          sounds.click();
          render();
        });
        return t;
      };

      grid.append(
        tile('wifi', 'Wi-Fi', get('wifi', true) ? 'NovaNet' : 'Off', get('wifi', true) ? 'wifi' : 'wifi-off', get('wifi', true)),
        tile('bluetooth', 'Bluetooth', get('bluetooth', true) ? 'On' : 'Off', 'bluetooth', get('bluetooth', true)),
        tile('dnd', 'Do Not Disturb', get('dnd', false) ? 'On' : 'Off', 'moon', get('dnd', false)),
        (() => {
          const dark = resolvedTheme() === 'dark';
          const t = h('button', { class: `cc-tile${dark ? ' on' : ''}` },
            h('span', { class: 'cc-knob', html: icon(dark ? 'moon' : 'sun') }),
            h('span', { class: 'cc-label', text: 'Appearance' }),
            h('span', { class: 'cc-sub', text: dark ? 'Dark' : 'Light' }),
          );
          t.addEventListener('click', () => { setTheme(dark ? 'light' : 'dark'); sounds.click(); render(); });
          return t;
        })(),
      );
      el.append(grid);

      const brightRow = h('div', { class: 'cc-slider-row' },
        h('span', { html: icon('brightness') }),
        slider({
          min: 35, max: 100, value: get('brightness', 100),
          onChange: (v) => { set('brightness', v); },
        }),
      );
      el.append(brightRow);

      const volRow = h('div', { class: 'cc-slider-row' },
        h('span', { html: icon('volume') }),
        slider({
          min: 0, max: 100, value: get('volume', 62),
          onChange: (v) => { set('volume', v); sounds.click(); },
        }),
      );
      el.append(volRow);

      const footer = h('div', { class: 'cc-footer' },
        h('button', { class: 'btn', html: `${icon('settings')} Settings`, onclick: () => { closePanel(); openSettings('appearance'); } }),
        h('button', { class: 'btn', html: `${icon('lock')} Lock`, onclick: () => { closePanel(); window.OS?.lock(); } }),
      );
      el.append(footer);
    };

    render();
    return el;
  });
}

export function notificationCenter() {
  openPanel('nc', () => {
    const el = h('div', { class: 'notification-center' });
    const render = () => {
      el.replaceChildren();
      const now = new Date();
      el.append(h('div', { class: 'nc-clock' },
        h('div', { class: 'nc-time', text: formatTime(now) }),
        h('div', { class: 'nc-date', text: formatDate(now, { full: true }) }),
      ));

      const list = notificationsAPI.list();
      const header = h('div', { class: 'nc-header' },
        h('span', { text: 'Notifications' }),
        h('div', { class: 'spacer', style: { flex: '1' } }),
        list.length ? h('button', { class: 'btn btn-plain', text: 'Clear', onclick: () => { notificationsAPI.clear(); render(); } }) : null,
      );
      el.append(header);

      const listEl = h('div', { class: 'nc-list' });
      if (!list.length) {
        listEl.append(h('div', { class: 'nc-empty' },
          h('div', { html: icon('bell') }),
          h('div', { text: 'No notifications' }),
          h('div', { style: { fontSize: '10.5px', opacity: '.75', marginTop: '3px' }, text: 'Alerts from apps show up here.' }),
        ));
      } else {
        for (const n of list) {
          const item = h('div', { class: 'nc-item' },
            h('span', { class: 'nc-icon', html: icon(n.icon || 'bell') }),
            h('div', { style: { minWidth: '0', flex: '1' } },
              h('div', { class: 'nc-title', text: n.title }),
              n.text ? h('div', { class: 'nc-text', text: n.text }) : null,
              h('div', { class: 'nc-time', text: relativeTime(n.time) }),
            ),
            h('button', {
              class: 'icon-btn',
              title: 'Dismiss',
              'aria-label': 'Dismiss notification',
              style: { width: '20px', height: '20px', flex: 'none' },
              html: icon('x'),
              onclick: (e) => { e.stopPropagation(); notificationsAPI.remove(n.id); render(); },
            }),
          );
          item.addEventListener('click', () => {
            if (n.app && getApp(n.app)) window.OS?.openApp(n.app);
            notificationsAPI.markAllRead();
            render();
          });
          listEl.append(item);
        }
      }
      el.append(listEl);

      const footer = h('div', { class: 'cc-footer' },
        h('button', { class: 'btn', html: `${icon('bell')} Notification Settings`, onclick: () => { closePanel(); openSettings('notifications'); } }),
      );
      el.append(footer);
    };
    render();
    return el;
  });
}

function wifiMenu(anchor) {
  const on = get('wifi', true);
  showMenu({
    anchor,
    align: 'right',
    minWidth: 240,
    items: [
      { header: 'Wi-Fi' },
      { label: `Wi-Fi ${on ? 'On' : 'Off'}`, icon: on ? 'wifi' : 'wifi-off', checked: on, action: () => set('wifi', !on) },
      { separator: true },
      { label: 'NovaNet', icon: on ? 'check' : null, disabled: !on, action: () => toast({ title: 'Connected to NovaNet', text: 'Simulated network', icon: 'wifi' }) },
      { label: 'Nova Guest', icon: 'lock', disabled: !on, action: () => toast({ title: 'Nova Guest', text: 'This network is simulated.', icon: 'wifi' }) },
      { separator: true },
      { label: 'Network Settings…', icon: 'settings', action: () => openSettings('network') },
    ],
  });
}

function batteryMenu(anchor) {
  const pct = BATTERY.level;
  showMenu({
    anchor,
    align: 'right',
    minWidth: 236,
    items: [
      { header: 'Battery' },
      { label: `${pct}% — ${BATTERY.charging ? 'Charging' : 'On battery'}`, icon: 'battery', disabled: true },
      { label: 'Power Adapter: Connected', icon: 'zap', disabled: true },
      { separator: true },
      { label: 'Energy Saver…', icon: 'settings', action: () => openSettings('displays') },
    ],
  });
}

function updateStatus() {
  if (!bar) return;
  const wifiOn = get('wifi', true);
  if (wifiBtn) {
    wifiBtn.innerHTML = icon(wifiOn ? 'wifi' : 'wifi-off');
    wifiBtn.title = wifiOn ? 'Wi-Fi: NovaNet' : 'Wi-Fi off';
    wifiBtn.classList.toggle('off', !wifiOn);
  }
  if (batteryFill) {
    batteryFill.style.width = `${BATTERY.level}%`;
    batteryFill.style.background = BATTERY.level < 20 ? '#ff453a' : 'currentColor';
  }
  if (batteryPct) batteryPct.textContent = `${BATTERY.level}%`;
  if (unreadDot) unreadDot.style.display = notificationsAPI.unread() ? '' : 'none';
}

function tickClock() {
  if (!clockEl) return;
  const now = new Date();
  const showSeconds = !!get('clock.seconds', false);
  const h24 = !!get('clock.format24', false);
  const time = formatTime(now, { seconds: showSeconds, h24 });
  const date = get('clock.showDate', true) ? formatDate(now, { short: true }) : '';
  clockEl.textContent = date ? `${date}  ${time}` : time;
  clockEl.title = formatDate(now, { full: true });
}

/* ------------------------------------------------------------
   Menus rendering
   ------------------------------------------------------------ */

let appMenuGroup = null;

function toggleAppMenu(btn, group) {
  if (btn.classList.contains('open')) { closeMenu(); btn.classList.remove('open'); return; }
  bar.querySelectorAll('.mb-item.open').forEach((n) => n.classList.remove('open'));
  btn.classList.add('open');
  showMenu({
    anchor: btn,
    items: group.items,
    minWidth: 220,
  });
  const closeWatch = () => {
    if (!document.querySelector('.menu')) {
      btn.classList.remove('open');
      document.removeEventListener('pointerdown', closeWatch, true);
    }
  };
  setTimeout(() => document.addEventListener('pointerdown', closeWatch, true), 0);
}

function bindMenuButton(btn, group) {
  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleAppMenu(btn, group);
  });
}

function renderMenus() {
  if (!menusEl) return;
  closeMenu();
  menusEl.replaceChildren();

  const active = wm.getActiveWindow();
  const app = active?.app || (active ? getApp(active.appId) : null);
  const name = active ? (app?.name || active.title || 'Application') : 'Finder';
  appNameEl.textContent = name;

  const groups = active && app ? appMenuItems(active, app) : fallbackMenus();
  // The bold app name doubles as the application menu (as on classic desktops)
  appMenuGroup = active && app ? groups[0] : null;
  const rest = appMenuGroup ? groups.slice(1) : groups;

  for (const group of rest) {
    const btn = h('button', { class: 'mb-item appmenu' },
      h('span', { class: 'mb-menulabel', text: group.label }),
    );
    bindMenuButton(btn, group);
    menusEl.append(btn);
  }
}

/* ------------------------------------------------------------
   Init
   ------------------------------------------------------------ */

export function initMenubar() {
  bar = document.getElementById('menubar');
  if (!bar) return { refresh: () => {} };

  /* left side */
  const logoBtn = h('button', { class: 'mb-item mb-logo', 'aria-label': `About ${SYSTEM.name}`, html: logo(16) });
  logoBtn.addEventListener('click', () => systemMenu(logoBtn));

  appNameEl = h('button', { class: 'mb-item mb-appname', text: 'Finder' });
  appNameEl.addEventListener('click', (e) => {
    if (!appMenuGroup) return;
    e.stopPropagation();
    toggleAppMenu(appNameEl, appMenuGroup);
  });

  menusEl = h('div', { class: 'mb-menus', style: { display: 'flex', alignItems: 'center', gap: '1px', minWidth: '0' } });

  /* right side */
  wifiBtn = h('button', { class: 'mb-item mb-status wifi', title: 'Wi-Fi', html: icon('wifi') });
  wifiBtn.addEventListener('click', () => wifiMenu(wifiBtn));

  const battery = h('button', { class: 'mb-item mb-status', title: 'Battery' },
    h('div', { class: 'mb-battery' },
      h('span', { class: 'mb-battery-shell' }, batteryFill = h('span', { class: 'mb-battery-fill', style: { width: `${BATTERY.level}%` } })),
      batteryPct = h('span', { class: 'pct', text: `${BATTERY.level}%` }),
    ),
  );
  battery.addEventListener('click', () => batteryMenu(battery));

  const ccBtn = h('button', { class: 'mb-item mb-cc', title: 'Control Center', html: icon('sliders') });
  ccBtn.addEventListener('click', () => controlCenter());

  const searchBtn = h('button', { class: 'mb-item mb-status', title: 'Spotlight Search', html: icon('search') });
  searchBtn.addEventListener('click', () => window.OS?.spotlight?.());

  clockEl = h('button', { class: 'mb-item mb-clock', text: '' });
  clockEl.addEventListener('click', () => notificationCenter());

  unreadDot = h('span', {
    class: 'mb-unread',
    style: {
      width: '5px', height: '5px', borderRadius: '50%', background: 'var(--accent)',
      display: 'none', flex: 'none',
    },
  });

  statusEl = h('div', { class: 'mb-status-group', style: { display: 'flex', alignItems: 'center', gap: '1px' } },
    wifiBtn, battery, unreadDot, ccBtn, searchBtn, clockEl,
  );

  bar.append(
    logoBtn,
    appNameEl,
    menusEl,
    h('div', { class: 'mb-spacer' }),
    statusEl,
  );

  /* events */
  const unsubs = [
    on('active-app', () => { renderMenus(); updateStatus(); }),
    on('window:open', () => { renderMenus(); updateStatus(); }),
    on('window:close', () => { renderMenus(); updateStatus(); }),
    on('window:state', () => renderMenus()),
    on('window:title', () => renderMenus()),
    on('notifications:change', () => { updateStatus(); if (panel?.kind === 'nc') { closePanel(); notificationCenter(); } }),
    on('settings:change', ({ path }) => {
      if (!path || path === '*' || path === 'wifi' || path.startsWith('clock') || path.startsWith('notifications')) {
        updateStatus();
        tickClock();
      }
      if (!path || path === '*' || path.startsWith('dock')) updateStatus();
    }),
    on('theme:change', () => { closePanel(); }),
  ];

  renderMenus();
  updateStatus();
  tickClock();
  clockTimer = setInterval(tickClock, 1000);

  // Refresh menus when the viewport hides labels
  const onResize = () => updateStatus();
  window.addEventListener('resize', onResize);

  return {
    refresh: () => { renderMenus(); updateStatus(); tickClock(); },
    dispose() {
      unsubs.forEach((fn) => fn());
      clearInterval(clockTimer);
      window.removeEventListener('resize', onResize);
      closePanel();
    },
  };
}

export function closePanels() {
  closePanel();
}

export default { initMenubar, controlCenter, notificationCenter, closePanels };
