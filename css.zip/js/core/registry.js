/* ============================================================
   Nova OS — application registry and launcher
   ============================================================ */

import * as finder from '../apps/finder.js';
import * as files from '../apps/files.js';
import * as browser from '../apps/browser.js';
import * as terminal from '../apps/terminal.js';
import * as notes from '../apps/notes.js';
import * as calculator from '../apps/calculator.js';
import * as calendar from '../apps/calendar.js';
import * as settings from '../apps/settings.js';
import * as editor from '../apps/editor.js';
import * as appstore from '../apps/appstore.js';
import * as weather from '../apps/weather.js';
import wm from './windowManager.js';
import { basename } from './util.js';

const modules = [finder, files, browser, terminal, notes, calculator, calendar, settings, editor, appstore, weather];

export const APPS = modules.map((m) => ({
  ...m.meta,
  mount: m.mount,
  menus: m.menus || null,
}));

const byId = new Map(APPS.map((a) => [a.id, a]));

export function getApp(id) {
  return byId.get(id) || null;
}

export function listApps() {
  return APPS.slice();
}

export function categories() {
  return Array.from(new Set(APPS.map((a) => a.category))).sort();
}

export function launch(appId, params = {}, opts = {}) {
  const app = getApp(appId);
  if (!app) {
    throw new Error(`Unknown application: ${appId}`);
  }
  const inferredTitle = params?.title
    || (params?.path ? basename(params.path) : null)
    || app.name;
  const size = app.defaultSize || { w: 900, h: 600 };
  const min = app.minSize || { w: 360, h: 260 };
  return wm.createWindow({
    appId: app.id,
    app,
    title: inferredTitle,
    width: opts.width ?? size.w,
    height: opts.height ?? size.h,
    minWidth: min.w,
    minHeight: min.h,
    singleton: opts.singleton ?? app.singleton ?? false,
    params,
    center: opts.center !== false,
    x: opts.x,
    y: opts.y,
    resizable: opts.resizable !== false,
  });
}

export function appIconName(id) {
  return getApp(id)?.icon || id;
}

export function appCategoriesFor(id) {
  return getApp(id)?.category || 'Other';
}
