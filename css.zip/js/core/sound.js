/* ============================================================
   Nova OS — subtle UI sounds (WebAudio, generated on the fly)
   ============================================================ */

import { get } from './state.js';

let ctx = null;
let unlocked = false;

/* Browsers only allow audio after a gesture — wait for the first one. */
if (typeof window !== 'undefined') {
  const unlock = () => {
    unlocked = true;
    window.removeEventListener('pointerdown', unlock, true);
    window.removeEventListener('keydown', unlock, true);
  };
  window.addEventListener('pointerdown', unlock, true);
  window.addEventListener('keydown', unlock, true);
}

function audio() {
  if (!unlocked) return null;
  if (!ctx) {
    const Ctor = window.AudioContext || window.webkitAudioContext;
    if (!Ctor) return null;
    ctx = new Ctor();
  }
  if (ctx.state === 'suspended') ctx.resume().catch(() => {});
  return ctx;
}

function tone({ freq = 520, dur = 0.07, type = 'sine', peak = 0.045, slide = 0, delay = 0 }) {
  const ac = audio();
  if (!ac) return;
  const volume = Number(get('volume', 60)) / 100;
  if (!volume || get('dnd', false)) return;

  const t0 = ac.currentTime + delay;
  const osc = ac.createOscillator();
  const gain = ac.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t0);
  if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t0 + dur);
  gain.gain.setValueAtTime(0.0001, t0);
  gain.gain.exponentialRampToValueAtTime(peak * volume, t0 + 0.008);
  gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  osc.connect(gain).connect(ac.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.02);
}

export const sounds = {
  click() { tone({ freq: 880, dur: 0.035, type: 'triangle', peak: 0.02 }); },
  open() {
    tone({ freq: 520, dur: 0.09, type: 'sine', peak: 0.035, slide: 180 });
    tone({ freq: 780, dur: 0.07, type: 'sine', peak: 0.02, delay: 0.04 });
  },
  close() { tone({ freq: 480, dur: 0.08, type: 'sine', peak: 0.03, slide: -180 }); },
  minimize() { tone({ freq: 640, dur: 0.1, type: 'sine', peak: 0.03, slide: -280 }); },
  notify() {
    tone({ freq: 880, dur: 0.1, type: 'sine', peak: 0.04 });
    tone({ freq: 1174, dur: 0.16, type: 'sine', peak: 0.035, delay: 0.09 });
  },
  error() {
    tone({ freq: 220, dur: 0.14, type: 'triangle', peak: 0.04, slide: -60 });
  },
  success() {
    tone({ freq: 660, dur: 0.08, type: 'sine', peak: 0.035 });
    tone({ freq: 990, dur: 0.12, type: 'sine', peak: 0.03, delay: 0.07 });
  },
  theme() { tone({ freq: 420, dur: 0.12, type: 'sine', peak: 0.03, slide: 220 }); },
};

export default sounds;
