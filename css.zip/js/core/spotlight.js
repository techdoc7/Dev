/* ============================================================
   Nova OS — Spotlight
   One search box for apps, files and system actions.
   ============================================================ */

import { h, fuzzyScore, dirname, basename, extname, formatBytes } from '../core/util.js';
import { icon, appIcon } from '../core/icons.js';
import { listApps } from '../core/registry.js';
import { fs, HOME, editorFor } from '../core/fs.js';
import { get, set, setTheme, resolvedTheme, setWallpaper } from '../core/state.js';
import { wallpapers } from '../core/wallpapers.js';
import { closeMenu, closePopover } from '../core/ui.js';
import sounds from '../core/sound.js';

let overlay = null;
let input = null;
let resultsEl = null;
let openFlag = false;
let results = [];
let activeIndex = 0;
let previousFocus = null;

/* ------------------------------------------------------------
   Actions
   ------------------------------------------------------------ */

const ACTIONS = [
  {
    id: 'theme',
    title: () => `Switch to ${resolvedTheme() === 'dark' ? 'Light' : 'Dark'} Appearance`,
    keywords: ['theme', 'dark', 'light', 'appearance', 'mode'],
    icon: () => (resolvedTheme() === 'dark' ? 'sun' : 'moon'),
    sub: 'System Action',
    run: () => { setTheme(resolvedTheme() === 'dark' ? 'light' : 'dark'); },
  },
  {
    id: 'lock',
    title: 'Lock Screen',
    keywords: ['lock', 'screen', 'secure', 'logout'],
    icon: 'lock',
    sub: 'System Action',
    run: () => window.OS?.lock(),
  },
  {
    id: 'settings-appearance',
    title: 'Appearance Settings',
    keywords: ['settings', 'wallpaper', 'accent', 'theme', 'appearance'],
    icon: 'palette',
    sub: 'System Settings',
    run: () => window.OS?.openApp('settings', { section: 'appearance' }),
  },
  {
    id: 'settings-dock',
    title: 'Desktop & Dock Settings',
    keywords: ['settings', 'dock', 'desktop', 'magnification', 'autohide'],
    icon: 'monitor',
    sub: 'System Settings',
    run: () => window.OS?.openApp('settings', { section: 'desktop' }),
  },
  {
    id: 'settings-network',
    title: 'Network Settings',
    keywords: ['settings', 'wifi', 'network', 'bluetooth'],
    icon: 'wifi',
    sub: 'System Settings',
    run: () => window.OS?.openApp('settings', { section: 'network' }),
  },
  {
    id: 'settings-keyboard',
    title: 'Keyboard Shortcuts',
    keywords: ['settings', 'keyboard', 'shortcuts', 'keys'],
    icon: 'keyboard',
    sub: 'System Settings',
    run: () => window.OS?.openApp('settings', { section: 'keyboard' }),
  },
  {
    id: 'settings-storage',
    title: 'Storage Settings',
    keywords: ['settings', 'storage', 'disk', 'files'],
    icon: 'hard-drive',
    sub: 'System Settings',
    run: () => window.OS?.openApp('settings', { section: 'storage' }),
  },
  {
    id: 'new-terminal',
    title: 'New Terminal Window',
    keywords: ['terminal', 'new', 'shell', 'command'],
    icon: 'terminal',
    sub: 'Application',
    run: () => window.OS?.openApp('terminal'),
  },
  {
    id: 'new-note',
    title: 'New Note',
    keywords: ['notes', 'new', 'write'],
    icon: 'note',
    sub: 'Application',
    run: () => window.OS?.openApp('notes'),
  },
  {
    id: 'desktop-refresh',
    title: 'Refresh Desktop',
    keywords: ['desktop', 'refresh', 'reload', 'icons'],
    icon: 'refresh',
    sub: 'System Action',
    run: () => window.OS?.refreshDesktop?.(),
  },
];

/* ------------------------------------------------------------
   Searching
   ------------------------------------------------------------ */

function appResults(query) {
  const out = [];
  for (const app of listApps()) {
    if (app.id === 'weather' && !query) { /* still include */ }
    const score = query
      ? Math.max(fuzzyScore(query, app.name), fuzzyScore(query, app.category || '') - 180)
      : 1;
    if (score < 0) continue;
    out.push({
      kind: 'app',
      appId: app.id,
      title: app.name,
      sub: app.description || app.category,
      score: score + 40,
      run: () => window.OS?.openApp(app.id),
    });
  }
  return out.sort((a, b) => b.score - a.score);
}

function fileResults(query) {
  if (!query) {
    try {
      const recent = fs.list(`${HOME}/Desktop`).concat(fs.list(`${HOME}/Documents`));
      return recent.slice(0, 4).map((entry) => ({
        kind: 'file',
        title: entry.name,
        sub: entry.path,
        entry,
        score: 1,
        run: () => openFile(entry),
      }));
    } catch { return []; }
  }
  let found = [];
  try { found = fs.search(query, HOME); } catch { found = []; }
  return found.slice(0, 6).map((entry) => ({
    kind: 'file',
    title: entry.name,
    sub: entry.path,
    entry,
    score: 200 - entry.path.length,
    run: () => openFile(entry),
  }));
}

function actionResults(query) {
  const out = [];
  for (const action of ACTIONS) {
    const title = typeof action.title === 'function' ? action.title() : action.title;
    const haystack = [title, ...(action.keywords || [])].join(' ');
    const score = query ? fuzzyScore(query, haystack) : 0;
    if (query && score < 0) continue;
    out.push({
      kind: 'action',
      title,
      sub: action.sub || 'Action',
      icon: typeof action.icon === 'function' ? action.icon() : action.icon,
      score: score + 20,
      run: action.run,
    });
  }
  if (query) {
    for (const wp of wallpapers) {
      const score = fuzzyScore(query, `${wp.name} wallpaper`);
      if (score < 0) continue;
      out.push({
        kind: 'action',
        title: `Set Wallpaper: ${wp.name}`,
        sub: 'Wallpaper',
        icon: 'image',
        score: score - 60,
        run: () => {
          setWallpaper(wp.id);
          window.OS?.notify('Wallpaper applied', wp.name, 'image');
        },
      });
    }
  }
  return out.sort((a, b) => b.score - a.score);
}

function openFile(entry) {
  if (!entry) return;
  if (entry.type === 'dir') {
    window.OS?.openApp('finder', { path: entry.path });
    return;
  }
  if (entry.type === 'app' && entry.appId) {
    window.OS?.openApp(entry.appId);
    return;
  }
  if (editorFor(entry.path)) {
    window.OS?.openApp('editor', { path: entry.path });
    return;
  }
  window.OS?.openApp('finder', { path: dirname(entry.path) });
}

/* ------------------------------------------------------------
   Rendering
   ------------------------------------------------------------ */

function displayIcon(result) {
  if (result.kind === 'app') return appIcon(result.appId);
  if (result.kind === 'file') {
    const iconName = result.entry?.type === 'dir' ? 'folder' : extname(result.title) === 'md' ? 'file-text' : 'file';
    return `<span class="spot-glyph">${icon(iconName)}</span>`;
  }
  return `<span class="spot-glyph">${icon(result.icon || 'sparkles')}</span>`;
}

function render(query = '') {
  resultsEl.replaceChildren();
  const q = query.trim();

  const apps = appResults(q).slice(0, q ? 6 : 6);
  const files = fileResults(q);
  const actions = actionResults(q).slice(0, q ? 6 : 4);

  const grouped = [
    { label: 'Applications', items: apps },
    { label: 'Files', items: files },
    { label: 'Actions', items: actions },
  ].filter((group) => group.items.length);

  results = [];
  for (const group of grouped) {
    resultsEl.append(h('div', { class: 'spot-group', text: group.label }));
    for (const result of group.items) {
      const index = results.length;
      results.push(result);
      const row = h('div', { class: 'spot-item', dataset: { index: String(index) } },
        h('span', { html: displayIcon(result), style: { display: 'contents' } }),
        h('div', { class: 'spot-text' },
          h('div', { class: 'spot-name', text: result.title }),
          h('div', { class: 'spot-sub', text: result.sub || '' }),
        ),
        h('span', { class: 'spot-enter', html: icon('corner-down-left') }),
      );
      row.addEventListener('pointerenter', () => setActive(index, false));
      row.addEventListener('click', () => run(index));
      resultsEl.append(row);
    }
  }

  if (!results.length) {
    resultsEl.append(h('div', { class: 'spot-empty' },
      h('div', { html: icon('search'), style: { opacity: '.5', marginBottom: '6px' } }),
      h('div', { text: `No results for “${q}”` }),
      h('div', { style: { fontSize: '11px', marginTop: '4px', opacity: '.7' }, text: 'Try an app name, a file, or an action like “dark”.' }),
    ));
  }

  activeIndex = Math.min(activeIndex, Math.max(0, results.length - 1));
  setActive(activeIndex, false);
}

function setActive(index, scroll = true) {
  if (!results.length) return;
  activeIndex = (index + results.length) % results.length;
  resultsEl.querySelectorAll('.spot-item').forEach((node) => {
    const active = Number(node.dataset.index) === activeIndex;
    node.classList.toggle('active', active);
    if (active && scroll) node.scrollIntoView({ block: 'nearest' });
  });
}

function run(index = activeIndex) {
  const result = results[index];
  if (!result) return;
  close();
  try { result.run(); } catch (err) { console.error('[spotlight] action failed', err); }
  sounds.open();
}

/* ------------------------------------------------------------
   Open / close
   ------------------------------------------------------------ */

export function openSpotlight(initialQuery = '') {
  if (!overlay) initSpotlight();
  if (openFlag) {
    if (initialQuery) { input.value = initialQuery; render(initialQuery); }
    input.focus();
    return;
  }
  closeMenu();
  closePopover();
  openFlag = true;
  previousFocus = document.activeElement;
  activeIndex = 0;
  input.value = initialQuery;
  overlay.hidden = false;
  render(initialQuery);
  requestAnimationFrame(() => {
    input.focus();
    if (initialQuery) input.select();
  });
  sounds.click();
}

export function closeSpotlight() {
  if (!overlay || !openFlag) return;
  openFlag = false;
  overlay.hidden = true;
  if (previousFocus && typeof previousFocus.focus === 'function') {
    try { previousFocus.focus({ preventScroll: true }); } catch { /* ignore */ }
  }
}

export function toggleSpotlight() {
  if (openFlag) closeSpotlight();
  else openSpotlight();
}

const close = closeSpotlight;

/* ------------------------------------------------------------
   Init
   ------------------------------------------------------------ */

export function initSpotlight() {
  const layer = document.getElementById('overlay-layer');
  if (!layer) return { open: () => {}, close: () => {}, toggle: () => {} };

  input = h('input', {
    type: 'text',
    placeholder: 'Search apps, files and actions',
    spellcheck: 'false',
    autocomplete: 'off',
    'aria-label': 'Spotlight search',
  });

  resultsEl = h('div', { class: 'spot-results' });

  const box = h('div', { class: 'spotlight', role: 'dialog', 'aria-label': 'Spotlight' },
    h('div', { class: 'spot-input-row' },
      h('span', { html: icon('search') }),
      input,
    ),
    resultsEl,
    h('div', { class: 'spot-foot' },
      h('span', { html: `${icon('chevron-up')}` }, h('span', { text: 'Navigate' })),
      h('span', { html: `${icon('corner-down-left')}` }, h('span', { text: 'Open' })),
      h('span', { html: `${icon('x')}` }, h('span', { text: 'Close' })),
      h('div', { style: { flex: '1' } }),
      h('span', { text: `${listApps().length} apps · virtual disk` }),
    ),
  );

  overlay = h('div', { class: 'spotlight-backdrop', hidden: true }, box);
  layer.append(overlay);

  overlay.addEventListener('pointerdown', (e) => {
    if (e.target === overlay) closeSpotlight();
  });

  input.addEventListener('input', () => {
    activeIndex = 0;
    render(input.value);
  });

  input.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setActive(activeIndex + 1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(activeIndex - 1); }
    else if (e.key === 'Enter') { e.preventDefault(); run(); }
    else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closeSpotlight(); }
    else if (e.key === 'Tab') { e.preventDefault(); setActive(activeIndex + (e.shiftKey ? -1 : 1)); }
  });

  overlay.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { e.preventDefault(); closeSpotlight(); }
  });

  return { open: openSpotlight, close: closeSpotlight, toggle: toggleSpotlight };
}

export default { initSpotlight, openSpotlight, closeSpotlight, toggleSpotlight };
