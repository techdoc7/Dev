/* ============================================================
   Nova OS — system state: settings, appearance, notifications
   ============================================================ */

import { load, save } from './storage.js';
import { emit } from './bus.js';
import { wallpapers, getWallpaper } from './wallpapers.js';
import { uid } from './util.js';

export const SYSTEM = {
  name: 'Nova OS',
  codename: 'Aurora',
  version: '1.0.0',
  build: '26A-1001',
  kernel: 'Nova Core 6.2',
  bootTime: Date.now(),
};

export const ACCENTS = [
  { id: 'blue', name: 'Blue', rgb: '10, 132, 255', hex: '#0a84ff' },
  { id: 'purple', name: 'Purple', rgb: '148, 108, 255', hex: '#946cff' },
  { id: 'pink', name: 'Pink', rgb: '255, 73, 128', hex: '#ff4980' },
  { id: 'red', name: 'Red', rgb: '255, 69, 58', hex: '#ff453a' },
  { id: 'orange', name: 'Orange', rgb: '255, 149, 0', hex: '#ff9500' },
  { id: 'yellow', name: 'Yellow', rgb: '255, 204, 0', hex: '#ffcc00' },
  { id: 'green', name: 'Green', rgb: '48, 209, 88', hex: '#30d158' },
  { id: 'graphite', name: 'Graphite', rgb: '142, 142, 147', hex: '#8e8e93' },
];

export const DEFAULT_DOCK = ['finder', 'browser', 'terminal', 'settings', 'notes', 'calculator', 'calendar', 'files', 'editor', 'appstore'];

export const DEFAULT_SETTINGS = {
  theme: 'dark',            // dark | light | auto
  accent: 'blue',
  wallpaper: 'aurora',
  reduceMotion: false,
  transparency: true,
  brightness: 100,
  volume: 62,
  wifi: true,
  bluetooth: true,
  dnd: false,
  userName: 'nova',
  fullName: 'Nova User',
  computerName: 'Nova Studio',
  dock: {
    position: 'bottom',
    autohide: false,
    magnification: true,
    size: 52,
    items: [...DEFAULT_DOCK],
    showRecents: true,
  },
  desktop: {
    showIcons: true,
    iconSize: 56,
    sort: 'name',
  },
  clock: {
    format24: false,
    seconds: false,
    showDate: true,
  },
  browser: {
    homepage: 'start',
    searchEngine: 'DuckDuckGo',
  },
};

function deepMerge(base, extra) {
  if (!extra || typeof extra !== 'object' || Array.isArray(extra)) return base;
  const out = Array.isArray(base) ? [...base] : { ...base };
  for (const [k, v] of Object.entries(extra)) {
    if (v && typeof v === 'object' && !Array.isArray(v) && base && typeof base[k] === 'object' && !Array.isArray(base[k])) {
      out[k] = deepMerge(base[k], v);
    } else if (v !== undefined) {
      out[k] = v;
    }
  }
  return out;
}

let state = deepMerge(DEFAULT_SETTINGS, load('settings', {}));
// Repair dock item list
if (!Array.isArray(state.dock.items) || !state.dock.items.length) state.dock.items = [...DEFAULT_DOCK];

const themeQuery = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

export function resolvedTheme() {
  if (state.theme === 'auto') return themeQuery && themeQuery.matches ? 'dark' : 'light';
  return state.theme === 'light' ? 'light' : 'dark';
}

let saveTimer = null;
function persist() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => save('settings', state), 160);
}

export function getSettings() { return state; }

export function get(path, fallback) {
  const parts = String(path).split('.');
  let cur = state;
  for (const p of parts) {
    if (cur === null || cur === undefined) return fallback;
    cur = cur[p];
  }
  return cur === undefined ? fallback : cur;
}

export function set(path, value, { silent = false } = {}) {
  const parts = String(path).split('.');
  let cur = state;
  for (let i = 0; i < parts.length - 1; i++) {
    if (typeof cur[parts[i]] !== 'object' || cur[parts[i]] === null) cur[parts[i]] = {};
    cur = cur[parts[i]];
  }
  cur[parts[parts.length - 1]] = value;
  persist();
  if (!silent) {
    applyAppearance();
    emit('settings:change', { path, value, settings: state });
  }
  return value;
}

export function patch(partial, opts) {
  state = deepMerge(state, partial);
  persist();
  applyAppearance();
  emit('settings:change', { path: '*', value: partial, settings: state });
  return state;
}

export function resetSettings() {
  state = deepMerge(DEFAULT_SETTINGS, {});
  persist();
  applyAppearance();
  emit('settings:change', { path: '*', value: state, settings: state });
}

export function applyAppearance() {
  const root = document.documentElement;
  const theme = resolvedTheme();
  root.dataset.theme = theme;
  root.dataset.accent = state.accent || 'blue';
  root.dataset.reduceMotion = String(!!state.reduceMotion);
  root.dataset.transparency = String(state.transparency !== false);

  root.style.setProperty('--dock-icon', `${state.dock.size || 52}px`);
  root.style.setProperty('--desk-icon-size', `${state.desktop.iconSize || 56}px`);

  const wp = document.getElementById('wallpaper');
  if (wp) {
    const css = getWallpaper(state.wallpaper).css;
    if (wp.dataset.wallpaper !== state.wallpaper) {
      wp.dataset.wallpaper = state.wallpaper;
      if (wp.style.background) {
        wp.style.opacity = '0';
        setTimeout(() => {
          wp.style.background = css;
          wp.style.opacity = '1';
        }, 130);
      } else {
        wp.style.background = css;
        wp.style.opacity = '1';
      }
    }
  }

  const shade = document.getElementById('wallpaperShade');
  if (shade) shade.style.opacity = theme === 'light' ? '0.35' : '1';

  const overlay = document.getElementById('brightnessOverlay');
  if (overlay) overlay.style.opacity = String((100 - Number(state.brightness ?? 100)) / 100 * 0.72);

  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = theme === 'dark' ? '#0b0b0d' : '#e8e8ed';
}

if (themeQuery) {
  const onChange = () => { if (state.theme === 'auto') { applyAppearance(); emit('theme:change', resolvedTheme()); } };
  if (themeQuery.addEventListener) themeQuery.addEventListener('change', onChange);
  else if (themeQuery.addListener) themeQuery.addListener(onChange);
}

export function setTheme(theme) {
  const value = ['dark', 'light', 'auto'].includes(theme) ? theme : 'dark';
  state.theme = value;
  persist();
  applyAppearance();
  emit('theme:change', resolvedTheme());
  emit('settings:change', { path: 'theme', value, settings: state });
  return resolvedTheme();
}

export function toggleTheme() {
  return setTheme(resolvedTheme() === 'dark' ? 'light' : 'dark');
}

export function setWallpaper(id) {
  const wp = wallpapers.find((w) => w.id === id);
  if (!wp) return false;
  state.wallpaper = wp.id;
  persist();
  applyAppearance();
  emit('wallpaper:change', wp.id);
  return true;
}

/* ------------------------------------------------------------
   Notifications
   ------------------------------------------------------------ */

let notifications = load('notifications', []);
if (!Array.isArray(notifications)) notifications = [];

function saveNotifications() {
  notifications = notifications.slice(0, 40);
  save('notifications', notifications);
}

export const notificationsAPI = {
  list() { return notifications; },
  unread() { return notifications.filter((n) => !n.read).length; },
  add({ title = 'Notification', text = '', icon = 'bell', silent = false, app = 'system' } = {}) {
    const entry = { id: uid('ntf'), title, text, icon, app, time: Date.now(), read: false };
    notifications.unshift(entry);
    saveNotifications();
    emit('notifications:change', notifications);
    if (!silent) emit('notification:toast', entry);
    return entry;
  },
  remove(id) {
    notifications = notifications.filter((n) => n.id !== id);
    saveNotifications();
    emit('notifications:change', notifications);
  },
  clear() {
    notifications = [];
    saveNotifications();
    emit('notifications:change', notifications);
  },
  markAllRead() {
    notifications.forEach((n) => { n.read = true; });
    saveNotifications();
    emit('notifications:change', notifications);
  },
};

/* Convenience */
export function notify(title, text, icon) {
  return notificationsAPI.add({ title, text, icon });
}

export const settings = { get, set, patch, getSettings, resetSettings, applyAppearance, DEFAULT_SETTINGS };
