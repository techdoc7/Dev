/* ============================================================
   Nova OS — persistence helpers (localStorage, namespaced)
   ============================================================ */

const NS = 'nova.';

export function load(key, fallback) {
  try {
    const raw = localStorage.getItem(NS + key);
    if (raw === null || raw === undefined) return fallback;
    return JSON.parse(raw);
  } catch (err) {
    console.warn(`[storage] could not read "${key}"`, err);
    return fallback;
  }
}

export function save(key, value) {
  try {
    localStorage.setItem(NS + key, JSON.stringify(value));
    return true;
  } catch (err) {
    console.warn(`[storage] could not write "${key}"`, err);
    return false;
  }
}

export function remove(key) {
  try { localStorage.removeItem(NS + key); } catch { /* ignore */ }
}

export function keys() {
  const out = [];
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k && k.startsWith(NS)) out.push(k.slice(NS.length));
  }
  return out;
}

export function clearNamespace() {
  for (const k of keys()) remove(k);
}

export function bytesFor(key) {
  try {
    const raw = localStorage.getItem(NS + key);
    return raw ? new Blob([raw]).size : 0;
  } catch { return 0; }
}

export function totalBytes() {
  let total = 0;
  for (const k of keys()) total += bytesFor(k);
  return total;
}
