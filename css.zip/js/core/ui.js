/* ============================================================
   Nova OS — UI primitives: menus, modals, toasts, popovers
   ============================================================ */

import { h, uid, escapeHTML, nextFrame } from './util.js';
import { icon } from './icons.js';

const overlay = () => document.getElementById('overlay-layer');

let activeMenu = null;
let activePopover = null;

/* ------------------------------------------------------------
   Menus
   ------------------------------------------------------------ */

export function closeMenu() {
  if (activeMenu) {
    activeMenu.el.remove();
    activeMenu.cleanup?.();
    activeMenu = null;
  }
}

function positionSurface(el, { x, y, anchor, align = 'left', offset = 6, minMargin = 8 }) {
  const rect = el.getBoundingClientRect();
  let left = x ?? 0;
  let top = y ?? 0;
  if (anchor) {
    const ar = anchor.getBoundingClientRect();
    left = align === 'right' ? ar.right - rect.width : align === 'center' ? ar.left + ar.width / 2 - rect.width / 2 : ar.left;
    top = ar.bottom + offset;
  }
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  if (left + rect.width > vw - minMargin) left = vw - rect.width - minMargin;
  if (left < minMargin) left = minMargin;
  if (top + rect.height > vh - minMargin) {
    const above = anchor ? anchor.getBoundingClientRect().top - rect.height - offset : top - rect.height;
    top = above > minMargin ? above : Math.max(minMargin, vh - rect.height - minMargin);
  }
  el.style.left = `${Math.round(left)}px`;
  el.style.top = `${Math.round(top)}px`;
}

export function showMenu({ x, y, anchor, items = [], align = 'left', minWidth = 210, className = '' }) {
  closeMenu();
  closePopover();
  const el = h('div', { class: `menu ${className}`.trim(), role: 'menu' });
  el.style.minWidth = `${minWidth}px`;
  el.style.left = '-9999px';
  el.style.top = '-9999px';

  for (const item of items) {
    if (!item) continue;
    if (item.separator) {
      el.append(h('div', { class: 'menu-sep' }));
      continue;
    }
    if (item.header) {
      el.append(h('div', { class: 'menu-header', text: item.header }));
      continue;
    }
    const row = h('div', {
      class: `menu-item${item.disabled ? ' disabled' : ''}${item.danger ? ' danger' : ''}`,
      role: 'menuitem',
      tabindex: '-1',
    });
    if (item.checked) row.append(h('span', { class: 'mi-check', html: icon('check') }));
    else if (item.icon) row.append(h('span', { class: 'mi-icon', html: icon(item.icon) }));
    else row.append(h('span', { class: 'mi-check' }));
    row.append(h('span', { class: 'mi-label', text: item.label }));
    if (item.shortcut) row.append(h('span', { class: 'mi-shortcut', text: item.shortcut }));
    if (item.submenu) row.append(h('span', { class: 'mi-sub', html: icon('chevron-right') }));
    row.addEventListener('pointerenter', () => {
      el.querySelectorAll('.menu-item.active').forEach((n) => n.classList.remove('active'));
      row.classList.add('active');
    });
    row.addEventListener('click', (e) => {
      e.stopPropagation();
      if (item.disabled) return;
      closeMenu();
      try { item.action?.(); } catch (err) { console.error('[menu] action failed', err); }
    });
    el.append(row);
  }

  overlay().append(el);
  positionSurface(el, { x, y, anchor, align });

  const onPointerDown = (e) => {
    if (!el.contains(e.target)) closeMenu();
  };
  const onKey = (e) => {
    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      closeMenu();
    } else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      const rows = Array.from(el.querySelectorAll('.menu-item:not(.disabled)'));
      if (!rows.length) return;
      const idx = rows.indexOf(el.querySelector('.menu-item.active'));
      const next = e.key === 'ArrowDown'
        ? rows[(idx + 1) % rows.length]
        : rows[(idx - 1 + rows.length) % rows.length];
      rows.forEach((r) => r.classList.remove('active'));
      next.classList.add('active');
    } else if (e.key === 'Enter') {
      const active = el.querySelector('.menu-item.active');
      if (active) { e.preventDefault(); active.click(); }
    }
  };
  setTimeout(() => {
    if (!activeMenu) return;
    document.addEventListener('pointerdown', onPointerDown, true);
    document.addEventListener('keydown', onKey);
  }, 0);
  activeMenu = {
    el,
    cleanup: () => {
      document.removeEventListener('pointerdown', onPointerDown, true);
      document.removeEventListener('keydown', onKey);
    },
  };

  return el;
}

export function closePopover() {
  if (activePopover) {
    activePopover.el.remove();
    activePopover.cleanup?.();
    activePopover = null;
  }
}

export function showPopover({ anchor, content, align = 'right', className = '', offset = 6, onClose }) {
  closePopover();
  closeMenu();
  const el = h('div', { class: `popover ${className}`.trim() });
  el.style.left = '-9999px';
  el.style.top = '-9999px';
  if (typeof content === 'string') el.innerHTML = content;
  else if (content) el.append(content);
  overlay().append(el);
  positionSurface(el, { anchor, align, offset });

  const onPointerDown = (e) => {
    if (!el.contains(e.target) && !anchor.contains(e.target)) {
      closePopover();
      onClose?.();
    }
  };
  const onKey = (e) => {
    if (e.key === 'Escape') { closePopover(); onClose?.(); }
  };
  setTimeout(() => {
    document.addEventListener('pointerdown', onPointerDown, true);
    document.addEventListener('keydown', onKey);
  }, 0);
  activePopover = {
    el,
    cleanup: () => {
      document.removeEventListener('pointerdown', onPointerDown, true);
      document.removeEventListener('keydown', onKey);
    },
  };
  return el;
}

/* ------------------------------------------------------------
   Modals
   ------------------------------------------------------------ */

const modalStack = [];

export function showModal({
  title = '',
  body = '',
  icon: iconName = null,
  tone = '',
  width = 420,
  actions = [{ label: 'OK', value: true, primary: true }],
  dismissible = true,
  footerNote = '',
  onMount = null,
  className = '',
} = {}) {
  return new Promise((resolve) => {
    const backdrop = h('div', { class: 'modal-backdrop' });
    const modal = h('div', { class: `modal ${className}`.trim(), role: 'dialog', 'aria-modal': 'true' });
    modal.style.width = `${width}px`;

    const head = h('div', { class: 'modal-head' });
    if (iconName) head.append(h('div', { class: `modal-icon ${tone}`.trim(), html: icon(iconName) }));
    if (title) head.append(h('h3', { text: title }));
    modal.append(head);

    const bodyEl = h('div', { class: 'modal-body' });
    if (typeof body === 'string') bodyEl.innerHTML = body;
    else if (body) bodyEl.append(body);
    modal.append(bodyEl);

    const foot = h('div', { class: 'modal-foot' });
    if (footerNote) foot.append(h('div', { class: 'modal-note', text: footerNote }));

    let resolved = false;
    const close = (value) => {
      if (resolved) return;
      resolved = true;
      backdrop.style.opacity = '0';
      backdrop.style.transition = 'opacity .14s';
      modal.style.transform = 'scale(.97)';
      modal.style.transition = 'transform .14s';
      setTimeout(() => backdrop.remove(), 140);
      document.removeEventListener('keydown', onKey, true);
      const idx = modalStack.indexOf(entry);
      if (idx >= 0) modalStack.splice(idx, 1);
      resolve(value);
    };
    const entry = { close, el: backdrop };

    for (const action of actions) {
      if (!action) continue;
      const btn = h('button', {
        class: `btn ${action.primary ? 'btn-primary' : ''} ${action.danger ? 'btn-danger' : ''} ${action.plain ? 'btn-plain' : ''}`.trim(),
        text: action.label,
        onclick: () => close(action.value),
      });
      foot.append(btn);
    }
    modal.append(foot);

    const onKey = (e) => {
      if (e.key === 'Escape' && dismissible) {
        e.preventDefault();
        e.stopPropagation();
        close(null);
      }
      if (e.key === 'Enter' && !e.shiftKey) {
        const tag = document.activeElement?.tagName;
        if (tag === 'TEXTAREA') return;
        const primary = actions.find((a) => a.primary);
        if (primary) {
          e.preventDefault();
          close(primary.value);
        }
      }
      if (e.key === 'Tab') {
        const focusables = modal.querySelectorAll('button, input, textarea, select, [tabindex="0"]');
        if (!focusables.length) return;
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener('keydown', onKey, true);

    backdrop.addEventListener('pointerdown', (e) => {
      if (e.target === backdrop && dismissible) close(null);
    });

    overlay().append(backdrop);
    backdrop.append(modal);
    modalStack.push(entry);

    onMount?.(bodyEl, close);
    nextFrame(() => {
      const firstInput = modal.querySelector('input, textarea, select');
      if (firstInput) {
        firstInput.focus();
        if (firstInput.select && firstInput.type !== 'range') firstInput.select();
      } else {
        modal.querySelector('.btn-primary')?.focus();
      }
    });
  });
}

export function confirmDialog({ title, message, confirmLabel = 'OK', cancelLabel = 'Cancel', danger = false, iconName = 'alert' }) {
  return showModal({
    title,
    body: `<p>${message}</p>`,
    icon: iconName,
    tone: danger ? 'danger' : 'warn',
    width: 380,
    actions: [
      { label: cancelLabel, value: false },
      { label: confirmLabel, value: true, primary: !danger, danger },
    ],
  }).then((v) => v === true);
}

export function promptDialog({
  title,
  message = '',
  label = '',
  value = '',
  placeholder = '',
  confirmLabel = 'OK',
  validate = null,
  danger = false,
} = {}) {
  const body = h('div', { class: 'form-grid' });
  if (message) body.append(h('p', { html: message }));
  if (label) body.append(h('div', { class: 'form-row-col' }, h('label', { text: label })));
  const input = h('input', { class: 'input', value, placeholder, spellcheck: 'false' });
  body.append(input);

  return showModal({
    title,
    body,
    width: 400,
    actions: [
      { label: 'Cancel', value: null },
      { label: confirmLabel, value: 'ok', primary: true, danger },
    ],
    onMount: (bodyEl, close) => {
      const primary = bodyEl.parentElement.querySelector('.btn-primary');
      primary?.addEventListener('click', (e) => {
        const err = validate ? validate(input.value) : null;
        if (err) {
          e.stopImmediatePropagation();
          let note = bodyEl.querySelector('.field-error');
          if (!note) {
            note = h('div', { class: 'field-error', style: { color: '#ff453a', fontSize: '11px', marginTop: '2px' } });
            bodyEl.append(note);
          }
          note.textContent = err;
          input.focus();
          e.preventDefault();
        }
      }, true);
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          const err = validate ? validate(input.value) : null;
          if (err) {
            e.preventDefault();
            e.stopPropagation();
            let note = bodyEl.querySelector('.field-error');
            if (!note) {
              note = h('div', { class: 'field-error', style: { color: '#ff453a', fontSize: '11px', marginTop: '2px' } });
              bodyEl.append(note);
            }
            note.textContent = err;
            return;
          }
          close(input.value.trim());
        }
      });
    },
  }).then((v) => (v === 'ok' ? input.value.trim() : null));
}

export function alertDialog({ title, message, iconName = 'info', tone = '' }) {
  return showModal({
    title,
    body: `<p>${message}</p>`,
    icon: iconName,
    tone,
    width: 390,
    actions: [{ label: 'OK', value: true, primary: true }],
  });
}

export function closeTopModal() {
  const top = modalStack[modalStack.length - 1];
  if (top) { top.close(null); return true; }
  return false;
}

/* ------------------------------------------------------------
   Toasts
   ------------------------------------------------------------ */

export function toast({ title, text = '', icon: iconName = 'bell', timeout = 4200, appId = null, onClick = null } = {}) {
  const layer = document.getElementById('toast-layer');
  if (!layer) return null;
  const el = h('div', { class: 'toast' });
  const iconBox = h('div', { class: 'toast-icon', html: icon(iconName) });
  const body = h('div', { class: 'toast-body' },
    h('div', { class: 'toast-title', text: title }),
    text ? h('div', { class: 'toast-text', text }) : null,
  );
  const closeBtn = h('button', { class: 'toast-close', 'aria-label': 'Dismiss', html: icon('x') });
  el.append(iconBox, body, closeBtn);
  if (appId) el.dataset.app = appId;

  let timer = null;
  const dismiss = () => {
    clearTimeout(timer);
    el.classList.add('out');
    setTimeout(() => el.remove(), 220);
  };
  closeBtn.addEventListener('click', dismiss);
  el.addEventListener('pointerenter', () => clearTimeout(timer));
  el.addEventListener('pointerleave', () => { timer = setTimeout(dismiss, 1600); });
  if (onClick) {
    body.style.cursor = 'pointer';
    body.addEventListener('click', () => { onClick(); dismiss(); });
  }

  layer.append(el);
  while (layer.children.length > 4) layer.firstElementChild.remove();
  timer = setTimeout(dismiss, timeout);
  return el;
}

/* ------------------------------------------------------------
   Misc
   ------------------------------------------------------------ */

export function badge(text, tone = '') {
  return h('span', { class: `badge ${tone}`.trim(), text });
}

export function emptyState(iconName, title, text) {
  return h('div', { class: 'empty-state' },
    h('div', { html: icon(iconName) }),
    h('b', { text: title }),
    text ? h('span', { text }) : null,
  );
}

export function iconButton(name, title, onClick, cls = '') {
  return h('button', { class: `icon-btn ${cls}`.trim(), title, 'aria-label': title, html: icon(name), onclick: onClick });
}

export function switchControl(checked, onChange, title = '') {
  const el = h('button', {
    class: 'switch',
    role: 'switch',
    'aria-checked': String(!!checked),
    title,
    onclick: (e) => {
      e.stopPropagation();
      const next = el.getAttribute('aria-checked') !== 'true';
      el.setAttribute('aria-checked', String(next));
      onChange?.(next);
    },
  });
  return el;
}

export function field(label, control, hint = '') {
  return h('div', { class: 'form-row-col' },
    h('label', { text: label }),
    control,
    hint ? h('div', { class: 'settings-note', text: hint }) : null,
  );
}

export function setSliderFill(input) {
  const min = Number(input.min || 0);
  const max = Number(input.max || 100);
  const val = Number(input.value);
  const pct = ((val - min) / (max - min)) * 100;
  input.style.setProperty('--fill', `${pct}%`);
}

export function slider({ min = 0, max = 100, value = 50, step = 1, onInput, onChange, width = '' } = {}) {
  const input = h('input', {
    type: 'range',
    class: 'slider',
    min, max, step, value,
    style: width ? { width } : {},
  });
  setSliderFill(input);
  input.addEventListener('input', () => {
    setSliderFill(input);
    onInput?.(Number(input.value));
  });
  input.addEventListener('change', () => onChange?.(Number(input.value)));
  return input;
}

export async function copyToClipboard(text, label = 'Copied to clipboard') {
  try {
    await navigator.clipboard.writeText(text);
    toast({ title: label, icon: 'clipboard-check' });
    return true;
  } catch {
    toast({ title: 'Could not copy', text: 'Clipboard access was blocked by the browser.', icon: 'alert' });
    return false;
  }
}

/* Close open menu when clicking inside the menubar (which manages its own state) */
export function hasOpenSurface() {
  return !!activeMenu || !!activePopover;
}
