/* ============================================================
   Nova OS — utilities
   ============================================================ */

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

/** Tiny element factory. */
export function h(tag, props = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class' || k === 'className') el.className = v;
    else if (k === 'html') el.innerHTML = v;
    else if (k === 'text') el.textContent = v;
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else if (k === 'dataset' && typeof v === 'object') Object.assign(el.dataset, v);
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'value') el.value = v;
    else if (k === 'checked') el.checked = !!v;
    else if (v === true) el.setAttribute(k, '');
    else el.setAttribute(k, v);
  }
  for (const c of children.flat(3)) {
    if (c === null || c === undefined || c === false) continue;
    el.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return el;
}

/** Set innerHTML from a trusted template and return the first element. */
export function elFromHTML(html) {
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}

export const clamp = (n, min, max) => Math.min(max, Math.max(min, n));
export const lerp = (a, b, t) => a + (b - a) * t;

let uidCounter = 0;
export function uid(prefix = 'id') {
  uidCounter++;
  return `${prefix}_${Date.now().toString(36)}${uidCounter.toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}

export function debounce(fn, wait = 200) {
  let t = null;
  const wrapped = (...args) => {
    clearTimeout(t);
    t = setTimeout(() => { t = null; fn(...args); }, wait);
  };
  wrapped.cancel = () => { clearTimeout(t); t = null; };
  wrapped.flush = (...args) => { clearTimeout(t); t = null; fn(...args); };
  return wrapped;
}

export function throttle(fn, wait = 100) {
  let last = 0;
  let timer = null;
  return (...args) => {
    const now = Date.now();
    const remaining = wait - (now - last);
    if (remaining <= 0) {
      last = now;
      fn(...args);
    } else if (!timer) {
      timer = setTimeout(() => {
        timer = null;
        last = Date.now();
        fn(...args);
      }, remaining);
    }
  };
}

export function escapeHTML(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function escapeAttr(str) {
  return escapeHTML(str);
}

export function capitalize(s) {
  return s ? s[0].toUpperCase() + s.slice(1) : s;
}

export function formatBytes(bytes = 0) {
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  let i = 0;
  let n = bytes;
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
  return `${n < 10 && i > 0 ? n.toFixed(1) : Math.round(n)} ${units[i]}`;
}

const pad = (n) => String(n).padStart(2, '0');

export function formatTime(date = new Date(), { seconds = false, h24 = false } = {}) {
  const d = date instanceof Date ? date : new Date(date);
  let hours = d.getHours();
  let suffix = '';
  if (!h24) {
    suffix = hours >= 12 ? ' PM' : ' AM';
    hours = hours % 12 || 12;
  }
  return `${h24 ? pad(hours) : hours}:${pad(d.getMinutes())}${seconds ? ':' + pad(d.getSeconds()) : ''}${suffix}`;
}

export function formatDate(date = new Date(), opts = {}) {
  const d = date instanceof Date ? date : new Date(date);
  return d.toLocaleDateString(undefined, opts.weekday
    ? { weekday: 'long', month: 'long', day: 'numeric' }
    : opts.short
      ? { month: 'short', day: 'numeric' }
      : opts.full
        ? { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }
        : { month: 'short', day: 'numeric', year: 'numeric' });
}

export function formatDateTime(ts) {
  return `${formatDate(ts)} · ${formatTime(ts)}`;
}

export function relativeTime(ts) {
  const now = Date.now();
  const diff = now - new Date(ts).getTime();
  if (diff < 45_000) return 'Just now';
  if (diff < 3_600_000) return `${Math.round(diff / 60_000)} min ago`;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const d = new Date(ts);
  if (d >= today) return formatTime(ts);
  const yest = new Date(today); yest.setDate(yest.getDate() - 1);
  if (d >= yest) return `Yesterday`;
  if (diff < 7 * 86_400_000) return d.toLocaleDateString(undefined, { weekday: 'long' });
  return formatDate(ts, { short: true });
}

export function formatDuration(ms) {
  const s = Math.floor(ms / 1000);
  const days = Math.floor(s / 86400);
  const hours = Math.floor((s % 86400) / 3600);
  const mins = Math.floor((s % 3600) / 60);
  const secs = s % 60;
  if (days) return `${days}d ${hours}h ${mins}m`;
  if (hours) return `${hours}h ${mins}m`;
  if (mins) return `${mins}m ${secs}s`;
  return `${secs}s`;
}

export function pathJoin(...parts) {
  return parts
    .filter(Boolean)
    .join('/')
    .replace(/\/+/g, '/');
}

export function basename(p = '') {
  const parts = String(p).split('/').filter(Boolean);
  return parts[parts.length - 1] || '/';
}

export function dirname(p = '/') {
  const parts = String(p).split('/').filter(Boolean);
  parts.pop();
  return '/' + parts.join('/');
}

export function extname(name = '') {
  const base = basename(name);
  const i = base.lastIndexOf('.');
  return i > 0 ? base.slice(i + 1).toLowerCase() : '';
}

export function stripExt(name = '') {
  return name.replace(/\.[^.]+$/, '');
}

export function isEditable(el) {
  if (!el) return false;
  const tag = el.tagName;
  return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || el.isContentEditable;
}

export function escapeRegExp(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export function highlightMatch(text, query) {
  if (!query) return escapeHTML(text);
  const q = escapeRegExp(query);
  return escapeHTML(text).replace(new RegExp(`(${q})`, 'ig'), '<mark>$1</mark>');
}

/** Run a callback after the browser has painted. */
export const nextFrame = (fn) => requestAnimationFrame(() => requestAnimationFrame(fn));

export function randomId(prefix) {
  return `${prefix}-${Math.random().toString(36).slice(2, 9)}`;
}

export function downloadText(filename, text, mime = 'text/plain') {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

/** Very small fuzzy matcher: returns score or -1. */
export function fuzzyScore(query, text) {
  const q = query.toLowerCase().trim();
  const t = text.toLowerCase();
  if (!q) return 0;
  if (t === q) return 1000;
  if (t.startsWith(q)) return 800 - t.length;
  const idx = t.indexOf(q);
  if (idx >= 0) return 600 - idx * 2;
  let qi = 0;
  let score = 0;
  for (let i = 0; i < t.length && qi < q.length; i++) {
    if (t[i] === q[qi]) { qi++; score += 10; }
  }
  return qi === q.length ? score : -1;
}

/** Ensures a string is a safe-ish http(s) url, adding a scheme when missing. */
export function normalizeURL(input) {
  let v = String(input || '').trim();
  if (!v) return '';
  if (/^[a-z][a-z0-9+.-]*:/i.test(v)) {
    return /^(https?|about|data|mailto):/i.test(v) ? v : '';
  }
  const looksLikeHost = /^[\w-]+(\.[\w-]+)+(:\d+)?(\/.*)?$/.test(v) || v.startsWith('localhost');
  if (!looksLikeHost) {
    return `https://duckduckgo.com/?q=${encodeURIComponent(v)}`;
  }
  return `https://${v}`;
}

export function hostOf(url) {
  try { return new URL(url).hostname.replace(/^www\./, ''); } catch { return url; }
}

export function getStoreStats() {
  let total = 0;
  const items = [];
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (!key) continue;
    const val = localStorage.getItem(key) || '';
    const bytes = new Blob([key + val]).size;
    total += bytes;
    items.push({ key, bytes });
  }
  return { total, items };
}
