/* ============================================================
   Nova OS — wallpapers (generated gradients, no assets)
   ============================================================ */

export const wallpapers = [
  {
    id: 'aurora',
    name: 'Aurora',
    css: `radial-gradient(120% 90% at 18% 8%, #1e4f8f 0%, rgba(30,79,143,0) 55%),
          radial-gradient(90% 80% at 82% 12%, #6e3fa8 0%, rgba(110,63,168,0) 58%),
          radial-gradient(100% 100% at 55% 100%, #0a6e72 0%, rgba(10,110,114,0) 62%),
          linear-gradient(155deg, #06111f 0%, #0a0d1c 50%, #140a24 100%)`,
  },
  {
    id: 'nebula',
    name: 'Nebula',
    css: `radial-gradient(90% 70% at 25% 20%, #5a2a9c 0%, rgba(90,42,156,0) 60%),
          radial-gradient(80% 70% at 75% 35%, #b03a7a 0%, rgba(176,58,122,0) 60%),
          radial-gradient(100% 80% at 50% 100%, #1b1d4d 0%, rgba(27,29,77,0) 70%),
          linear-gradient(160deg, #0b0714, #160b26 55%, #0a0614)`,
  },
  {
    id: 'sunset',
    name: 'Sunset',
    css: `radial-gradient(80% 60% at 78% 12%, #ffb26b 0%, rgba(255,178,107,0) 58%),
          radial-gradient(70% 60% at 22% 26%, #ff7a8a 0%, rgba(255,122,138,0) 62%),
          radial-gradient(130% 90% at 50% 108%, #ffd08a 0%, rgba(255,208,138,0) 55%),
          linear-gradient(180deg, #2a1b52 0%, #6c3465 42%, #c95a5c 78%, #f0955b 100%)`,
  },
  {
    id: 'lagoon',
    name: 'Lagoon',
    css: `radial-gradient(90% 80% at 20% 10%, #0f6f7a 0%, rgba(15,111,122,0) 60%),
          radial-gradient(100% 90% at 85% 30%, #0b4a6b 0%, rgba(11,74,107,0) 60%),
          radial-gradient(90% 70% at 40% 100%, #0d5d63 0%, rgba(13,93,99,0) 60%),
          linear-gradient(160deg, #03171d, #062a32 50%, #04121a)`,
  },
  {
    id: 'graphite',
    name: 'Graphite',
    css: `radial-gradient(100% 80% at 50% 0%, #3a3d44 0%, rgba(58,61,68,0) 60%),
          radial-gradient(80% 60% at 82% 82%, #26282e 0%, rgba(38,40,46,0) 70%),
          linear-gradient(160deg, #16171a, #25272c 60%, #101114)`,
  },
  {
    id: 'midnight',
    name: 'Midnight',
    css: `radial-gradient(100% 80% at 50% 0%, #14335c 0%, rgba(20,51,92,0) 60%),
          radial-gradient(70% 60% at 85% 90%, #0d2440 0%, rgba(13,36,64,0) 70%),
          linear-gradient(160deg, #02040a, #060b14 60%, #020308)`,
  },
  {
    id: 'blossom',
    name: 'Blossom',
    css: `radial-gradient(90% 70% at 20% 20%, #ffd9e8 0%, rgba(255,217,232,0) 60%),
          radial-gradient(80% 80% at 80% 18%, #e9d5ff 0%, rgba(233,213,255,0) 60%),
          radial-gradient(100% 100% at 50% 100%, #fff2e2 0%, rgba(255,242,226,0) 70%),
          linear-gradient(160deg, #f7eaf5, #fce7ec 55%, #fff4ea)`,
  },
  {
    id: 'sand',
    name: 'Sand',
    css: `radial-gradient(90% 70% at 75% 10%, #f6d9b0 0%, rgba(246,217,176,0) 60%),
          radial-gradient(80% 80% at 20% 30%, #e8c9a0 0%, rgba(232,201,160,0) 60%),
          radial-gradient(100% 90% at 50% 100%, #f3e5cf 0%, rgba(243,229,207,0) 70%),
          linear-gradient(165deg, #e6d2b7, #f1e3cf 55%, #dcc5a8)`,
  },
];

export function getWallpaper(id) {
  return wallpapers.find((w) => w.id === id) || wallpapers[0];
}

export function wallpaperCSS(id) {
  return getWallpaper(id).css;
}
