/* ============================================================
   Nova OS — window manager
   Dragging, resizing, focus, z-index, minimize / maximize.
   ============================================================ */

import { h, clamp, uid, nextFrame } from './util.js';
import { icon } from './icons.js';
import { emit } from './bus.js';
import { get } from './state.js';
import sounds from './sound.js';

const windows = new Map();
let zCounter = 200;
let cascade = 0;
let activeId = null;

const layer = () => document.getElementById('windows-layer');

export function getWorkArea() {
  const menubarH = 30;
  const dock = get('dock', {});
  const dockVisible = !dock.autohide;
  const dockSize = 92;
  const bottom = dockVisible && dock.position === 'bottom' ? 100 : 8;
  const left = dockVisible && dock.position === 'left' ? dockSize : 0;
  const right = dockVisible && dock.position === 'right' ? dockSize : 0;
  return {
    left,
    top: menubarH,
    right: window.innerWidth - right,
    bottom: window.innerHeight - bottom,
    width: window.innerWidth - left - right,
    height: window.innerHeight - menubarH - bottom,
  };
}

export function getWindows() {
  return Array.from(windows.values());
}

export function getWindow(idOrApp) {
  if (!idOrApp) return null;
  if (windows.has(idOrApp)) return windows.get(idOrApp);
  return getWindows().find((w) => w.appId === idOrApp && w.state !== 'minimized')
    || getWindows().find((w) => w.appId === idOrApp);
}

export function getWindowsForApp(appId) {
  return getWindows().filter((w) => w.appId === appId);
}

export function getActiveWindow() {
  return activeId ? windows.get(activeId) : null;
}

export function getActiveAppId() {
  return activeId ? windows.get(activeId)?.appId || null : null;
}

function applyRect(win, r) {
  win.rect = { ...r };
  win.el.style.left = `${Math.round(r.x)}px`;
  win.el.style.top = `${Math.round(r.y)}px`;
  win.el.style.width = `${Math.round(r.w)}px`;
  win.el.style.height = `${Math.round(r.h)}px`;
}

function focusNextWindow(excludeId) {
  const candidates = getWindows()
    .filter((w) => w.id !== excludeId && w.state !== 'minimized')
    .sort((a, b) => Number(b.el.style.zIndex || 0) - Number(a.el.style.zIndex || 0));
  if (candidates.length) focusWindow(candidates[0].id);
  else {
    activeId = null;
    emit('window:blur');
    emit('active-app', { appId: null, win: null });
  }
}

export function focusWindow(id) {
  const win = windows.get(id);
  if (!win) return;
  if (win.state === 'minimized') {
    restoreWindow(id);
    return;
  }
  if (activeId === id) {
    if (win.el.style.zIndex !== String(zCounter)) {
      zCounter += 1;
      win.el.style.zIndex = String(zCounter);
    }
    return;
  }
  zCounter += 1;
  win.el.style.zIndex = String(zCounter);
  win.el.classList.add('active');
  win.el.classList.remove('inactive');
  for (const other of windows.values()) {
    if (other.id !== id) {
      other.el.classList.remove('active');
      other.el.classList.add('inactive');
    }
  }
  activeId = id;
  emit('window:focus', win);
  emit('active-app', { appId: win.appId, win });
}

export function setWindowTitle(id, title) {
  const win = windows.get(id);
  if (!win) return;
  win.title = title;
  const titleEl = win.el.querySelector('.window-title');
  if (titleEl) titleEl.textContent = title;
  if (activeId === id) emit('window:title', win);
}

export function createWindow(opts) {
  const {
    appId,
    app,
    title = app?.name || 'Window',
    width = 900,
    height = 600,
    minWidth = 320,
    minHeight = 220,
    x,
    y,
    resizable = true,
    singleton = false,
    params = {},
    center = true,
  } = opts;

  if (singleton) {
    const existing = getWindows().find((w) => w.appId === appId);
    if (existing) {
      if (existing.state === 'minimized') restoreWindow(existing.id);
      focusWindow(existing.id);
      if (params && existing.ctx?.receiveParams) existing.ctx.receiveParams(params);
      return existing;
    }
  }

  const area = getWorkArea();
  const w = Math.max(minWidth, Math.min(width, area.width - 32));
  const winH = Math.max(minHeight, Math.min(height, area.height - 32));

  let px;
  let py;
  if (center && x === undefined) {
    px = area.left + (area.width - w) / 2 + (cascade % 5) * 26 - 52;
    py = area.top + Math.max(10, (area.height - winH) / 2 - 24) + (cascade % 5) * 22;
  } else {
    px = x ?? area.left + 40;
    py = y ?? area.top + 40;
  }
  cascade = (cascade + 1) % 8;
  px = clamp(px, area.left + 12, Math.max(area.left + 12, area.right - w - 12));
  py = clamp(py, area.top + 8, Math.max(area.top + 8, area.bottom - winH - 8));

  const id = uid('win');
  zCounter += 1;

  const el = h('div', {
    class: 'window active',
    dataset: { id, app: appId },
    style: {
      left: `${Math.round(px)}px`,
      top: `${Math.round(py)}px`,
      width: `${Math.round(w)}px`,
      height: `${Math.round(winH)}px`,
      zIndex: String(zCounter),
    },
  });

  const chrome = h('div', { class: 'window-chrome' });
  const traffic = h('div', { class: 'traffic' });
  const closeBtn = h('button', { class: 'tl close', title: 'Close', 'aria-label': 'Close', html: icon('x') });
  const minBtn = h('button', { class: 'tl min', title: 'Minimize', 'aria-label': 'Minimize', html: icon('minus') });
  const maxBtn = h('button', { class: 'tl max', title: 'Zoom', 'aria-label': 'Maximize', html: icon('plus') });
  traffic.append(closeBtn, minBtn, maxBtn);

  const titleEl = h('div', { class: 'window-title', text: title });
  const tools = h('div', { class: 'window-tools' });
  chrome.append(traffic, titleEl, tools);

  const bodyEl = h('div', { class: 'window-body' });
  el.append(chrome, bodyEl);

  if (resizable) {
    for (const dir of ['n', 's', 'e', 'w', 'ne', 'nw', 'se', 'sw']) {
      el.append(h('div', { class: `rh ${dir}`, dataset: { dir } }));
    }
  }

  layer().append(el);
  sounds.open();

  const win = {
    id,
    appId,
    app,
    el,
    bodyEl,
    ctx: null,
    api: null,
    state: 'normal',
    rect: { x: px, y: py, w, h: winH },
    prevRect: null,
    title,
    params,
    minWidth,
    minHeight,
    resizable,
    createdAt: Date.now(),
  };
  windows.set(id, win);

  closeBtn.addEventListener('click', (e) => { e.stopPropagation(); closeWindow(id); });
  minBtn.addEventListener('click', (e) => { e.stopPropagation(); minimizeWindow(id); });
  maxBtn.addEventListener('click', (e) => { e.stopPropagation(); toggleMaximize(id); });

  el.addEventListener('pointerdown', () => focusWindow(id), true);

  let lastChromeClick = 0;
  chrome.addEventListener('pointerdown', (e) => {
    if (e.button !== 0 || e.target.closest('.tl, .window-tools, button')) return;
    startDrag(win, e);
  });
  chrome.addEventListener('dblclick', (e) => {
    if (e.target.closest('.tl, .window-tools, button')) return;
    const now = Date.now();
    if (now - lastChromeClick < 400) return;
    lastChromeClick = now;
    toggleMaximize(id);
  });

  for (const handle of el.querySelectorAll('.rh')) {
    handle.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      e.preventDefault();
      startResize(win, e, handle.dataset.dir);
    });
  }

  win.ctx = {
    win,
    app,
    params,
    setTitle: (t) => setWindowTitle(id, t),
    setTools: (node) => {
      tools.replaceChildren();
      if (node) tools.append(node);
    },
    close: () => closeWindow(id),
    minimize: () => minimizeWindow(id),
    maximize: () => maximizeWindow(id),
    restore: () => restoreWindow(id),
    focus: () => focusWindow(id),
    toast: (opts) => emit('ui:toast', opts),
    receiveParams: (p) => win.ctx.onParams?.(p),
  };

  try {
    win.api = app?.mount ? app.mount(bodyEl, win.ctx) : null;
  } catch (err) {
    console.error(`[app:${appId}] mount failed`, err);
    bodyEl.append(h('div', { class: 'empty-state', style: { padding: '30px' } },
      h('b', { text: 'This app could not start' }),
      h('span', { text: String(err?.message || err) }),
      h('pre', {
        style: { fontSize: '10px', maxWidth: '100%', overflow: 'auto', textAlign: 'left', marginTop: '10px', color: 'var(--text-3)' },
        text: String(err?.stack || ''),
      }),
    ));
  }

  // dictate active state of previously open windows
  for (const other of windows.values()) {
    if (other.id !== id) { other.el.classList.remove('active'); other.el.classList.add('inactive'); }
  }

  activeId = id;
  focusWindow(id);
  emit('window:open', win);
  emit('window:state', win);

  if (params?.__noFocus) {
    win.el.classList.remove('active');
    win.el.classList.add('inactive');
  }

  return win;
}

/* ------------------------------------------------------------
   Dragging
   ------------------------------------------------------------ */

function startDrag(win, e) {
  if (!windows.has(win.id)) return;
  focusWindow(win.id);

  let originX = win.rect.x;
  let originY = win.rect.y;

  if (win.state === 'maximized') {
    const area = getWorkArea();
    const ratio = (e.clientX - win.rect.x) / win.rect.w;
    unmaximizeInstant(win);
    const nx = clamp(e.clientX - win.rect.w * ratio, area.left - win.rect.w + 120, window.innerWidth - 120);
    originX = nx;
    originY = clamp(e.clientY - 20, area.top, area.top + 40);
    applyRect(win, { ...win.rect, x: originX, y: originY });
  }

  const startX = e.clientX;
  const startY = e.clientY;
  const startRect = { ...win.rect };
  win.el.classList.add('dragging');
  document.body.style.cursor = 'grabbing';

  const onMove = (ev) => {
    const dx = ev.clientX - startX;
    const dy = ev.clientY - startY;
    const area = getWorkArea();
    const nx = clamp(startRect.x + dx, -startRect.w + 110, window.innerWidth - 110);
    const ny = clamp(startRect.y + dy, area.top, window.innerHeight - 44);
    applyRect(win, { ...startRect, x: nx, y: ny });
  };
  const onUp = () => {
    win.el.classList.remove('dragging');
    document.body.style.cursor = '';
    document.removeEventListener('pointermove', onMove);
    document.removeEventListener('pointerup', onUp);
  };
  document.addEventListener('pointermove', onMove);
  document.addEventListener('pointerup', onUp);
}

/* ------------------------------------------------------------
   Resizing
   ------------------------------------------------------------ */

function startResize(win, e, dir) {
  if (win.state === 'maximized') return;
  const startX = e.clientX;
  const startY = e.clientY;
  const start = { ...win.rect };
  win.el.classList.add('resizing');
  document.body.style.cursor = getComputedStyle(e.currentTarget).cursor;

  const onMove = (ev) => {
    let { x, y, w, h: height } = start;
    const dx = ev.clientX - startX;
    const dy = ev.clientY - startY;

    if (dir.includes('e')) w = clamp(start.w + dx, win.minWidth, window.innerWidth - start.x - 4);
    if (dir.includes('s')) height = clamp(start.h + dy, win.minHeight, window.innerHeight - start.y - 4);
    if (dir.includes('w')) {
      const nw = clamp(start.w - dx, win.minWidth, start.x + start.w);
      x = start.x + start.w - nw;
      w = nw;
    }
    if (dir.includes('n')) {
      const nh = clamp(start.h - dy, win.minHeight, start.y + start.h - 26);
      y = start.y + start.h - nh;
      height = nh;
    }
    applyRect(win, { x, y, w, h: height });
  };
  const onUp = () => {
    win.el.classList.remove('resizing');
    document.body.style.cursor = '';
    document.removeEventListener('pointermove', onMove);
    document.removeEventListener('pointerup', onUp);
  };
  document.addEventListener('pointermove', onMove);
  document.addEventListener('pointerup', onUp);
}

/* ------------------------------------------------------------
   State changes
   ------------------------------------------------------------ */

export function maximizeWindow(id) {
  const win = windows.get(id);
  if (!win || win.state === 'maximized') return;
  if (win.state === 'minimized') { restoreWindow(id); return; }
  win.prevRect = { ...win.rect };
  const area = getWorkArea();
  win.el.classList.add('animating', 'maximized');
  win.state = 'maximized';
  applyRect(win, { x: area.left, y: area.top, w: area.width, h: area.height });
  setTimeout(() => win.el.classList.remove('animating'), 280);
  emit('window:state', win);
  emit('window:maximize', win);
}

export function restoreWindow(id) {
  const win = windows.get(id);
  if (!win) return;

  if (win.state === 'minimized') {
    win.el.classList.remove('minimized');
    const target = dockTargetFor(win);
    const cx = win.rect.x + win.rect.w / 2;
    const cy = win.rect.y + win.rect.h / 2;
    if (target) {
      win.el.style.transition = 'none';
      win.el.style.transformOrigin = 'center';
      win.el.style.transform = `translate(${target.x - cx}px, ${target.y - cy}px) scale(.04)`;
      win.el.style.opacity = '0';
      void win.el.offsetWidth;
      win.el.style.transition = 'transform .34s var(--ease-out), opacity .3s';
      win.el.style.transform = '';
      win.el.style.opacity = '1';
      setTimeout(() => {
        win.el.style.transition = '';
        win.el.style.transform = '';
        win.el.style.opacity = '';
      }, 360);
    }
    win.state = win.prevRect && win.el.classList.contains('maximized') ? 'maximized' : 'normal';
    win.el.classList.remove('minimized');
    win.el.classList.add('active');
    activeId = id;
    focusWindow(id);
    sounds.open();
    emit('window:state', win);
    emit('window:restore', win);
    return;
  }

  if (win.state !== 'maximized') return;

  unmaximizeInstant(win);
  win.el.classList.add('animating');
  applyRect(win, win.prevRect || { ...win.rect });
  setTimeout(() => win.el.classList.remove('animating'), 280);
  focusWindow(id);
  emit('window:state', win);
  emit('window:restore', win);
}

function unmaximizeInstant(win) {
  win.el.classList.remove('maximized');
  const prev = win.prevRect || win.rect;
  win.state = 'normal';
  const area = getWorkArea();
  applyRect(win, {
    x: clamp(prev.x, area.left - prev.w + 110, window.innerWidth - 110),
    y: clamp(prev.y, area.top, window.innerHeight - 80),
    w: Math.min(prev.w, window.innerWidth),
    h: Math.min(prev.h, window.innerHeight),
  });
  win.prevRect = null;
}

export function toggleMaximize(id) {
  const win = windows.get(id);
  if (!win) return;
  if (win.state === 'maximized') restoreWindow(id);
  else maximizeWindow(id);
}

export function minimizeWindow(id) {
  const win = windows.get(id);
  if (!win || win.state === 'minimized') return;
  const target = dockTargetFor(win);
  const cx = win.rect.x + win.rect.w / 2;
  const cy = win.rect.y + win.rect.h / 2;
  win.state = 'minimized';
  win.el.classList.add('minimizing');
  win.el.style.transformOrigin = 'center';
  win.el.style.transition = 'transform .3s var(--ease-out), opacity .28s';
  if (target) {
    win.el.style.transform = `translate(${target.x - cx}px, ${target.y - cy}px) scale(.04)`;
  } else {
    win.el.style.transform = 'translateY(40vh) scale(.2)';
  }
  win.el.style.opacity = '0';
  sounds.minimize();
  setTimeout(() => {
    if (win.el.classList.contains('minimizing')) {
      win.el.classList.add('minimized');
      win.el.classList.remove('minimizing');
      win.el.style.transform = '';
      win.el.style.opacity = '';
      win.el.style.transition = '';
    }
  }, 300);
  if (activeId === id) focusNextWindow(id);
  emit('window:state', win);
  emit('window:minimize', win);
}

function dockTargetFor(win) {
  const item = document.querySelector(`.dock-item[data-app="${win.appId}"]`);
  if (!item) return null;
  const r = item.getBoundingClientRect();
  return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
}

export function closeWindow(id) {
  const win = windows.get(id);
  if (!win) return;
  if (win.closing) return;

  const proceed = () => {
    win.closing = true;
    const wasActive = activeId === id;
    win.el.classList.add('closing');
    win.el.classList.remove('active');
    sounds.close();
    setTimeout(() => {
      win.el.remove();
      windows.delete(id);
      try { win.api?.dispose?.(); } catch (err) { console.error('[app] dispose failed', err); }
      if (wasActive) {
        activeId = null;
        focusNextWindow(id);
      }
      emit('window:close', win);
      emit('window:state', win);
    }, 150);
  };

  if (win.ctx?.onBeforeClose) {
    Promise.resolve(win.ctx.onBeforeClose())
      .then((ok) => { if (ok !== false) proceed(); })
      .catch((err) => { console.error('[window] close hook failed', err); proceed(); });
  } else {
    proceed();
  }
}

export function closeAllForApp(appId) {
  for (const win of getWindowsForApp(appId)) closeWindow(win.id);
}

export function minimizeAll() {
  for (const win of getWindows()) if (win.state !== 'minimized') minimizeWindow(win.id);
}

export function restoreAll() {
  for (const win of getWindows()) if (win.state === 'minimized') restoreWindow(win.id);
}

export function focusApp(appId) {
  const win = getWindow(appId);
  if (win) focusWindow(win.id);
  return win;
}

export function cycleWindows() {
  const list = getWindows().filter((w) => w.state !== 'minimized');
  if (list.length < 2) return;
  const sorted = list.sort((a, b) => Number(a.el.style.zIndex) - Number(b.el.style.zIndex));
  const bottom = sorted[0];
  focusWindow(bottom.id);
}

/* Keep windows in view when the viewport changes */
let resizeTimer = null;
window.addEventListener('resize', () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    const area = getWorkArea();
    for (const win of windows.values()) {
      if (win.state === 'maximized') {
        applyRect(win, { x: area.left, y: area.top, w: area.width, h: area.height });
        continue;
      }
      const r = { ...win.rect };
      if (r.x > window.innerWidth - 100) r.x = window.innerWidth - Math.min(r.w, 400);
      if (r.y > window.innerHeight - 60) r.y = Math.max(area.top, window.innerHeight - 300);
      if (r.w > window.innerWidth) r.w = window.innerWidth;
      if (r.h > window.innerHeight - area.top) r.h = window.innerHeight - area.top - 20;
      applyRect(win, r);
    }
    emit('viewport:resize');
  }, 120);
});

/* Expose a couple of helpers for the dock / menubar */
export const wm = {
  createWindow,
  closeWindow,
  minimizeWindow,
  maximizeWindow,
  restoreWindow,
  toggleMaximize,
  focusWindow,
  focusApp,
  getWindows,
  getWindow,
  getWindowsForApp,
  getActiveWindow,
  getActiveAppId,
  setWindowTitle,
  closeAllForApp,
  minimizeAll,
  restoreAll,
  cycleWindows,
  getWorkArea,
};

export default wm;
