/* Development-only terminal command sweep (?cmdtest=1) */

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

const CHECKS = [
  ['help', /help|commands/i],
  ['neofetch', /Nova/],
  ['date', /\d/],
  ['time', /\d/],
  ['hostname', /\w/],
  ['uptime', /up/i],
  ['version', /Nova/],
  ['whoami', /nova/i],
  ['history', /history|No commands/i],
  ['sudo ls', /permission|denied|not allowed|sudo/i],
  ['pwd', /\/Users\/nova/],
  ['ls -la', /Desktop/],
  ['cd Documents', /Documents/],
  ['pwd', /\/Users\/nova\/Documents/],
  ['mkdir /Users/nova/Documents/cmdtest', /created|mkdir|exist/i],
  ['touch /Users/nova/Documents/cmdtest/a.txt', /created|touch|empty/i],
  ['echo hello > /Users/nova/Documents/cmdtest/a.txt', /wrote|written|saved|echo|hello/i],
  ['cat /Users/nova/Documents/cmdtest/a.txt', /hello/],
  ['echo hello', /hello/],
  ['cp /Users/nova/Documents/cmdtest/a.txt /Users/nova/Documents/cmdtest/b.txt', /→|copied|cp/i],
  ['mv /Users/nova/Documents/cmdtest/b.txt /Users/nova/Documents/cmdtest/c.txt', /→|moved|mv/i],
  ['tree /Users/nova/Documents/cmdtest', /cmdtest|a\.txt|c\.txt/],
  ['apps', /finder|terminal/i],
  ['open calculator', /calculator/i],
  ['windows', /Calculator/i],
  ['minimize calculator', /minimiz/i],
  ['maximize calculator', /maximiz/i],
  ['restore calculator', /restor/i],
  ['close calculator', /clos/i],
  ['theme dark', /dark/i],
  ['theme light', /light/i],
  ['theme toggle', /theme/i],
  ['wallpaper list', /Aurora/i],
  ['wallpaper nebula', /nebula/i],
  ['settings appearance', /Settings/i],
  ['notifications', /./],
  ['notifications clear', /clear/i],
  ['browser', /Browser/i],
  ['edit /Users/nova/Desktop/Welcome.md', /[Ee]ditor|[Oo]pen/],
  ['rm -r /Users/nova/Documents/cmdtest', /removed|deleted|rm/i],
  ['clear', /./],
];

export async function runCmdTest() {
  await wait(1400);
  const { OS } = await import('../api.js');
  const results = [];

  for (const [command, pattern] of CHECKS) {
    try {
      const out = await OS.exec(command);
      const text = String(out || '');
      const ok = command === 'clear' || pattern.test(text) || text === '';
      results.push({ command, ok, text: text.split('\n').slice(0, 3).join(' | ').slice(0, 120) });
    } catch (err) {
      results.push({ command, ok: false, text: String(err?.message || err) });
    }
    await wait(60);
  }

  // Close windows opened by open/settings/browser/edit
  for (const id of ['calculator', 'settings', 'browser', 'editor']) OS.closeApp(id);

  const failed = results.filter((r) => !r.ok);
  const pre = document.createElement('pre');
  pre.id = 'nova-cmdtest';
  pre.textContent = results.map((r) => `${r.ok ? 'PASS' : 'FAIL'} ${r.command} :: ${r.text}`).join('\n')
    + `\n\n${failed.length ? failed.length + ' FAILED' : 'ALL PASS (' + results.length + ')'}`;
  pre.style.cssText = 'position:fixed;left:8px;bottom:8px;z-index:99999;max-height:80vh;overflow:auto;background:#000c;color:#fff;padding:10px;font:11px monospace;border-radius:8px';
  document.body.append(pre);
  return results;
}

export default { runCmdTest };
