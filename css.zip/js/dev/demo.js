﻿/* Development-only UI demos used for visual QA (?demo=...) */

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

function rightClick(el, x, y) {
  el?.dispatchEvent(new MouseEvent('contextmenu', { bubbles: true, cancelable: true, clientX: x, clientY: y }));
}

function pointer(type, target, x, y) {
  target?.dispatchEvent(new PointerEvent(type, {
    bubbles: true,
    cancelable: true,
    clientX: x,
    clientY: y,
    pointerId: 1,
    pointerType: 'mouse',
    button: 0,
    buttons: type === 'pointerup' ? 0 : 1,
  }));
}

function measure(label, win) {
  const r = win?.el?.getBoundingClientRect();
  const rect = win?.rect || {};
  const pre = document.createElement('pre');
  pre.id = 'nova-measure';
  pre.textContent = `${label} :: window ${Math.round(r.left)},${Math.round(r.top)} ${Math.round(r.width)}x${Math.round(r.height)} | rect ${Math.round(rect.x)},${Math.round(rect.y)} ${Math.round(rect.w)}x${Math.round(rect.h)} | viewport ${window.innerWidth}x${window.innerHeight} | state=${win?.state ?? '?'}`;
  document.body.append(pre);
}

async function dragWindow(win, dx, dy) {
  const chrome = win.el.querySelector('.window-chrome') || win.el.querySelector('.window-titlebar');
  const r = chrome.getBoundingClientRect();
  const x = r.left + r.width / 2;
  const y = r.top + r.height / 2;
  pointer('pointerdown', chrome, x, y);
  await wait(30);
  pointer('pointermove', document, x + dx / 2, y + dy / 2);
  await wait(30);
  pointer('pointermove', document, x + dx, y + dy);
  await wait(30);
  pointer('pointerup', document, x + dx, y + dy);
  await wait(140);
}

async function resizeWindow(win, dx, dy) {
  const handle = win.el.querySelector('.rh.se') || win.el.querySelector('.rh');
  const r = handle.getBoundingClientRect();
  const x = r.left + r.width / 2;
  const y = r.top + r.height / 2;
  pointer('pointerdown', handle, x, y);
  await wait(30);
  pointer('pointermove', document, x + dx, y + dy);
  await wait(60);
  pointer('pointerup', document, x + dx, y + dy);
  await wait(140);
}

export async function runDemo(kind) {
  if (new URLSearchParams(location.search).get('noanim') === '1') {
    const style = document.createElement('style');
    style.textContent = '*,*::before,*::after{transition:none!important;animation:none!important}';
    document.head.append(style);
  }
  await wait(900);
  if (kind === 'desktop-menu') {
    const el = document.getElementById('desktop');
    const rect = el.getBoundingClientRect();
    rightClick(el, rect.width * 0.45, rect.height * 0.5);
  } else if (kind === 'app-menu') {
    window.OS?.openApp('finder');
    await wait(700);
    document.querySelector('.mb-appname')?.click();
  } else if (kind === 'file-menu') {
    const win = window.OS?.openApp('finder');
    await wait(700);
    const tile = win?.el.querySelector('.file-tile');
    const r = tile?.getBoundingClientRect();
    rightClick(tile, r?.left + 30, r?.top + 30);
  } else if (kind === 'logo-menu') {
    document.querySelector('.mb-logo')?.click();
    await wait(300);
  } else if (kind === 'about') {
    document.querySelector('.mb-logo')?.click();
    await wait(250);
    [...document.querySelectorAll('.menu .menu-item')].find((n) => n.textContent.includes('About'))?.click();
    await wait(400);
  } else if (kind === 'calendar-new') {
    const win = window.OS?.openApp('calendar');
    await wait(700);
    win.api?.newEvent?.();
    await wait(500);
  } else if (kind === 'calendar-flow') {
    const win = window.OS?.openApp('calendar');
    await wait(700);
    const before = win.api.getEvents().length;
    win.api.newEvent();
    await wait(400);
    const modal = document.querySelector('.modal');
    const title = modal?.querySelector('input.input');
    if (title) {
      title.value = 'QA Sync';
      title.dispatchEvent(new Event('input', { bubbles: true }));
    }
    modal?.querySelector('.btn-primary')?.click();
    await wait(700);
    const after = win.api.getEvents();
    const added = after.find((e) => e.title === 'QA Sync');
    const titleOk = modal ? modal.querySelector('.modal-head h3')?.textContent : 'no-modal';
    const pre = document.createElement('pre');
    pre.id = 'nova-measure';
    pre.textContent = `heading=${titleOk} | before=${before} after=${after.length} | added=${added ? JSON.stringify({ date: added.date, time: added.time, cal: added.calendar }) : 'NO'}`;
    document.body.append(pre);
    if (added) win.api.deleteEvent(added.id);
  } else if (kind === 'settings-probe') {
    const win = window.OS?.openApp('settings');
    await wait(800);
    const out = [];
    const check = (name, ok, extra = '') => out.push(`${ok ? 'PASS' : 'FAIL'} ${name}${extra ? ' :: ' + extra : ''}`);

    win.api.open('desktop');
    await wait(400);
    const leftBtn = [...win.el.querySelectorAll('.segmented button')].find((b) => b.textContent.trim() === 'Left');
    const layer = document.getElementById('dock-layer');
    leftBtn?.click();
    await wait(500);
    check('dock position left via settings', layer.classList.contains('left'), layer.className);
    [...win.el.querySelectorAll('.segmented button')].find((b) => b.textContent.trim() === 'Bottom')?.click();
    await wait(400);
    check('dock position restored', !layer.classList.contains('left'), layer.className);

    win.api.open('appearance');
    await wait(400);
    const accentBefore = document.documentElement.dataset.accent;
    const wallBefore = document.getElementById('wallpaper').style.background;
    const swatches = win.el.querySelectorAll('.accent-swatch');
    swatches[2]?.click();
    await wait(300);
    const accentAfter = document.documentElement.dataset.accent;
    check('accent swatch applies', !!accentAfter && accentAfter !== accentBefore, `${accentBefore} → ${accentAfter}`);
    const wps = win.el.querySelectorAll('.wallpaper-card');
    wps[2]?.click();
    await wait(400);
    check('wallpaper card applies', document.getElementById('wallpaper').style.background !== wallBefore, `${wps.length} wallpapers`);
    window.OS.setAccent('blue');
    window.OS.setWallpaper('aurora');

    const pre = document.createElement('pre');
    pre.id = 'nova-measure';
    pre.textContent = out.join('\n') + `\n\n${out.some((l) => l.startsWith('FAIL')) ? 'FAILURES' : 'ALL PASS'}`;
    document.body.append(pre);
  } else if (kind === 'desktop-drag') {
    await wait(500);
    const node = document.querySelector('.desk-item[data-path="/Users/nova/Desktop/Welcome.md"]');
    const before = localStorage.getItem('nova.desktop.layout') || '{}';
    const r = node?.getBoundingClientRect();
    const opts = (x, y) => ({ bubbles: true, cancelable: true, button: 0, buttons: 1, pointerId: 1, pointerType: 'mouse', clientX: x, clientY: y });
    node?.dispatchEvent(new PointerEvent('pointerdown', opts(r.left + 20, r.top + 20)));
    await wait(120);
    document.dispatchEvent(new PointerEvent('pointermove', opts(r.left + 90, r.top + 70)));
    await wait(120);
    document.dispatchEvent(new PointerEvent('pointerup', opts(r.left + 90, r.top + 70)));
    await wait(400);
    const after = localStorage.getItem('nova.desktop.layout') || '{}';
    if (before === '{}') localStorage.removeItem('nova.desktop.layout');
    const pre = document.createElement('pre');
    pre.id = 'nova-measure';
    pre.textContent = `dragged=${before !== after} | moved=${node?.style.top || ''}/${node?.style.right || ''} | layout=${after}`;
    document.body.append(pre);
  } else if (kind === 'dock-reorder') {
    await wait(700);
    const before = window.OS.settings.get('dock.items').slice();
    const src = document.querySelector('.dock-item[data-app="finder"]');
    const dst = document.querySelector('.dock-item[data-app="notes"]');
    const dt = new DataTransfer();
    src.dispatchEvent(new DragEvent('dragstart', { bubbles: true, cancelable: true, dataTransfer: dt }));
    await wait(150);
    const r = dst.getBoundingClientRect();
    dst.dispatchEvent(new DragEvent('dragover', { bubbles: true, cancelable: true, dataTransfer: dt, clientX: r.left + r.width * 0.8, clientY: r.top + 20 }));
    await wait(120);
    dst.dispatchEvent(new DragEvent('drop', { bubbles: true, cancelable: true, dataTransfer: dt, clientX: r.left + r.width * 0.8, clientY: r.top + 20 }));
    src.dispatchEvent(new DragEvent('dragend', { bubbles: true, cancelable: true, dataTransfer: dt }));
    await wait(500);
    const after = window.OS.settings.get('dock.items').slice();
    window.OS.settings.set('dock.items', before);
    const pre = document.createElement('pre');
    pre.id = 'nova-measure';
    pre.textContent = `moved=${JSON.stringify(before)} -> ${JSON.stringify(after)} | changed=${before.join() !== after.join()} | finderIndex=${after.indexOf('finder')} notesIndex=${after.indexOf('notes')}`;
    document.body.append(pre);
  } else if (kind === 'store-details') {
    const win = window.OS?.openApp('appstore');
    await wait(900);
    win.el.querySelector('.store-app-row')?.click();
    await wait(400);
  } else if (kind === 'dock-menu') {
    const item = document.querySelector('.dock-item[data-app="finder"]');
    const r = item?.getBoundingClientRect();
    rightClick(item, r?.left + 20, r?.top + 10);
    await wait(250);
    const menu = document.querySelector('.menu');
    const mr = menu?.getBoundingClientRect();
    const pre = document.createElement('pre');
    pre.id = 'nova-measure';
    pre.textContent = `anchor ${Math.round(r.left)},${Math.round(r.top)} ${Math.round(r.width)}x${Math.round(r.height)} | menu ${Math.round(mr.left)},${Math.round(mr.top)} ${Math.round(mr.width)}x${Math.round(mr.height)} | vh=${window.innerHeight}`;
    document.body.append(pre);
  } else if (kind === 'menus') {
    window.OS?.openApp('browser');
    await wait(700);
    const buttons = document.querySelectorAll('#menubar .mb-menus .mb-item');
    buttons[0]?.click();
  } else if (kind === 'drag') {
    const win = window.OS?.openApp('finder');
    await wait(800);
    const before = win.el.getBoundingClientRect();
    await dragWindow(win, 170, 96);
    await resizeWindow(win, 120, 70);
    measure(`drag from ${Math.round(before.left)},${Math.round(before.top)}`, win);
  } else if (kind === 'maximize') {
    const win = window.OS?.openApp('notes');
    await wait(800);
    const chrome = win.el.querySelector('.window-chrome') || win.el.querySelector('.window-titlebar');
    const r = chrome.getBoundingClientRect();
    const opts = { bubbles: true, cancelable: true, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, button: 0 };
    chrome.dispatchEvent(new MouseEvent('mousedown', opts));
    chrome.dispatchEvent(new MouseEvent('mouseup', opts));
    chrome.dispatchEvent(new MouseEvent('click', opts));
    chrome.dispatchEvent(new MouseEvent('dblclick', opts));
    await wait(1400);
    measure('after double click', win);
  } else if (kind === 'minimize') {
    const win = window.OS?.openApp('calculator');
    await wait(700);
    win.el.querySelector('.tl.min')?.click();
    await wait(900);
  } else if (kind === 'spotlight-file') {
    window.OS?.spotlight('welcome');
  } else if (kind === 'cal-probe') {
    const icon = document.querySelector('.dock-item[data-app="calendar"] .app-icon');
    const month = icon?.querySelector('.cal-tile-month');
    const day = icon?.querySelector('.cal-tile-day');
    const cs = icon ? getComputedStyle(icon) : null;
    const dm = month ? getComputedStyle(month) : null;
    const dd = day ? getComputedStyle(day) : null;
    const pre = document.createElement('pre');
    pre.id = 'nova-measure';
    pre.textContent = [
      `icon ${JSON.stringify(icon?.getBoundingClientRect().toJSON())} size=${cs?.getPropertyValue('--size')} w=${cs?.width} h=${cs?.height} disp=${cs?.display} pad=${cs?.padding} overflow=${cs?.overflow}`,
      `month ${JSON.stringify(month?.getBoundingClientRect().toJSON())} fs=${dm?.fontSize} mt=${dm?.marginTop}`,
      `day ${JSON.stringify(day?.getBoundingClientRect().toJSON())} fs=${dd?.fontSize} mt=${dd?.marginTop}`,
    ].join('\n');
    document.body.append(pre);
  } else if (kind === 'terminal-keys') {
    const win = window.OS?.openApp('terminal');
    await wait(900);
    const input = win.el.querySelector('.term-input');
    input.focus();
    const type = (text) => { input.value = text; input.dispatchEvent(new Event('input', { bubbles: true })); };
    const key = (k) => input.dispatchEvent(new KeyboardEvent('keydown', { key: k, bubbles: true, cancelable: true }));
    type('hel');
    await wait(200);
    const suggestions = [...win.el.querySelectorAll('.term-suggest-item, .ts-item, .term-suggest *')]
      .map((n) => n.textContent.trim()).filter(Boolean).slice(0, 6);
    key('Tab');
    await wait(150);
    const completed = input.value;
    key('Enter');
    await wait(600);
    type('pwd');
    key('Enter');
    await wait(300);
    key('ArrowUp');
    await wait(120);
    const historyValue = input.value;
    key('Enter');
    await wait(400);
    const text = win.el.querySelector('.term-screen')?.innerText || '';
    const pre = document.createElement('pre');
    pre.id = 'nova-measure';
    pre.textContent = `suggest=${JSON.stringify(suggestions)}\ncompleted=${JSON.stringify(completed)}\nhistory=${JSON.stringify(historyValue)}\n--- screen ---\n${text.split('\n').slice(-8).join('\n')}`;
    document.body.append(pre);
  } else if (kind === 'editor-save') {
    const path = '/Users/nova/Documents/nova-demo.txt';
    window.OS?.writeFile(path, 'line one\n');
    const win = window.OS?.openApp('editor', { path });
    await wait(900);
    const textarea = win.el.querySelector('textarea');
    textarea.value = 'line one\nline two edited';
    textarea.dispatchEvent(new Event('input', { bubbles: true }));
    await wait(200);
    const dirty = win.el.querySelector('.unsaved-dot')?.classList.contains('on');
    textarea.dispatchEvent(new KeyboardEvent('keydown', { key: 's', ctrlKey: true, bubbles: true, cancelable: true }));
    await wait(700);
    const saved = window.OS.readFile(path);
    window.OS.deleteFile(path);
    const pre = document.createElement('pre');
    pre.id = 'nova-measure';
    pre.textContent = `dirty=${dirty} saved=${JSON.stringify(saved)} dirtyAfter=${win.el.querySelector('.unsaved-dot')?.classList.contains('on')}`;
    document.body.append(pre);
  } else if (kind === 'calc-notes') {
    const calc = window.OS?.openApp('calculator');
    await wait(500);
    calc.api.input('12*7=');
    await wait(200);
    const value = calc.el.querySelector('.calc-value')?.textContent;
    window.OS?.closeApp('calculator');

    const notes = window.OS?.openApp('notes');
    await wait(600);
    const created = window.OS.notes.create('Demo note', 'Body from self test');
    await wait(300);
    const titleInput = notes.el.querySelector('.note-title');
    const bodyInput = notes.el.querySelector('.note-body');
    if (titleInput) { titleInput.value = 'Edited title'; titleInput.dispatchEvent(new Event('input', { bubbles: true })); }
    if (bodyInput) { bodyInput.value = 'Edited body'; bodyInput.dispatchEvent(new Event('input', { bubbles: true })); }
    await wait(400);
    const saved = window.OS.notes.list().find((n) => n.id === created?.id) || window.OS.notes.list()[0];
    const leftovers = window.OS.notes.list().filter((n) => n.title === 'Edited title' || n.title === 'Demo note');
    for (const n of leftovers) window.OS.notes.remove(n.id);
    const pre = document.createElement('pre');
    pre.id = 'nova-measure';
    pre.textContent = `calcValue=${value} | note=${JSON.stringify(saved && { title: saved.title, body: saved.body })} | count=${window.OS.notes.list().length}`;
    document.body.append(pre);
  } else if (kind === 'interactions') {
    const out = [];
    const check = (name, ok, extra = '') => out.push(`${ok ? 'PASS' : 'FAIL'} ${name}${extra ? ' :: ' + extra : ''}`);

    // dock launch + minimize + dock restore
    const dockFinder = document.querySelector('.dock-item[data-app="finder"]');
    dockFinder.click();
    await wait(700);
    let win = document.querySelector('.window[data-app="finder"]');
    check('dock launch', !!win);
    win.querySelector('.tl.min').click();
    await wait(600);
    check('minimize via traffic light', document.querySelector('.window[data-app="finder"]')?.classList.contains('minimized'));
    check('minimized dot state', dockFinder.classList.contains('minimized'));
    dockFinder.click();
    await wait(800);
    check('restore from dock', !document.querySelector('.window[data-app="finder"]')?.classList.contains('minimized'));

    // desktop context menu → new folder
    const desktop = document.getElementById('desktop');
    const dr = desktop.getBoundingClientRect();
    desktop.dispatchEvent(new MouseEvent('contextmenu', { bubbles: true, cancelable: true, clientX: dr.width * 0.3, clientY: dr.height * 0.4 }));
    await wait(300);
    const items = [...document.querySelectorAll('.menu .menu-item .mi-label')].map((n) => n.textContent.trim());
    check('desktop menu items', items.length > 4, items.slice(0, 8).join(', '));
    const newFolderItem = [...document.querySelectorAll('.menu .menu-item')].find((n) => n.textContent.includes('New Folder'));
    newFolderItem?.click();
    await wait(400);
    const modal = document.querySelector('.modal');
    check('new folder dialog', !!modal);
    if (modal) {
      const input = modal.querySelector('input');
      input.value = 'QA Folder';
      input.dispatchEvent(new Event('input', { bubbles: true }));
      modal.querySelector('.btn-primary')?.click();
      await wait(600);
      check('folder created', window.OS.exists('/Users/nova/Desktop/QA Folder'));
      window.OS.deleteFile('/Users/nova/Desktop/QA Folder');
    }

    // autohide reveal
    window.OS.settings.set('dock.autohide', true);
    await wait(300);
    const hotzone = document.querySelector('.dock-hotzone');
    hotzone.dispatchEvent(new PointerEvent('pointerenter', { bubbles: true }));
    hotzone.dispatchEvent(new PointerEvent('pointermove', { bubbles: true }));
    await wait(300);
    check('dock autohide reveal', document.getElementById('dock-layer').classList.contains('revealed'));
    window.OS.settings.set('dock.autohide', false);

    // control center appearance tile
    const before = window.OS.theme;
    window.OS.controlCenter();
    await wait(400);
    const tiles = [...document.querySelectorAll('.cc-tile')];
    const appearance = tiles.find((t) => t.textContent.includes('Appearance'));
    appearance?.click();
    await wait(300);
    check('control center theme toggle', window.OS.theme !== before, `${before} → ${window.OS.theme}`);
    window.OS.setTheme(before);
    window.OS.closePanels();

    const pre = document.createElement('pre');
    pre.id = 'nova-measure';
    pre.textContent = out.join('\n') + `\n\n${out.some((l) => l.startsWith('FAIL')) ? 'FAILURES' : 'ALL PASS'}`;
    document.body.append(pre);
  } else if (kind === 'dock-left') {
    window.OS?.settings.set('dock.position', 'left');
  } else if (kind === 'dock-autohide') {
    window.OS?.settings.set('dock.autohide', true);
  } else if (kind === 'dock-probe') {
    window.OS?.openApp('finder');
    await wait(800);
    const rows = [...document.querySelectorAll('.dock-item')].slice(0, 4).map((it) => {
      const d = it.querySelector('.dock-dot');
      const r = d.getBoundingClientRect();
      const cs = getComputedStyle(d);
      return `${it.dataset.app} cls=${it.className} dot=${Math.round(r.left)},${Math.round(r.top)} ${r.width}x${r.height} op=${cs.opacity} bg=${cs.backgroundColor} color=${cs.color}`;
    });
    const pre = document.createElement('pre');
    pre.id = 'nova-measure';
    pre.textContent = `${rows.join('\n')}\ndock=${JSON.stringify(document.getElementById('dock').getBoundingClientRect().toJSON())}`;
    document.body.append(pre);
  }
}

export default { runDemo };

