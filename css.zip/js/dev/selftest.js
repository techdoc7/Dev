/* Development-only self test — never loaded unless ?selftest=1 */

import { OS } from '../api.js';
import wm from '../core/windowManager.js';

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

export async function runSelfTest() {
  const results = [];
  const check = (name, fn) => {
    try {
      const value = fn();
      results.push({ name, ok: true, value: value === undefined ? '' : value });
    } catch (err) {
      results.push({ name, ok: false, value: String(err?.message || err) });
    }
  };

  await wait(1200);

  check('apps.list', () => `${OS.apps.list().length} apps`);
  check('apps.get(terminal)', () => OS.apps.get('terminal').name);

  const dir = '/Users/nova/Desktop/SelfTest';
  check('createFolder', () => OS.createFolder(dir).path);
  check('createFile', () => OS.createFile(`${dir}/hello.txt`, 'hello nova').path);
  check('readFile', () => {
    const text = OS.readFile(`${dir}/hello.txt`);
    if (text !== 'hello nova') throw new Error(`unexpected: ${text}`);
    return text;
  });
  check('listDir', () => OS.listDir(dir).map((e) => e.name).join(','));
  check('searchFiles', () => OS.searchFiles('hello', dir).length);
  check('copyFile', () => OS.copyFile(`${dir}/hello.txt`, `${dir}/copy.txt`).to);
  check('moveFile', () => OS.moveFile(`${dir}/copy.txt`, `${dir}/moved.txt`).to);
  check('deleteFile', () => OS.deleteFile(`${dir}/moved.txt`).deleted);
  check('deleteFolder', () => OS.deleteFile(dir).deleted);
  check('exists after delete', () => OS.exists(dir));
  check('path traversal blocked', () => {
    try { OS.readFile('../../etc/passwd'); } catch { return 'blocked'; }
    throw new Error('traversal was allowed');
  });

  try {
    const pwd = await OS.exec('pwd');
    results.push({ name: 'exec pwd', ok: true, value: pwd.trim() });
  } catch (err) {
    results.push({ name: 'exec pwd', ok: false, value: String(err?.message || err) });
  }
  results.push({ name: 'exec ls', ok: true, value: await OS.exec('ls /Applications').then((t) => t.split('\n').length + ' lines').catch((e) => { throw e; }) });

  for (const cmd of ['whoami', 'date', 'echo selftest-ok', 'help', 'theme', 'apps', 'windows', 'df', 'uname', 'history']) {
    try {
      await OS.exec(cmd);
      results.push({ name: `exec ${cmd}`, ok: true, value: '' });
    } catch (err) {
      results.push({ name: `exec ${cmd}`, ok: false, value: String(err?.message || err) });
    }
  }

  check('openApp calculator', () => {
    const win = OS.openApp('calculator');
    if (!win) throw new Error('no window returned');
    return win.appId;
  });
  await wait(400);
  check('windows.list', () => OS.windows.list().length);
  check('windows.minimize', () => {
    const win = wm.getWindows().find((w) => w.appId === 'calculator');
    if (!win) throw new Error('calculator window missing');
    return OS.windows.minimize(win.id);
  });
  check('windows.restore', () => {
    const win = wm.getWindows().find((w) => w.appId === 'calculator');
    return OS.windows.restore(win.id);
  });
  check('windows.maximize', () => {
    const win = wm.getWindows().find((w) => w.appId === 'calculator');
    return OS.windows.maximize(win.id);
  });
  check('windows.restore again', () => {
    const win = wm.getWindows().find((w) => w.appId === 'calculator');
    return OS.windows.restore(win.id);
  });
  check('closeApp calculator', () => OS.closeApp('calculator'));

  check('theme switch', () => {
    const before = OS.theme;
    OS.setTheme(before === 'dark' ? 'light' : 'dark');
    const after = OS.theme;
    OS.setTheme(before);
    if (after === before) throw new Error('theme did not change');
    return `${before} → ${after}`;
  });
  check('accent', () => { OS.setAccent('violet'); return OS.settings.get('accent'); });
  check('wallpaper', () => { OS.setWallpaper('nebula'); return OS.settings.get('wallpaper'); });
  check('notifications', () => {
    OS.notify('Self test', 'notifications work', 'sparkles');
    const count = OS.notifications.list().length;
    OS.clearNotifications();
    return count;
  });
  check('spotlight api', () => { OS.spotlight(''); OS.closeSpotlight(); return 'ok'; });
  check('window geometry sane', () => {
    const win = OS.openApp('finder');
    if (win.rect.w < 200 || win.rect.h < 200) throw new Error('bad rect');
    return `${win.rect.w}x${win.rect.h}`;
  });

  await wait(300);
  const failed = results.filter((r) => !r.ok);
  const pre = document.createElement('pre');
  pre.id = 'nova-selftest';
  pre.textContent = results.map((r) => `${r.ok ? 'PASS' : 'FAIL'} ${r.name}${r.value !== '' ? ` :: ${r.value}` : ''}`).join('\n')
    + `\n\n${failed.length ? `${failed.length} FAILED` : 'ALL PASS'}`;
  pre.style.cssText = 'position:fixed;left:8px;bottom:8px;z-index:99999;max-height:70vh;overflow:auto;background:#000c;color:#fff;padding:10px;font:11px monospace;border-radius:8px';
  document.body.append(pre);
  console.log(pre.textContent);
  return results;
}

export default { runSelfTest };
