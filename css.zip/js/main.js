/* ============================================================
   Nova OS — boot
   ============================================================ */

import { applyAppearance, resolvedTheme, SYSTEM, notificationsAPI, setTheme, setWallpaper } from './core/state.js';
import { installOS } from './api.js';
import { initDesktop } from './core/desktop.js';
import { initDock } from './core/dock.js';
import { initMenubar } from './core/menubar.js';
import { initSpotlight, toggleSpotlight, closeSpotlight } from './core/spotlight.js';
import { initLockScreen, lockScreen, isLocked } from './core/lockscreen.js';
import { closeMenu } from './core/ui.js';
import wm from './core/windowManager.js';

const bootEl = () => document.getElementById('boot');

let started = false;
let bootFinished = false;

/* ------------------------------------------------------------
   Error surfacing
   ------------------------------------------------------------ */

let errorShown = false;

function surfaceError(err, source = 'runtime') {
  console.error(`[nova:${source}]`, err);
  if (errorShown) return;
  errorShown = true;
  try {
    import('./core/ui.js').then(({ toast }) => {
      toast({
        title: 'Something went wrong',
        text: String(err?.message || err || 'Unknown error'),
        icon: 'alert',
        timeout: 6000,
      });
    });
  } catch { /* ignore */ }
}

window.addEventListener('error', (e) => {
  if (e?.error) surfaceError(e.error, 'error');
});

window.addEventListener('unhandledrejection', (e) => {
  surfaceError(e?.reason, 'promise');
});

/* ------------------------------------------------------------
   Global keyboard shortcuts
   ------------------------------------------------------------ */

function bindShortcuts() {
  document.addEventListener('keydown', (e) => {
    if (isLocked()) return;
    const mod = e.metaKey || e.ctrlKey;
    const key = String(e.key || '').toLowerCase();
    const inField = e.target && (e.target.closest?.('input, textarea, select, [contenteditable="true"]'));

    // Spotlight
    if (mod && e.code === 'Space') {
      e.preventDefault();
      toggleSpotlight();
      return;
    }

    if (isLocked()) return;

    // Settings
    if (mod && e.key === ',') {
      e.preventDefault();
      window.OS?.openApp('settings');
      return;
    }

    // Lock
    if (mod && e.ctrlKey && key === 'q') {
      e.preventDefault();
      lockScreen();
      return;
    }

    // Close / minimize / cycle
    if (mod && !e.shiftKey && key === 'w') {
      const active = wm.getActiveWindow();
      if (active) {
        e.preventDefault();
        wm.closeWindow(active.id);
      }
      return;
    }
    if (mod && key === 'm') {
      const active = wm.getActiveWindow();
      if (active) {
        e.preventDefault();
        wm.minimizeWindow(active.id);
      }
      return;
    }
    if (mod && (e.key === '`' || e.code === 'Backquote')) {
      e.preventDefault();
      wm.cycleWindows();
      return;
    }

    // Escape closes transient surfaces
    if (e.key === 'Escape' && !inField) {
      closeMenu();
      closeSpotlight();
    }
  }, true);
}

/* ------------------------------------------------------------
   Dev / automation query parameters
   ------------------------------------------------------------ */

function parseApps(params) {
  const list = [];
  const many = params.get('apps');
  if (many) {
    for (const raw of many.split(',')) {
      const value = raw.trim();
      if (!value) continue;
      const [id, extra] = value.split(':');
      list.push({ id, extra });
    }
  }
  const single = params.get('app');
  if (single) {
    const [id, extra] = single.split(':');
    list.push({ id, extra });
  }
  return list;
}

function applyQueryParams() {
  const params = new URLSearchParams(location.search);

  if (params.get('reset') === '1') {
    try {
      for (const key of Object.keys(localStorage)) {
        if (key.startsWith('nova.')) localStorage.removeItem(key);
      }
    } catch { /* ignore */ }
    const url = new URL(location.href);
    url.searchParams.delete('reset');
    location.replace(url.toString());
    return;
  }

  const theme = params.get('theme');
  if (theme && ['dark', 'light', 'auto'].includes(theme)) setTheme(theme);

  const wallpaper = params.get('wallpaper');
  if (wallpaper) setWallpaper(wallpaper);

  const apps = parseApps(params);
  const section = params.get('section');
  apps.forEach(({ id, extra }, index) => {
    setTimeout(() => {
      try {
        const appParams = {};
        if (id === 'settings') appParams.section = extra || section || 'appearance';
        else if (id === 'browser') appParams.url = params.get('url') || undefined;
        else if (id === 'editor') appParams.path = params.get('path') || undefined;
        else if (id === 'finder' || id === 'files') appParams.path = params.get('path') || undefined;
        else if (id === 'calendar' && params.get('date')) appParams.date = params.get('date');
        else if (id === 'weather' && params.get('city')) appParams.city = params.get('city');
        if (extra && id !== 'settings') appParams[extra] = true;
        for (const k of Object.keys(appParams)) if (appParams[k] === undefined) delete appParams[k];
        window.OS.openApp(id, appParams);
      } catch (err) {
        console.error('[boot] could not open', id, err, err?.stack);
      }
    }, 220 + index * 160);
  });

  if (params.get('selftest') === '1') {
    import('./dev/selftest.js').then((m) => m.runSelfTest()).catch((err) => console.error('[selftest]', err));
  }

  if (params.get('cmdtest') === '1') {
    import('./dev/cmdtest.js').then((m) => m.runCmdTest()).catch((err) => console.error('[cmdtest]', err));
  }

  if (params.get('demo')) {
    import('./dev/demo.js').then((m) => m.runDemo(params.get('demo'))).catch((err) => console.error('[demo]', err));
  }

  if (params.get('spotlight') === '1') {
    setTimeout(() => window.OS.spotlight(params.get('q') || ''), 500);
  }

  if (params.get('panel') === 'cc') {
    setTimeout(() => window.OS.controlCenter(), 600);
  }
  if (params.get('panel') === 'nc') {
    setTimeout(() => window.OS.notificationCenter(), 600);
  }

  if (params.get('lock') === '1') {
    setTimeout(() => lockScreen(), 700);
  }

  if (params.get('theme') === 'light' || params.get('theme') === 'dark') {
    // keep the explicit request visible in the URL even after state persistence
    document.documentElement.dataset.theme = params.get('theme');
  }
}

/* ------------------------------------------------------------
   Boot
   ------------------------------------------------------------ */

function welcomeOnce() {
  let seen = false;
  try { seen = localStorage.getItem('nova.welcomed') === '1'; } catch { seen = false; }
  if (seen) return;
  try { localStorage.setItem('nova.welcomed', '1'); } catch { /* ignore */ }
  setTimeout(() => {
    notificationsAPI.add({
      title: 'Welcome to Nova OS',
      text: 'Press ⌘/Ctrl + Space for Spotlight, or open Terminal and type “help”.',
      icon: 'sparkles',
      silent: true,
      app: 'system',
    });
  }, 1600);
}

function hideBoot() {
  const el = bootEl();
  if (!el) return;
  el.classList.add('done');
  setTimeout(() => { el.style.display = 'none'; }, 700);
}

export function start() {
  if (started) return;
  started = true;

  applyAppearance();
  installOS();

  const shell = {
    desktop: initDesktop(),
    dock: initDock(),
    menubar: initMenubar(),
    spotlight: initSpotlight(),
    lock: initLockScreen(),
  };

  bindShortcuts();

  // Never allow host files to be dropped into the page
  window.addEventListener('dragover', (e) => {
    if (e.dataTransfer?.types?.includes('Files')) e.preventDefault();
  });
  window.addEventListener('drop', (e) => {
    if (e.dataTransfer?.files?.length) e.preventDefault();
  });

  // Persist theme changes from the media query
  document.documentElement.dataset.novaVersion = SYSTEM.version;

  const finishBoot = () => {
    if (bootFinished) return;
    bootFinished = true;
    hideBoot();
    applyQueryParams();
    welcomeOnce();
  };

  if (document.readyState === 'complete') {
    setTimeout(finishBoot, 900);
  } else {
    window.addEventListener('load', () => setTimeout(finishBoot, 900), { once: true });
    // Never let a slow resource keep the splash up forever
    setTimeout(finishBoot, 3600);
  }

  // Re-apply appearance when returning to the tab
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) applyAppearance();
  });

  // Expose internals for debugging
  window.__novaDebug = {
    wm,
    shell,
    theme: () => resolvedTheme(),
    state: () => import('./core/state.js').then((m) => m.getSettings()),
  };

  console.info(`%c${SYSTEM.name} ${SYSTEM.version} · ${SYSTEM.codename}`, 'color:#7cc4ff;font-weight:600');
  console.info('Automation: use window.OS — the supported API for apps, files, windows and settings.');

  return shell;
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', start, { once: true });
} else {
  start();
}

export default { start };
