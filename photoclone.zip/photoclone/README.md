# Photoclone

Photoclone is an **offline, browser-based image editor** with a familiar layered workflow. It is built with original code and assets, and performs all editing locally in the browser.

## Features

- Layered documents with nested groups, visibility, locking, opacity, reordering, duplication, merge-down, flattening, editable layer masks, clipping masks, styles, and 27 blend-mode choices
- Brush, pencil, eraser, gradient, paint bucket, clone stamp, healing, blur, dodge/burn, shape, editable point/paragraph/vertical type, pen/path, move, crop, eyedropper, hand, and zoom tools
- Rectangular, elliptical, freehand, polygonal, path, and magic-wand selections with add/subtract, feather, expand, contract, and invert operations
- Dedicated Free Transform tool with selection transforms, move, scale, rotate, skew, constrained/from-center modifiers, 90° rotation, flipping, and explicit commit/cancel
- Image adjustments: brightness/contrast, levels, curves, exposure, vibrance, color balance, threshold, posterize, invert, desaturate, black and white, and auto tone
- Non-destructive adjustment layers with editable properties, opacity, masks, clipping, history, and project persistence
- Filters: Gaussian and motion blur, sharpen, unsharp mask, noise, mosaic, emboss, and edge detection
- Full history with jump-to-state undo/redo and a bounded memory budget
- Multiple draggable document tabs, zoom/pan controls, live thumbnails, keyboard shortcuts, and foreground/background swatches
- PNG, JPEG, WebP, BMP, SVG, and GIF import; PNG, JPEG, and WebP export
- Cut, copy, paste, clear, foreground fill, and selection-stroke editing commands
- Image Size and Canvas Size workflows preserve layers, masks, selections, and paths
- Offline Image Processor batch-exports all open documents as PNG, JPEG, or WebP with remembered settings and sequential encoding
- Layered `.pclone` project save/load, IndexedDB autosave, and crash-recovery prompts
- No runtime network access and no external assets

Advanced blend modes marked with `≈` use the nearest blend operation provided by the browser canvas API.

## Run locally

```bash
npm install
npm run dev
```

The development server is available at `http://localhost:5173` by default.

## Production build

```bash
npm run build
npm run preview
```

The static production output is written to `dist/` and can be served by any static web server.

## Main shortcuts

- `Ctrl+N` new document, `Ctrl+O` open, `Ctrl+S` save project, `Ctrl+Shift+E` export PNG
- `Ctrl+Z` undo, `Ctrl+Shift+Z` redo, `Ctrl+T` Free Transform
- `Ctrl+A` select all, `Ctrl+D` deselect, `Ctrl+Shift+I` invert selection
- `Ctrl+0` fit, `Ctrl+1` actual pixels, `Ctrl+Tab` next document
- Tool letters are displayed in each toolbar tooltip; hold `Space` and drag to pan

## Project layout

```text
src/
├── editor/      # document state, types, tools, and settings
├── engine/      # painting, selection, compositing, filters, and persistence
├── hooks/       # keyboard and dialog behavior
├── ui/          # workspace, menus, panels, and dialogs
├── styles/      # application theme
└── main.tsx     # entry point
```

## Privacy

Photoclone has no runtime network dependency. Documents, autosaves, clipboard data, and processing remain on the local device unless you explicitly save or export a file.

## License

[MIT](LICENSE) — original implementation, with no Adobe code or assets.
