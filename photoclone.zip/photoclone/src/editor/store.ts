import { create } from 'zustand'
import {
  BlendMode,
  BLEND_CSS_MAP,
  AdjustmentKind,
  DocumentMeta,
  HistoryEntry,
  LayerStyle,
  PenPath,
  PhotoLayer,
  Selection,
  TextLayerData,
  ToolId,
  ZOOM_MAX,
  ZOOM_MIN,
} from './types'
import { clonePenPath } from '../engine/penpath'
import { cloneSelection, maskEdges } from '../engine/selection'
import { decodeProject, encodeProject, PCLONE_MIME, projectFilename } from '../engine/project'
import { ADJUSTMENT_LABELS, defaultAdjustment } from '../engine/adjustmentLayer'

/** Deep-clone a layer style object (styles are plain data). */
function cloneStyle(style: LayerStyle | null | undefined): LayerStyle | null | undefined {
  if (!style) return style
  return JSON.parse(JSON.stringify(style)) as LayerStyle
}

/* ------------------------------------------------------------------ */
/* Utilities                                                           */
/* ------------------------------------------------------------------ */

let uidCounter = 1
const nextId = (prefix: string): string => {
  uidCounter += 1
  return `${prefix}${uidCounter}`
}

export function makeCanvas(w: number, h: number): HTMLCanvasElement {
  const c = document.createElement('canvas')
  c.width = Math.max(1, Math.round(w))
  c.height = Math.max(1, Math.round(h))
  return c
}

export function canvasCtx(c: HTMLCanvasElement): CanvasRenderingContext2D {
  const ctx = c.getContext('2d', { willReadFrequently: true })
  if (!ctx) throw new Error('2D context unavailable')
  return ctx
}

export function cloneCanvas(src: HTMLCanvasElement): HTMLCanvasElement {
  const out = makeCanvas(src.width, src.height)
  const ctx = canvasCtx(out)
  ctx.drawImage(src, 0, 0)
  return out
}

function makeLayer(doc: { width: number; height: number }, name: string): PhotoLayer {
  return {
    id: nextId('L'),
    name,
    type: 'pixel',
    visible: true,
    locked: false,
    opacity: 1,
    blendMode: 'normal',
    canvas: makeCanvas(doc.width, doc.height),
  }
}

function rasterizeText(layer: PhotoLayer, data: TextLayerData): void {
  const ctx = canvasCtx(layer.canvas)
  ctx.clearRect(0, 0, layer.canvas.width, layer.canvas.height)
  ctx.fillStyle = data.color
  ctx.textBaseline = 'top'
  ctx.font = `${data.italic ? 'italic ' : ''}${data.bold ? '700 ' : '400 '}${Math.round(data.size)}px ${data.font}`
  const normalized: TextLayerData = {
    ...data,
    mode: data.mode ?? 'point',
    orientation: data.orientation ?? 'horizontal',
    align: data.align ?? 'left',
    leading: data.leading ?? 0,
    tracking: data.tracking ?? 0,
    boxWidth: data.boxWidth ?? 420,
    boxHeight: data.boxHeight ?? 240,
    underline: !!data.underline,
    strike: !!data.strike,
  }
  const lineHeight = normalized.leading && normalized.leading > 0 ? normalized.leading : Math.round(data.size * 1.2)
  const letterSpace = data.size * (normalized.tracking ?? 0) / 1000
  const measure = (text: string) => ctx.measureText(text).width + Math.max(0, text.length - 1) * letterSpace
  const drawChars = (text: string, x: number, y: number, extraWordSpace = 0) => {
    let cursor = x
    for (const char of text) {
      ctx.fillText(char, cursor, y)
      cursor += ctx.measureText(char).width + letterSpace + (char === ' ' ? extraWordSpace : 0)
    }
    return cursor - x
  }
  const wrap = (text: string, width: number): string[] => {
    const lines: string[] = []
    for (const paragraph of text.split('\n')) {
      if (!paragraph) { lines.push(''); continue }
      const words = paragraph.split(/\s+/)
      let line = ''
      for (const word of words) {
        const candidate = line ? `${line} ${word}` : word
        if (line && measure(candidate) > width) { lines.push(line); line = word }
        else line = candidate
      }
      lines.push(line)
    }
    return lines
  }
  const decorate = (x: number, y: number, width: number) => {
    ctx.save()
    ctx.strokeStyle = data.color
    ctx.lineWidth = Math.max(1, data.size / 16)
    if (normalized.underline) { ctx.beginPath(); ctx.moveTo(x, y + data.size * 1.05); ctx.lineTo(x + width, y + data.size * 1.05); ctx.stroke() }
    if (normalized.strike) { ctx.beginPath(); ctx.moveTo(x, y + data.size * 0.52); ctx.lineTo(x + width, y + data.size * 0.52); ctx.stroke() }
    ctx.restore()
  }

  if (normalized.orientation === 'vertical') {
    const columns = data.text.split('\n')
    columns.forEach((column, columnIndex) => {
      const x = data.x - columnIndex * lineHeight
      let y = data.y
      for (const char of column) {
        ctx.fillText(char, x, y)
        y += lineHeight
      }
    })
  } else {
    const boxWidth = Math.max(8, normalized.boxWidth ?? 420)
    const lines = normalized.mode === 'paragraph' ? wrap(data.text, boxWidth) : data.text.split('\n')
    lines.forEach((line, index) => {
      const y = data.y + index * lineHeight
      if (normalized.mode === 'paragraph' && normalized.boxHeight && y - data.y + lineHeight > normalized.boxHeight) return
      const width = measure(line)
      let x = data.x
      if (normalized.align === 'center') x += (boxWidth - width) / 2
      else if (normalized.align === 'right') x += boxWidth - width
      let justifyExtra = 0
      if (normalized.align === 'justify' && normalized.mode === 'paragraph' && index < lines.length - 1) {
        const spaces = (line.match(/ /g) || []).length
        if (spaces) justifyExtra = Math.max(0, boxWidth - width) / spaces
      }
      const drawn = letterSpace || justifyExtra ? drawChars(line, x, y, justifyExtra) : (ctx.fillText(line, x, y), width)
      decorate(x, y, drawn)
    })
  }
  layer.textData = JSON.parse(JSON.stringify(normalized)) as TextLayerData
}

function colorLuma(hex: string): number {
  const value = parseInt(hex.replace('#', ''), 16)
  return ((value >> 16) & 255) * 0.299 + ((value >> 8) & 255) * 0.587 + (value & 255) * 0.114
}

function rasterizeEditableLayer(layer: PhotoLayer): void {
  if (layer.type === 'text') {
    layer.type = 'pixel'
    layer.textData = undefined
  }
}

/* ------------------------------------------------------------------ */
/* State                                                               */
/* ------------------------------------------------------------------ */

export type EditorDoc = DocumentMeta & {
  history: HistoryEntry[]
  historyIndex: number
  selection: Selection | null
  /** Single pending pen path per document (Photoshop "work path") */
  workPath: PenPath | null
  /** Project differs from its last explicit .pclone save. */
  dirty: boolean
}

export interface NewDocOptions {
  name?: string
  width: number
  height: number
  background: 'white' | 'black' | 'transparent'
}

export interface EditorState {
  docs: EditorDoc[]
  activeDocId: string | null
  tool: ToolId
  fg: string
  bg: string
  revision: number
  toast: { id: number; text: string } | null
  persistenceStatus: 'idle' | 'saving' | 'saved' | 'error'
  lastAutosave: number | null
  /** Layer whose mask is currently targeted by paint tools; null targets pixels. */
  editingMaskLayerId: string | null

  /* document actions */
  newDoc: (opts: NewDocOptions) => void
  closeDoc: (id: string) => void
  closeActiveDoc: () => void
  setActiveDoc: (id: string) => void
  reorderDoc: (dragId: string, targetId: string | null, side?: 'before' | 'after') => void
  openImageFile: (file: File) => Promise<void>
  openProjectFile: (file: Blob, quiet?: boolean) => Promise<string | null>
  saveActiveProject: (saveAs?: boolean) => Promise<void>
  setDocDirty: (docId: string, dirty: boolean) => void
  exportActiveDoc: (format?: 'png' | 'jpeg' | 'webp') => void
  exportAllDocuments: (format: 'png' | 'jpeg' | 'webp', quality?: number) => Promise<void>

  /* clipboard / pixel editing */
  copyPixels: () => Promise<void>
  cutPixels: () => Promise<void>
  pastePixels: () => Promise<void>
  clearPixels: () => void
  fillPixels: () => void
  strokeSelection: (width?: number) => void

  /* tool / colors */
  setTool: (t: ToolId) => void
  swapColors: () => void
  resetColors: () => void
  setFg: (c: string) => void
  setBg: (c: string) => void
  bump: () => void
  showToast: (text: string) => void
  setPersistenceStatus: (status: EditorState['persistenceStatus'], savedAt?: number | null) => void

  /* layers */
  addLayer: () => void
  duplicateLayer: (layerId: string) => void
  removeLayer: (layerId: string) => void
  mergeDown: (layerId: string) => void
  flattenImage: () => Promise<void>
  selectLayer: (layerId: string) => void
  moveLayer: (layerId: string, dir: -1 | 1) => void
  toggleVisible: (layerId: string) => void
  setLocked: (layerId: string, v: boolean) => void
  renameLayer: (layerId: string, name: string) => void
  setLayerOpacity: (layerId: string, opacity: number) => void
  setLayerBlend: (layerId: string, blend: BlendMode) => void
  addLayerMask: (layerId: string) => void
  toggleLayerMask: (layerId: string) => void
  removeLayerMask: (layerId: string) => void
  invertLayerMask: (layerId: string) => void
  setEditingMask: (layerId: string | null) => void
  setLayerClipping: (layerId: string, clipping: boolean) => void
  addGroup: () => void
  setLayerParent: (layerId: string, parentId: string | null) => void
  toggleGroupOpen: (layerId: string) => void
  addAdjustmentLayer: (kind: AdjustmentKind) => void
  updateLayerAdjustment: (layerId: string, params: Record<string, number>) => void

  /* selections */
  setSelection: (sel: Selection | null, label: string) => void
  selectAll: () => void
  deselect: () => void
  invertSelection: () => void
  featherSelection: (px: number) => void
  growSelection: (px: number) => void
  contractSelection: (px: number) => void

  /* paths, text, and layer styles */
  setWorkPath: (path: PenPath | null, label?: string) => void
  pathMakeSelection: (feather?: number) => void
  pathStroke: (paint: { color: string; size: number; hardness: number; opacity: number }) => void
  addTextLayer: (o: TextLayerData) => void
  updateTextLayer: (layerId: string, o: TextLayerData) => void
  setLayerStyle: (layerId: string, style: LayerStyle | null) => void

  /* image ops */
  cropDocument: (x0: number, y0: number, width: number, height: number) => void
  resizeDocument: (width: number, height: number, smooth?: boolean) => void
  resizeCanvas: (width: number, height: number, anchorX?: -1 | 0 | 1, anchorY?: -1 | 0 | 1) => void
  rotateCanvas: (deg: 90 | 180 | 270) => void
  flipCanvas: (axis: 'h' | 'v') => void

  /* transform mode */
  transformActive: boolean
  setTransformActive: (v: boolean) => void

  /* history */
  pushHistory: (label: string) => void
  undo: () => void
  redo: () => void
  jumpHistory: (index: number) => void

  /* view */
  setZoom: (docId: string, zoom: number, focal?: { x: number; y: number }) => void
  panBy: (docId: string, dx: number, dy: number) => void
}

let toastTimer: ReturnType<typeof setTimeout> | null = null
const projectHandles = new Map<string, any>()
const HISTORY_MEMORY_BUDGET = 256 * 1024 * 1024
let pixelClipboard: HTMLCanvasElement | null = null

function canvasBlob(canvas: HTMLCanvasElement, type = 'image/png', quality?: number): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error('Could not encode image')), type, quality)
  })
}

async function blobCanvas(blob: Blob): Promise<HTMLCanvasElement> {
  const url = URL.createObjectURL(blob)
  try {
    const image = await new Promise<HTMLImageElement>((resolve, reject) => {
      const img = new Image()
      img.onload = () => resolve(img)
      img.onerror = () => reject(new Error('Could not read clipboard image'))
      img.src = url
    })
    const canvas = makeCanvas(image.naturalWidth, image.naturalHeight)
    canvasCtx(canvas).drawImage(image, 0, 0)
    return canvas
  } finally {
    URL.revokeObjectURL(url)
  }
}

export const useEditor = create<EditorState>((set, get) => {
  /** Replace doc entry immutably and bump revision. */
  const patchDoc = (id: string, patch: Partial<EditorDoc>) => {
    set((s) => ({
      revision: s.revision + 1,
      docs: s.docs.map((d) => (d.id === id ? { ...d, ...patch } : d)),
    }))
  }

  /** Run fn on active doc, patching it immutably. */
  const editActive = (fn: (doc: EditorDoc) => boolean | void) => {
    const s = get()
    const doc = s.docs.find((d) => d.id === s.activeDocId)
    if (!doc) return
    const draft: EditorDoc = {
      ...doc,
      layers: [...doc.layers],
      history: [...doc.history],
    }
    if (fn(draft) === false) return
    draft.dirty = true
    set((st) => ({
      revision: st.revision + 1,
      docs: st.docs.map((d) => (d.id === draft.id ? draft : d)),
    }))
  }

  const findLayer = (doc: EditorDoc, layerId: string): { layer: PhotoLayer; index: number } | null => {
    const index = doc.layers.findIndex((l) => l.id === layerId)
    if (index < 0) return null
    return { layer: doc.layers[index], index }
  }

  const snap = (doc: EditorDoc, label: string): HistoryEntry => ({
    label,
    width: doc.width,
    height: doc.height,
    activeLayerId: doc.activeLayerId,
    layers: doc.layers.map((l) => ({
      ...l,
      canvas: cloneCanvas(l.canvas),
      mask: l.mask ? cloneCanvas(l.mask) : null,
      children: undefined,
      style: cloneStyle(l.style),
      adjustment: l.adjustment ? JSON.parse(JSON.stringify(l.adjustment)) : undefined,
    })),
    selection: cloneSelection(doc.selection),
    workPath: clonePenPath(doc.workPath),
  })

  /** Restore every document property represented by a history snapshot. */
  const restoreSnap = (doc: EditorDoc, entry: HistoryEntry): void => {
    doc.width = entry.width ?? doc.width
    doc.height = entry.height ?? doc.height
    doc.layers = entry.layers.map((l) => ({
      ...l,
      canvas: cloneCanvas(l.canvas),
      mask: l.mask ? cloneCanvas(l.mask) : null,
      children: undefined,
      style: cloneStyle(l.style),
      adjustment: l.adjustment ? JSON.parse(JSON.stringify(l.adjustment)) : undefined,
    }))
    doc.activeLayerId = findLayer(doc, entry.activeLayerId)?.layer.id ?? doc.layers[doc.layers.length - 1].id
    doc.selection = cloneSelection(entry.selection ?? null)
    doc.workPath = clonePenPath(entry.workPath ?? null)
  }

  /** Limit full-canvas snapshots by an approximate per-document memory budget. */
  const historyLimit = (doc: EditorDoc): number => {
    const masks = doc.layers.reduce((n, layer) => n + (layer.mask ? 1 : 0), 0)
    const surfaces = Math.max(1, doc.layers.length + masks + (doc.selection ? 1 : 0))
    const bytesPerStep = Math.max(1, doc.width * doc.height * 4 * surfaces)
    return Math.max(2, Math.min(60, Math.floor(HISTORY_MEMORY_BUDGET / bytesPerStep)))
  }

  const commitHistory = (doc: EditorDoc, label: string): void => {
    doc.history = doc.history.slice(0, doc.historyIndex + 1)
    doc.history.push(snap(doc, label))
    const limit = historyLimit(doc)
    while (doc.history.length > limit) doc.history.shift()
    doc.historyIndex = doc.history.length - 1
  }

  return {
    docs: [],
    activeDocId: null,
    tool: 'brush',
    fg: '#000000',
    bg: '#ffffff',
    revision: 0,
    toast: null,
    persistenceStatus: 'idle',
    lastAutosave: null,
    editingMaskLayerId: null,

    /* ---------------- documents ---------------- */
    newDoc: (opts) => {
      const doc: EditorDoc = {
        id: nextId('D'),
        name: opts.name || 'Untitled',
        width: Math.max(1, Math.round(opts.width)),
        height: Math.max(1, Math.round(opts.height)),
        zoom: 1,
        panX: 0,
        panY: 0,
        activeLayerId: '',
        layers: [],
        history: [],
        historyIndex: -1,
        selection: null,
        workPath: null,
        dirty: true,
      }
      const bg = makeLayer(doc, 'Background')
      bg.locked = opts.background !== 'transparent'
      if (opts.background === 'transparent') bg.name = 'Layer 1'
      const ctx = canvasCtx(bg.canvas)
      if (opts.background === 'white') {
        ctx.fillStyle = '#ffffff'
        ctx.fillRect(0, 0, doc.width, doc.height)
      } else if (opts.background === 'black') {
        ctx.fillStyle = '#000000'
        ctx.fillRect(0, 0, doc.width, doc.height)
      }
      doc.layers = [bg]
      doc.activeLayerId = bg.id
      doc.history = [snap(doc, 'New Document')]
      doc.historyIndex = 0
      set((s) => ({ revision: s.revision + 1, docs: [...s.docs, doc], activeDocId: doc.id, editingMaskLayerId: null }))
    },

    closeDoc: (id) => {
      const closing = get().docs.find((d) => d.id === id)
      if (closing?.dirty && !window.confirm(`Close “${closing.name}” without saving?`)) return
      projectHandles.delete(id)
      set((s) => {
        const docs = s.docs.filter((d) => d.id !== id)
        const activeDocId =
          s.activeDocId === id ? (docs.length ? docs[docs.length - 1].id : null) : s.activeDocId
        return { revision: s.revision + 1, docs, activeDocId, editingMaskLayerId: null }
      })
    },

    closeActiveDoc: () => {
      const id = get().activeDocId
      if (id) get().closeDoc(id)
    },

    setActiveDoc: (id) => set((s) => ({ revision: s.revision + 1, activeDocId: id, editingMaskLayerId: null })),

    reorderDoc: (dragId, targetId, side = 'before') =>
      set((s) => {
        if (dragId === targetId) return s
        const from = s.docs.findIndex((d) => d.id === dragId)
        if (from < 0) return s
        const docs = [...s.docs]
        const [dragged] = docs.splice(from, 1)
        if (targetId === null) {
          docs.push(dragged)
        } else {
          const target = docs.findIndex((d) => d.id === targetId)
          if (target < 0) docs.push(dragged)
          else docs.splice(target + (side === 'after' ? 1 : 0), 0, dragged)
        }
        return { docs, revision: s.revision + 1 }
      }),

    openImageFile: (file) =>
      new Promise((resolve) => {
        const url = URL.createObjectURL(file)
        const img = new Image()
        img.onload = () => {
          URL.revokeObjectURL(url)
          const name = file.name.replace(/\.[^.]+$/, '')
          get().newDoc({ name, width: img.naturalWidth, height: img.naturalHeight, background: 'transparent' })
          const st = get()
          const doc = st.docs.find((d) => d.id === st.activeDocId)
          if (doc) {
            doc.layers[0].locked = false
            canvasCtx(doc.layers[0].canvas).drawImage(img, 0, 0)
            get().renameLayer(doc.layers[0].id, name)
            get().pushHistory('Open Image')
          }
          resolve()
        }
        img.onerror = () => {
          URL.revokeObjectURL(url)
          get().showToast(`Could not open "${file.name}"`)
          resolve()
        }
        img.src = url
      }),

    openProjectFile: async (file, quiet = false) => {
      try {
        const decoded = await decodeProject(file)
        const id = nextId('D')
        const layerIds = new Map<string, string>()
        const layers = decoded.layers.map((layer) => {
          const newId = nextId('L')
          layerIds.set(layer.id, newId)
          return { ...layer, id: newId }
        })
        for (const layer of layers) {
          if (layer.parentId) layer.parentId = layerIds.get(layer.parentId) ?? null
        }
        const doc: EditorDoc = {
          id,
          name: decoded.name,
          width: decoded.width,
          height: decoded.height,
          zoom: decoded.zoom,
          panX: decoded.panX,
          panY: decoded.panY,
          activeLayerId: layerIds.get(decoded.activeLayerId) ?? layers[layers.length - 1].id,
          layers,
          history: [],
          historyIndex: 0,
          selection: decoded.selection,
          workPath: clonePenPath(decoded.workPath),
          dirty: false,
        }
        doc.history = [snap(doc, 'Open Project')]
        set((s) => ({
          revision: s.revision + 1,
          docs: [...s.docs, doc],
          activeDocId: doc.id,
          editingMaskLayerId: null,
          fg: decoded.fg,
          bg: decoded.bg,
        }))
        if (!quiet) get().showToast(`Opened ${projectFilename(decoded.name)}`)
        return id
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Could not open project'
        if (!quiet) get().showToast(message)
        return null
      }
    },

    saveActiveProject: async (saveAs = false) => {
      const s = get()
      const doc = s.docs.find((d) => d.id === s.activeDocId)
      if (!doc) return
      const filename = projectFilename(doc.name)
      let handle = !saveAs ? projectHandles.get(doc.id) : undefined
      const picker = (window as any).showSaveFilePicker as undefined | ((o: any) => Promise<any>)

      /* Ask for the destination before PNG encoding so browser user activation
         is still valid after a menu click / Ctrl+S. */
      if (!handle && picker) {
        try {
          handle = await picker({
            suggestedName: filename,
            types: [{ description: 'Photoclone project', accept: { [PCLONE_MIME]: ['.pclone'] } }],
          })
        } catch (error) {
          if ((error as DOMException)?.name === 'AbortError') return
          handle = undefined
        }
      }

      try {
        get().setPersistenceStatus('saving')
        const blob = await encodeProject(doc, { fg: s.fg, bg: s.bg })
        if (handle) {
          const writable = await handle.createWritable()
          await writable.write(blob)
          await writable.close()
          projectHandles.set(doc.id, handle)
        } else {
          const url = URL.createObjectURL(blob)
          const a = document.createElement('a')
          a.href = url
          a.download = filename
          a.click()
          setTimeout(() => URL.revokeObjectURL(url), 5000)
        }
        set((state) => ({
          revision: state.revision + 1,
          docs: state.docs.map((d) => d.id === doc.id ? { ...d, dirty: false } : d),
          persistenceStatus: 'saved',
        }))
        get().showToast(`Saved ${filename}`)
      } catch (error) {
        get().setPersistenceStatus('error')
        get().showToast(error instanceof Error ? error.message : 'Could not save project')
      }
    },

    setDocDirty: (docId, dirty) =>
      set((s) => ({ docs: s.docs.map((d) => d.id === docId ? { ...d, dirty } : d) })),

    exportActiveDoc: (format = 'png') => {
      const s = get()
      const doc = s.docs.find((d) => d.id === s.activeDocId)
      if (!doc) return
      void import('../engine/composite').then(({ compositeDoc }) => {
        const rendered = compositeDoc(doc, makeCanvas(doc.width, doc.height), `export-${Date.now()}`)
        const out = makeCanvas(doc.width, doc.height)
        const outCtx = canvasCtx(out)
        if (format === 'jpeg') {
          outCtx.fillStyle = '#ffffff'
          outCtx.fillRect(0, 0, out.width, out.height)
        }
        outCtx.drawImage(rendered, 0, 0)
        const mime = format === 'jpeg' ? 'image/jpeg' : format === 'webp' ? 'image/webp' : 'image/png'
        out.toBlob((blob: Blob | null) => {
          if (!blob) return
          const a = document.createElement('a')
          a.href = URL.createObjectURL(blob)
          a.download = `${doc.name || 'untitled'}.${format === 'jpeg' ? 'jpg' : format}`
          a.click()
          setTimeout(() => URL.revokeObjectURL(a.href), 4000)
          get().showToast(`Exported ${format.toUpperCase()}`)
        }, mime, format === 'png' ? undefined : 0.92)
      })
    },

    exportAllDocuments: async (format, quality = 0.92) => {
      const docs = [...get().docs]
      if (!docs.length) return
      const mime = format === 'jpeg' ? 'image/jpeg' : format === 'webp' ? 'image/webp' : 'image/png'
      const extension = format === 'jpeg' ? 'jpg' : format
      const picker = (window as any).showDirectoryPicker as undefined | (() => Promise<any>)
      let directory: any = null
      if (picker) {
        try {
          directory = await picker()
        } catch (error) {
          if ((error as DOMException)?.name === 'AbortError') return
        }
      }
      const { compositeDoc } = await import('../engine/composite')
      get().setPersistenceStatus('saving')
      try {
        const usedNames = new Map<string, number>()
        for (let index = 0; index < docs.length; index++) {
          const doc = docs[index]
          get().showToast(`Exporting ${index + 1} of ${docs.length}: ${doc.name}`)
          const rendered = compositeDoc(doc, makeCanvas(doc.width, doc.height), `batch-${Date.now()}-${index}`)
          const out = makeCanvas(doc.width, doc.height)
          const ctx = canvasCtx(out)
          if (format === 'jpeg') {
            ctx.fillStyle = '#ffffff'
            ctx.fillRect(0, 0, out.width, out.height)
          }
          ctx.drawImage(rendered, 0, 0)
          const blob = await canvasBlob(out, mime, format === 'png' ? undefined : Math.max(0.1, Math.min(1, quality)))
          const safeBase = (doc.name || `document-${index + 1}`).replace(/\.[^.]+$/, '').replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').trim() || `document-${index + 1}`
          const seen = usedNames.get(safeBase) ?? 0
          usedNames.set(safeBase, seen + 1)
          const filename = `${safeBase}${seen ? `-${seen + 1}` : ''}.${extension}`
          if (directory) {
            const handle = await directory.getFileHandle(filename, { create: true })
            const writable = await handle.createWritable()
            await writable.write(blob)
            await writable.close()
          } else {
            const url = URL.createObjectURL(blob)
            const a = document.createElement('a')
            a.href = url
            a.download = filename
            a.click()
            setTimeout(() => URL.revokeObjectURL(url), 5000)
          }
        }
        get().setPersistenceStatus('saved')
        get().showToast(`Exported ${docs.length} document${docs.length === 1 ? '' : 's'} as ${format.toUpperCase()}`)
      } catch (error) {
        get().setPersistenceStatus('error')
        get().showToast(error instanceof Error ? error.message : 'Batch export failed')
      }
    },

    /* ---------------- clipboard / pixel editing ---------------- */
    copyPixels: async () => {
      const s = get()
      const doc = s.docs.find((d) => d.id === s.activeDocId)
      const layer = doc?.layers.find((l) => l.id === doc.activeLayerId)
      if (!doc || !layer) return
      const targetingMask = s.editingMaskLayerId === layer.id && !!layer.mask
      if ((layer.type === 'group' || layer.type === 'adjustment') && !targetingMask) {
        get().showToast('This layer has no direct pixels to copy')
        return
      }
      const copied = cloneCanvas(targetingMask ? layer.mask! : layer.canvas)
      if (doc.selection) {
        const ctx = canvasCtx(copied)
        ctx.globalCompositeOperation = 'destination-in'
        ctx.drawImage(doc.selection.mask, 0, 0)
        ctx.globalCompositeOperation = 'source-over'
      }
      pixelClipboard = copied
      try {
        if (navigator.clipboard?.write && typeof ClipboardItem !== 'undefined') {
          const blob = await canvasBlob(copied)
          await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })])
        }
      } catch {
        /* The in-app clipboard remains available if browser permission is denied. */
      }
      get().showToast(doc.selection ? 'Copied selected pixels' : 'Copied active layer')
    },

    cutPixels: async () => {
      const s = get()
      const doc = s.docs.find((d) => d.id === s.activeDocId)
      const layer = doc?.layers.find((l) => l.id === doc.activeLayerId)
      if (!doc || !layer) return
      if (layer.locked) {
        get().showToast('Active layer is locked')
        return
      }
      await get().copyPixels()
      get().clearPixels()
    },

    pastePixels: async () => {
      let source = pixelClipboard ? cloneCanvas(pixelClipboard) : null
      if (!source) {
        try {
          const read = navigator.clipboard?.read
          if (read) {
            const items = await read.call(navigator.clipboard)
            outer: for (const item of items) {
              for (const type of item.types) {
                if (type.startsWith('image/')) {
                  source = await blobCanvas(await item.getType(type))
                  break outer
                }
              }
            }
          }
        } catch {
          /* Browser clipboard access can be unavailable or denied. */
        }
      }
      if (!source) {
        get().showToast('No image pixels are available to paste')
        return
      }
      editActive((doc) => {
        const layer = makeLayer(doc, 'Pasted Layer')
        canvasCtx(layer.canvas).drawImage(source!, 0, 0)
        const active = findLayer(doc, doc.activeLayerId)?.layer
        layer.parentId = active?.type === 'group' ? active.id : active?.parentId ?? null
        doc.layers.push(layer)
        doc.activeLayerId = layer.id
        commitHistory(doc, 'Paste')
        return true
      })
    },

    clearPixels: () => {
      const s = get()
      const doc = s.docs.find((d) => d.id === s.activeDocId)
      const layer = doc?.layers.find((l) => l.id === doc.activeLayerId)
      if (!doc || !layer) return
      if (layer.locked) {
        get().showToast('Active layer is locked')
        return
      }
      const targetingMask = s.editingMaskLayerId === layer.id && !!layer.mask
      if ((layer.type === 'group' || layer.type === 'adjustment') && !targetingMask) {
        get().showToast('Target the layer mask or select a pixel layer')
        return
      }
      const target = targetingMask ? layer.mask! : layer.canvas
      if (!targetingMask) rasterizeEditableLayer(layer)
      const ctx = canvasCtx(target)
      if (doc.selection) {
        ctx.save()
        ctx.globalCompositeOperation = 'destination-out'
        ctx.drawImage(doc.selection.mask, 0, 0)
        ctx.restore()
      } else {
        ctx.clearRect(0, 0, target.width, target.height)
      }
      get().pushHistory('Clear')
    },

    fillPixels: () => {
      const s = get()
      const doc = s.docs.find((d) => d.id === s.activeDocId)
      const layer = doc?.layers.find((l) => l.id === doc.activeLayerId)
      if (!doc || !layer) return
      if (layer.locked) {
        get().showToast('Active layer is locked')
        return
      }
      const targetingMask = s.editingMaskLayerId === layer.id && !!layer.mask
      if ((layer.type === 'group' || layer.type === 'adjustment') && !targetingMask) {
        get().showToast('Target the layer mask or select a pixel layer')
        return
      }
      const fill = makeCanvas(doc.width, doc.height)
      const fctx = canvasCtx(fill)
      fctx.fillStyle = targetingMask ? '#ffffff' : s.fg
      fctx.fillRect(0, 0, doc.width, doc.height)
      if (doc.selection) {
        fctx.globalCompositeOperation = 'destination-in'
        fctx.drawImage(doc.selection.mask, 0, 0)
      }
      const target = targetingMask ? layer.mask! : layer.canvas
      if (!targetingMask) rasterizeEditableLayer(layer)
      const targetCtx = canvasCtx(target)
      if (targetingMask && colorLuma(s.fg) < 128) {
        targetCtx.save()
        targetCtx.globalCompositeOperation = 'destination-out'
        targetCtx.drawImage(fill, 0, 0)
        targetCtx.restore()
      } else targetCtx.drawImage(fill, 0, 0)
      get().pushHistory('Fill')
    },

    strokeSelection: (width = 2) => {
      const s = get()
      const doc = s.docs.find((d) => d.id === s.activeDocId)
      const layer = doc?.layers.find((l) => l.id === doc.activeLayerId)
      if (!doc || !layer) return
      if (!doc.selection) {
        get().showToast('Make a selection before stroking it')
        return
      }
      if (layer.locked) {
        get().showToast('Active layer is locked')
        return
      }
      const targetingMask = s.editingMaskLayerId === layer.id && !!layer.mask
      if ((layer.type === 'group' || layer.type === 'adjustment') && !targetingMask) {
        get().showToast('Target the layer mask or select a pixel layer')
        return
      }
      const ctx = canvasCtx(targetingMask ? layer.mask! : layer.canvas)
      if (!targetingMask) rasterizeEditableLayer(layer)
      const w = Math.max(1, Math.round(width))
      ctx.save()
      const conceal = targetingMask && colorLuma(s.fg) < 128
      if (conceal) ctx.globalCompositeOperation = 'destination-out'
      ctx.fillStyle = targetingMask ? '#ffffff' : s.fg
      ctx.strokeStyle = targetingMask ? '#ffffff' : s.fg
      ctx.lineWidth = w
      if (doc.selection.path) {
        ctx.stroke(doc.selection.path)
      } else {
        const points = maskEdges(doc.selection.mask).points
        const r = Math.floor(w / 2)
        for (let i = 0; i < points.length; i += 2) {
          ctx.fillRect(points[i] - r, points[i + 1] - r, w, w)
        }
      }
      ctx.restore()
      get().pushHistory('Stroke Selection')
    },

    /* ---------------- tools & colors ---------------- */
    setTool: (t) => set({ tool: t }),
    swapColors: () => set((s) => ({ fg: s.bg, bg: s.fg })),
    resetColors: () => set({ fg: '#000000', bg: '#ffffff' }),
    setFg: (c) => set({ fg: c }),
    setBg: (c) => set({ bg: c }),
    bump: () => set((s) => ({ revision: s.revision + 1 })),
    showToast: (text) => {
      if (toastTimer) clearTimeout(toastTimer)
      set({ toast: { id: Date.now(), text } })
      toastTimer = setTimeout(() => set({ toast: null }), 2600)
    },
    setPersistenceStatus: (status, savedAt) =>
      set((s) => ({
        persistenceStatus: status,
        lastAutosave: savedAt === undefined ? s.lastAutosave : savedAt,
      })),

    /* ---------------- layers ---------------- */
    addLayer: () =>
      editActive((doc) => {
        const layer = makeLayer(doc, `Layer ${doc.layers.length}`)
        const active = findLayer(doc, doc.activeLayerId)?.layer
        layer.parentId = active?.type === 'group' ? active.id : active?.parentId ?? null
        doc.layers.push(layer)
        doc.activeLayerId = layer.id
        commitHistory(doc, 'New Layer')
        return true
      }),

    duplicateLayer: (layerId) =>
      editActive((doc) => {
        const f = findLayer(doc, layerId)
        if (!f) return false
        const sourceIds = new Set<string>([layerId])
        if (f.layer.type === 'group') {
          let changed = true
          while (changed) {
            changed = false
            for (const layer of doc.layers) {
              if (layer.parentId && sourceIds.has(layer.parentId) && !sourceIds.has(layer.id)) {
                sourceIds.add(layer.id)
                changed = true
              }
            }
          }
        }
        const idMap = new Map<string, string>()
        for (const id of sourceIds) idMap.set(id, nextId('L'))
        const copies = doc.layers.filter((layer) => sourceIds.has(layer.id)).map((layer) => ({
          ...layer,
          id: idMap.get(layer.id)!,
          name: layer.id === layerId ? `${layer.name} copy` : layer.name,
          parentId: layer.id === layerId ? layer.parentId ?? null : (layer.parentId ? idMap.get(layer.parentId) ?? layer.parentId : null),
          canvas: cloneCanvas(layer.canvas),
          mask: layer.mask ? cloneCanvas(layer.mask) : null,
          style: cloneStyle(layer.style),
          textData: layer.textData ? JSON.parse(JSON.stringify(layer.textData)) : undefined,
          adjustment: layer.adjustment ? JSON.parse(JSON.stringify(layer.adjustment)) : undefined,
        }))
        doc.layers.splice(f.index + 1, 0, ...copies)
        doc.activeLayerId = idMap.get(layerId)!
        commitHistory(doc, f.layer.type === 'group' ? 'Duplicate Group' : 'Duplicate Layer')
        return true
      }),

    removeLayer: (layerId) => {
      editActive((doc) => {
        const f = findLayer(doc, layerId)
        if (!f || doc.layers.length <= 1) return false
        if (f.layer.type === 'group') {
          for (const child of doc.layers) {
            if (child.parentId === layerId) child.parentId = f.layer.parentId ?? null
          }
        }
        doc.layers.splice(f.index, 1)
        if (doc.activeLayerId === layerId) {
          doc.activeLayerId = (doc.layers[Math.max(0, f.index - 1)] ?? doc.layers[0]).id
        }
        commitHistory(doc, 'Delete Layer')
        return true
      })
      if (get().editingMaskLayerId === layerId) set({ editingMaskLayerId: null })
    },

    mergeDown: (layerId) =>
      editActive((doc) => {
        const f = findLayer(doc, layerId)
        if (!f || f.index === 0) return false
        const lower = doc.layers[f.index - 1]
        const upper = f.layer
        if (upper.type === 'group' || upper.type === 'adjustment' || lower.type === 'group' || lower.type === 'adjustment') {
          get().showToast('Flatten the image to merge groups or adjustment layers')
          return false
        }
        const merged = makeCanvas(doc.width, doc.height)
        const ctx = canvasCtx(merged)
        for (const layer of [lower, upper]) {
          if (!layer.visible) continue
          let source = layer.canvas
          if (layer.mask && layer.maskEnabled !== false) {
            source = cloneCanvas(layer.canvas)
            const sourceCtx = canvasCtx(source)
            sourceCtx.globalCompositeOperation = 'destination-in'
            sourceCtx.drawImage(layer.mask, 0, 0)
            sourceCtx.globalCompositeOperation = 'source-over'
          }
          ctx.save()
          ctx.globalAlpha = layer.opacity
          ctx.globalCompositeOperation = ((BLEND_CSS_MAP as Record<string, string>)[layer.blendMode] ?? 'source-over') as GlobalCompositeOperation
          ctx.drawImage(source, 0, 0)
          ctx.restore()
        }
        lower.canvas = merged
        lower.visible = true
        lower.opacity = 1
        lower.blendMode = 'normal'
        lower.style = null
        lower.mask = null
        lower.maskEnabled = true
        lower.type = 'pixel'
        doc.layers.splice(f.index, 1)
        doc.activeLayerId = lower.id
        commitHistory(doc, 'Merge Down')
        return true
      }),

    flattenImage: async () => {
      const initial = get()
      const id = initial.activeDocId
      const source = initial.docs.find((doc) => doc.id === id)
      if (!source) return
      const { compositeDoc } = await import('../engine/composite')
      const rendered = cloneCanvas(compositeDoc(source, makeCanvas(source.width, source.height), `flatten-${Date.now()}`))
      if (get().activeDocId !== id) return
      editActive((doc) => {
        const layer = makeLayer(doc, 'Background')
        layer.canvas = rendered
        doc.layers = [layer]
        doc.activeLayerId = layer.id
        doc.selection = null
        commitHistory(doc, 'Flatten Image')
        return true
      })
      set({ editingMaskLayerId: null })
    },

    selectLayer: (layerId) => set((state) => {
      const doc = state.docs.find((item) => item.id === state.activeDocId)
      if (!doc?.layers.some((layer) => layer.id === layerId)) return state
      return {
        revision: state.revision + 1,
        editingMaskLayerId: null,
        docs: state.docs.map((item) => item.id === doc.id ? { ...item, activeLayerId: layerId } : item),
      }
    }),

    moveLayer: (layerId, dir) =>
      editActive((doc) => {
        const f = findLayer(doc, layerId)
        if (!f) return false
        const ni = f.index + dir
        if (ni < 0 || ni >= doc.layers.length) return false
        doc.layers[f.index] = doc.layers[ni]
        doc.layers[ni] = f.layer
        commitHistory(doc, 'Reorder Layer')
        return true
      }),

    toggleVisible: (layerId) =>
      editActive((doc) => {
        const f = findLayer(doc, layerId)
        if (!f) return false
        f.layer.visible = !f.layer.visible
        commitHistory(doc, f.layer.visible ? 'Show Layer' : 'Hide Layer')
        return true
      }),

    setLocked: (layerId, v) =>
      editActive((doc) => {
        const f = findLayer(doc, layerId)
        if (!f) return false
        f.layer.locked = v
        commitHistory(doc, v ? 'Lock Layer' : 'Unlock Layer')
        return true
      }),

    renameLayer: (layerId, name) =>
      editActive((doc) => {
        const f = findLayer(doc, layerId)
        if (!f) return false
        f.layer.name = name || 'Layer'
        commitHistory(doc, 'Rename Layer')
        return true
      }),

    setLayerOpacity: (layerId, opacity) =>
      editActive((doc) => {
        const f = findLayer(doc, layerId)
        if (!f) return false
        f.layer.opacity = opacity
        return true
      }),

    setLayerBlend: (layerId, blend) =>
      editActive((doc) => {
        const f = findLayer(doc, layerId)
        if (!f) return false
        f.layer.blendMode = blend
        commitHistory(doc, 'Layer Blend Mode')
        return true
      }),

    addLayerMask: (layerId) =>
      {
        editActive((doc) => {
        const f = findLayer(doc, layerId)
        if (!f) return false
        const mask = makeCanvas(doc.width, doc.height)
        const ctx = canvasCtx(mask)
        if (doc.selection) ctx.drawImage(doc.selection.mask, 0, 0)
        else {
          ctx.fillStyle = '#ffffff'
          ctx.fillRect(0, 0, doc.width, doc.height)
        }
        f.layer.mask = mask
        f.layer.maskEnabled = true
        commitHistory(doc, doc.selection ? 'Layer Mask from Selection' : 'Add Layer Mask')
        return true
        })
        set({ editingMaskLayerId: layerId })
      },

    toggleLayerMask: (layerId) =>
      editActive((doc) => {
        const f = findLayer(doc, layerId)
        if (!f?.layer.mask) return false
        f.layer.maskEnabled = f.layer.maskEnabled === false
        commitHistory(doc, f.layer.maskEnabled ? 'Enable Layer Mask' : 'Disable Layer Mask')
        return true
      }),

    removeLayerMask: (layerId) =>
      {
        editActive((doc) => {
        const f = findLayer(doc, layerId)
        if (!f?.layer.mask) return false
        f.layer.mask = null
        f.layer.maskEnabled = true
        commitHistory(doc, 'Delete Layer Mask')
        return true
        })
        if (get().editingMaskLayerId === layerId) set({ editingMaskLayerId: null })
      },

    invertLayerMask: (layerId) =>
      editActive((doc) => {
        const f = findLayer(doc, layerId)
        if (!f?.layer.mask) return false
        const mask = f.layer.mask
        const ctx = canvasCtx(mask)
        const img = ctx.getImageData(0, 0, mask.width, mask.height)
        for (let i = 0; i < img.data.length; i += 4) img.data[i + 3] = 255 - img.data[i + 3]
        ctx.putImageData(img, 0, 0)
        commitHistory(doc, 'Invert Layer Mask')
        return true
      }),

    setEditingMask: (layerId) => {
      if (layerId === null) {
        set({ editingMaskLayerId: null })
        return
      }
      const s = get()
      const doc = s.docs.find((d) => d.id === s.activeDocId)
      if (!doc?.layers.some((layer) => layer.id === layerId && !!layer.mask)) return
      set({ editingMaskLayerId: layerId })
    },

    setLayerClipping: (layerId, clipping) =>
      editActive((doc) => {
        const f = findLayer(doc, layerId)
        if (!f || f.index === 0) return false
        f.layer.clipping = clipping
        commitHistory(doc, clipping ? 'Create Clipping Mask' : 'Release Clipping Mask')
        return true
      }),

    addGroup: () =>
      editActive((doc) => {
        const group = makeLayer(doc, `Group ${doc.layers.filter((l) => l.type === 'group').length + 1}`)
        group.type = 'group'
        group.opened = true
        group.blendMode = 'pass-through'
        const active = findLayer(doc, doc.activeLayerId)
        group.parentId = active?.layer.parentId ?? null
        doc.layers.splice(active ? active.index + 1 : doc.layers.length, 0, group)
        doc.activeLayerId = group.id
        commitHistory(doc, 'New Group')
        return true
      }),

    setLayerParent: (layerId, parentId) =>
      editActive((doc) => {
        const f = findLayer(doc, layerId)
        if (!f || layerId === parentId) return false
        if (parentId) {
          const parent = findLayer(doc, parentId)?.layer
          if (!parent || parent.type !== 'group') return false
          let cursor: PhotoLayer | undefined = parent
          while (cursor?.parentId) {
            if (cursor.parentId === layerId) return false
            cursor = doc.layers.find((l) => l.id === cursor?.parentId)
          }
        }
        f.layer.parentId = parentId
        commitHistory(doc, parentId ? 'Move Into Group' : 'Release From Group')
        return true
      }),

    toggleGroupOpen: (layerId) => set((state) => ({
      revision: state.revision + 1,
      docs: state.docs.map((doc) => doc.id !== state.activeDocId ? doc : {
        ...doc,
        layers: doc.layers.map((layer) => layer.id === layerId && layer.type === 'group' ? { ...layer, opened: layer.opened === false } : layer),
      }),
    })),

    addAdjustmentLayer: (kind) => {
      editActive((doc) => {
        const layer = makeLayer(doc, ADJUSTMENT_LABELS[kind])
        layer.type = 'adjustment'
        layer.adjustment = defaultAdjustment(kind)
        layer.mask = makeCanvas(doc.width, doc.height)
        const maskContext = canvasCtx(layer.mask)
        maskContext.fillStyle = '#ffffff'
        maskContext.fillRect(0, 0, doc.width, doc.height)
        layer.maskEnabled = true
        const activeIndex = doc.layers.findIndex((item) => item.id === doc.activeLayerId)
        const active = activeIndex >= 0 ? doc.layers[activeIndex] : null
        layer.parentId = active?.type === 'group' ? active.id : active?.parentId ?? null
        doc.layers.splice(activeIndex < 0 ? doc.layers.length : activeIndex + 1, 0, layer)
        doc.activeLayerId = layer.id
        commitHistory(doc, `New ${ADJUSTMENT_LABELS[kind]} Layer`)
        return true
      })
      set({ editingMaskLayerId: get().activeDocId ? get().docs.find((d) => d.id === get().activeDocId)?.activeLayerId ?? null : null })
    },

    updateLayerAdjustment: (layerId, params) =>
      editActive((doc) => {
        const f = findLayer(doc, layerId)
        if (!f?.layer.adjustment) return false
        f.layer.adjustment = { ...f.layer.adjustment, params: { ...f.layer.adjustment.params, ...params } }
        return true
      }),

    /* ---------------- selections ---------------- */
    setSelection: (sel, label) =>
      editActive((doc) => {
        doc.selection = sel
        commitHistory(doc, label)
        return true
      }),

    selectAll: () => {
      const st = get()
      void import('../engine/selection').then(({ makeMask, maskCtx, fillRectMask }) => {
        const doc = st.docs.find((d) => d.id === st.activeDocId)
        if (!doc) return
        const mask = makeMask(doc.width, doc.height)
        fillRectMask(maskCtx(mask), 0, 0, doc.width, doc.height, 0)
        const path = new Path2D()
        path.rect(0, 0, doc.width, doc.height)
        st.setSelection({ mask, path }, 'Select All')
      })
    },

    deselect: () => get().setSelection(null, 'Deselect'),

    invertSelection: () => {
      const st = get()
      void import('../engine/selection').then(({ invertMask }) => {
        const doc = st.docs.find((d) => d.id === st.activeDocId)
        if (!doc?.selection) {
          st.showToast('No selection to invert')
          return
        }
        st.setSelection({ mask: invertMask(doc.selection.mask), path: null }, 'Inverse Selection')
      })
    },

    featherSelection: (px) => {
      const st = get()
      void import('../engine/selection').then(({ featherMask }) => {
        const doc = st.docs.find((d) => d.id === st.activeDocId)
        if (!doc?.selection) {
          st.showToast('No selection to feather')
          return
        }
        st.setSelection({ mask: featherMask(doc.selection.mask, px), path: doc.selection.path }, 'Feather Selection')
      })
    },

    growSelection: (px) => {
      const st = get()
      void import('../engine/selection').then(({ growMask }) => {
        const doc = st.docs.find((d) => d.id === st.activeDocId)
        if (!doc?.selection) {
          st.showToast('No selection to expand')
          return
        }
        st.setSelection({ mask: growMask(doc.selection.mask, px), path: null }, 'Expand Selection')
      })
    },

    contractSelection: (px) => {
      const st = get()
      void import('../engine/selection').then(({ contractMask }) => {
        const doc = st.docs.find((d) => d.id === st.activeDocId)
        if (!doc?.selection) {
          st.showToast('No selection to contract')
          return
        }
        st.setSelection({ mask: contractMask(doc.selection.mask, px), path: null }, 'Contract Selection')
      })
    },

    /* ---------------- image ops ---------------- */
    resizeDocument: (width, height, smooth = true) =>
      editActive((doc) => {
        const w = Math.max(1, Math.min(32768, Math.round(width)))
        const h = Math.max(1, Math.min(32768, Math.round(height)))
        if (w === doc.width && h === doc.height) return false
        const sx = w / doc.width
        const sy = h / doc.height
        for (const layer of doc.layers) {
          const next = makeCanvas(w, h)
          const ctx = canvasCtx(next)
          ctx.imageSmoothingEnabled = smooth
          ctx.imageSmoothingQuality = 'high'
          ctx.drawImage(layer.canvas, 0, 0, w, h)
          layer.canvas = next
          if (layer.mask) {
            const mask = makeCanvas(w, h)
            const maskContext = canvasCtx(mask)
            maskContext.imageSmoothingEnabled = smooth
            maskContext.imageSmoothingQuality = 'high'
            maskContext.drawImage(layer.mask, 0, 0, w, h)
            layer.mask = mask
          }
          if (layer.textData) {
            layer.textData = {
              ...layer.textData,
              x: layer.textData.x * sx,
              y: layer.textData.y * sy,
              size: layer.textData.size * sy,
            }
          }
        }
        if (doc.selection) {
          const mask = makeCanvas(w, h)
          const ctx = canvasCtx(mask)
          ctx.imageSmoothingEnabled = smooth
          ctx.drawImage(doc.selection.mask, 0, 0, w, h)
          doc.selection = { mask, path: null }
        }
        if (doc.workPath) {
          doc.workPath = {
            ...doc.workPath,
            points: doc.workPath.points.map((p) => ({
              x: p.x * sx, y: p.y * sy,
              c1x: p.c1x * sx, c1y: p.c1y * sy,
              c2x: p.c2x * sx, c2y: p.c2y * sy,
            })),
          }
        }
        doc.width = w
        doc.height = h
        commitHistory(doc, 'Image Size')
        return true
      }),

    resizeCanvas: (width, height, anchorX = 0, anchorY = 0) =>
      editActive((doc) => {
        const w = Math.max(1, Math.min(32768, Math.round(width)))
        const h = Math.max(1, Math.min(32768, Math.round(height)))
        if (w === doc.width && h === doc.height) return false
        const dx = anchorX === -1 ? 0 : anchorX === 1 ? w - doc.width : Math.round((w - doc.width) / 2)
        const dy = anchorY === -1 ? 0 : anchorY === 1 ? h - doc.height : Math.round((h - doc.height) / 2)
        for (const layer of doc.layers) {
          const next = makeCanvas(w, h)
          canvasCtx(next).drawImage(layer.canvas, dx, dy)
          layer.canvas = next
          if (layer.mask) {
            const mask = makeCanvas(w, h)
            canvasCtx(mask).drawImage(layer.mask, dx, dy)
            layer.mask = mask
          }
          if (layer.textData) layer.textData = { ...layer.textData, x: layer.textData.x + dx, y: layer.textData.y + dy }
        }
        if (doc.selection) {
          const mask = makeCanvas(w, h)
          canvasCtx(mask).drawImage(doc.selection.mask, dx, dy)
          doc.selection = { mask, path: null }
        }
        if (doc.workPath) {
          doc.workPath = {
            ...doc.workPath,
            points: doc.workPath.points.map((p) => ({
              x: p.x + dx, y: p.y + dy,
              c1x: p.c1x + dx, c1y: p.c1y + dy,
              c2x: p.c2x + dx, c2y: p.c2y + dy,
            })),
          }
        }
        doc.width = w
        doc.height = h
        doc.panX = 0
        doc.panY = 0
        commitHistory(doc, 'Canvas Size')
        return true
      }),

    cropDocument: (x0, y0, width, height) =>
      editActive((doc) => {
        const x = Math.max(0, Math.round(x0))
        const y = Math.max(0, Math.round(y0))
        const w = Math.max(1, Math.round(width))
        const h = Math.max(1, Math.round(height))
        if (x + w <= 0 || y + h <= 0 || (x <= 0 && y <= 0 && w >= doc.width && h >= doc.height)) return false
        for (const layer of doc.layers) {
          const nc = makeCanvas(w, h)
          canvasCtx(nc).drawImage(layer.canvas, -x, -y)
          layer.canvas = nc
          if (layer.mask) {
            const nm = makeCanvas(w, h)
            canvasCtx(nm).drawImage(layer.mask, -x, -y)
            layer.mask = nm
          }
          if (layer.textData) layer.textData = { ...layer.textData, x: layer.textData.x - x, y: layer.textData.y - y }
        }
        doc.width = w
        doc.height = h
        doc.selection = null
        doc.panX = 0
        doc.panY = 0
        commitHistory(doc, 'Crop')
        return true
      }),

    rotateCanvas: (deg) =>
      editActive((doc) => {
        const swap = deg !== 180
        const nw = swap ? doc.height : doc.width
        const nh = swap ? doc.width : doc.height
        for (const layer of doc.layers) {
          const src = layer.canvas
          const nc = makeCanvas(nw, nh)
          const ctx = canvasCtx(nc)
          if (deg === 90) ctx.setTransform(0, 1, -1, 0, src.height, 0)
          else if (deg === 180) ctx.setTransform(-1, 0, 0, -1, src.width, src.height)
          else ctx.setTransform(0, -1, 1, 0, 0, src.width)
          ctx.drawImage(src, 0, 0)
          layer.canvas = nc
          if (layer.type === 'text') {
            layer.type = 'pixel'
            layer.textData = undefined
          }
          if (layer.mask) {
            const srcMask = layer.mask
            const nextMask = makeCanvas(nw, nh)
            const maskCtx = canvasCtx(nextMask)
            if (deg === 90) maskCtx.setTransform(0, 1, -1, 0, srcMask.height, 0)
            else if (deg === 180) maskCtx.setTransform(-1, 0, 0, -1, srcMask.width, srcMask.height)
            else maskCtx.setTransform(0, -1, 1, 0, 0, srcMask.width)
            maskCtx.drawImage(srcMask, 0, 0)
            layer.mask = nextMask
          }
        }
        doc.width = nw
        doc.height = nh
        doc.selection = null
        commitHistory(doc, deg === 90 ? 'Rotate 90° CW' : deg === 180 ? 'Rotate 180°' : 'Rotate 90° CCW')
        return true
      }),

    flipCanvas: (axis) =>
      editActive((doc) => {
        for (const layer of doc.layers) {
          const src = layer.canvas
          const nc = makeCanvas(src.width, src.height)
          const ctx = canvasCtx(nc)
          if (axis === 'h') ctx.setTransform(-1, 0, 0, 1, src.width, 0)
          else ctx.setTransform(1, 0, 0, -1, 0, src.height)
          ctx.drawImage(src, 0, 0)
          layer.canvas = nc
          if (layer.type === 'text') {
            layer.type = 'pixel'
            layer.textData = undefined
          }
          if (layer.mask) {
            const srcMask = layer.mask
            const nextMask = makeCanvas(srcMask.width, srcMask.height)
            const maskCtx = canvasCtx(nextMask)
            if (axis === 'h') maskCtx.setTransform(-1, 0, 0, 1, srcMask.width, 0)
            else maskCtx.setTransform(1, 0, 0, -1, 0, srcMask.height)
            maskCtx.drawImage(srcMask, 0, 0)
            layer.mask = nextMask
          }
        }
        doc.selection = null
        commitHistory(doc, axis === 'h' ? 'Flip Horizontal' : 'Flip Vertical')
        return true
      }),

    /* ---------------- transform mode ---------------- */
    transformActive: false,
    setTransformActive: (v) => set((s) => ({ revision: s.revision + 1, transformActive: v })),

    /* ---------------- history ---------------- */
    pushHistory: (label) =>
      editActive((doc) => {
        commitHistory(doc, label)
        return true
      }),

    undo: () =>
      editActive((doc) => {
        if (doc.historyIndex <= 0) {
          get().showToast('Nothing more to undo')
          return false
        }
        doc.historyIndex -= 1
        const entry = doc.history[doc.historyIndex]
        restoreSnap(doc, entry)
        return true
      }),

    redo: () =>
      editActive((doc) => {
        if (doc.historyIndex >= doc.history.length - 1) {
          get().showToast('Nothing more to redo')
          return false
        }
        doc.historyIndex += 1
        const entry = doc.history[doc.historyIndex]
        restoreSnap(doc, entry)
        return true
      }),

    jumpHistory: (index) =>
      editActive((doc) => {
        const target = Math.max(0, Math.min(doc.history.length - 1, Math.round(index)))
        if (target === doc.historyIndex) return false
        const entry = doc.history[target]
        if (!entry) return false
        doc.historyIndex = target
        restoreSnap(doc, entry)
        return true
      }),

    /* ---------------- paths, text, layer styles ---------------- */
    setWorkPath: (path, label) =>
      editActive((doc) => {
        doc.workPath = clonePenPath(path)
        if (label) {
          commitHistory(doc, label)
        }
        return true
      }),

    pathMakeSelection: (feather = 0) => {
      const st = get()
      void Promise.all([import('../engine/selection'), import('../engine/penpath')]).then(
        ([selEng, penEng]) => {
          const doc = st.docs.find((d) => d.id === st.activeDocId)
          if (!doc) return
          const work = doc.workPath
          if (!work || work.points.length < 2) {
            st.showToast('Draw a path with the pen tool first')
            return
          }
          const path = penEng.buildPath2D(work.points, work.closed)
          const mask = selEng.makeMask(doc.width, doc.height)
          selEng.fillPathMask(selEng.maskCtx(mask), path, doc.width, doc.height, Math.max(0, feather))
          st.setSelection({ mask, path }, 'Make Selection')
        },
      )
    },

    pathStroke: (paint) => {
      const st = get()
      void Promise.all([import('../engine/brush'), import('../engine/penpath')]).then(
        ([brush, penEng]) => {
          const doc = st.docs.find((d) => d.id === st.activeDocId)
          if (!doc) return
          const work = doc.workPath
          if (!work || work.points.length < 2) {
            st.showToast('Draw a path with the pen tool first')
            return
          }
          const layer = doc.layers.find((l) => l.id === doc.activeLayerId)
          if (!layer) return
          if (layer.locked) {
            st.showToast('Active layer is locked')
            return
          }
          const pts = penEng.flattenPenPath(work.points, work.closed, 4)
          const ctx = canvasCtx(layer.canvas)
          ctx.save()
          const o = {
            size: Math.max(1, paint.size),
            hardness: paint.hardness,
            color: paint.color,
            alpha: Math.min(1, Math.max(0.02, paint.opacity / 100)),
          }
          for (let i = 0; i + 3 < pts.length; i += 2) {
            brush.stampAlongLine(ctx, pts[i], pts[i + 1], pts[i + 2], pts[i + 3], 1, o, 'brush')
          }
          /* degenerate flat path: a single stamp */
          if (pts.length === 2) brush.stampBrush(ctx, pts[0], pts[1], o)
          ctx.restore()
          st.pushHistory('Stroke Path')
        },
      )
    },

    addTextLayer: (o) =>
      editActive((doc) => {
        const title = o.text.split('\n')[0].trim().slice(0, 24) || 'Text'
        const layer = makeLayer(doc, title)
        layer.type = 'text'
        rasterizeText(layer, o)
        doc.layers.push(layer)
        doc.activeLayerId = layer.id
        commitHistory(doc, 'Add Text')
        return true
      }),

    updateTextLayer: (layerId, o) =>
      editActive((doc) => {
        const f = findLayer(doc, layerId)
        if (!f || f.layer.type !== 'text') return false
        rasterizeText(f.layer, o)
        f.layer.name = o.text.split('\n')[0].trim().slice(0, 24) || 'Text'
        commitHistory(doc, 'Edit Text')
        return true
      }),

    setLayerStyle: (layerId, style) =>
      editActive((doc) => {
        const f = findLayer(doc, layerId)
        if (!f) return false
        f.layer.style = style ? (JSON.parse(JSON.stringify(style)) as LayerStyle) : null
        return true
      }),

    /* ---------------- view ---------------- */
    setZoom: (docId, zoom, focal) => {
      const d = get().docs.find((x) => x.id === docId)
      if (!d) return
      const z = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, zoom))
      if (focal) {
        const k = z / d.zoom
        patchDoc(docId, { zoom: z, panX: focal.x - (focal.x - d.panX) * k, panY: focal.y - (focal.y - d.panY) * k })
      } else {
        patchDoc(docId, { zoom: z })
      }
    },

    panBy: (docId, dx, dy) => {
      const d = get().docs.find((x) => x.id === docId)
      if (!d) return
      patchDoc(docId, { panX: d.panX + dx, panY: d.panY + dy })
    },
  }
})

export function clampZoom(z: number): number {
  return Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, z))
}
