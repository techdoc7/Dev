import { create } from 'zustand'

/** Per-tool persistent settings, shown in the options bar. */
export interface ToolSettingsState {
  brushSize: number
  brushHardness: number
  brushOpacity: number
  brushFlow: number
  brushSpacing: number
  tolerance: number
  antialias: boolean
  feather: number
  gradientType: 'linear' | 'radial'
  gradientPreset: 'fg-bg' | 'fg-transparent' | 'black-white'
  textFont: string
  textSize: number
  textBold: boolean
  textItalic: boolean
  textColor: string
  textMode: 'point' | 'paragraph'
  textOrientation: 'horizontal' | 'vertical'
  textAlign: 'left' | 'center' | 'right' | 'justify'
  textLeading: number
  textTracking: number
  textBoxWidth: number
  textBoxHeight: number
  textUnderline: boolean
  textStrike: boolean
  set: <K extends keyof Omit<ToolSettingsState, 'set'>>(key: K, value: ToolSettingsState[K]) => void
}

export const FONT_LIST = [
  'Arial', 'Arial Black', 'Arial Narrow', 'Bahnschrift', 'Calibri', 'Calibri Light',
  'Cambria', 'Candara', 'Century Gothic', 'Comic Sans MS', 'Consolas', 'Constantia',
  'Corbel', 'Courier New', 'Ebrima', 'Franklin Gothic Medium', 'Gabriola', 'Gadugi',
  'Georgia', 'Impact', 'Ink Free', 'Javanese Text', 'Leelawadee UI', 'Lucida Console',
  'Lucida Sans Unicode', 'Malgun Gothic', 'Microsoft Himalaya', 'Microsoft JhengHei',
  'Microsoft New Tai Lue', 'Microsoft PhagsPa', 'Microsoft Sans Serif', 'Microsoft Tai Le',
  'Microsoft YaHei', 'Microsoft Yi Baiti', 'MingLiU-ExtB', 'Mongolian Baiti', 'MS Gothic',
  'MV Boli', 'Nirmala UI', 'Palatino Linotype', 'Segoe Print', 'Segoe Script', 'Segoe UI',
  'Segoe UI Emoji', 'SimSun', 'Sitka Text', 'Sylfaen', 'Symbol', 'Tahoma',
  'Times New Roman', 'Trebuchet MS', 'Verdana', 'Webdings', 'Wingdings',
]

export const useToolSettings = create<ToolSettingsState>((set) => ({
  brushSize: 32,
  brushHardness: 85,
  brushOpacity: 100,
  brushFlow: 100,
  brushSpacing: 9,
  tolerance: 32,
  antialias: true,
  feather: 0,
  gradientType: 'linear',
  gradientPreset: 'fg-bg',
  textFont: 'Arial',
  textSize: 48,
  textBold: false,
  textItalic: false,
  textColor: '#000000',
  textMode: 'point',
  textOrientation: 'horizontal',
  textAlign: 'left',
  textLeading: 0,
  textTracking: 0,
  textBoxWidth: 420,
  textBoxHeight: 240,
  textUnderline: false,
  textStrike: false,
  set: (key, value) => set(({ [key]: value } as any)),
}))
