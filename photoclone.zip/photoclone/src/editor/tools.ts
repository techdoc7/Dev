import { ToolId } from '../editor/types'

export interface ToolDef {
  id: ToolId
  label: string
  shortcut: string
  /** 24×24 original SVG path artwork (stroke style, no external assets). */
  icon: string[]
  /** Optional nested tool group (ellipse under marquee, etc.) */
  group?: string
}

/** All icons are original, hand-authored SVG line art (MIT-style, no tracked assets). */
export const TOOL_LIST: ToolDef[] = [
  { id: 'move', label: 'Move', shortcut: 'V', icon: ['M12 2 v20', 'M2 12 h20', 'M12 2 l-3.4 3.4', 'M12 2 l3.4 3.4', 'M12 22 l-3.4 -3.4', 'M12 22 l3.4 -3.4', 'M2 12 l3.4 -3.4', 'M2 12 l3.4 3.4', 'M22 12 l-3.4 -3.4', 'M22 12 l-3.4 3.4'] },
  { id: 'marquee-rect', label: 'Rectangular Marquee', shortcut: 'M', icon: ['M2.5 5.5 h19 v13 h-19 z'] },
  { id: 'marquee-ellipse', label: 'Elliptical Marquee', shortcut: 'M', icon: ['M12 5.5 a9.5 6.5 0 1 0 0.01 0 z'] },
  { id: 'lasso', label: 'Lasso', shortcut: 'L', icon: ['M6 10 a5 4.8 0 1 1 12 0 a5 4.8 0 0 1 -12 0.2', 'M7.5 16.8 q-2.5 1.6 -1.2 3 q1 1 2.6 -0.4'] },
  { id: 'lasso-poly', label: 'Polygonal Lasso', shortcut: 'L', icon: ['M3.5 7 h7 v6 h6 v8 h-13 z'] },
  { id: 'wand', label: 'Magic Wand', shortcut: 'W', icon: ['M13.5 10.5 L4 20', 'M18.5 3.5 v4', 'M18.5 3.5 l-1.6 1.6', 'M16.5 5.5 l4 -4', 'M21 9 h-4', 'M14.8 6.8 -1.2 1.2', 'M15 11 h-3', 'M19.5 11.8 l2 2 -2 2 -2 -2 z'] },
  { id: 'crop', label: 'Crop', shortcut: 'C', icon: ['M6.5 2.5 v15 h15', 'M2.5 6.5 h15 v15'] },
  { id: 'eyedropper', label: 'Eyedropper', shortcut: 'I', icon: ['M19.5 3.2 l1.6 1.6 a1.1 1.1 0 0 1 -0.2 1.7 l-3.2 2.2 -2.1 -2.1 2.2 -3.2 a1.1 1.1 0 0 1 1.7 -0.2 z', 'M15.2 6.6 L7.5 14.3 a2 2 0 0 0 -0.6 1.2 l-0.4 1.6 1.6 -0.4 a2 2 0 0 0 1.2 -0.6 l7.7 -7.7'] },
  { id: 'heal', label: 'Healing Brush', shortcut: 'J', icon: ['M5 19 L19 5', 'M7 7 l10 10', 'M4 16 l4 4', 'M16 4 l4 4'] },
  { id: 'brush', label: 'Brush', shortcut: 'B', icon: ['M19.8 3.1 a1.6 1.6 0 0 1 1.1 1.1 c0.4 1 0.1 2.5 -1 3.6 l-6.8 6.8 -3.3 -3.3 6.8 -6.8 c1.1 -1.1 2.6 -1.4 3.6 -1 z', 'M9 12.2 l3.3 3.3 c-0.4 2.3 -2.4 4.1 -5 4.1 c-1.3 0 -2.5 0.6 -3.6 1.6 c0.3 -3.4 2.7 -9 5.3 -9 z'] },
  { id: 'pencil', label: 'Pencil', shortcut: 'B', icon: ['M3 21 l1 -4.5 L17.2 3.3 a2 2 0 0 1 2.8 0 l0.7 0.7 a2 2 0 0 1 0 2.8 L7.5 20 z'] },
  { id: 'stamp', label: 'Clone Stamp', shortcut: 'S', icon: ['M12 3 a4.5 4.5 0 0 1 4.5 4.3 c0 2 -1.2 3 -1.2 4.7 h-6.6 c0 -1.7 -1.2 -2.7 -1.2 -4.7 A4.5 4.5 0 0 1 12 3 z', 'M6 20 h12 M6 20 c0.5 0 1.6 -1 6 -1 c4.4 0 5.5 1 6 1 z', 'M8.8 14 h6.4 v2 h-6.4 z'] },
  { id: 'eraser', label: 'Eraser', shortcut: 'E', icon: ['M9 19 h11', 'M6.4 20.4 l-3 -3 a1.6 1.6 0 0 1 0 -2.3 L13.7 5 19.4 10.7 9 21.1 A1.6 1.6 0 0 1 6.4 20.4 z', 'M10 9 15.7 14.7'] },
  { id: 'gradient', label: 'Gradient', shortcut: 'G', icon: ['M3.5 4.5 h17 v15 h-17 z', 'M3.5 15.5 h17', 'M3.5 10 h17', 'M12 4.5 v15'] },
  { id: 'bucket', label: 'Paint Bucket', shortcut: 'G', icon: ['M5 4 l10 10 -7 7 -6 -6 z', 'M5 4 l5 -2', 'M15 15 q4 -1 5 3 q-1 3 -4 3'] },
  { id: 'blur', label: 'Blur', shortcut: 'R', icon: ['M12 3.5 c3.5 3.6 6.5 6.6 6.5 10 a6.5 6.5 0 0 1 -13 0 c0 -3.4 3 -6.4 6.5 -10 z'] },
  { id: 'dodge', label: 'Dodge / Burn', shortcut: 'O', icon: ['M4 15 a8 5.5 0 1 0 16 0 a8 5.5 0 1 0 -16 0', 'M12 3.5 v8', 'M10 5.5 12 3.5 14 5.5'] },
  { id: 'pen', label: 'Pen', shortcut: 'P', icon: ['M8 4.5 h8 v5 l-4 4.5 -4 -4.5 z', 'M12 14 v5', 'M10 19 h4'] },
  { id: 'type', label: 'Type', shortcut: 'T', icon: ['M4 4.5 h16 v3.2', 'M12 4.5 v14', 'M9.5 18.5 h5'] },
  { id: 'shape', label: 'Shape / Rectangle', shortcut: 'U', icon: ['M3.5 6 h17 v12 h-17 z', 'M13 13 a2 2 0 1 0 0.01 0 z'] },
  { id: 'path-select', label: 'Path Selection', shortcut: 'A', icon: ['M4 4 h6 v6 h-6 z', 'M18 4 a2 2 0 1 0 -0.01 0', 'M18 18 a2 2 0 1 0 -0.01 0', 'M4 18 h6 v-6'] },
  { id: 'transform', label: 'Free Transform', shortcut: 'Ctrl+T', icon: ['M3 8 V3 h5', 'M16 3 h5 v5', 'M21 16 v5 h-5', 'M8 21 H3 v-5', 'M7 7 h10 v10 H7 z'] },
  { id: 'hand', label: 'Hand', shortcut: 'H', icon: ['M7 11 V5.2 a1.3 1.3 0 0 1 2.6 0 V10', 'M9.6 10 V4 a1.3 1.3 0 0 1 2.6 0 v6', 'M12.2 10 V5 a1.3 1.3 0 0 1 2.6 0 v6.5', 'M14.8 11.2 V7.5 a1.3 1.3 0 0 1 2.6 0 V14 a7 7 0 0 1 -6.9 7 c-2.6 0 -3.9 -1.3 -5.6 -3.6 L3.4 15.4 c-0.8 -1 0.7 -2.7 1.9 -1.9 L7 14.8 V11'] },
  { id: 'zoom', label: 'Zoom', shortcut: 'Z', icon: ['M10.5 3.5 a7 7 0 1 0 0.01 0 z', 'M20.5 20.5 l-6 -6', 'M7.5 10.5 h6 M10.5 7.5 v6'] },
]

export const TOOL_BY_ID = new Map(TOOL_LIST.map((t) => [t.id, t]))
