// Photoclone core type definitions

/** Layer blend modes (Photoshop-style naming). CSS supports a subset natively;
 *  expanded modes use the nearest browser-canvas blend operation. */
export type BlendMode =
  | 'pass-through'
  | 'normal'
  | 'dissolve'
  | 'darken'
  | 'multiply'
  | 'color-burn'
  | 'linear-burn'
  | 'darker-color'
  | 'lighten'
  | 'screen'
  | 'color-dodge'
  | 'linear-dodge'
  | 'lighter-color'
  | 'overlay'
  | 'soft-light'
  | 'hard-light'
  | 'vivid-light'
  | 'linear-light'
  | 'pin-light'
  | 'hard-mix'
  | 'difference'
  | 'exclusion'
  | 'divide'
  | 'hue'
  | 'saturation'
  | 'color'
  | 'luminosity'

/** CSS globalCompositeOperation nearest matches for rendering. */
export const BLEND_CSS_MAP: Record<Exclude<BlendMode, 'pass-through'>, string> = {
  'normal': 'source-over',
  'dissolve': 'source-over',
  'darken': 'darken',
  'multiply': 'multiply',
  'color-burn': 'color-burn',
  'linear-burn': 'multiply',
  'darker-color': 'darken',
  'lighten': 'lighten',
  'screen': 'screen',
  'color-dodge': 'color-dodge',
  'linear-dodge': 'lighter',
  'lighter-color': 'lighten',
  'overlay': 'overlay',
  'soft-light': 'soft-light',
  'hard-light': 'hard-light',
  'vivid-light': 'hard-light',
  'linear-light': 'hard-light',
  'pin-light': 'hard-light',
  'hard-mix': 'hard-light',
  'difference': 'difference',
  'exclusion': 'exclusion',
  'divide': 'difference',
  'hue': 'hue',
  'saturation': 'saturation',
  'color': 'color',
  'luminosity': 'luminosity',
}

export const BLEND_LABELS: Record<BlendMode, string> = {
  'pass-through': 'Pass Through',
  'normal': 'Normal',
  'dissolve': 'Dissolve',
  'darken': 'Darken',
  'multiply': 'Multiply',
  'color-burn': 'Color Burn',
  'linear-burn': 'Linear Burn',
  'darker-color': 'Darker Color',
  'lighten': 'Lighten',
  'screen': 'Screen',
  'color-dodge': 'Color Dodge',
  'linear-dodge': 'Linear Dodge (Add)',
  'lighter-color': 'Lighter Color',
  'overlay': 'Overlay',
  'soft-light': 'Soft Light',
  'hard-light': 'Hard Light',
  'vivid-light': 'Vivid Light',
  'linear-light': 'Linear Light',
  'pin-light': 'Pin Light',
  'hard-mix': 'Hard Mix',
  'difference': 'Difference',
  'exclusion': 'Exclusion',
  'divide': 'Divide',
  'hue': 'Hue',
  'saturation': 'Saturation',
  'color': 'Color',
  'luminosity': 'Luminosity',
}

export type LayerType = 'pixel' | 'text' | 'adjustment' | 'fill' | 'group'

/** Non-destructive layer effects. */
export interface LayerStyle {
  stroke?: { width: number; color: string }
  shadow?: { dx: number; dy: number; blur: number; color: string }
}

export interface TextLayerData {
  text: string
  x: number
  y: number
  size: number
  bold: boolean
  italic: boolean
  font: string
  color: string
  mode?: 'point' | 'paragraph'
  orientation?: 'horizontal' | 'vertical'
  align?: 'left' | 'center' | 'right' | 'justify'
  /** Baseline distance in pixels; 0 means automatic 1.2× size. */
  leading?: number
  /** Photoshop-style tracking in thousandths of an em. */
  tracking?: number
  boxWidth?: number
  boxHeight?: number
  underline?: boolean
  strike?: boolean
}

export type AdjustmentKind =
  | 'brightness-contrast'
  | 'levels'
  | 'exposure'
  | 'hue-saturation'
  | 'vibrance'
  | 'color-balance'
  | 'black-white'
  | 'invert'
  | 'threshold'
  | 'posterize'

export interface AdjustmentLayerData {
  kind: AdjustmentKind
  params: Record<string, number>
}

export interface PhotoLayer {
  id: string
  name: string
  type: LayerType
  visible: boolean
  locked: boolean
  /** 0..1 */
  opacity: number
  blendMode: BlendMode
  /** Offscreen raster bitmap for pixel layers */
  canvas: HTMLCanvasElement
  /** Legacy nested children field; current groups use parentId links. */
  children?: PhotoLayer[]
  opened?: boolean
  /** Non-destructive stroke / drop-shadow style */
  style?: LayerStyle | null
  /** Optional document-sized alpha mask. Transparent pixels conceal the layer. */
  mask?: HTMLCanvasElement | null
  maskEnabled?: boolean
  /** Clip this layer to the transparency of the nearest non-clipping layer below it. */
  clipping?: boolean
  /** Editable source retained for text layers; canvas is its raster preview. */
  textData?: TextLayerData
  /** Render-time color operation for non-destructive adjustment layers. */
  adjustment?: AdjustmentLayerData
  /** Flat-storage hierarchy link used by group layers. */
  parentId?: string | null
}

/** Bezier pen anchor: position + in/out control handles */
export interface PenPoint {
  x: number
  y: number
  c1x: number
  c1y: number
  c2x: number
  c2y: number
}

export interface PenPath {
  points: PenPoint[]
  closed: boolean
}

export interface DocumentMeta {
  id: string
  name: string
  width: number
  height: number
  zoom: number
  panX: number
  panY: number
  activeLayerId: string
  layers: PhotoLayer[]
}

export interface HistoryEntry {
  label: string
  width: number
  height: number
  activeLayerId: string
  layers: PhotoLayer[]
  selection?: Selection | null
  workPath?: PenPath | null
}

export type ToolId =
  | 'move' | 'marquee-rect' | 'marquee-ellipse' | 'lasso' | 'lasso-poly' | 'wand'
  | 'crop' | 'eyedropper' | 'heal' | 'brush' | 'pencil' | 'stamp'
  | 'eraser' | 'gradient' | 'bucket' | 'blur' | 'dodge' | 'pen' | 'type' | 'shape'
  | 'path-select' | 'transform' | 'hand' | 'zoom'

export interface DocumentPreset {
  name: string
  width: number
  height: number
}

/** Raster selection: alpha-mask canvas (doc-sized) + optional vector path for ants. */
export interface Selection {
  mask: HTMLCanvasElement
  path: Path2D | null
}

export const ZOOM_MIN = 0.0078125   // 1/128  (~0.78%)
export const ZOOM_MAX = 32
