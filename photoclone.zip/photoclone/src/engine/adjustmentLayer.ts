import { AdjustmentKind, AdjustmentLayerData } from '../editor/types'
import * as A from './adjustments'

export const ADJUSTMENT_LABELS: Record<AdjustmentKind, string> = {
  'brightness-contrast': 'Brightness / Contrast',
  levels: 'Levels',
  exposure: 'Exposure',
  'hue-saturation': 'Hue / Saturation',
  vibrance: 'Vibrance',
  'color-balance': 'Color Balance',
  'black-white': 'Black & White',
  invert: 'Invert',
  threshold: 'Threshold',
  posterize: 'Posterize',
}

export function defaultAdjustment(kind: AdjustmentKind): AdjustmentLayerData {
  const params: Record<AdjustmentKind, Record<string, number>> = {
    'brightness-contrast': { brightness: 0, contrast: 0 },
    levels: { inBlack: 0, gamma: 1, inWhite: 255, outBlack: 0, outWhite: 255 },
    exposure: { exposure: 0, offset: 0, gamma: 1 },
    'hue-saturation': { hue: 0, saturation: 0, lightness: 0 },
    vibrance: { vibrance: 0 },
    'color-balance': { red: 0, green: 0, blue: 0 },
    'black-white': {},
    invert: {},
    threshold: { threshold: 128 },
    posterize: { levels: 4 },
  }
  return { kind, params: { ...params[kind] } }
}

export function applyAdjustmentLayer(image: ImageData, data: AdjustmentLayerData): void {
  const p = data.params
  switch (data.kind) {
    case 'brightness-contrast': A.brightnessContrast(image, p.brightness ?? 0, p.contrast ?? 0); break
    case 'levels': A.levels(image, p.inBlack ?? 0, p.gamma ?? 1, p.inWhite ?? 255, p.outBlack ?? 0, p.outWhite ?? 255); break
    case 'exposure': A.exposure(image, p.exposure ?? 0, p.offset ?? 0, p.gamma ?? 1); break
    case 'hue-saturation': A.hueSaturation(image, p.hue ?? 0, p.saturation ?? 0, p.lightness ?? 0); break
    case 'vibrance': A.vibrance(image, p.vibrance ?? 0); break
    case 'color-balance': A.colorBalance(image, p.red ?? 0, p.green ?? 0, p.blue ?? 0); break
    case 'black-white': A.blackAndWhite(image); break
    case 'invert': A.invert(image); break
    case 'threshold': A.threshold(image, p.threshold ?? 128); break
    case 'posterize': A.posterize(image, p.levels ?? 4); break
  }
}
