/* Adjustments & filter engine — per-pixel ops, separable convolutions.
   All functions mutate the given ImageData in place.
   All original code. */

export type LUT = Uint8ClampedArray // 256 entries

/* ------------------------------------------------------------------ */
/* Color look-up tables                                                */
/* ------------------------------------------------------------------ */

export function identityLUT(): LUT {
  const l = new Uint8ClampedArray(256)
  for (let i = 0; i < 256; i++) l[i] = i
  return l
}

export function applyLUT(img: ImageData, lr: LUT, lg: LUT, lb: LUT): void {
  const px = img.data
  for (let i = 0; i < px.length; i += 4) {
    px[i] = lr[px[i]]
    px[i + 1] = lg[px[i + 1]]
    px[i + 2] = lb[px[i + 2]]
  }
}

/* ------------------------------------------------------------------ */
/* Histogram                                                           */
/* ------------------------------------------------------------------ */

export interface Histogram {
  r: Uint32Array
  g: Uint32Array
  b: Uint32Array
}

export function histogram(img: ImageData): Histogram {
  const px = img.data
  const h: Histogram = {
    r: new Uint32Array(256),
    g: new Uint32Array(256),
    b: new Uint32Array(256),
  }
  for (let i = 0; i < px.length; i += 4) {
    h.r[px[i]]++
    h.g[px[i + 1]]++
    h.b[px[i + 2]]++
  }
  return h
}

/* ------------------------------------------------------------------ */
/* Tonal adjustments                                                   */
/* ------------------------------------------------------------------ */

/** brightness −150..150, contrast −100..100 */
export function brightnessContrast(img: ImageData, brightness: number, contrast: number): void {
  const lut = identityLUT()
  const off = brightness
  const c = (contrast + 100) / 100
  for (let v = 0; v < 256; v++) {
    lut[v] = Math.round((v + off - 127.5) * c + 127.5)
  }
  applyLUT(img, lut, lut, lut)
}

/** levels: in black/white + gamma, remapped out to outBlack..outWhite */
export function levels(
  img: ImageData,
  inBlack: number,
  inGamma: number,
  inWhite: number,
  outBlack: number,
  outWhite: number,
): void {
  const lo = Math.min(inBlack, inWhite - 1)
  const hi = Math.max(inWhite, lo + 1)
  const span = hi - lo
  const g = Math.max(0.01, inGamma)
  const lut = identityLUT()
  for (let v = 0; v < 256; v++) {
    let t = (v - lo) / span
    t = Math.min(1, Math.max(0, t))
    t = Math.pow(t, 1 / g)
    lut[v] = Math.round(outBlack + t * (outWhite - outBlack))
  }
  applyLUT(img, lut, lut, lut)
}

/** exposure in stops, offset -0.5..0.5, gamma correction */
export function exposure(img: ImageData, stops: number, offset: number, gamma: number): void {
  const mul = Math.pow(2, stops)
  const ov = offset * 255
  const g = Math.max(0.01, gamma)
  const px = img.data
  for (let i = 0; i < px.length; i += 4) {
    for (let c = 0; c < 3; c++) {
      const v = px[i + c]
      let out = v * mul + ov
      out = Math.pow(Math.min(1, Math.max(0, out / 255)), 1 / g) * 255
      px[i + c] = out
    }
  }
}

/* ------------------------------------------------------------------ */
/* HSL-family operations                                               */
/* ------------------------------------------------------------------ */

function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
  r /= 255; g /= 255; b /= 255
  const mx = Math.max(r, g, b)
  const mn = Math.min(r, g, b)
  const l = (mx + mn) / 2
  if (mx === mn) return [0, 0, l]
  const d = mx - mn
  const s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn)
  let h: number
  if (mx === r) h = ((g - b) / d + (g < b ? 6 : 0)) / 6
  else if (mx === g) h = ((b - r) / d + 2) / 6
  else h = ((r - g) / d + 4) / 6
  return [h, s, l]
}

function hueToRgb(p: number, q: number, t: number): number {
  if (t < 0) t += 1
  if (t > 1) t -= 1
  if (t < 1 / 6) return p + (q - p) * 6 * t
  if (t < 1 / 2) return q
  if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6
  return p
}

function hslToRgb(h: number, s: number, l: number): [number, number, number] {
  if (s === 0) {
    const v = Math.round(l * 255)
    return [v, v, v]
  }
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s
  const p = 2 * l - q
  return [
    Math.round(hueToRgb(p, q, h + 1 / 3) * 255),
    Math.round(hueToRgb(p, q, h) * 255),
    Math.round(hueToRgb(p, q, h - 1 / 3) * 255),
  ]
}

/** hue −180..180 (degrees), saturation/lightness −100..100 percent */
export function hueSaturation(img: ImageData, hue: number, saturation: number, lightness: number): void {
  const hd = hue / 360
  const px = img.data
  for (let i = 0; i < px.length; i += 4) {
    const [h, s, l] = rgbToHsl(px[i], px[i + 1], px[i + 2])
    if (s === 0 && saturation <= 0) continue
    let ns: number
    if (saturation >= 0) {
      ns = s < 1e-6 ? s : s + (1 - s) * (saturation / 100)
    } else {
      ns = s * (1 + saturation / 100)
    }
    let nl: number
    if (lightness >= 0) nl = l + (1 - l) * (lightness / 100)
    else nl = l * (1 + lightness / 100)
    const [r, g, b] = hslToRgb((h + hd) % 1, Math.max(0, Math.min(1, ns)), Math.max(0, Math.min(1, nl)))
    px[i] = r; px[i + 1] = g; px[i + 2] = b
  }
}

/** vibrance −100..100: boosts low-saturation colors harder */
export function vibrance(img: ImageData, amount: number): void {
  const a = amount / 100
  if (a === 0) return
  const px = img.data
  for (let i = 0; i < px.length; i += 4) {
    const r = px[i], g = px[i + 1], b = px[i + 2]
    const mx = Math.max(r, g, b)
    const mn = Math.min(r, g, b)
    if (mx === mn || mx === 0) continue
    const sat = (mx - mn) / mx
    const boost = a * (1 - sat)
    const avg = (r + g + b) / 3
    px[i] = r + (r - avg) * boost
    px[i + 1] = g + (g - avg) * boost
    px[i + 2] = b + (b - avg) * boost
  }
}

/** color balance −100..100 per axis */
export function colorBalance(img: ImageData, red: number, green: number, blue: number): void {
  const px = img.data
  const dr = red * 0.6, dg = green * 0.6, db = blue * 0.6
  for (let i = 0; i < px.length; i += 4) {
    px[i] = px[i] + dr
    px[i + 1] = px[i + 1] + dg
    px[i + 2] = px[i + 2] + db
  }
}

/* ------------------------------------------------------------------ */
/* Greyscale / colorizing                                              */
/* ------------------------------------------------------------------ */

export function desaturate(img: ImageData): void {
  const px = img.data
  for (let i = 0; i < px.length; i += 4) {
    const l = 0.299 * px[i] + 0.587 * px[i + 1] + 0.114 * px[i + 2]
    px[i] = l; px[i + 1] = l; px[i + 2] = l
  }
}

export function invert(img: ImageData): void {
  const px = img.data
  for (let i = 0; i < px.length; i += 4) {
    px[i] = 255 - px[i]
    px[i + 1] = 255 - px[i + 1]
    px[i + 2] = 255 - px[i + 2]
  }
}

/** threshold 0..255 on luma; alpha is preserved */
export function threshold(img: ImageData, level: number): void {
  const px = img.data
  for (let i = 0; i < px.length; i += 4) {
    const on = 0.299 * px[i] + 0.587 * px[i + 1] + 0.114 * px[i + 2] >= level
    const v = on ? 255 : 0
    px[i] = v; px[i + 1] = v; px[i + 2] = v
  }
}

/** posterize with n levels per channel */
export function posterize(img: ImageData, n: number): void {
  const steps = Math.max(2, Math.round(n))
  const lut = identityLUT()
  for (let v = 0; v < 256; v++) {
    lut[v] = Math.round(v / 255 * (steps - 1)) * (255 / (steps - 1))
  }
  applyLUT(img, lut, lut, lut)
}

/** black & white with luminosity weights */
export function blackAndWhite(img: ImageData): void {
  desaturate(img)
}

/** per-channel auto levels: clip 0.1% at both ends and stretch */
export function autoTone(img: ImageData): void {
  const { width: w, height: h } = img
  const clip = Math.max(1, Math.floor(w * h * 0.001))
  const hists = histogram(img)
  const luts: LUT[] = []
  for (const ch of [hists.r, hists.g, hists.b]) {
    let lo = 0
    let acc = 0
    while (lo < 255 && acc + ch[lo] < clip) acc += ch[lo++]
    let hi = 255
    acc = 0
    while (hi > 0 && acc + ch[hi] < clip) acc += ch[hi--]
    if (hi <= lo) {
      const id = identityLUT()
      luts.push(id)
      continue
    }
    const lut = identityLUT()
    const span = hi - lo
    for (let v = 0; v < 256; v++) {
      const t = Math.min(1, Math.max(0, (v - lo) / span))
      lut[v] = Math.round(t * 255)
    }
    luts.push(lut)
  }
  applyLUT(img, luts[0], luts[1], luts[2])
}

/* ------------------------------------------------------------------ */
/* Convolution foundation                                              */
/* ------------------------------------------------------------------ */

/** 3×3 convolution, clamped at edges. Alpha is preserved from the source. */
export function convolve3(img: ImageData, kernel: [number, number, number, number, number, number, number, number, number], offset = 0): void {
  const { width: w, height: h } = img
  const src = new Uint8ClampedArray(img.data)
  const px = img.data
  for (let y = 0; y < h; y++) {
    const rowUp = (Math.max(0, y - 1) * w) * 4
    const rowMid = y * w * 4
    const rowDn = (Math.min(h - 1, y + 1) * w) * 4
    for (let x = 0; x < w; x++) {
      const cx = Math.max(0, x - 1) * 4
      const mx = x * 4
      const dx = Math.min(w - 1, x + 1) * 4
      const o = rowMid + mx
      if (px[o + 3] === 0 && src[rowUp + mx + 3] === 0 && src[rowUp + dx + 3] === 0 && src[rowMid + cx + 3] === 0 &&
        src[rowMid + dx + 3] === 0 && src[rowDn + cx + 3] === 0 && src[rowDn + mx + 3] === 0 && src[rowDn + dx + 3] === 0) continue
      let r = 0, g = 0, b = 0
      for (let k = 0; k < 9; k++) {
        const ky = k < 3 ? rowUp : k < 6 ? rowMid : rowDn
        const kx = k % 3 === 0 ? cx : k % 3 === 1 ? mx : dx
        const kv = kernel[k]
        r += src[ky + kx] * kv
        g += src[ky + kx + 1] * kv
        b += src[ky + kx + 2] * kv
      }
      px[o] = r + offset
      px[o + 1] = g + offset
      px[o + 2] = b + offset
    }
  }
}

/* ------------------------------------------------------------------ */
/* Blur family                                                         */
/* ------------------------------------------------------------------ */

/** Gaussian blur approximated with a true separable kernel (alpha preserved). */
export function gaussianBlur(img: ImageData, radius: number): void {
  const r = Math.max(0, radius)
  if (r < 0.3) return
  const sigma = Math.max(0.5, r / 2)
  const k = Math.min(160, Math.ceil(sigma * 2.5))
  const kern = new Float32Array(2 * k + 1)
  let s = 0
  for (let i = -k; i <= k; i++) {
    const v = Math.exp(-(i * i) / (2 * sigma * sigma))
    kern[i + k] = v
    s += v
  }
  for (let i = 0; i < kern.length; i++) kern[i] /= s

  const { width: w, height: h } = img
  const src = new Uint8ClampedArray(img.data)
  const tmp = new Uint8ClampedArray(src.length)
  const px = img.data

  /* horizontal */
  for (let y = 0; y < h; y++) {
    const row = y * w * 4
    for (let x = 0; x < w; x++) {
      let ar = 0, ag = 0, ab = 0
      for (let i = -k; i <= k; i++) {
        let sx = x + i
        if (sx < 0) sx = 0
        else if (sx >= w) sx = w - 1
        const j = row + sx * 4
        const kv = kern[i + k]
        ar += src[j] * kv
        ag += src[j + 1] * kv
        ab += src[j + 2] * kv
      }
      const o = row + x * 4
      tmp[o] = ar
      tmp[o + 1] = ag
      tmp[o + 2] = ab
      tmp[o + 3] = src[o + 3]
    }
  }
  /* vertical */
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let ar = 0, ag = 0, ab = 0
      for (let i = -k; i <= k; i++) {
        let sy = y + i
        if (sy < 0) sy = 0
        else if (sy >= h) sy = h - 1
        const j = sy * w * 4 + x * 4
        const kv = kern[i + k]
        ar += tmp[j] * kv
        ag += tmp[j + 1] * kv
        ab += tmp[j + 2] * kv
      }
      const o = y * w * 4 + x * 4
      px[o] = ar
      px[o + 1] = ag
      px[o + 2] = ab
      px[o + 3] = tmp[o + 3]
    }
  }
}

/** directional blur: average of samples along a line, distance in px */
export function motionBlur(img: ImageData, angleDeg: number, distance: number): void {
  const { width: w, height: h } = img
  const dist = Math.max(0, distance)
  if (dist < 1) return
  const src = new Uint8ClampedArray(img.data)
  const px = img.data
  const rad = (angleDeg * Math.PI) / 180
  const dx = Math.cos(rad)
  const dy = Math.sin(rad)
  const samples = Math.max(2, Math.ceil(dist))
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let r = 0, g = 0, b = 0
      for (let i = 0; i < samples; i++) {
        const t = samples === 1 ? 0 : i / (samples - 1) - 0.5
        let sx = Math.round(x + dx * t * dist)
        let sy = Math.round(y + dy * t * dist)
        if (sx < 0) sx = 0
        else if (sx >= w) sx = w - 1
        if (sy < 0) sy = 0
        else if (sy >= h) sy = h - 1
        const j = (sy * w + sx) * 4
        r += src[j]; g += src[j + 1]; b += src[j + 2]
      }
      const o = (y * w + x) * 4
      px[o] = r / samples
      px[o + 1] = g / samples
      px[o + 2] = b / samples
      px[o + 3] = src[o + 3]
    }
  }
}

/* ------------------------------------------------------------------ */
/* Sharpen family                                                      */
/* ------------------------------------------------------------------ */

/** sharpen amount in percent (e.g. 100 = subtle strong) */
export function sharpen(img: ImageData, amountPct: number): void {
  const a = amountPct / 100
  const c = 1 + 4 * a
  convolve3(img, [0, -a, 0, -a, c, -a, 0, -a, 0], 0)
}

/** unsharp mask: amount % 0..300, radius px, threshold level 0..255 */
export function unsharpMask(img: ImageData, amountPct: number, radius: number, thresholdLevel: number): void {
  const amt = amountPct / 100
  if (amt <= 0) return
  const { width: w, height: h } = img
  const blurred = new ImageData(new Uint8ClampedArray(img.data), w, h)
  gaussianBlur(blurred, radius)
  const px = img.data
  const bp = blurred.data
  const cut = Math.max(0, thresholdLevel)
  for (let i = 0; i < px.length; i += 4) {
    for (let c = 0; c < 3; c++) {
      const diff = px[i + c] - bp[i + c]
      if (Math.abs(diff) >= cut) {
        px[i + c] = px[i + c] + amt * diff
      }
    }
  }
}

/* ------------------------------------------------------------------ */
/* Noise / pixelation / stylize                                        */
/* ------------------------------------------------------------------ */

/** add noise amount 0..100 */
export function addNoise(img: ImageData, amount: number, monochromatic: boolean): void {
  const a = Math.max(0, Math.min(100, amount)) / 100 * 96
  if (a <= 0) return
  const px = img.data
  for (let i = 0; i < px.length; i += 4) {
    if (px[i + 3] === 0) continue
    if (monochromatic) {
      const n = (Math.random() - 0.5) * 2 * a
      px[i] = px[i] + n
      px[i + 1] = px[i + 1] + n
      px[i + 2] = px[i + 2] + n
    } else {
      px[i] = px[i] + (Math.random() - 0.5) * 2 * a
      px[i + 1] = px[i + 1] + (Math.random() - 0.5) * 2 * a
      px[i + 2] = px[i + 2] + (Math.random() - 0.5) * 2 * a
    }
  }
}

/** pixelate into cell px blocks */
export function mosaic(img: ImageData, cell: number): void {
  const { width: w, height: h } = img
  const size = Math.max(2, Math.round(cell))
  if (size < 2) return
  const src = new Uint8ClampedArray(img.data)
  const px = img.data
  for (let by = 0; by < h; by += size) {
    for (let bx = 0; bx < w; bx += size) {
      const ex = Math.min(w, bx + size)
      const ey = Math.min(h, by + size)
      let r = 0, g = 0, b = 0, a = 0, n = 0
      for (let y = by; y < ey; y++) {
        for (let x = bx; x < ex; x++) {
          const j = (y * w + x) * 4
          r += src[j]; g += src[j + 1]; b += src[j + 2]; a += src[j + 3]
          n++
        }
      }
      r = r / n; g = g / n; b = b / n; a = a / n
      for (let y = by; y < ey; y++) {
        for (let x = bx; x < ex; x++) {
          const j = (y * w + x) * 4
          px[j] = r; px[j + 1] = g; px[j + 2] = b; px[j + 3] = a
        }
      }
    }
  }
}

/** classic emboss kernel (sum-zero) with a 50% grey lift — flat areas → 128 */
export function emboss(img: ImageData): void {
  convolve3(img, [-2, -1, 0, -1, 0, 1, 0, 1, 2], 128)
}

/** edge detect, light-on-dark */
export function findEdges(img: ImageData): void {
  convolve3(img, [0, -1, 0, -1, 4, -1, 0, -1, 0], 0)
}

/* ------------------------------------------------------------------ */
/* Curves — monotone cubic spline through control points               */
/* ------------------------------------------------------------------ */

export interface CurvePoint {
  x: number // 0..255
  y: number // 0..255
}

/** Build a 256-entry LUT from control points (Fritsch–Carlson monotone cubic). */
export function splineLUT(points: CurvePoint[]): LUT {
  const pts = points
    .map((p) => ({ x: Math.max(0, Math.min(255, p.x)), y: Math.max(0, Math.min(255, p.y)) }))
    .sort((a, b) => a.x - b.x)
  if (pts.length === 1) {
    const id = identityLUT()
    for (let i = 0; i < 256; i++) id[i] = pts[0].y
    return id
  }
  pts[0] = { x: 0, y: pts[0].y }
  pts[pts.length - 1] = { x: 255, y: pts[pts.length - 1].y }
  const n = pts.length
  const dx: number[] = []
  const dy: number[] = []
  for (let i = 0; i < n - 1; i++) {
    dx.push(pts[i + 1].x - pts[i].x)
    dy.push(pts[i + 1].y - pts[i].y)
  }
  /* tangents: secants at ends, average at midpoints */
  const t: number[] = new Array(n)
  t[0] = dy[0] / Math.max(1, dx[0])
  for (let i = 1; i < n - 1; i++) {
    t[i] = (dy[i - 1] / Math.max(1, dx[i - 1]) + dy[i] / Math.max(1, dx[i])) / 2
  }
  t[n - 1] = dy[n - 2] / Math.max(1, dx[n - 2])
  /* limit to avoid overshoot */
  for (let i = 0; i < n - 1; i++) {
    if (dy[i] === 0) {
      t[i] = 0
      t[i + 1] = 0
      continue
    }
    const aq = t[i] / dy[i]
    const bq = t[i + 1] / dy[i]
    if (aq * aq + bq * bq > 9) {
      const tk = 3 / Math.sqrt(aq * aq + bq * bq)
      t[i] = tk * aq * dy[i]
      t[i + 1] = tk * bq * dy[i]
    }
  }
  const lut = identityLUT()
  let seg = 0
  for (let v = 0; v <= 255; v++) {
    while (seg < n - 2 && pts[seg + 1].x < v) seg++
    let y: number
    if (v <= pts[0].x) y = pts[0].y
    else if (v >= pts[n - 1].x) y = pts[n - 1].y
    else if (dy[seg] === 0) y = pts[seg].y
    else {
      const u = (v - pts[seg].x) / dx[seg]
      const u2 = u * u
      const u3 = u2 * u
      const h00 = 2 * u3 - 3 * u2 + 1
      const h10 = u3 - 2 * u2 + u
      const h01 = -2 * u3 + 3 * u2
      const h11 = u3 - u2
      y = h00 * pts[seg].y + h10 * dx[seg] * t[seg] + h01 * pts[seg + 1].y + h11 * dx[seg] * t[seg + 1]
    }
    lut[v] = Math.round(Math.min(255, Math.max(0, y)))
  }
  return lut
}
