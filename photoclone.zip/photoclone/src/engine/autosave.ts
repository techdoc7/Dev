/* IndexedDB-backed crash recovery. Project payloads are the exact same compact
   .pclone Blobs used for downloaded files. Nothing leaves the browser. */

const DB_NAME = 'photoclone-local'
const DB_VERSION = 1
const STORE = 'autosaves'
const SESSION_KEY = 'current-session'

export interface AutosaveRecord {
  id: typeof SESSION_KEY
  version: 1
  savedAt: number
  activeIndex: number
  projects: Blob[]
}

function requestResult<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error ?? new Error('IndexedDB request failed'))
  })
}

function transactionDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve()
    tx.onabort = () => reject(tx.error ?? new Error('IndexedDB transaction was aborted'))
    tx.onerror = () => reject(tx.error ?? new Error('IndexedDB transaction failed'))
  })
}

export function openAutosaveDb(): Promise<IDBDatabase> {
  if (!('indexedDB' in globalThis)) return Promise.reject(new Error('IndexedDB is unavailable'))
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION)
    request.onupgradeneeded = () => {
      const db = request.result
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: 'id' })
    }
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error ?? new Error('Could not open local recovery storage'))
  })
}

export async function readAutosave(): Promise<AutosaveRecord | null> {
  const db = await openAutosaveDb()
  try {
    const tx = db.transaction(STORE, 'readonly')
    const done = transactionDone(tx)
    const value = await requestResult(tx.objectStore(STORE).get(SESSION_KEY))
    await done
    const record = value as AutosaveRecord | undefined
    if (!record || record.version !== 1 || !Array.isArray(record.projects) || record.projects.length === 0) return null
    return record
  } finally {
    db.close()
  }
}

export async function writeAutosave(record: Omit<AutosaveRecord, 'id' | 'version'>): Promise<void> {
  const db = await openAutosaveDb()
  try {
    const tx = db.transaction(STORE, 'readwrite')
    const done = transactionDone(tx)
    tx.objectStore(STORE).put({ ...record, id: SESSION_KEY, version: 1 } satisfies AutosaveRecord)
    await done
  } finally {
    db.close()
  }
}

export async function clearAutosave(): Promise<void> {
  const db = await openAutosaveDb()
  try {
    const tx = db.transaction(STORE, 'readwrite')
    const done = transactionDone(tx)
    tx.objectStore(STORE).delete(SESSION_KEY)
    await done
  } finally {
    db.close()
  }
}
