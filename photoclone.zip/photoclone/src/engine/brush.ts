/* Raster painting primitives — original code. */

export interface StampOpts {
  /** diameter in doc px */
  size: number
  /** 0..100 */
  hardness: number
  /** opaque hex like #ff8800 */
  color: string
  /** 0..1 effective stamp alpha */
  alpha: number
}

function clamp01(v: number): number {
  return Math.min(1, Math.max(0, v))
}

/** Soft/hard round brush stamp via radial-gradient falloff. */
export function stampBrush(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  o: StampOpts,
): void {
  const r = Math.max(0.5, o.size / 2)
  const h = clamp01(o.hardness / 100)
  ctx.save()
  ctx.globalAlpha = clamp01(o.alpha)
  if (h >= 0.985) {
    ctx.fillStyle = o.color
    ctx.beginPath()
    ctx.arc(x, y, r, 0, Math.PI * 2)
    ctx.fill()
  } else {
    const inner = r * h * 0.97
    const g = ctx.createRadialGradient(x, y, Math.max(0, inner), x, y, r)
    g.addColorStop(0, o.color)
    g.addColorStop(1, o.color + '00')
    ctx.fillStyle = g
    ctx.beginPath()
    ctx.arc(x, y, r, 0, Math.PI * 2)
    ctx.fill()
  }
  ctx.restore()
}

/** Hard, aliased square stamp (pencil). */
export function stampPencil(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  o: StampOpts,
): void {
  const s = Math.max(1, Math.round(o.size))
  ctx.save()
  ctx.globalAlpha = clamp01(o.alpha)
  ctx.fillStyle = o.color
  ctx.fillRect(
    Math.round(x - s / 2),
    Math.round(y - s / 2),
    s,
    s,
  )
  ctx.restore()
}

/** Stamp along a segment with even spacing (mouse-sampling like). */
export function stampAlongLine(
  ctx: CanvasRenderingContext2D,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  spacing: number,
  o: StampOpts,
  kind: 'brush' | 'pencil',
): void {
  const dx = x1 - x0
  const dy = y1 - y0
  const dist = Math.hypot(dx, dy)
  if (dist < 0.01) {
    if (kind === 'pencil') stampPencil(ctx, x1, y1, o)
    else stampBrush(ctx, x1, y1, o)
    return
  }
  const step = Math.max(0.75, spacing)
  const count = Math.ceil(dist / step) + 1
  for (let i = 0; i < count; i++) {
    const t = Math.min(1, (i * step) / dist)
    const x = x0 + dx * t
    const y = y0 + dy * t
    if (kind === 'pencil') stampPencil(ctx, x, y, o)
    else stampBrush(ctx, x, y, o)
  }
}

/* ------------------------------------------------------------------ */
/* Uniform-spacing stroke walker                                       */
/*                                                                     */
/* Stamps at exact distance multiples along the path regardless of how  */
/* irregularly the OS delivers mouse-move events — this is what makes   */
/* strokes feel continuous instead of beaded.                          */
/* ------------------------------------------------------------------ */

export interface StrokeWalker {
  x: number
  y: number
  /** distance remaining until the next stamp */
  toNext: number
}

export function beginWalker(x: number, y: number, spacing: number): StrokeWalker {
  return { x, y, toNext: walkerSpacing(spacing) }
}

export function walkerSpacing(spacing: number): number {
  return Math.max(0.75, spacing)
}

/** Advance the walker to (x1,y1), stamping wherever spacing multiples are crossed. */
export function walkStamp(
  ctx: CanvasRenderingContext2D,
  walker: StrokeWalker,
  x1: number,
  y1: number,
  spacing: number,
  o: StampOpts,
  kind: 'brush' | 'pencil',
): void {
  const dx = x1 - walker.x
  const dy = y1 - walker.y
  const dist = Math.hypot(dx, dy)
  if (dist < 0.0001) return
  const ux = dx / dist
  const uy = dy / dist
  let travelled = 0
  while (dist - travelled >= walker.toNext) {
    travelled += walker.toNext
    const sx = walker.x + ux * travelled
    const sy = walker.y + uy * travelled
    if (kind === 'pencil') stampPencil(ctx, sx, sy, o)
    else stampBrush(ctx, sx, sy, o)
    walker.toNext = walkerSpacing(spacing)
  }
  walker.toNext -= dist - travelled
  if (walker.toNext < 0) walker.toNext = 0
  walker.x = x1
  walker.y = y1
}

/* ---------------- gradients ---------------- */

export function hexToRgba(hex: string, alpha: number): string {
  let h = hex.replace('#', '')
  if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2]
  const r = parseInt(h.slice(0, 2), 16)
  const g = parseInt(h.slice(2, 4), 16)
  const b = parseInt(h.slice(4, 6), 16)
  return `rgba(${r}, ${g}, ${b}, ${clamp01(alpha)})`
}

export type GradientKind = 'linear' | 'radial'

/** Fill an entire layer with a 2-stop gradient along a drag vector. */
export function paintGradient(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  fromColor: string,
  toColor: string,
  kind: GradientKind,
): void {
  ctx.save()
  let grad: CanvasGradient
  if (kind === 'radial') {
    const r = Math.max(1, Math.hypot(x1 - x0, y1 - y0))
    grad = ctx.createRadialGradient(x0, y0, 0, x0, y0, r)
  } else {
    grad = ctx.createLinearGradient(x0, y0, x1, y1)
  }
  grad.addColorStop(0, fromColor)
  grad.addColorStop(1, toColor)
  ctx.fillStyle = grad
  ctx.fillRect(0, 0, w, h)
  ctx.restore()
}
