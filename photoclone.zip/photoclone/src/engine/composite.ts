import { canvasCtx, makeCanvas } from '../editor/store'
import { BLEND_CSS_MAP, LayerStyle, PhotoLayer } from '../editor/types'
import { applyAdjustmentLayer } from './adjustmentLayer'

/** Any object shaped like a document that the compositor can draw. */
export interface CompositeTarget {
  width: number
  height: number
  layers: PhotoLayer[]
}

/* ------------------------------------------------------------------ */
/* Non-destructive layer styles                                        */
/*                                                                     */
/* Shadow: silhouette stamped with ctx.shadow*, then the shadow is     */
/* isolated by erasing the layer's own footprint (destination-out).     */
/* Outer stroke: silhouette dilated in 8 sampled directions, then       */
/* tinted via a 'source-in' fill.                                      */
/* Results cached per layer keyed by content-revision + size + style.   */
/* ------------------------------------------------------------------ */

const MIN_SHADOW_BLUR = 0.15

function hexToRgbaStr(hex: string): string {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim())
  if (!m) return hex
  const v = parseInt(m[1], 16)
  return `rgba(${(v >> 16) & 255}, ${(v >> 8) & 255}, ${v & 255}, 1)`
}

/** Layer copy with its drop shadow baked (footprint erased). */
function shadowCanvas(layer: PhotoLayer, w: number, h: number, shadow: NonNullable<LayerStyle['shadow']>): HTMLCanvasElement {
  const t = makeCanvas(w, h)
  const ctx = canvasCtx(t)
  ctx.save()
  ctx.shadowColor = hexToRgbaStr(shadow.color)
  ctx.shadowBlur = Math.max(MIN_SHADOW_BLUR, shadow.blur)
  ctx.shadowOffsetX = shadow.dx
  ctx.shadowOffsetY = shadow.dy
  ctx.drawImage(layer.canvas, 0, 0)
  ctx.restore()
  /* erase layer pixels + everything directly under them → shadow only */
  ctx.globalCompositeOperation = 'destination-out'
  ctx.drawImage(layer.canvas, 0, 0)
  ctx.globalCompositeOperation = 'source-over'
  return t
}

/** Dilated silhouette tinted `color` (solid outer stroke ring). */
function strokeCanvas(layer: PhotoLayer, w: number, h: number, stroke: NonNullable<LayerStyle['stroke']>): HTMLCanvasElement {
  const d = Math.max(1, Math.round(stroke.width))
  const t = makeCanvas(w, h)
  const ctx = canvasCtx(t)
  ctx.save()
  const inv = Math.SQRT1_2 * d
  for (const [ox, oy] of [
    [d, 0], [-d, 0], [0, d], [0, -d],
    [inv, inv], [inv, -inv], [-inv, inv], [-inv, -inv],
  ] as const) {
    ctx.drawImage(layer.canvas, ox, oy)
  }
  ctx.restore()
  ctx.globalCompositeOperation = 'source-in'
  ctx.fillStyle = hexToRgbaStr(stroke.color)
  ctx.fillRect(0, 0, w, h)
  ctx.globalCompositeOperation = 'source-over'
  return t
}

interface StyleCacheEntry {
  key: string
  canvas: HTMLCanvasElement
}

const styleCache = new WeakMap<PhotoLayer, StyleCacheEntry>()

/**
 * Render a layer's non-destructive style (stroke + shadow) beneath its pixels.
 * `revKey` should change whenever the pixel content may have changed
 * (e.g. the document revision). Returns the input canvas unchanged when no style.
 */
export function renderStyledLayer(layer: PhotoLayer, w: number, h: number, revKey: string): HTMLCanvasElement {
  const style = layer.style
  if (!style || (!style.shadow && !style.stroke)) return layer.canvas
  let key: string
  try {
    key = `${revKey}|${w}x${h}|${JSON.stringify(style)}`
  } catch {
    key = `${revKey}|${w}x${h}|raw`
  }
  const cached = styleCache.get(layer)
  if (cached && cached.key === key) return cached.canvas

  const styled = makeCanvas(w, h)
  const ctx = canvasCtx(styled)
  /* shadow beneath, then stroke ring, then the layer itself on top */
  if (style.shadow) ctx.drawImage(shadowCanvas(layer, w, h, style.shadow), 0, 0)
  if (style.stroke) ctx.drawImage(strokeCanvas(layer, w, h, style.stroke), 0, 0)
  ctx.drawImage(layer.canvas, 0, 0)

  if (cached) {
    cached.key = key
    cached.canvas.width = 0
    cached.canvas.height = 0
  }
  styleCache.set(layer, { key, canvas: styled })
  return styled
}

/** Apply a layer's alpha mask after styles have been rendered. */
function renderMaskedLayer(layer: PhotoLayer, source: HTMLCanvasElement, w: number, h: number): HTMLCanvasElement {
  if (!layer.mask || layer.maskEnabled === false) return source
  const masked = makeCanvas(w, h)
  const ctx = canvasCtx(masked)
  ctx.drawImage(source, 0, 0)
  ctx.globalCompositeOperation = 'destination-in'
  ctx.drawImage(layer.mask, 0, 0)
  ctx.globalCompositeOperation = 'source-over'
  return masked
}

function compositeStack(layers: PhotoLayer[], parentId: string | null, target: HTMLCanvasElement, width: number, height: number, revision: string): void {
  const ctx = canvasCtx(target)
  const groupIds = new Set(layers.filter((l) => l.type === 'group').map((l) => l.id))
  const members = layers.filter((layer) => parentId === null
    ? !layer.parentId || !groupIds.has(layer.parentId)
    : layer.parentId === parentId)
  let clipBase: HTMLCanvasElement | null = null
  for (const layer of members) {
    if (layer.type === 'group') {
      let surface = makeCanvas(width, height)
      compositeStack(layers, layer.id, surface, width, height, revision)
      surface = renderMaskedLayer(layer, surface, width, height)
      if (!layer.clipping) {
        clipBase = makeCanvas(width, height)
        if (layer.visible) canvasCtx(clipBase).drawImage(surface, 0, 0)
      } else if (clipBase) {
        const clipped = makeCanvas(width, height)
        const cctx = canvasCtx(clipped)
        cctx.drawImage(surface, 0, 0)
        cctx.globalCompositeOperation = 'destination-in'
        cctx.drawImage(clipBase, 0, 0)
        surface = clipped
      }
      if (!layer.visible) continue
      ctx.save()
      ctx.globalAlpha = layer.opacity
      ctx.globalCompositeOperation = layer.blendMode === 'pass-through' ? 'source-over' : (((BLEND_CSS_MAP as Record<string, string>)[layer.blendMode] ?? 'source-over') as GlobalCompositeOperation)
      ctx.drawImage(surface, 0, 0)
      ctx.restore()
      continue
    }
    if (layer.type === 'adjustment' && layer.adjustment) {
      if (!layer.visible) continue
      let adjusted = makeCanvas(width, height)
      const adjustedCtx = canvasCtx(adjusted)
      adjustedCtx.drawImage(target, 0, 0)
      const image = adjustedCtx.getImageData(0, 0, width, height)
      applyAdjustmentLayer(image, layer.adjustment)
      adjustedCtx.putImageData(image, 0, 0)
      if (layer.mask && layer.maskEnabled !== false) adjusted = renderMaskedLayer(layer, adjusted, width, height)
      if (layer.clipping && clipBase) {
        const clipped = makeCanvas(width, height)
        const clippedCtx = canvasCtx(clipped)
        clippedCtx.drawImage(adjusted, 0, 0)
        clippedCtx.globalCompositeOperation = 'destination-in'
        clippedCtx.drawImage(clipBase, 0, 0)
        adjusted = clipped
      }
      ctx.save()
      ctx.globalAlpha = layer.opacity
      ctx.globalCompositeOperation = ((BLEND_CSS_MAP as Record<string, string>)[layer.blendMode] ?? 'source-over') as GlobalCompositeOperation
      ctx.drawImage(adjusted, 0, 0)
      ctx.restore()
      continue
    }
    const styled = renderStyledLayer(layer, width, height, revision)
    let surface = renderMaskedLayer(layer, styled, width, height)
    if (!layer.clipping) {
      clipBase = makeCanvas(width, height)
      if (layer.visible) canvasCtx(clipBase).drawImage(surface, 0, 0)
    } else if (clipBase) {
      const clipped = makeCanvas(width, height)
      const clippedCtx = canvasCtx(clipped)
      clippedCtx.drawImage(surface, 0, 0)
      clippedCtx.globalCompositeOperation = 'destination-in'
      clippedCtx.drawImage(clipBase, 0, 0)
      clippedCtx.globalCompositeOperation = 'source-over'
      surface = clipped
    }
    if (!layer.visible) continue
    ctx.save()
    ctx.globalAlpha = layer.opacity
    ctx.globalCompositeOperation =
      ((BLEND_CSS_MAP as Record<string, string>)[layer.blendMode] ??
      'source-over') as GlobalCompositeOperation
    ctx.drawImage(surface, 0, 0)
    ctx.restore()
  }
}

/** Blend a document's full layer stack into a target canvas (bottom → top). */
export function compositeDoc(
  doc: CompositeTarget,
  target: HTMLCanvasElement,
  revision = '',
): HTMLCanvasElement {
  const ctx = canvasCtx(target)
  if (ctx.canvas.width !== doc.width) ctx.canvas.width = doc.width
  if (ctx.canvas.height !== doc.height) ctx.canvas.height = doc.height
  ctx.clearRect(0, 0, doc.width, doc.height)
  compositeStack(doc.layers, null, target, doc.width, doc.height, revision)
  return target
}

/** Blend a single (active) layer, used for isolated previews. */
export function compositeLayer(
  layer: PhotoLayer,
  width: number,
  height: number,
  target: HTMLCanvasElement,
  revision = '',
): HTMLCanvasElement {
  const ctx = canvasCtx(target)
  if (ctx.canvas.width !== width) ctx.canvas.width = width
  if (ctx.canvas.height !== height) ctx.canvas.height = height
  ctx.clearRect(0, 0, width, height)
  if (layer.visible) {
    ctx.save()
    ctx.globalAlpha = layer.opacity
    ctx.globalCompositeOperation =
      ((BLEND_CSS_MAP as Record<string, string>)[layer.blendMode] ??
      'source-over') as GlobalCompositeOperation
    const styled = renderStyledLayer(layer, width, height, revision)
    ctx.drawImage(renderMaskedLayer(layer, styled, width, height), 0, 0)
    ctx.restore()
  }
  return target
}

/** Build the light/dark checkerboard pattern used behind transparent areas. */
export function makeCheckerPattern(): CanvasPattern {
  const tile = document.createElement('canvas')
  tile.width = 16
  tile.height = 16
  const tctx = canvasCtx(tile)
  tctx.fillStyle = '#c8c8c8'
  tctx.fillRect(0, 0, 16, 16)
  tctx.fillStyle = '#ffffff'
  tctx.fillRect(0, 0, 8, 8)
  tctx.fillRect(8, 8, 8, 8)
  const ctx = canvasCtx(tile)
  return ctx.createPattern(tile, 'repeat') as CanvasPattern
}
