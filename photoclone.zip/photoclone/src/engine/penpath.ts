/* Pen path helpers — Path2D construction and bezier flattening.
   All original code. */

import { PenPoint, PenPath } from '../editor/types'

/** Build a Path2D from pen anchors (cubic segments through handles). */
export function buildPath2D(points: PenPoint[], closed: boolean): Path2D {
  const path = new Path2D()
  if (points.length === 0) return path
  path.moveTo(points[0].x, points[0].y)
  for (let i = 1; i < points.length; i++) {
    const prev = points[i - 1]
    const cur = points[i]
    path.bezierCurveTo(prev.c2x, prev.c2y, cur.c1x, cur.c1y, cur.x, cur.y)
  }
  if (closed && points.length > 1) {
    const last = points[points.length - 1]
    const first = points[0]
    path.bezierCurveTo(last.c2x, last.c2y, first.c1x, first.c1y, first.x, first.y)
    path.closePath()
  }
  return path
}

/** Flatten the path to a polyline [x0,y0,x1,y1,…] sampled every `step` px. */
export function flattenPenPath(points: PenPoint[], closed: boolean, step = 6): number[] {
  const out: number[] = []
  if (points.length === 0) return out

  const pushPoint = (x: number, y: number): void => {
    const n = out.length
    if (n >= 2) {
      const d = Math.hypot(x - out[n - 2], y - out[n - 1])
      if (d < step) return
    }
    out.push(x, y)
  }

  pushPoint(points[0].x, points[0].y)
  for (let i = 1; i < points.length; i++) {
    const prev = points[i - 1]
    const cur = points[i]
    const p0 = { x: prev.x, y: prev.y }
    const c1 = { x: prev.c2x, y: prev.c2y }
    const c2 = { x: cur.c1x, y: cur.c1y }
    const p1 = { x: cur.x, y: cur.y }
    /* chord length to pick a reasonable sample count */
    const chord = Math.hypot(p1.x - p0.x, p1.y - p0.y)
    const ctrl = Math.hypot(c1.x - p0.x, c1.y - p0.y) + Math.hypot(c2.x - p1.x, c2.y - p1.y)
    const steps = Math.max(2, Math.ceil(Math.max(chord, ctrl) / Math.max(2, step)))
    for (let s = 1; s <= steps; s++) {
      const t = s / steps
      const u = 1 - t
      const bx = u * u * u * p0.x + 3 * u * u * t * c1.x + 3 * u * t * t * c2.x + t * t * t * p1.x
      const by = u * u * u * p0.y + 3 * u * u * t * c1.y + 3 * u * t * t * c2.y + t * t * t * p1.y
      pushPoint(bx, by)
    }
  }
  if (closed && points.length > 1) {
    const last = points[points.length - 1]
    const first = points[0]
    const p0 = { x: last.x, y: last.y }
    const c1 = { x: last.c2x, y: last.c2y }
    const c2 = { x: first.c1x, y: first.c1y }
    const p1 = { x: first.x, y: first.y }
    const chord = Math.hypot(p1.x - p0.x, p1.y - p0.y)
    const steps = Math.max(2, Math.ceil(chord / Math.max(2, step)))
    for (let s = 1; s <= steps; s++) {
      const t = s / steps
      const u = 1 - t
      const bx = u * u * u * p0.x + 3 * u * u * t * c1.x + 3 * u * t * t * c2.x + t * t * t * p1.x
      const by = u * u * u * p0.y + 3 * u * u * t * c1.y + 3 * u * t * t * c2.y + t * t * t * p1.y
      pushPoint(bx, by)
    }
    pushPoint(first.x, first.y)
  }
  return out
}

export function clonePenPath(p: PenPath | null | undefined): PenPath | null {
  if (!p) return null
  return {
    closed: p.closed,
    points: p.points.map((q) => ({ ...q })),
  }
}

/** Nearest anchor within tol — returns its index or -1 */
export function anchorHit(points: PenPoint[], x: number, y: number, tol: number): number {
  let best = -1
  let bestD = tol
  for (let i = 0; i < points.length; i++) {
    const d = Math.hypot(points[i].x - x, points[i].y - y)
    if (d < bestD) { bestD = d; best = i }
  }
  return best
}

/** Nearest handle within tol (handles coincident with their anchor are skipped) */
export function handleHit(
  points: PenPoint[],
  x: number,
  y: number,
  tol: number,
): { idx: number; side: 'in' | 'out' } | null {
  for (let i = 0; i < points.length; i++) {
    const p = points[i]
    const dIn = Math.hypot(p.c1x - x, p.c1y - y)
    const dOut = Math.hypot(p.c2x - x, p.c2y - y)
    if (dOut < tol && Math.hypot(p.c2x - p.x, p.c2y - p.y) > 0.5) return { idx: i, side: 'out' }
    if (dIn < tol && Math.hypot(p.c1x - p.x, p.c1y - p.y) > 0.5) return { idx: i, side: 'in' }
  }
  return null
}
