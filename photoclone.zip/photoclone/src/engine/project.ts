/* Photoclone project container (.pclone), version 1.

   Binary layout:
     8 bytes  ASCII "PCLONE01"
     4 bytes  little-endian JSON header byte length
     N bytes  UTF-8 JSON metadata
     ...      PNG assets in the order declared by header.assets

   Keeping PNGs as binary Blob parts avoids base64's ~33% size overhead and
   lets IndexedDB store the same compact project Blob used for downloads. */

import { AdjustmentLayerData, BlendMode, LayerStyle, LayerType, PenPath, PhotoLayer, Selection, TextLayerData } from '../editor/types'

const MAGIC_TEXT = 'PCLONE01'
const MAGIC = new TextEncoder().encode(MAGIC_TEXT)
const HEADER_LIMIT = 8 * 1024 * 1024
export const PCLONE_MIME = 'application/x-photoclone'

interface AssetMeta {
  kind: 'layer' | 'selection' | 'mask'
  bytes: number
  mime: 'image/png'
}

interface LayerMeta {
  id: string
  name: string
  type: LayerType
  visible: boolean
  locked: boolean
  opacity: number
  blendMode: BlendMode
  style?: LayerStyle | null
  asset: number
  maskAsset?: number | null
  maskEnabled?: boolean
  clipping?: boolean
  textData?: TextLayerData
  adjustment?: AdjustmentLayerData
  parentId?: string | null
  opened?: boolean
}

interface ProjectHeaderV1 {
  format: 'photoclone'
  version: 1
  savedAt: number
  appVersion: string
  assets: AssetMeta[]
  editor: { fg: string; bg: string }
  document: {
    name: string
    width: number
    height: number
    zoom: number
    panX: number
    panY: number
    activeLayerId: string
    layers: LayerMeta[]
    selectionAsset: number | null
    workPath: PenPath | null
  }
}

export interface ProjectSource {
  name: string
  width: number
  height: number
  zoom: number
  panX: number
  panY: number
  activeLayerId: string
  layers: PhotoLayer[]
  selection: Selection | null
  workPath: PenPath | null
}

export interface DecodedProject {
  name: string
  width: number
  height: number
  zoom: number
  panX: number
  panY: number
  activeLayerId: string
  layers: PhotoLayer[]
  selection: Selection | null
  workPath: PenPath | null
  fg: string
  bg: string
  savedAt: number
}

function canvasPng(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (blob) resolve(blob)
      else reject(new Error('Could not encode a project bitmap'))
    }, 'image/png')
  })
}

function canvas2d(canvas: HTMLCanvasElement): CanvasRenderingContext2D {
  const ctx = canvas.getContext('2d', { willReadFrequently: true })
  if (!ctx) throw new Error('2D canvas is unavailable')
  return ctx
}

async function pngCanvas(blob: Blob, width: number, height: number): Promise<HTMLCanvasElement> {
  const canvas = document.createElement('canvas')
  canvas.width = width
  canvas.height = height
  const ctx = canvas2d(canvas)
  /* Object-URL decoding is used instead of createImageBitmap: some Chromium
     builds expose createImageBitmap for Blob slices but never settle its
     promise, which would leave project opening stuck indefinitely. */
  const url = URL.createObjectURL(blob)
  try {
    const image = await new Promise<HTMLImageElement>((resolve, reject) => {
      const img = new Image()
      img.onload = () => resolve(img)
      img.onerror = () => reject(new Error('Could not decode a project bitmap'))
      img.src = url
    })
    ctx.drawImage(image, 0, 0)
    return canvas
  } finally {
    URL.revokeObjectURL(url)
  }
}

function finite(v: unknown, fallback: number): number {
  return typeof v === 'number' && Number.isFinite(v) ? v : fallback
}

function validDimension(v: unknown): number {
  const n = Math.round(finite(v, 0))
  if (n < 1 || n > 32768) throw new Error('Project dimensions are invalid or unsupported')
  return n
}

/** Encode one layered document as a compact, binary .pclone Blob. */
export async function encodeProject(
  doc: ProjectSource,
  editor: { fg: string; bg: string } = { fg: '#000000', bg: '#ffffff' },
): Promise<Blob> {
  const blobs: Blob[] = []
  const assets: AssetMeta[] = []
  const layers: LayerMeta[] = []

  /* Sequential conversion avoids a large burst of simultaneous PNG encoders. */
  for (const layer of doc.layers) {
    const png = await canvasPng(layer.canvas)
    const asset = assets.length
    blobs.push(png)
    assets.push({ kind: 'layer', bytes: png.size, mime: 'image/png' })
    const meta: LayerMeta = {
      id: layer.id,
      name: layer.name,
      type: layer.type,
      visible: layer.visible,
      locked: layer.locked,
      opacity: layer.opacity,
      blendMode: layer.blendMode,
      style: layer.style ? JSON.parse(JSON.stringify(layer.style)) as LayerStyle : null,
      asset,
      maskAsset: null,
      maskEnabled: layer.maskEnabled !== false,
      clipping: !!layer.clipping,
      textData: layer.textData ? JSON.parse(JSON.stringify(layer.textData)) as TextLayerData : undefined,
      adjustment: layer.adjustment ? JSON.parse(JSON.stringify(layer.adjustment)) as AdjustmentLayerData : undefined,
      parentId: layer.parentId ?? null,
      opened: layer.opened !== false,
    }
    if (layer.mask) {
      const maskPng = await canvasPng(layer.mask)
      meta.maskAsset = assets.length
      blobs.push(maskPng)
      assets.push({ kind: 'mask', bytes: maskPng.size, mime: 'image/png' })
    }
    layers.push(meta)
  }

  let selectionAsset: number | null = null
  if (doc.selection) {
    const png = await canvasPng(doc.selection.mask)
    selectionAsset = assets.length
    blobs.push(png)
    assets.push({ kind: 'selection', bytes: png.size, mime: 'image/png' })
  }

  const header: ProjectHeaderV1 = {
    format: 'photoclone',
    version: 1,
    savedAt: Date.now(),
    appVersion: '1.0.0',
    assets,
    editor: { fg: editor.fg, bg: editor.bg },
    document: {
      name: doc.name,
      width: doc.width,
      height: doc.height,
      zoom: doc.zoom,
      panX: doc.panX,
      panY: doc.panY,
      activeLayerId: doc.activeLayerId,
      layers,
      selectionAsset,
      workPath: doc.workPath ? JSON.parse(JSON.stringify(doc.workPath)) as PenPath : null,
    },
  }
  const headerBytes = new TextEncoder().encode(JSON.stringify(header))
  if (headerBytes.byteLength > HEADER_LIMIT) throw new Error('Project metadata is too large')
  const size = new Uint8Array(4)
  new DataView(size.buffer).setUint32(0, headerBytes.byteLength, true)
  return new Blob([MAGIC, size, headerBytes, ...blobs], { type: PCLONE_MIME })
}

/** Decode and validate a .pclone Blob, including all PNG layer assets. */
export async function decodeProject(blob: Blob): Promise<DecodedProject> {
  if (blob.size < 12) throw new Error('This is not a valid .pclone project')
  const prefix = new Uint8Array(await blob.slice(0, 12).arrayBuffer())
  for (let i = 0; i < MAGIC.length; i++) {
    if (prefix[i] !== MAGIC[i]) throw new Error('Unrecognized project format')
  }
  const headerLength = new DataView(prefix.buffer, prefix.byteOffset, prefix.byteLength).getUint32(8, true)
  if (headerLength < 2 || headerLength > HEADER_LIMIT || 12 + headerLength > blob.size) {
    throw new Error('The project header is damaged')
  }
  let header: ProjectHeaderV1
  try {
    const bytes = await blob.slice(12, 12 + headerLength).arrayBuffer()
    header = JSON.parse(new TextDecoder().decode(bytes)) as ProjectHeaderV1
  } catch {
    throw new Error('The project metadata is damaged')
  }
  if (header.format !== 'photoclone' || header.version !== 1) {
    throw new Error(`Unsupported .pclone version: ${(header as any).version ?? 'unknown'}`)
  }
  if (!header.document || !Array.isArray(header.document.layers) || !Array.isArray(header.assets)) {
    throw new Error('The project metadata is incomplete')
  }
  const width = validDimension(header.document.width)
  const height = validDimension(header.document.height)

  const assetBlobs: Blob[] = []
  let offset = 12 + headerLength
  for (const asset of header.assets) {
    const bytes = Math.round(finite(asset?.bytes, -1))
    if (bytes < 0 || offset + bytes > blob.size) throw new Error('A project bitmap is damaged')
    assetBlobs.push(blob.slice(offset, offset + bytes, asset?.mime || 'image/png'))
    offset += bytes
  }

  const layers: PhotoLayer[] = []
  for (const meta of header.document.layers) {
    const asset = assetBlobs[meta.asset]
    if (!asset) throw new Error('A layer bitmap is missing')
    const maskBlob = meta.maskAsset == null ? null : assetBlobs[meta.maskAsset]
    if (meta.maskAsset != null && !maskBlob) throw new Error('A layer mask bitmap is missing')
    layers.push({
      id: String(meta.id || `layer-${layers.length}`),
      name: String(meta.name || `Layer ${layers.length + 1}`),
      type: meta.type || 'pixel',
      visible: meta.visible !== false,
      locked: !!meta.locked,
      opacity: Math.min(1, Math.max(0, finite(meta.opacity, 1))),
      blendMode: meta.blendMode || 'normal',
      canvas: await pngCanvas(asset, width, height),
      style: meta.style ? JSON.parse(JSON.stringify(meta.style)) as LayerStyle : null,
      mask: maskBlob ? await pngCanvas(maskBlob, width, height) : null,
      maskEnabled: meta.maskEnabled !== false,
      clipping: !!meta.clipping,
      textData: meta.textData ? JSON.parse(JSON.stringify(meta.textData)) as TextLayerData : undefined,
      adjustment: meta.adjustment ? JSON.parse(JSON.stringify(meta.adjustment)) as AdjustmentLayerData : undefined,
      parentId: meta.parentId ?? null,
      opened: meta.opened !== false,
    })
  }
  if (layers.length === 0) throw new Error('The project has no layers')
  const groups = new Set(layers.filter((layer) => layer.type === 'group').map((layer) => layer.id))
  for (const layer of layers) {
    if (!layer.parentId || !groups.has(layer.parentId) || layer.parentId === layer.id) {
      layer.parentId = null
      continue
    }
    const seen = new Set<string>([layer.id])
    let parentId: string | null | undefined = layer.parentId
    while (parentId) {
      if (seen.has(parentId)) { layer.parentId = null; break }
      seen.add(parentId)
      parentId = layers.find((candidate) => candidate.id === parentId)?.parentId
    }
  }

  let selection: Selection | null = null
  if (header.document.selectionAsset !== null) {
    const selBlob = assetBlobs[header.document.selectionAsset]
    if (!selBlob) throw new Error('The selection mask is missing')
    selection = { mask: await pngCanvas(selBlob, width, height), path: null }
  }

  return {
    name: String(header.document.name || 'Untitled'),
    width,
    height,
    zoom: Math.min(32, Math.max(0.0078125, finite(header.document.zoom, 1))),
    panX: finite(header.document.panX, 0),
    panY: finite(header.document.panY, 0),
    activeLayerId: String(header.document.activeLayerId || layers[layers.length - 1].id),
    layers,
    selection,
    workPath: header.document.workPath ?? null,
    fg: header.editor?.fg || '#000000',
    bg: header.editor?.bg || '#ffffff',
    savedAt: finite(header.savedAt, Date.now()),
  }
}

/** Safe cross-browser project filename. */
export function projectFilename(name: string): string {
  const base = (name || 'Untitled').replace(/\.pclone$/i, '').replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').trim()
  return `${base || 'Untitled'}.pclone`
}
