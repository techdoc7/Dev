/* Selection engine — raster masks, flood fill, ants edge detection.
   All original code. */
import { Selection } from '../editor/types'

export function makeMask(w: number, h: number): HTMLCanvasElement {
  const c = document.createElement('canvas')
  c.width = Math.max(1, Math.round(w))
  c.height = Math.max(1, Math.round(h))
  c.getContext('2d', { willReadFrequently: true })
  return c
}

export function maskCtx(mask: HTMLCanvasElement): CanvasRenderingContext2D {
  const ctx = mask.getContext('2d', { willReadFrequently: true })
  if (!ctx) throw new Error('no 2d ctx')
  return ctx
}

export function selectFeather(filters: number): string | 'none' {
  return filters > 0 ? `blur(${filters}px)` : 'none'
}

/** Fill an axis-aligned rect (x0..x1, y0..y1) into the mask, feathered if set. */
export function fillRectMask(
  ctx: CanvasRenderingContext2D,
  x0: number, y0: number, x1: number, y1: number,
  feather: number,
): void {
  ctx.save()
  ctx.filter = feather > 0 ? `blur(${feather}px)` : 'none'
  ctx.fillStyle = '#ffffff'
  const rx = Math.min(x0, x1)
  const ry = Math.min(y0, y1)
  const rw = Math.abs(x1 - x0)
  const rh = Math.abs(y1 - y0)
  ctx.fillRect(rx, ry, rw, rh)
  ctx.restore()
}

export function fillEllipseMask(
  ctx: CanvasRenderingContext2D,
  x0: number, y0: number, x1: number, y1: number,
  feather: number,
): void {
  ctx.save()
  ctx.filter = feather > 0 ? `blur(${feather}px)` : 'none'
  ctx.fillStyle = '#ffffff'
  ctx.beginPath()
  ctx.ellipse(
    (x0 + x1) / 2,
    (y0 + y1) / 2,
    Math.abs(x1 - x0) / 2,
    Math.abs(y1 - y0) / 2,
    0, 0, Math.PI * 2,
  )
  ctx.fill()
  ctx.restore()
}

/** Fill an arbitrary Path2D polygon-ish region onto the mask. */
export function fillPathMask(
  ctx: CanvasRenderingContext2D,
  path: Path2D,
  w: number,
  h: number,
  feather: number,
): void {
  ctx.save()
  ctx.filter = feather > 0 ? `blur(${feather}px)` : 'none'
  ctx.fillStyle = '#ffffff'
  ctx.fill(path)
  ctx.restore()
}

export function cloneMask(src: HTMLCanvasElement): HTMLCanvasElement {
  const out = makeMask(src.width, src.height)
  maskCtx(out).drawImage(src, 0, 0)
  return out
}

export function cloneSelection(sel: Selection | null): Selection | null {
  if (!sel) return null
  return {
    mask: cloneMask(sel.mask),
    path: sel.path ? new Path2D(sel.path) : null,
  }
}

/* set ops: out = max(a,b) */
export function combineMask(base: HTMLCanvasElement, other: HTMLCanvasElement): HTMLCanvasElement {
  const out = cloneMask(base)
  const ctx = maskCtx(out)
  ctx.save()
  ctx.globalCompositeOperation = 'lighten'
  ctx.drawImage(other, 0, 0)
  ctx.restore()
  return out
}

/* out = base minus other */
export function subtractMask(base: HTMLCanvasElement, other: HTMLCanvasElement): HTMLCanvasElement {
  const out = cloneMask(base)
  const ctx = maskCtx(out)
  ctx.save()
  ctx.globalCompositeOperation = 'destination-out'
  ctx.drawImage(other, 0, 0)
  ctx.restore()
  return out
}

/** invert alpha: out = 1 - a */
export function invertMask(mask: HTMLCanvasElement): HTMLCanvasElement {
  const w = mask.width
  const h = mask.height
  const out = makeMask(w, h)
  const ctx = maskCtx(out)
  ctx.fillStyle = '#ffffff'
  ctx.fillRect(0, 0, w, h)
  ctx.globalCompositeOperation = 'destination-out'
  ctx.drawImage(mask, 0, 0)
  return out
}

/** Blur with optional alpha threshold — approximates grow/contract. */
function blurMask(mask: HTMLCanvasElement, radius: number): HTMLCanvasElement {
  const out = makeMask(mask.width, mask.height)
  const ctx = maskCtx(out)
  ctx.filter = radius > 0 ? `blur(${Math.max(0.5, radius)}px)` : 'none'
  ctx.drawImage(mask, 0, 0)
  ctx.filter = 'none'
  return out
}

function thresholdMask(mask: HTMLCanvasElement, cut: number): HTMLCanvasElement {
  const out = cloneMask(mask)
  const ctx = maskCtx(out)
  const img = ctx.getImageData(0, 0, out.width, out.height)
  const px = img.data
  for (let i = 3; i < px.length; i += 4) {
    px[i] = px[i] >= cut ? 255 : 0
  }
  ctx.putImageData(img, 0, 0)
  return out
}

/** dilate by r (approx via blur + low threshold) */
export function growMask(mask: HTMLCanvasElement, r: number): HTMLCanvasElement {
  if (r <= 0) return cloneMask(mask)
  return thresholdMask(blurMask(mask, r), 16)
}

/** erode by r = invert(grow(invert)) */
export function contractMask(mask: HTMLCanvasElement, r: number): HTMLCanvasElement {
  if (r <= 0) return cloneMask(mask)
  return invertMask(growMask(invertMask(mask), r))
}

/** soft feather: blur alphas, no threshold */
export function featherMask(mask: HTMLCanvasElement, r: number): HTMLCanvasElement {
  return blurMask(mask, r)
}

/* ---------------- magic wand: tolerance flood fill ---------------- */

export function floodMask(
  src: HTMLCanvasElement,
  sx: number,
  sy: number,
  tolerance: number,
): HTMLCanvasElement {
  const w = src.width
  const h = src.height
  sx = Math.max(0, Math.min(w - 1, Math.floor(sx)))
  sy = Math.max(0, Math.min(h - 1, Math.floor(sy)))
  const ctx = src.getContext('2d', { willReadFrequently: true })
  if (!ctx) throw new Error('no ctx')
  const img = ctx.getImageData(0, 0, w, h)
  const px = img.data

  const i0 = (sy * w + sx) * 4
  const r0 = px[i0]
  const g0 = px[i0 + 1]
  const b0 = px[i0 + 2]
  const a0 = px[i0 + 3]

  const out = new ImageData(w, h)
  const od = out.data
  const visited = new Uint8Array(w * h)
  const stack: number[] = [sy * w + sx]

  const match = (idx: number): boolean => {
    const i4 = idx * 4
    if (a0 < 8) return px[i4 + 3] < 8
    return (
      Math.abs(px[i4] - r0) <= tolerance &&
      Math.abs(px[i4 + 1] - g0) <= tolerance &&
      Math.abs(px[i4 + 2] - b0) <= tolerance &&
      Math.abs(px[i4 + 3] - a0) <= tolerance
    )
  }

  while (stack.length > 0) {
    const idx = stack.pop()!
    if (visited[idx]) continue
    visited[idx] = 1
    if (!match(idx)) continue
    const i4 = idx * 4
    od[i4] = 255
    od[i4 + 1] = 255
    od[i4 + 2] = 255
    od[i4 + 3] = 255
    const x = idx % w
    if (x > 0) stack.push(idx - 1)
    if (x < w - 1) stack.push(idx + 1)
    if (idx >= w) stack.push(idx - w)
    if (idx < w * h - w) stack.push(idx + w)
  }

  const mask = makeMask(w, h)
  maskCtx(mask).putImageData(out, 0, 0)
  return mask
}

/* ---------------- marching ants helpers ---------------- */

export interface MaskEdges {
  points: Int32Array
  count: number
}

const edgeCache = new WeakMap<HTMLCanvasElement, MaskEdges>()

/** Opaque boundary pixels of the mask (any non-zero alpha next to empty). */
export function maskEdges(mask: HTMLCanvasElement): MaskEdges {
  const cached = edgeCache.get(mask)
  if (cached) return cached
  const w = mask.width
  const h = mask.height
  const ctx = maskCtx(mask)
  const img = ctx.getImageData(0, 0, w, h)
  const px = img.data
  const pairs: number[] = []
  const at = (x: number, y: number): number => (y < 0 || x < 0 || x >= w || y >= h ? 0 : px[(y * w + x) * 4 + 3])
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const a = at(x, y)
      if (a === 0) continue
      const below = a > 0 ? 1 : 0
      if (
        at(x - 1, y) === 0 || at(x + 1, y) === 0 ||
        at(x, y - 1) === 0 || at(x, y + 1) === 0
      ) {
        pairs.push(x, y)
      }
      void below
    }
  }
  const res: MaskEdges = { points: new Int32Array(pairs), count: pairs.length / 2 }
  edgeCache.set(mask, res)
  return res
}

/** Bounding box of non-transparent pixels (2px sample step for speed). */
export function contentBounds(src: HTMLCanvasElement): { x0: number; y0: number; x1: number; y1: number } {
  const w = src.width
  const h = src.height
  const ctx = src.getContext('2d', { willReadFrequently: true })!
  const px = ctx.getImageData(0, 0, w, h).data
  let x0 = w, y0 = h, x1 = -1, y1 = -1
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (px[(y * w + x) * 4 + 3] > 0) {
        if (x < x0) x0 = x
        if (x > x1) x1 = x
        if (y < y0) y0 = y
        if (y > y1) y1 = y
      }
    }
  }
  if (x1 < 0) return { x0: 0, y0: 0, x1: w, y1: h }
  return { x0, y0, x1: x1 + 1, y1: y1 + 1 }
}
