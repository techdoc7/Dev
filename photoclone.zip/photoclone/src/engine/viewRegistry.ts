/** Lets menu commands target the canvas viewport without prop plumbing. */
let viewport: HTMLElement | null = null

export function setViewport(el: HTMLElement | null): void {
  viewport = el
}

export function getViewportSize(): { w: number; h: number } | null {
  if (!viewport) return null
  return { w: viewport.clientWidth, h: viewport.clientHeight }
}

export function getViewportCenter(): { x: number; y: number } | null {
  const s = getViewportSize()
  return s ? { x: s.w / 2, y: s.h / 2 } : null
}
