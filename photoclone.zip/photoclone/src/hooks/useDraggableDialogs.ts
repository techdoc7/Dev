import { useEffect } from 'react'

interface DialogDrag {
  modal: HTMLElement
  pointerId: number
  dx: number
  dy: number
  width: number
  height: number
}

const EDGE_GAP = 6

function clampPosition(left: number, top: number, width: number, height: number) {
  const maxLeft = Math.max(EDGE_GAP, window.innerWidth - width - EDGE_GAP)
  const maxTop = Math.max(EDGE_GAP, window.innerHeight - height - EDGE_GAP)
  return {
    left: Math.min(maxLeft, Math.max(EDGE_GAP, left)),
    top: Math.min(maxTop, Math.max(EDGE_GAP, top)),
  }
}

/**
 * Makes every `.modal` window movable from its `.modal-title` bar.
 * Delegated pointer handling means dialogs mounted later are included
 * automatically (New Document, adjustments, filters, and Layer Style).
 */
export function useDraggableDialogs(): void {
  useEffect(() => {
    let drag: DialogDrag | null = null

    const onPointerDown = (e: PointerEvent) => {
      if (e.button !== 0) return
      const target = e.target as HTMLElement | null
      const title = target?.closest<HTMLElement>('.modal-title')
      const modal = title?.closest<HTMLElement>('.modal')
      if (!title || !modal) return

      const rect = modal.getBoundingClientRect()
      /* Freeze the initially centered grid item into viewport coordinates. */
      modal.style.position = 'fixed'
      modal.style.left = `${rect.left}px`
      modal.style.top = `${rect.top}px`
      modal.style.margin = '0'
      modal.style.transform = 'none'
      modal.dataset.dragged = 'true'
      modal.classList.add('modal-dragging')

      drag = {
        modal,
        pointerId: e.pointerId,
        dx: e.clientX - rect.left,
        dy: e.clientY - rect.top,
        width: rect.width,
        height: rect.height,
      }
      title.setPointerCapture?.(e.pointerId)
      e.preventDefault()
    }

    const onPointerMove = (e: PointerEvent) => {
      if (!drag || e.pointerId !== drag.pointerId) return
      const p = clampPosition(e.clientX - drag.dx, e.clientY - drag.dy, drag.width, drag.height)
      drag.modal.style.left = `${p.left}px`
      drag.modal.style.top = `${p.top}px`
      e.preventDefault()
    }

    const finish = (e: PointerEvent) => {
      if (!drag || e.pointerId !== drag.pointerId) return
      drag.modal.classList.remove('modal-dragging')
      drag = null
    }

    const onResize = () => {
      document.querySelectorAll<HTMLElement>('.modal[data-dragged="true"]').forEach((modal) => {
        const r = modal.getBoundingClientRect()
        const p = clampPosition(r.left, r.top, r.width, r.height)
        modal.style.left = `${p.left}px`
        modal.style.top = `${p.top}px`
      })
    }

    document.addEventListener('pointerdown', onPointerDown)
    document.addEventListener('pointermove', onPointerMove, { passive: false })
    document.addEventListener('pointerup', finish)
    document.addEventListener('pointercancel', finish)
    window.addEventListener('resize', onResize)
    return () => {
      document.removeEventListener('pointerdown', onPointerDown)
      document.removeEventListener('pointermove', onPointerMove)
      document.removeEventListener('pointerup', finish)
      document.removeEventListener('pointercancel', finish)
      window.removeEventListener('resize', onResize)
    }
  }, [])
}
