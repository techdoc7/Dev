/** Photoshop-compatible keyboard shortcuts. */
export function useHotkeys() {
  const handled = (e: KeyboardEvent) => {
    const st = (globalThis as any).__photocloneStore as
      | undefined
      | typeof import('../editor/store').useEditor
    if (!st) return
    const s = st.getState()
    const tag = (e.target as HTMLElement)?.tagName
    const editable = tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || (e.target as HTMLElement)?.isContentEditable

    /* Text and numeric fields own their editing shortcuts (especially Ctrl+Z). */
    if (editable) return false

    if (e.ctrlKey || e.metaKey) {
      const k = e.key.toLowerCase()
      if (k === 'tab') {
        e.preventDefault()
        if (!s.docs.length) return true
        const index = s.docs.findIndex((d: any) => d.id === s.activeDocId)
        const delta = e.shiftKey ? -1 : 1
        const next = (index + delta + s.docs.length) % s.docs.length
        s.setActiveDoc(s.docs[next].id)
        return true
      }
      if (k === 'z' && !e.shiftKey) { e.preventDefault(); s.undo(); return true }
      if ((k === 'z' && e.shiftKey) || k === 'y') { e.preventDefault(); s.redo(); return true }
      if (k === 'n' && e.shiftKey) { e.preventDefault(); if (s.activeDocId) s.addLayer(); else (window as any).__photocloneOpenNew?.(); return true }
      if (k === 'n') { e.preventDefault(); (window as any).__photocloneOpenNew?.(); return true }
      if (k === 'o') { e.preventDefault(); (window as any).__photocloneOpenFile?.(); return true }
      if (k === 's' && e.shiftKey) { e.preventDefault(); void s.saveActiveProject(true); return true }
      if (k === 's') { e.preventDefault(); void s.saveActiveProject(false); return true }
      if (k === 'w') { e.preventDefault(); s.closeActiveDoc(); return true }
      if (k === 'x') { e.preventDefault(); void s.cutPixels(); return true }
      if (k === 'c') { e.preventDefault(); void s.copyPixels(); return true }
      if (k === 'v') { e.preventDefault(); void s.pastePixels(); return true }
      if (k === 'j') { e.preventDefault(); const d = s.docs.find((x: any) => x.id === s.activeDocId); if (d) s.duplicateLayer(d.activeLayerId); return true }
      if (k === 'g' && e.altKey) { e.preventDefault(); const d = s.docs.find((x: any) => x.id === s.activeDocId); const layer = d?.layers.find((x: any) => x.id === d.activeLayerId); if (layer) s.setLayerClipping(layer.id, !layer.clipping); return true }
      if (k === 'e' && e.shiftKey) { e.preventDefault(); s.exportActiveDoc(); return true }
      if (k === 'e') { e.preventDefault(); const d = s.docs.find((x: any) => x.id === s.activeDocId); if (d) s.mergeDown(d.activeLayerId); return true }
      if (k === 'a') { e.preventDefault(); s.selectAll(); return true }
      if (k === 'd' && !e.shiftKey) { e.preventDefault(); s.deselect(); return true }
      if (k === 'i' && e.shiftKey) { e.preventDefault(); s.invertSelection(); return true }
      if (k === 'i') {
        e.preventDefault()
        window.dispatchEvent(new CustomEvent('pc:pixmap', { detail: 'invert' }))
        return true
      }
      if (k === 't') { e.preventDefault(); window.dispatchEvent(new Event('pc:transformFree')); return true }
      if (k === '=' || k === '+') { e.preventDefault(); window.dispatchEvent(new CustomEvent('pc:zoomIn')); return true }
      if (k === '-') { e.preventDefault(); window.dispatchEvent(new CustomEvent('pc:zoomOut')); return true }
      if (k === '0') { e.preventDefault(); window.dispatchEvent(new CustomEvent('pc:zoomFit')); return true }
      if (k === '1') { e.preventDefault(); window.dispatchEvent(new CustomEvent('pc:zoomActual')); return true }
      return true
    }

    if (e.key === 'Delete' || e.key === 'Backspace') {
      e.preventDefault()
      if (e.shiftKey) s.fillPixels()
      else s.clearPixels()
      return true
    }

    switch (e.key.toLowerCase()) {
      case 'v': s.setTool('move'); return true
      case 'm': s.setTool(e.shiftKey ? 'marquee-ellipse' : 'marquee-rect'); return true
      case 'l': s.setTool(e.shiftKey ? 'lasso-poly' : 'lasso'); return true
      case 'w': s.setTool('wand'); return true
      case 'c': s.setTool('crop'); return true
      case 'i': s.setTool('eyedropper'); return true
      case 'j': s.setTool('heal'); return true
      case 'b': s.setTool(e.shiftKey ? 'pencil' : 'brush'); return true
      case 's': s.setTool('stamp'); return true
      case 'e': s.setTool('eraser'); return true
      case 'g': s.setTool(e.shiftKey ? 'bucket' : 'gradient'); return true
      case 'r': s.setTool('blur'); return true
      case 'o': s.setTool('dodge'); return true
      case 'p': s.setTool('pen'); return true
      case 't': s.setTool('type'); return true
      case 'u': s.setTool('shape'); return true
      case 'a': s.setTool('path-select'); return true
      case 'h': s.setTool('hand'); return true
      case 'z': s.setTool('zoom'); return true
      case 'x': s.swapColors(); return true
      case 'd': s.resetColors(); return true
      default:
        return false
    }
  }

  const onKeyDown = (e: KeyboardEvent) => {
    if (handled(e)) e.preventDefault()
  }
  window.addEventListener('keydown', onKeyDown)
  return () => window.removeEventListener('keydown', onKeyDown)
}
