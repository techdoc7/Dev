import { useCallback, useEffect, useMemo, useState } from 'react'
import ToolPalette from './ToolPalette'
import OptionsBar from './OptionsBar'
import DocumentView from './DocumentView'
import ContextMenu from './ContextMenu'
import StyleDialogHost from './StyleDialogHost'
import AutosaveHost from './AutosaveHost'
import MenuBar from './MenuBar'
import StatusBar from './StatusBar'
import Toast from './Toast'
import NewDocumentDialog from './dialogs/NewDocumentDialog'
import DocumentSizeDialog, { DocumentSizeDialogKind } from './dialogs/DocumentSizeDialogs'
import BatchExportDialog from './dialogs/BatchExportDialog'
import PixmapDialogHost, { applyPixmapImmediate, usePixmapDialog } from './dialogs/PixmapDialogs'

const IMMEDIATE_IDS = new Set(['invert', 'desaturate', 'black-white', 'auto-tone', 'sharpen', 'emboss', 'find-edges'])
import LayersPanel from './panels/LayersPanel'
import HistoryPanel from './panels/HistoryPanel'
import ColorPanel from './panels/ColorPanel'
import { useEditor } from '../editor/store'
import { useToolSettings } from '../editor/toolSettings'
import { useHotkeys } from '../hooks/useHotkeys'
import { useDraggableDialogs } from '../hooks/useDraggableDialogs'
import { buildMenus, Commands } from './menus'
import { getViewportCenter, getViewportSize } from '../engine/viewRegistry'

function PanelsColumn() {
  return (
    <div className="panels-col">
      <ColorPanel />
      <HistoryPanel />
      <LayersPanel />
    </div>
  )
}

function activeDoc() {
  const st = useEditor.getState()
  return st.docs.find((d) => d.id === st.activeDocId) ?? null
}

export default function App() {
  const [showNewDialog, setShowNewDialog] = useState(false)
  const [sizeDialog, setSizeDialog] = useState<DocumentSizeDialogKind | null>(null)
  const [showBatchExport, setShowBatchExport] = useState(false)
  const [fileEl, setFileEl] = useState<HTMLInputElement | null>(null)
  /* menus must rebuild when a document opens/closes — their disabled flags are
     computed at build time, and `commands` alone never changes identity */
  const docOpen = useEditor((s) => !!s.activeDocId)
  const toast = useCallback((msg: string) => useEditor.getState().showToast(msg), [])
  const noDoc = useCallback(() => !useEditor.getState().activeDocId, [])

  /* Photoshop-style movable adjustment/filter/new/style dialogs. */
  useDraggableDialogs()

  /* keyboard shortcuts */
  useEffect(useHotkeys(), [])

  /* store ref for hotkeys */
  useEffect(() => {
    ;(globalThis as any).__photocloneStore = useEditor
  }, [])

  /* Native browser warning only when explicit project saves are outstanding. */
  useEffect(() => {
    const beforeUnload = (e: BeforeUnloadEvent) => {
      if (!useEditor.getState().docs.some((d) => d.dirty)) return
      e.preventDefault()
      e.returnValue = ''
    }
    window.addEventListener('beforeunload', beforeUnload)
    return () => window.removeEventListener('beforeunload', beforeUnload)
  }, [])

  /* command plumbing used by menus + hotkeys */
  useEffect(() => {
    ;(globalThis as any).__photocloneOpenNew = () => setShowNewDialog(true)
    ;(globalThis as any).__photocloneOpenFile = () => fileEl?.click()
    const zoomIn = () => {
      const d = activeDoc()
      if (d) useEditor.getState().setZoom(d.id, d.zoom * Math.pow(2, 0.35), getViewportCenter() ?? undefined)
    }
    const zoomOut = () => {
      const d = activeDoc()
      if (d) useEditor.getState().setZoom(d.id, d.zoom * Math.pow(2, -0.35), getViewportCenter() ?? undefined)
    }
    const zoomActual = () => {
      const d = activeDoc()
      const vp = getViewportSize()
      if (d) {
        useEditor.getState().setZoom(d.id, 1)
        if (vp) useEditor.getState().panBy(d.id, (vp.w - d.width) / 2 - d.panX, (vp.h - d.height) / 2 - d.panY)
      }
    }
    const zoomFit = () => {
      const d = activeDoc()
      const vp = getViewportSize()
      if (!d || !vp) return
      const fit = Math.min((vp.w - 48) / d.width, (vp.h - 48) / d.height)
      const zz = Math.min(1, Math.max(0.0078125, fit))
      const st = useEditor.getState()
      st.setZoom(d.id, zz)
      st.panBy(d.id, (vp.w - d.width * zz) / 2 - d.panX, (vp.h - d.height * zz) / 2 - d.panY)
    }
    const on = (name: string, fn: (e: Event) => void) => window.addEventListener(name, fn)
    on('pc:zoomIn', zoomIn)
    on('pc:zoomOut', zoomOut)
    on('pc:zoomActual', zoomActual)
    on('pc:zoomFit', zoomFit)
    const onPixmap = (e: Event) => {
      const id = (e as CustomEvent).detail as string
      if (IMMEDIATE_IDS.has(id)) applyPixmapImmediate(id as any)
      else usePixmapDialog.getState().openDialog(id as any)
    }
    on('pc:pixmap', onPixmap)
    return () => {
      window.removeEventListener('pc:zoomIn', zoomIn)
      window.removeEventListener('pc:zoomOut', zoomOut)
      window.removeEventListener('pc:zoomActual', zoomActual)
      window.removeEventListener('pc:zoomFit', zoomFit)
      window.removeEventListener('pc:pixmap', onPixmap)
    }
  }, [fileEl])

  const commands: Commands = useMemo(
    () => ({
      noDoc,
      toast,
      newDialog: () => setShowNewDialog(true),
      openFile: () => fileEl?.click(),
      exportPng: () => useEditor.getState().exportActiveDoc(),
      exportJpeg: () => useEditor.getState().exportActiveDoc('jpeg'),
      exportWebp: () => useEditor.getState().exportActiveDoc('webp'),
      batchExport: () => setShowBatchExport(true),
      saveProject: () => { void useEditor.getState().saveActiveProject(false) },
      saveProjectAs: () => { void useEditor.getState().saveActiveProject(true) },
      close: () => useEditor.getState().closeActiveDoc(),
      undo: () => useEditor.getState().undo(),
      redo: () => useEditor.getState().redo(),
      cut: () => { void useEditor.getState().cutPixels() },
      copy: () => { void useEditor.getState().copyPixels() },
      paste: () => { void useEditor.getState().pastePixels() },
      clear: () => useEditor.getState().clearPixels(),
      fill: () => useEditor.getState().fillPixels(),
      strokeSelection: () => useEditor.getState().strokeSelection(),
      flatten: () => {
        void useEditor.getState().flattenImage()
      },
      mergeDown: () => {
        const st = useEditor.getState()
        const d = activeDoc()
        if (d) st.mergeDown(d.activeLayerId)
      },
      selectAll: () => useEditor.getState().selectAll(),
      deselect: () => useEditor.getState().deselect(),
      invertSelection: () => useEditor.getState().invertSelection(),
      feather: () => useEditor.getState().featherSelection(useToolSettings.getState().feather || 8),
      expand: () => useEditor.getState().growSelection(5),
      contract: () => useEditor.getState().contractSelection(5),
      freeTransform: () => window.dispatchEvent(new Event('pc:transformFree')),
      rotate90: () => useEditor.getState().rotateCanvas(90),
      rotate270: () => useEditor.getState().rotateCanvas(270),
      rotate180: () => useEditor.getState().rotateCanvas(180),
      flipH: () => useEditor.getState().flipCanvas('h'),
      flipV: () => useEditor.getState().flipCanvas('v'),
      pixmap: (id) => {
        const IMMEDIATE = new Set(['invert', 'desaturate', 'black-white', 'auto-tone', 'sharpen', 'emboss', 'find-edges'])
        if (IMMEDIATE.has(id)) applyPixmapImmediate(id as any)
        else usePixmapDialog.getState().openDialog(id as any)
      },
      zoomIn: () => window.dispatchEvent(new Event('pc:zoomIn')),
      zoomOut: () => window.dispatchEvent(new Event('pc:zoomOut')),
      zoomActual: () => window.dispatchEvent(new Event('pc:zoomActual')),
      zoomFit: () => window.dispatchEvent(new Event('pc:zoomFit')),
      addLayer: () => useEditor.getState().addLayer(),
      duplicateLayer: () => {
        const d = activeDoc()
        if (d) useEditor.getState().duplicateLayer(d.activeLayerId)
      },
      deleteLayer: () => {
        const d = activeDoc()
        if (d) useEditor.getState().removeLayer(d.activeLayerId)
      },
      styleDialog: (tab) => window.dispatchEvent(new CustomEvent('pc:openStyle', { detail: { tab } })),
      styleClear: () => {
        const d = activeDoc()
        if (d) {
          const st = useEditor.getState()
          st.setLayerStyle(d.activeLayerId, null)
          st.pushHistory('Clear Layer Style')
        }
      },
      toggleClipping: () => {
        const st = useEditor.getState()
        const d = activeDoc()
        const layer = d?.layers.find((l) => l.id === d.activeLayerId)
        if (layer) st.setLayerClipping(layer.id, !layer.clipping)
      },
      pathMakeSelection: () => useEditor.getState().pathMakeSelection(useToolSettings.getState().feather),
      pathStroke: () => {
        const st = useEditor.getState()
        const ts = useToolSettings.getState()
        st.pathStroke({ color: st.fg, size: ts.brushSize, hardness: ts.brushHardness, opacity: ts.brushOpacity })
      },
      cropTool: () => useEditor.getState().setTool('crop'),
      nextTab: () => {
        const st = useEditor.getState()
        if (!st.docs.length) return
        const index = st.docs.findIndex((d) => d.id === st.activeDocId)
        st.setActiveDoc(st.docs[(index + 1) % st.docs.length].id)
      },
      imageSize: () => setSizeDialog('image'),
      canvasSize: () => setSizeDialog('canvas'),
    }),
    [noDoc, toast, fileEl],
  )

  const menus = useMemo(() => buildMenus(commands), [commands, docOpen])

  return (
    <div className="app">
      <MenuBar menus={menus} />
      <OptionsBar />
      <div className="app-body">
        <ToolPalette />
        <div className="app-canvas">
          <DocumentView />
        </div>
        <PanelsColumn />
      </div>
      <StatusBar />
      <Toast />
      <ContextMenu />
      <StyleDialogHost />
      <AutosaveHost />
      {showNewDialog && <NewDocumentDialog onClose={() => setShowNewDialog(false)} />}
      {sizeDialog && <DocumentSizeDialog kind={sizeDialog} onClose={() => setSizeDialog(null)} />}
      {showBatchExport && <BatchExportDialog onClose={() => setShowBatchExport(false)} />}
      <PixmapDialogHost />
      <input
        ref={setFileEl}
        type="file"
        accept=".pclone,application/x-photoclone,image/png,image/jpeg,image/webp,image/bmp,image/svg+xml,image/gif"
        hidden
        onChange={async (e) => {
          const files = e.target.files
          if (files?.length) {
            for (const f of Array.from(files)) {
              if (f.name.toLowerCase().endsWith('.pclone') || f.type === 'application/x-photoclone') {
                await useEditor.getState().openProjectFile(f)
              } else {
                await useEditor.getState().openImageFile(f)
              }
            }
          }
          e.target.value = ''
        }}
        multiple
      />
    </div>
  )
}
