import { useEffect, useRef, useState } from 'react'
import { clearAutosave, readAutosave, writeAutosave, AutosaveRecord } from '../engine/autosave'
import { encodeProject } from '../engine/project'
import { useEditor } from '../editor/store'

const AUTOSAVE_DELAY = 2600

function idleTurn(): Promise<void> {
  return new Promise((resolve) => {
    const ric = (window as any).requestIdleCallback as undefined | ((cb: () => void, o: { timeout: number }) => number)
    if (ric) ric(resolve, { timeout: 1200 })
    else window.setTimeout(resolve, 40)
  })
}

/** IndexedDB autosave scheduler plus startup crash-recovery prompt. */
export default function AutosaveHost() {
  const [recovery, setRecovery] = useState<AutosaveRecord | null>(null)
  const [ready, setReady] = useState(false)
  const recovering = useRef(false)

  useEffect(() => {
    let live = true
    void readAutosave()
      .then((record) => {
        if (!live) return
        if (record?.projects.length) setRecovery(record)
        else setReady(true)
      })
      .catch(() => {
        if (live) setReady(true) /* private modes may disable IndexedDB */
      })
    return () => { live = false }
  }, [])

  useEffect(() => {
    if (!ready) return
    let timer: number | null = null
    let saving = false
    let rerun = false
    let disposed = false

    const schedule = () => {
      if (timer !== null) window.clearTimeout(timer)
      timer = window.setTimeout(() => { void save() }, AUTOSAVE_DELAY)
    }

    const save = async () => {
      timer = null
      if (saving) { rerun = true; return }
      saving = true
      const startedRevision = useEditor.getState().revision
      try {
        await idleTurn()
        if (disposed) return
        const st = useEditor.getState()
        if (st.docs.length === 0) {
          await clearAutosave()
          st.setPersistenceStatus('idle', null)
          return
        }
        st.setPersistenceStatus('saving')
        const projects: Blob[] = []
        /* Sequential projects/layers keep peak encoder memory predictable. */
        for (const doc of st.docs) projects.push(await encodeProject(doc, { fg: st.fg, bg: st.bg }))
        const savedAt = Date.now()
        await writeAutosave({
          savedAt,
          activeIndex: Math.max(0, st.docs.findIndex((d) => d.id === st.activeDocId)),
          projects,
        })
        useEditor.getState().setPersistenceStatus('saved', savedAt)
      } catch {
        useEditor.getState().setPersistenceStatus('error')
      } finally {
        saving = false
        if (rerun || useEditor.getState().revision !== startedRevision) {
          rerun = false
          schedule()
        }
      }
    }

    const unsubscribe = useEditor.subscribe((state, prev) => {
      if (state.revision !== prev.revision) schedule()
    })
    if (useEditor.getState().docs.length) schedule()
    return () => {
      disposed = true
      unsubscribe()
      if (timer !== null) window.clearTimeout(timer)
    }
  }, [ready])

  if (!recovery) return null

  const recover = async () => {
    if (recovering.current) return
    recovering.current = true
    const ids: string[] = []
    useEditor.getState().setPersistenceStatus('saving')
    for (const blob of recovery.projects) {
      const id = await useEditor.getState().openProjectFile(blob, true)
      if (id) {
        ids.push(id)
        useEditor.getState().setDocDirty(id, true)
      }
    }
    if (ids.length) {
      const active = ids[Math.min(ids.length - 1, Math.max(0, recovery.activeIndex))]
      useEditor.getState().setActiveDoc(active)
      useEditor.getState().showToast(`Recovered ${ids.length} autosaved project${ids.length === 1 ? '' : 's'}`)
      useEditor.getState().setPersistenceStatus('saved', recovery.savedAt)
    } else {
      useEditor.getState().setPersistenceStatus('error')
    }
    setRecovery(null)
    setReady(true)
  }

  const discard = async () => {
    try { await clearAutosave() } catch { /* storage unavailable: still continue */ }
    setRecovery(null)
    setReady(true)
  }

  return (
    <div className="modal-scrim">
      <div className="modal recovery-dialog" role="dialog" aria-modal="true" aria-label="Recover autosave">
        <div className="modal-title">Recover Autosaved Work</div>
        <div className="modal-body">
          <p>Photoclone found locally autosaved work from:</p>
          <p className="recovery-time">{new Date(recovery.savedAt).toLocaleString()}</p>
          <p>{recovery.projects.length} open project{recovery.projects.length === 1 ? '' : 's'} can be restored. The data never left this browser.</p>
        </div>
        <div className="modal-foot">
          <button className="btn" onClick={() => void discard()}>Discard</button>
          <span className="foot-flex" />
          <button className="btn primary" onClick={() => void recover()}>Recover</button>
        </div>
      </div>
    </div>
  )
}
