/* Photoshop-style right-click menu — original code.
   Replaces the browser context menu app-wide:
   · over the canvas it is tool-aware (brush → size/hardness, marquee/wand →
     selection ops, crop → apply/cancel)
   · elsewhere it offers common File/Edit/View actions */

import { useEffect } from 'react'
import React, { useRef, useState } from 'react'
import { useEditor } from '../editor/store'
import { useToolSettings } from '../editor/toolSettings'

interface CtxItem {
  sep?: boolean
  label?: string
  accel?: string
  disabled?: boolean
  onSelect?: () => void
  slider?: 'size' | 'hardness' | 'opacity' | 'flow' | 'spacing' | 'feather' | 'tolerance'
  select?: 'gradientType'
  hint?: string
}

interface CtxMenuState {
  x: number
  y: number
  items: CtxItem[]
  title: string
  key: number
}

let openCounter = 0

function buildCanvasItems(tool: string, hasDoc: boolean): { items: CtxItem[]; title: string } {
  const st = useEditor.getState()
  const doc = st.docs.find((d) => d.id === st.activeDocId)
  const sel = !!doc?.selection

  if (!doc || !hasDoc) {
    return {
      title: 'Canvas',
      items: [
        { label: 'New…', onSelect: () => (globalThis as any).__photocloneOpenNew?.() },
        { label: 'Open…', onSelect: () => (globalThis as any).__photocloneOpenFile?.() },
        { sep: true },
        { label: 'About Photoclone', onSelect: () => st.showToast('Photoclone v1.0.0 — original, offline, MIT') },
      ],
    }
  }

  const selectionItems: CtxItem[] = [
    { label: 'Select All', accel: 'Ctrl+A', onSelect: () => st.selectAll() },
    { label: 'Deselect', accel: 'Ctrl+D', disabled: !sel, onSelect: () => st.deselect() },
    { label: 'Select Inverse', accel: 'Ctrl+Shift+I', disabled: !sel, onSelect: () => st.invertSelection() },
  ]
  const editItems: CtxItem[] = [
    { label: 'Cut', accel: 'Ctrl+X', onSelect: () => { void st.cutPixels() } },
    { label: 'Copy', accel: 'Ctrl+C', onSelect: () => { void st.copyPixels() } },
    { label: 'Paste', accel: 'Ctrl+V', onSelect: () => { void st.pastePixels() } },
    { label: 'Clear', accel: 'Delete', onSelect: () => st.clearPixels() },
  ]
  const featherItems: CtxItem[] = [
    { sep: true },
    { slider: 'feather', disabled: !sel },
    { label: 'Feather Selection', disabled: !sel, onSelect: () => st.featherSelection(useToolSettings.getState().feather || 8) },
    { label: 'Expand 5 px', disabled: !sel, onSelect: () => st.growSelection(5) },
    { label: 'Contract 5 px', disabled: !sel, onSelect: () => st.contractSelection(5) },
  ]

  switch (tool) {
    case 'brush':
    case 'pencil':
    case 'eraser':
      return {
        title: tool === 'brush' ? 'Brush' : tool === 'pencil' ? 'Pencil' : 'Eraser',
        items: [
          { slider: 'size' },
          { slider: 'hardness' },
          { sep: true },
          { slider: 'opacity' },
          { slider: 'flow' },
          { slider: 'spacing' },
          { sep: true },
          { hint: 'Alt+click samples a color' },
        ],
      }
    case 'gradient':
      return {
        title: 'Gradient',
        items: [
          { select: 'gradientType' },
          { sep: true },
          { hint: 'Drag on the canvas to draw the gradient' },
        ],
      }
    case 'bucket':
      return {
        title: 'Paint Bucket',
        items: [
          { slider: 'tolerance' },
          { sep: true },
          { hint: 'Click to fill a contiguous region with the foreground color' },
        ],
      }
    case 'wand':
      return {
        title: 'Magic Wand',
        items: [
          { slider: 'tolerance' },
          { sep: true },
          ...selectionItems,
          ...featherItems,
        ],
      }
    case 'marquee-rect':
    case 'marquee-ellipse':
      return { title: 'Marquee', items: [...selectionItems, ...featherItems] }
    case 'lasso':
    case 'lasso-poly':
      return { title: tool === 'lasso' ? 'Lasso' : 'Polygonal Lasso', items: [...selectionItems] }
    case 'move':
      return {
        title: 'Move',
        items: [
          { label: 'Free Transform', accel: 'Ctrl+T', onSelect: () => window.dispatchEvent(new Event('pc:transformFree')) },
          { sep: true },
          ...editItems,
          { sep: true },
          ...selectionItems,
        ],
      }
    case 'crop':
      return {
        title: 'Crop',
        items: [
          { label: 'Apply Crop', accel: 'Enter', onSelect: () => window.dispatchEvent(new Event('pc:cropApply')) },
          { label: 'Cancel Crop', accel: 'Esc', onSelect: () => window.dispatchEvent(new Event('pc:cropCancel')) },
        ],
      }
    case 'pen':
    case 'path-select':
      return {
        title: tool === 'pen' ? 'Pen Path' : 'Path Selection',
        items: [
          {
            label: 'Make Selection…',
            disabled: !doc.workPath,
            onSelect: () => st.pathMakeSelection(useToolSettings.getState().feather),
          },
          {
            label: 'Stroke Path',
            disabled: !doc.workPath,
            onSelect: () => {
              const ts = useToolSettings.getState()
              st.pathStroke({ color: st.fg, size: ts.brushSize, hardness: ts.brushHardness, opacity: ts.brushOpacity })
            },
          },
          { sep: true },
          {
            label: 'Delete Work Path',
            disabled: !doc.workPath,
            onSelect: () => st.setWorkPath(null, 'Delete Path'),
          },
          { hint: tool === 'pen' ? 'Click-drag creates Bézier handles' : 'Drag anchors and handles to reshape' },
        ],
      }
    default:
      return {
        title: 'Canvas',
        items: [
          { label: 'Undo', accel: 'Ctrl+Z', onSelect: () => st.undo() },
          { label: 'Redo', accel: 'Ctrl+Shift+Z', onSelect: () => st.redo() },
          { sep: true },
          { label: 'Free Transform', accel: 'Ctrl+T', onSelect: () => window.dispatchEvent(new Event('pc:transformFree')) },
          { sep: true },
          ...selectionItems,
          { sep: true },
          { label: 'Fit on Screen', accel: 'Ctrl+0', onSelect: () => window.dispatchEvent(new Event('pc:zoomFit')) },
          { label: '100 %', accel: 'Ctrl+1', onSelect: () => window.dispatchEvent(new Event('pc:zoomActual')) },
        ],
      }
  }
}

function buildGeneralItems(hasDoc: boolean): { items: CtxItem[]; title: string } {
  const st = useEditor.getState()
  const items: CtxItem[] = [
    { label: 'New…', accel: 'Ctrl+N', onSelect: () => (globalThis as any).__photocloneOpenNew?.() },
    { label: 'Open…', accel: 'Ctrl+O', onSelect: () => (globalThis as any).__photocloneOpenFile?.() },
    { sep: true },
    { label: 'Save .pclone', accel: 'Ctrl+S', disabled: !hasDoc, onSelect: () => { void st.saveActiveProject(false) } },
    { label: 'Export as PNG…', accel: 'Ctrl+Shift+E', disabled: !hasDoc, onSelect: () => st.exportActiveDoc() },
    { label: 'Undo', accel: 'Ctrl+Z', disabled: !hasDoc, onSelect: () => st.undo() },
    { label: 'Redo', accel: 'Ctrl+Shift+Z', disabled: !hasDoc, onSelect: () => st.redo() },
    { label: 'Cut', accel: 'Ctrl+X', disabled: !hasDoc, onSelect: () => { void st.cutPixels() } },
    { label: 'Copy', accel: 'Ctrl+C', disabled: !hasDoc, onSelect: () => { void st.copyPixels() } },
    { label: 'Paste', accel: 'Ctrl+V', disabled: !hasDoc, onSelect: () => { void st.pastePixels() } },
    { sep: true },
    { label: 'Fit on Screen', accel: 'Ctrl+0', disabled: !hasDoc, onSelect: () => window.dispatchEvent(new Event('pc:zoomFit')) },
  ]
  return { title: 'Photoclone', items }
}

type SliderKind = NonNullable<CtxItem['slider']>
type SettingKey = keyof Omit<import('../editor/toolSettings').ToolSettingsState, 'set'>

function CtxSlider({ kind }: { kind: SliderKind }): JSX.Element {
  const meta: Record<SliderKind, { label: string; key: SettingKey; min: number; max: number; step: number }> = {
    size: { label: 'Size (px)', key: 'brushSize', min: 1, max: 400, step: 1 },
    hardness: { label: 'Hardness %', key: 'brushHardness', min: 0, max: 100, step: 1 },
    opacity: { label: 'Opacity %', key: 'brushOpacity', min: 1, max: 100, step: 1 },
    flow: { label: 'Flow %', key: 'brushFlow', min: 1, max: 100, step: 1 },
    spacing: { label: 'Spacing %', key: 'brushSpacing', min: 1, max: 100, step: 1 },
    feather: { label: 'Feather (px)', key: 'feather', min: 0, max: 250, step: 1 },
    tolerance: { label: 'Tolerance', key: 'tolerance', min: 0, max: 255, step: 1 },
  }
  const m = meta[kind]
  const value = useToolSettings((s) => s[m.key])
  const set = useToolSettings((s) => s.set)
  return (
    <div className="dlg-row ctx-slider">
      <label className="dlg-label">{m.label}</label>
      <input
        className="dlg-range"
        type="range"
        min={m.min}
        max={m.max}
        step={m.step}
        value={Number(value)}
        onChange={(e) => set(m.key, Number(e.target.value))}
      />
      <span className="ctx-value">{String(value)}</span>
    </div>
  )
}

function CtxGradientSelect(): JSX.Element {
  const value = useToolSettings((s) => s.gradientPreset)
  const set = useToolSettings((s) => s.set)
  return (
    <div className="dlg-row ctx-slider">
      <label className="dlg-label">Preset</label>
      <select
        className="opt-select"
        value={value}
        onChange={(e) => set('gradientPreset', e.target.value as any)}
      >
        <option value="fg-bg">Foreground → Background</option>
        <option value="fg-transparent">Foreground → Transparent</option>
        <option value="black-white">Black → White</option>
      </select>
    </div>
  )
}

export default function ContextMenu(): JSX.Element {
  const [menu, setMenu] = useState<CtxMenuState | null>(null)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const onCtx = (e: MouseEvent) => {
      e.preventDefault()
      if (menu) { setMenu(null); return }
      const st = useEditor.getState()
      const target = e.target as HTMLElement
      const inViewport = !!target.closest('.doc-viewport')
      const hasDoc = !!st.activeDocId
      openCounter++
      const built = inViewport
        ? buildCanvasItems(st.tool, hasDoc)
        : buildGeneralItems(hasDoc)
      setMenu({ x: e.clientX, y: e.clientY, items: built.items, title: built.title, key: openCounter })
    }
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setMenu(null) }
    window.addEventListener('contextmenu', onCtx)
    window.addEventListener('keydown', onKey)
    return () => {
      window.removeEventListener('contextmenu', onCtx)
      window.removeEventListener('keydown', onKey)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [menu])

  /* clamp the panel inside the window after mount */
  React.useEffect(() => {
    const el = ref.current
    if (!el || !menu) return
    const r = el.getBoundingClientRect()
    if (r.right > window.innerWidth - 8 || r.bottom > window.innerHeight - 8) {
      setMenu({
        ...menu,
        x: Math.max(8, Math.min(menu.x, window.innerWidth - r.width - 8)),
        y: Math.max(8, Math.min(menu.y, window.innerHeight - r.height - 8)),
      })
    }
  }, [menu?.key])

  if (!menu) return <></>

  const close = () => setMenu(null)
  const run = (item: CtxItem) => {
    close()
    item.onSelect?.()
  }

  return (
    <div
      className="ctx-overlay"
      onMouseDown={(e) => { e.preventDefault(); close() }}
      onContextMenu={(e) => e.preventDefault()}
    >
      <div
        ref={ref}
        className="ctx-menu"
        style={{ left: menu.x, top: menu.y }}
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="ctx-title">{menu.title}</div>
        {menu.items.map((item, i) => {
          if (item.sep) return <div key={i} className="menu-sep" />
          if (item.slider !== undefined) return <CtxSlider key={i} kind={item.slider} />
          if (item.select === 'gradientType') return <CtxGradientSelect key={i} />
          if (item.hint) return <div key={i} className="ctx-hint">{item.hint}</div>
          return (
            <button
              key={i}
              type="button"
              disabled={item.disabled}
              className="menu-item"
              onClick={() => run(item)}
            >
              <span className="menu-item-label">{item.label}</span>
              {item.accel && <span className="menu-item-accel">{item.accel}</span>}
            </button>
          )
        })}
      </div>
    </div>
  )
}
