import React, { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { useEditor, canvasCtx, makeCanvas, cloneCanvas } from '../editor/store'
import { compositeDoc } from '../engine/composite'
import { stampAlongLine, walkStamp, beginWalker, walkerSpacing, StrokeWalker, paintGradient, hexToRgba } from '../engine/brush'
import {
  makeMask, maskCtx, fillRectMask, fillEllipseMask, fillPathMask,
  combineMask, subtractMask, floodMask, maskEdges, contentBounds,
} from '../engine/selection'
import { setViewport } from '../engine/viewRegistry'
import { useToolSettings } from '../editor/toolSettings'
import { PhotoLayer, Selection, ToolId, ZOOM_MAX, ZOOM_MIN, PenPath, PenPoint } from '../editor/types'
import { buildPath2D, flattenPenPath, anchorHit, handleHit, clonePenPath } from '../engine/penpath'

/* ---------------- offscreen compositor stage ---------------- */
let stage: HTMLCanvasElement | null = null
let stageFor: string | null = null
function getStage(docId: string, w: number, h: number): HTMLCanvasElement {
  if (!stage || stageFor !== docId) {
    stage = makeCanvas(w, h)
    stageFor = docId
  }
  if (stage.width !== w) stage.width = w
  if (stage.height !== h) stage.height = h
  return stage
}

function getChecker(): CanvasPattern | null {
  const tile = makeCanvas(8, 8)
  const tctx = canvasCtx(tile)
  tctx.fillStyle = '#808080'
  tctx.fillRect(0, 0, 8, 8)
  tctx.fillStyle = '#a0a0a0'
  tctx.fillRect(0, 0, 4, 4)
  tctx.fillRect(4, 4, 4, 4)
  return tctx.createPattern(tile, 'repeat')
}

const CURSORS: Record<string, string> = {
  brush: 'crosshair', pencil: 'crosshair', eraser: 'crosshair', eyedropper: 'crosshair',
  'marquee-rect': 'crosshair', 'marquee-ellipse': 'crosshair', lasso: 'crosshair',
  'lasso-poly': 'crosshair', wand: 'crosshair', crop: 'crosshair', gradient: 'crosshair', bucket: 'crosshair',
  blur: 'crosshair', dodge: 'crosshair', pen: 'crosshair', type: 'text', stamp: 'crosshair',
  move: 'move', 'path-select': 'default', transform: 'default', heal: 'crosshair', shape: 'crosshair',
  hand: 'grab', zoom: 'zoom-in',
}

const PAINT_TOOLS: ReadonlySet<ToolId> = new Set(['brush', 'pencil', 'eraser'])
const RETOUCH_TOOLS: ReadonlySet<ToolId> = new Set(['blur', 'dodge', 'stamp', 'heal'])

/* ---------------- drag states ---------------- */
interface PanState { type: 'pan'; x: number; y: number }
interface StrokeState {
  type: 'stroke'
  kind: 'brush' | 'pencil' | 'eraser'
  layerId: string
  color: string
  walker: StrokeWalker
  painted: boolean
  masked: boolean
  snapshot: HTMLCanvasElement | null
  target: 'pixels' | 'mask'
  maskMode: 'reveal' | 'conceal' | null
}
interface GradientState {
  type: 'gradient'
  layerId: string
  x0: number; y0: number; x1: number; y1: number
  masked: boolean
}
interface MarqueeState {
  type: 'marquee'
  tool: Extract<ToolId, 'marquee-rect' | 'marquee-ellipse'>
  x0: number; y0: number; x1: number; y1: number
  shift: boolean
  alt: boolean
  constrain: boolean
}
interface LassoState { type: 'lasso'; points: number[]; alt: boolean; shift: boolean }
interface MoveState {
  type: 'move'
  layerId: string
  base: HTMLCanvasElement
  region: HTMLCanvasElement | null
  startX: number
  startY: number
  lastDX: number
  lastDY: number
  hasSel: boolean
}
interface CropState { type: 'crop'; x0: number; y0: number; x1: number; y1: number }
interface ShapeState { type: 'shape'; layerId: string; x0: number; y0: number; x1: number; y1: number }
interface RetouchState {
  type: 'retouch'
  kind: 'blur' | 'dodge' | 'stamp' | 'heal'
  layerId: string
  snapshot: HTMLCanvasElement
  source: HTMLCanvasElement
  mask: HTMLCanvasElement
  result: HTMLCanvasElement
  walker: StrokeWalker
  painted: boolean
  opacity: number
}
interface PenDragState { type: 'pen' }
interface PathEditState {
  type: 'path-edit'
  mode: 'anchor' | 'handle' | 'whole'
  idx: number
  side: 'in' | 'out' | null
  lastX: number
  lastY: number
}
interface TransformDragState {
  type: 'transform'
  mode: 'move' | 'scale' | 'rotate' | 'skew'
  horiz: boolean
  vert: boolean
  anchorX: number
  anchorY: number
  startX: number
  startY: number
  rot0: number
  angle0: number
  hw0: number
  hh0: number
  cx0: number
  cy0: number
  skewX0: number
  skewY0: number
}
type DragState = PanState | StrokeState | GradientState | MarqueeState | LassoState | MoveState | CropState | ShapeState | RetouchState | TransformDragState | PenDragState | PathEditState

const isPan = (d: DragState): d is PanState => d.type === 'pan'
const isStroke = (d: DragState): d is StrokeState => d.type === 'stroke'
const isGrad = (d: DragState): d is GradientState => d.type === 'gradient'
const isMarquee = (d: DragState): d is MarqueeState => d.type === 'marquee'
const isLasso = (d: DragState): d is LassoState => d.type === 'lasso'
const isMoveLayer = (d: DragState): d is MoveState => d.type === 'move'
const isCrop = (d: DragState): d is CropState => d.type === 'crop'
const isShape = (d: DragState): d is ShapeState => d.type === 'shape'
const isRetouch = (d: DragState): d is RetouchState => d.type === 'retouch'
const isTransformDrag = (d: DragState): d is TransformDragState => d.type === 'transform'
const isPenDrag = (d: DragState): d is PenDragState => d.type === 'pen'
const isPathEdit = (d: DragState): d is PathEditState => d.type === 'path-edit'

interface TransformSession {
  layerId: string
  orig: HTMLCanvasElement
  origW: number
  origH: number
  origX: number
  origY: number
  cx: number
  cy: number
  hw: number
  hh: number
  rot: number
  skewX: number
  skewY: number
  fullOrig: HTMLCanvasElement
  base: HTMLCanvasElement
  hadSelection: boolean
}

interface TypeDraft {
  x: number
  y: number
  text: string
  layerId?: string
}

function docLayerOf(doc: { layers: PhotoLayer[]; activeLayerId: string } | null, id: string): PhotoLayer | null {
  return doc?.layers.find((l) => l.id === id) ?? null
}

export default function DocumentView() {
  const docs = useEditor((s) => s.docs)
  const activeDocId = useEditor((s) => s.activeDocId)
  const revision = useEditor((s) => s.revision)
  const tool = useEditor((s) => s.tool)
  const transformActive = useEditor((s) => s.transformActive)
  const editingMaskLayerId = useEditor((s) => s.editingMaskLayerId)

  const containerRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const overlayRef = useRef<HTMLCanvasElement>(null)
  const [size, setSize] = useState({ w: 0, h: 0 })
  const [spaceHeld, setSpaceHeld] = useState(false)
  const [cursor, setCursor] = useState<{ x: number; y: number } | null>(null)
  const [gradLine, setGradLine] = useState<{ x0: number; y0: number; x1: number; y1: number } | null>(null)
  const [marqueeBox, setMarqueeBox] = useState<{ x0: number; y0: number; x1: number; y1: number; tool: string } | null>(null)
  const [lassoPts, setLassoPts] = useState<number[] | null>(null)
  const [polyPts, setPolyPts] = useState<number[] | null>(null)
  const polyModeRef = useRef({ alt: false, shift: false })
  const [cropBox, setCropBox] = useState<{ x0: number; y0: number; x1: number; y1: number } | null>(null)
  const [shapeBox, setShapeBox] = useState<{ x0: number; y0: number; x1: number; y1: number } | null>(null)
  const [typeDraft, setTypeDraft] = useState<TypeDraft | null>(null)
  const [penDraft, setPenDraft] = useState<PenPath | null>(null)
  /* refs mirror the drafts so global drag/keyboard handlers always read fresh values */
  const typeDraftRef = useRef<TypeDraft | null>(null)
  const penDraftRef = useRef<PenPath | null>(null)
  const penCommittedRef = useRef(false)

  const updatePenDraft = (next: PenPath | null): void => {
    penDraftRef.current = next
    setPenDraft(next)
  }

  const updateTypeDraft = (next: TypeDraft | null): void => {
    typeDraftRef.current = next
    setTypeDraft(next)
  }
  const [, setSessionTick] = useState(0)
  const transformSession = useRef<TransformSession | null>(null)
  const fittedRef = useRef(new Set<string>())
  const dragRef = useRef<DragState | null>(null)
  const [dragging, setDragging] = useState(false)
  const rafRef = useRef(false)
  const [antsPhase, setAntsPhase] = useState(0)
  const [tabDrag, setTabDrag] = useState<{
    id: string
    overId: string | null
    side: 'before' | 'after'
  } | null>(null)
  const tabJustDragged = useRef(false)

  const doc = docs.find((d) => d.id === activeDocId) ?? null
  const textFont = useToolSettings((s) => s.textFont)
  const textSize = useToolSettings((s) => s.textSize)
  const textBold = useToolSettings((s) => s.textBold)
  const textItalic = useToolSettings((s) => s.textItalic)
  const textColor = useToolSettings((s) => s.textColor)
  const textMode = useToolSettings((s) => s.textMode)
  const textOrientation = useToolSettings((s) => s.textOrientation)
  const textAlign = useToolSettings((s) => s.textAlign)
  const textLeading = useToolSettings((s) => s.textLeading)
  const textTracking = useToolSettings((s) => s.textTracking)
  const textBoxWidth = useToolSettings((s) => s.textBoxWidth)
  const textBoxHeight = useToolSettings((s) => s.textBoxHeight)
  const textUnderline = useToolSettings((s) => s.textUnderline)
  const textStrike = useToolSettings((s) => s.textStrike)

  const scratch = useRef<HTMLCanvasElement | null>(null)
  const scratchKind = useRef<'paint' | 'erase' | null>(null)
  const cloneSource = useRef<{ layerId: string; x: number; y: number } | null>(null)
  let maskedScratch: HTMLCanvasElement | null = null

  const scheduleBump = () => {
    if (rafRef.current) return
    rafRef.current = true
    requestAnimationFrame(() => {
      rafRef.current = false
      useEditor.getState().bump()
    })
  }

  /* ---------------- free-transform sessions ---------------- */
  function startTransform(): void {
    const st = useEditor.getState()
    const d = st.docs.find((x) => x.id === st.activeDocId)
    if (!d) return
    const layer = docLayerOf(d, d.activeLayerId)
    if (!layer) return
    if (layer.type === 'adjustment' || layer.type === 'group') {
      st.showToast(`${layer.type === 'group' ? 'Groups' : 'Adjustment layers'} have no direct pixel content to transform`)
      st.setTransformActive(false)
      return
    }
    if (layer.locked) {
      st.showToast(`“${layer.name}” is locked`)
      st.setTransformActive(false)
      return
    }
    const fullOrig = cloneCanvas(layer.canvas)
    let working = fullOrig
    const base = makeCanvas(d.width, d.height)
    if (d.selection) {
      working = cloneCanvas(fullOrig)
      const workingCtx = canvasCtx(working)
      workingCtx.globalCompositeOperation = 'destination-in'
      workingCtx.drawImage(d.selection.mask, 0, 0)
      const baseCtx = canvasCtx(base)
      baseCtx.drawImage(fullOrig, 0, 0)
      baseCtx.globalCompositeOperation = 'destination-out'
      baseCtx.drawImage(d.selection.mask, 0, 0)
    }
    const b = contentBounds(working)
    const bw = Math.max(2, b.x1 - b.x0)
    const bh = Math.max(2, b.y1 - b.y0)
    const orig = makeCanvas(bw, bh)
    canvasCtx(orig).drawImage(working, -b.x0, -b.y0)
    transformSession.current = {
      layerId: layer.id,
      orig,
      origW: bw,
      origH: bh,
      origX: b.x0,
      origY: b.y0,
      cx: (b.x0 + b.x1) / 2,
      cy: (b.y0 + b.y1) / 2,
      hw: bw / 2,
      hh: bh / 2,
      rot: 0,
      skewX: 0,
      skewY: 0,
      fullOrig,
      base,
      hadSelection: !!d.selection,
    }
    st.setTransformActive(true)
    st.showToast('Free Transform — drag to move, handles to scale, top handle to rotate · Enter commits · Esc cancels')
    setSessionTick((n) => n + 1)
    scheduleBump()
  }

  function applyTransformPreview(): void {
    const st = useEditor.getState()
    const d = st.docs.find((x) => x.id === st.activeDocId)
    const sess = transformSession.current
    if (!d || !sess) return
    const layer = docLayerOf(d, sess.layerId)
    if (!layer) return
    const ctx = canvasCtx(layer.canvas)
    ctx.setTransform(1, 0, 0, 1, 0, 0)
    ctx.clearRect(0, 0, layer.canvas.width, layer.canvas.height)
    ctx.drawImage(sess.base, 0, 0)
    ctx.save()
    ctx.translate(sess.cx, sess.cy)
    ctx.rotate(sess.rot)
    ctx.transform(1, sess.skewY, sess.skewX, 1, 0, 0)
    ctx.scale((sess.hw * 2) / sess.origW, (sess.hh * 2) / sess.origH)
    ctx.drawImage(sess.orig, -sess.origW / 2, -sess.origH / 2)
    ctx.restore()
    ctx.setTransform(1, 0, 0, 1, 0, 0)
  }

  function commitTransform(): void {
    const sess = transformSession.current
    if (!sess) return
    applyTransformPreview()
    transformSession.current = null
    const st = useEditor.getState()
    const d = st.docs.find((x) => x.id === st.activeDocId)
    const layer = d ? docLayerOf(d, sess.layerId) : null
    if (layer?.type === 'text') {
      layer.type = 'pixel'
      layer.textData = undefined
    }
    if (d && sess.hadSelection) d.selection = null
    st.setTransformActive(false)
    st.pushHistory('Free Transform')
    if (st.tool === 'transform') st.setTool('move')
    setSessionTick((n) => n + 1)
  }

  function cancelTransform(): void {
    const sess = transformSession.current
    if (!sess) return
    const st = useEditor.getState()
    const d = st.docs.find((x) => x.id === st.activeDocId)
    const layer = d ? docLayerOf(d, sess.layerId) : null
    if (layer) {
      const ctx = canvasCtx(layer.canvas)
      ctx.setTransform(1, 0, 0, 1, 0, 0)
      ctx.clearRect(0, 0, layer.canvas.width, layer.canvas.height)
      ctx.drawImage(sess.fullOrig, 0, 0)
    }
    transformSession.current = null
    st.setTransformActive(false)
    if (st.tool === 'transform') st.setTool('move')
    setSessionTick((n) => n + 1)
    scheduleBump()
  }

  /* ---------------- viewport sizing + registry ---------------- */
  useLayoutEffect(() => {
    const el = containerRef.current
    if (!el) return
    const update = () => {
      const w = el.clientWidth
      const h = el.clientHeight
      setSize((prev) => (prev.w === w && prev.h === h ? prev : { w, h }))
    }
    const ro = new ResizeObserver(update)
    ro.observe(el)
    setViewport(el)
    update()
    return () => ro.disconnect()
  })

  /* rasterize the current text draft into a new layer */
  const commitTypeDraft = (): void => {
    const t = typeDraftRef.current
    if (!t) return
    typeDraftRef.current = null
    setTypeDraft(null)
    if (!t.text.trim() && !t.layerId) return
    const s = useToolSettings.getState()
    const data = {
      text: t.text,
      x: t.x,
      y: t.y,
      size: s.textSize,
      bold: s.textBold,
      italic: s.textItalic,
      font: s.textFont,
      color: s.textColor,
      mode: s.textMode,
      orientation: s.textOrientation,
      align: s.textAlign,
      leading: s.textLeading,
      tracking: s.textTracking,
      boxWidth: s.textBoxWidth,
      boxHeight: s.textBoxHeight,
      underline: s.textUnderline,
      strike: s.textStrike,
    }
    if (t.layerId) useEditor.getState().updateTextLayer(t.layerId, data)
    else useEditor.getState().addTextLayer(data)
  }

  const cancelTypeDraft = (): void => {
    typeDraftRef.current = null
    setTypeDraft(null)
  }

  const beginEditTextLayer = (layerId: string): boolean => {
    const st = useEditor.getState()
    const currentDoc = st.docs.find((d) => d.id === st.activeDocId)
    const layer = currentDoc?.layers.find((l) => l.id === layerId)
    if (!layer?.textData) return false
    const data = layer.textData
    const settings = useToolSettings.getState()
    settings.set('textFont', data.font)
    settings.set('textSize', data.size)
    settings.set('textBold', data.bold)
    settings.set('textItalic', data.italic)
    settings.set('textColor', data.color)
    settings.set('textMode', data.mode ?? 'point')
    settings.set('textOrientation', data.orientation ?? 'horizontal')
    settings.set('textAlign', data.align ?? 'left')
    settings.set('textLeading', data.leading ?? 0)
    settings.set('textTracking', data.tracking ?? 0)
    settings.set('textBoxWidth', data.boxWidth ?? 420)
    settings.set('textBoxHeight', data.boxHeight ?? 240)
    settings.set('textUnderline', !!data.underline)
    settings.set('textStrike', !!data.strike)
    updateTypeDraft({ x: data.x, y: data.y, text: data.text, layerId: layer.id })
    return true
  }

  useEffect(() => {
    const edit = (event: Event) => {
      const layerId = (event as CustomEvent<string>).detail
      if (layerId) beginEditTextLayer(layerId)
    }
    const create = () => {
      const st = useEditor.getState()
      const currentDoc = st.docs.find((d) => d.id === st.activeDocId)
      if (!currentDoc) { st.showToast('Open a document before adding text'); return }
      commitTypeDraft()
      st.setTool('type')
      updateTypeDraft({ x: Math.round(currentDoc.width * 0.15), y: Math.round(currentDoc.height * 0.15), text: '' })
    }
    const commit = () => commitTypeDraft()
    const cancel = () => cancelTypeDraft()
    window.addEventListener('pc:editText', edit)
    window.addEventListener('pc:newText', create)
    window.addEventListener('pc:textCommit', commit)
    window.addEventListener('pc:textCancel', cancel)
    return () => {
      window.removeEventListener('pc:editText', edit)
      window.removeEventListener('pc:newText', create)
      window.removeEventListener('pc:textCommit', commit)
      window.removeEventListener('pc:textCancel', cancel)
    }
  }, [])

  /* ---------------- keys: space pan, Enter/Esc for transform/crop/poly ---------------- */
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return
      if (e.code === 'Space' && !e.repeat) {
        e.preventDefault()
        setSpaceHeld(true)
      }
      if (e.key === 'Enter') {
        if (transformSession.current) {
          e.preventDefault()
          commitTransform()
        } else if (polyPts && polyPts.length >= 6) {
          e.preventDefault()
          commitLasso(polyPts, polyModeRef.current.alt, polyModeRef.current.shift, false)
          setPolyPts(null)
        }
      }
      if (e.key === 'Escape') {
        if (transformSession.current) cancelTransform()
        else if (polyPts) setPolyPts(null)
        else if (tool === 'pen' && penDraftRef.current) {
          /* pop the last pen anchor (Esc removes one point at a time) */
          const draft = penDraftRef.current
          if (draft.points.length <= 1) updatePenDraft(null)
          else updatePenDraft({ closed: false, points: draft.points.slice(0, -1) })
        }
      }
    }
    const up = (e: KeyboardEvent) => {
      if (e.code === 'Space') setSpaceHeld(false)
    }
    window.addEventListener('keydown', down)
    window.addEventListener('keyup', up)
    return () => {
      window.removeEventListener('keydown', down)
      window.removeEventListener('keyup', up)
    }
  }, [polyPts, tool])

  /* ---------------- Ctrl+T / transform flag goes through pc:transformFree ---------------- */
  useEffect(() => {
    window.addEventListener('pc:transformFree', onTransformEvent)
    const commit = () => commitTransform()
    const cancel = () => cancelTransform()
    const rotate = (event: Event) => {
      const sess = transformSession.current
      if (!sess) return
      sess.rot += ((event as CustomEvent<number>).detail || 0) * Math.PI / 180
      applyTransformPreview(); setSessionTick((n) => n + 1); scheduleBump()
    }
    const flip = (event: Event) => {
      const sess = transformSession.current
      if (!sess) return
      const axis = (event as CustomEvent<'h' | 'v'>).detail
      const next = makeCanvas(sess.orig.width, sess.orig.height)
      const ctx = canvasCtx(next)
      if (axis === 'h') ctx.setTransform(-1, 0, 0, 1, next.width, 0)
      else ctx.setTransform(1, 0, 0, -1, 0, next.height)
      ctx.drawImage(sess.orig, 0, 0)
      sess.orig = next
      applyTransformPreview(); setSessionTick((n) => n + 1); scheduleBump()
    }
    window.addEventListener('pc:transformCommit', commit)
    window.addEventListener('pc:transformCancel', cancel)
    window.addEventListener('pc:transformRotate', rotate)
    window.addEventListener('pc:transformFlip', flip)
    return () => {
      window.removeEventListener('pc:transformFree', onTransformEvent)
      window.removeEventListener('pc:transformCommit', commit)
      window.removeEventListener('pc:transformCancel', cancel)
      window.removeEventListener('pc:transformRotate', rotate)
      window.removeEventListener('pc:transformFlip', flip)
    }
  }, [])

  /* leaving pen/path-select commits the live draft into the work path */
  useEffect(() => {
    if (tool !== 'pen' && tool !== 'path-select' && penDraftRef.current) {
      useEditor.getState().setWorkPath(
        clonePenPath(penDraftRef.current),
        penCommittedRef.current ? undefined : 'Draw Path',
      )
      penCommittedRef.current = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tool])

  /* Leaving the Type tool commits the current editable text layer. */
  useEffect(() => {
    if (tool !== 'type' && typeDraftRef.current) commitTypeDraft()
    // commitTypeDraft reads current refs/settings intentionally.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tool])

  /* switching documents abandons local drafts */
  useEffect(() => {
    updateTypeDraft(null)
    updatePenDraft(null)
    penCommittedRef.current = false
  }, [doc?.id])

  useEffect(() => {
    if (transformActive && !transformSession.current) startTransform()
  }, [transformActive])

  useEffect(() => {
    if (tool === 'transform' && !transformSession.current) startTransform()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tool])

  function onTransformEvent(): void {
    if (transformSession.current) commitTransform()
    else startTransform()
  }

  /* ---------------- ants animation ---------------- */
  useEffect(() => {
    if (!doc?.selection) return
    const t = setInterval(() => setAntsPhase((p) => (p + 1) % 16), 110)
    return () => clearInterval(t)
  }, [doc?.selection])

  /* ---------------- auto-fit fresh document ---------------- */
  useEffect(() => {
    if (!doc || size.w < 40 || fittedRef.current.has(doc.id)) return
    fittedRef.current.add(doc.id)
    const st = useEditor.getState()
    const d = st.docs.find((x) => x.id === doc.id)
    if (!d) return
    if (d.zoom === 1 && d.panX === 0 && d.panY === 0) {
      const zz = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, Math.min((size.w - 48) / d.width, (size.h - 48) / d.height))) || 1
      st.setZoom(d.id, zz)
      st.panBy(d.id, (size.w - d.width * zz) / 2 - d.panX, (size.h - d.height * zz) / 2 - d.panY)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [doc?.id, size.w, size.h])

  /* ---------------- main doc render ---------------- */
  useEffect(() => {
    const canvas = canvasRef.current
    const cont = containerRef.current
    if (!canvas || !cont || !doc) return
    const dpr = window.devicePixelRatio || 1
    const w = cont.clientWidth
    const h = cont.clientHeight
    if (w < 2 || h < 2) return
    canvas.width = Math.round(w * dpr)
    canvas.height = Math.round(h * dpr)
    const ctx = canvasCtx(canvas)

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    ctx.save()
    const offX = ((doc.panX % 16) + 16) % 16
    const offY = ((doc.panY % 16) + 16) % 16
    ctx.translate(offX - 16, offY - 16)
    ctx.fillStyle = getChecker() ?? '#a0a0a0'
    ctx.fillRect(0, 0, w + 32, h + 32)
    ctx.restore()

    const stg = getStage(doc.id, doc.width, doc.height)
    compositeDoc(doc, stg, String(revision))

    const z = doc.zoom
    ctx.imageSmoothingEnabled = z < 4
    ctx.imageSmoothingQuality = 'high'
    ctx.setTransform(dpr * z, 0, 0, dpr * z, dpr * doc.panX, dpr * doc.panY)
    ctx.drawImage(stg, 0, 0)

    /* masked stroke preview overlay */
    if ((dragging || scratchKind.current === 'paint') && scratch.current && scratchKind.current === 'paint') {
      const masked = getScratchMasked(scratch.current, doc.selection)
      ctx.drawImage(masked, 0, 0)
    }

    ctx.lineWidth = 1 / z
    ctx.strokeStyle = 'rgba(64,128,255,0.85)'
    ctx.strokeRect(0, 0, doc.width, doc.height)

    const active = doc.layers.find((l) => l.id === doc.activeLayerId)
    if (active) {
      ctx.lineWidth = 1 / z
      ctx.strokeStyle = 'rgba(255,170,60,0.6)'
      ctx.strokeRect(0.5 / z, 0.5 / z, doc.width - 1 / z, doc.height - 1 / z)
    }
    void dragging
  }, [doc, revision, size, tool, dragging])

  function getScratchMasked(sc: HTMLCanvasElement, sel: Selection | null): HTMLCanvasElement {
    if (!maskedScratch) maskedScratch = makeCanvas(sc.width, sc.height)
    const m = maskedScratch
    if (m.width !== sc.width) m.width = sc.width
    if (m.height !== sc.height) m.height = sc.height
    const ctx = m.getContext('2d', { willReadFrequently: true })!
    ctx.setTransform(1, 0, 0, 1, 0, 0)
    ctx.clearRect(0, 0, m.width, m.height)
    ctx.drawImage(sc, 0, 0)
    if (sel) {
      ctx.globalCompositeOperation = 'destination-in'
      ctx.drawImage(sel.mask, 0, 0)
      ctx.globalCompositeOperation = 'source-over'
    }
    return m
  }

  /** Rebuild a retouch preview from the immutable stroke-start snapshot. */
  function applyRetouch(drag: RetouchState, d: typeof doc): void {
    if (!d) return
    const layer = docLayerOf(d, drag.layerId)
    if (!layer) return
    const rctx = canvasCtx(drag.result)
    rctx.setTransform(1, 0, 0, 1, 0, 0)
    rctx.clearRect(0, 0, drag.result.width, drag.result.height)
    rctx.drawImage(drag.source, 0, 0)
    rctx.globalCompositeOperation = 'destination-in'
    rctx.drawImage(drag.mask, 0, 0)
    if (d.selection) rctx.drawImage(d.selection.mask, 0, 0)
    rctx.globalCompositeOperation = 'source-over'

    const lctx = canvasCtx(layer.canvas)
    lctx.setTransform(1, 0, 0, 1, 0, 0)
    lctx.clearRect(0, 0, layer.canvas.width, layer.canvas.height)
    lctx.drawImage(drag.snapshot, 0, 0)
    lctx.save()
    lctx.globalAlpha = drag.opacity
    lctx.drawImage(drag.result, 0, 0)
    lctx.restore()
  }

  function makeRetouchSource(
    snapshot: HTMLCanvasElement,
    kind: RetouchState['kind'],
    startX: number,
    startY: number,
    sourcePoint: { x: number; y: number } | null,
    burn: boolean,
  ): HTMLCanvasElement {
    const out = makeCanvas(snapshot.width, snapshot.height)
    const ctx = canvasCtx(out)
    if (kind === 'blur') {
      ctx.filter = `blur(${Math.max(0.6, useToolSettings.getState().brushSize / 10)}px)`
      ctx.drawImage(snapshot, 0, 0)
      ctx.filter = 'none'
    } else if (kind === 'dodge') {
      ctx.drawImage(snapshot, 0, 0)
      const img = ctx.getImageData(0, 0, out.width, out.height)
      const amount = burn ? -42 : 42
      for (let i = 0; i < img.data.length; i += 4) {
        img.data[i] += amount
        img.data[i + 1] += amount
        img.data[i + 2] += amount
      }
      ctx.putImageData(img, 0, 0)
    } else if (sourcePoint) {
      ctx.drawImage(snapshot, startX - sourcePoint.x, startY - sourcePoint.y)
    }
    return out
  }

  /* ---------------- overlay: crop / transform / marquee / lasso / ants ---------------- */
  useEffect(() => {
    const ov = overlayRef.current
    const cont = containerRef.current
    if (!ov || !cont || !doc) return
    const dpr = window.devicePixelRatio || 1
    ov.width = Math.round(cont.clientWidth * dpr)
    ov.height = Math.round(cont.clientHeight * dpr)
    const ctx = ov.getContext('2d')!
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    ctx.clearRect(0, 0, ov.width, ov.height)
    const z = doc.zoom
    const docT = () => ctx.setTransform(dpr * z, 0, 0, dpr * z, dpr * doc.panX, dpr * doc.panY)

    /* crop preview */
    if (cropBox) {
      ctx.fillStyle = 'rgba(0,0,0,0.45)'
      ctx.fillRect(0, 0, ov.width, ov.height)
      docT()
      ctx.clearRect(cropBox.x0, cropBox.y0, cropBox.x1 - cropBox.x0, cropBox.y1 - cropBox.y0)
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 1 / z
      ctx.strokeRect(cropBox.x0, cropBox.y0, cropBox.x1 - cropBox.x0, cropBox.y1 - cropBox.y0)
      ctx.strokeStyle = 'rgba(255,255,255,0.35)'
      for (let i = 1; i < 3; i++) {
        const fx = cropBox.x0 + ((cropBox.x1 - cropBox.x0) * i) / 3
        const fy = cropBox.y0 + ((cropBox.y1 - cropBox.y0) * i) / 3
        ctx.beginPath(); ctx.moveTo(fx, cropBox.y0); ctx.lineTo(fx, cropBox.y1); ctx.stroke()
        ctx.beginPath(); ctx.moveTo(cropBox.x0, fy); ctx.lineTo(cropBox.x1, fy); ctx.stroke()
      }
      ctx.font = `${12 / z}px sans-serif`
      ctx.fillStyle = '#fff'
      const wpx = Math.round(cropBox.x1 - cropBox.x0)
      const hpx = Math.round(cropBox.y1 - cropBox.y0)
      ctx.fillText(`${wpx} × ${hpx}`, cropBox.x0 + 4 / z, cropBox.y0 - 6 / z)
    }

    /* rectangle shape preview */
    if (shapeBox) {
      docT()
      ctx.fillStyle = `${useEditor.getState().fg}55`
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 1 / z
      const x = Math.min(shapeBox.x0, shapeBox.x1)
      const y = Math.min(shapeBox.y0, shapeBox.y1)
      const w = Math.abs(shapeBox.x1 - shapeBox.x0)
      const h = Math.abs(shapeBox.y1 - shapeBox.y0)
      ctx.fillRect(x, y, w, h)
      ctx.strokeRect(x, y, w, h)
    }

    /* transform frame */
    const sess = transformSession.current
    if (sess) {
      docT()
      ctx.translate(sess.cx, sess.cy)
      ctx.rotate(sess.rot)
      ctx.transform(1, sess.skewY, sess.skewX, 1, 0, 0)
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 1 / z
      const hs = 5 / z
      ctx.strokeRect(-sess.hw, -sess.hh, sess.hw * 2, sess.hh * 2)
      const corners: [number, number][] = [
        [-sess.hw, -sess.hh], [0, -sess.hh], [sess.hw, -sess.hh],
        [-sess.hw, 0], [sess.hw, 0],
        [-sess.hw, sess.hh], [0, sess.hh], [sess.hw, sess.hh],
      ]
      for (const [hx, hy] of corners) {
        ctx.fillStyle = '#ffffff'
        ctx.fillRect(hx - hs, hy - hs, hs * 2, hs * 2)
      }
      const ry = -sess.hh - 24 / z
      ctx.beginPath(); ctx.moveTo(0, -sess.hh); ctx.lineTo(0, ry); ctx.stroke()
      ctx.beginPath(); ctx.arc(0, ry, 6 / z, 0, Math.PI * 2); ctx.stroke()
    }

    /* marquee preview */
    if (marqueeBox) {
      docT()
      ctx.lineWidth = 1 / z
      ctx.setLineDash([4 / z, 4 / z])
      ctx.strokeStyle = '#ffffff'
      if (marqueeBox.tool === 'rect') {
        ctx.strokeRect(marqueeBox.x0, marqueeBox.y0, marqueeBox.x1 - marqueeBox.x0, marqueeBox.y1 - marqueeBox.y0)
      } else {
        ctx.beginPath()
        ctx.ellipse((marqueeBox.x0 + marqueeBox.x1) / 2, (marqueeBox.y0 + marqueeBox.y1) / 2,
          Math.abs(marqueeBox.x1 - marqueeBox.x0) / 2, Math.abs(marqueeBox.y1 - marqueeBox.y0) / 2, 0, 0, Math.PI * 2)
        ctx.stroke()
      }
      ctx.strokeStyle = '#00000066'
      ctx.setLineDash([4 / z, 4 / z])
      ctx.lineDashOffset = 4 / z
      if (marqueeBox.tool === 'rect') {
        ctx.strokeRect(marqueeBox.x0, marqueeBox.y0, marqueeBox.x1 - marqueeBox.x0, marqueeBox.y1 - marqueeBox.y0)
      }
      ctx.setLineDash([])
    }

    /* lasso freehand preview */
    if (lassoPts && lassoPts.length >= 4) {
      docT()
      ctx.lineWidth = 1 / z
      ctx.strokeStyle = '#ffffffcc'
      ctx.beginPath()
      ctx.moveTo(lassoPts[0], lassoPts[1])
      for (let i = 2; i < lassoPts.length; i += 2) ctx.lineTo(lassoPts[i], lassoPts[i + 1])
      ctx.stroke()
    }

    /* polygonal lasso preview */
    if (polyPts && polyPts.length >= 2) {
      docT()
      ctx.lineWidth = 1 / z
      ctx.strokeStyle = '#ffffff'
      ctx.beginPath()
      ctx.moveTo(polyPts[0], polyPts[1])
      for (let i = 2; i < polyPts.length; i += 2) ctx.lineTo(polyPts[i], polyPts[i + 1])
      ctx.stroke()
      const lx = polyPts[polyPts.length - 2]
      const ly = polyPts[polyPts.length - 1]
      ctx.beginPath(); ctx.arc(lx, ly, 3 / z, 0, Math.PI * 2); ctx.stroke()
    }

    /* pen path / work path overlay */
    const penSrc = penDraft ?? doc.workPath
    if (penSrc && penSrc.points.length > 0) {
      docT()
      const path = buildPath2D(penSrc.points, penSrc.closed)
      ctx.lineWidth = 1.5 / z
      ctx.strokeStyle = 'rgba(120,200,255,0.95)'
      ctx.stroke(path)

      const as = 5 / z
      /* handle stems + knobs */
      for (const p of penSrc.points) {
        const hasIn = Math.hypot(p.c1x - p.x, p.c1y - p.y) > 0.5
        const hasOut = Math.hypot(p.c2x - p.x, p.c2y - p.y) > 0.5
        ctx.lineWidth = 1 / z
        ctx.strokeStyle = 'rgba(255,255,255,0.55)'
        if (hasIn) {
          ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.c1x, p.c1y); ctx.stroke()
          ctx.fillStyle = '#8fd0ff'
          ctx.beginPath(); ctx.arc(p.c1x, p.c1y, as * 0.7, 0, Math.PI * 2); ctx.fill()
        }
        if (hasOut) {
          ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.c2x, p.c2y); ctx.stroke()
          ctx.fillStyle = '#8fd0ff'
          ctx.beginPath(); ctx.arc(p.c2x, p.c2y, as * 0.7, 0, Math.PI * 2); ctx.fill()
        }
      }
      /* anchor squares */
      for (const p of penSrc.points) {
        ctx.fillStyle = '#ffffff'
        ctx.fillRect(p.x - as / 2, p.y - as / 2, as, as)
        ctx.lineWidth = 1 / z
        ctx.strokeStyle = '#00000099'
        ctx.strokeRect(p.x - as / 2, p.y - as / 2, as, as)
      }
      if (!penSrc.closed) {
        /* closing hint on the first anchor when 3+ points exist */
        if (penSrc.points.length >= 3) {
          const p0 = penSrc.points[0]
          ctx.fillStyle = '#8fd0ff'
          ctx.fillRect(p0.x - as * 0.9, p0.y - as * 0.9, as * 1.8, as * 1.8)
        }
      }
    }

    /* marching ants */
    const sel = doc.selection
    if (!sel) return
    if (sel.path) {
      docT()
      ctx.lineWidth = 1 / z
      ctx.setLineDash([3.5 / z, 3.5 / z])
      ctx.lineDashOffset = -(antsPhase % 7) / z
      ctx.strokeStyle = '#ffffff'
      ctx.stroke(sel.path)
      ctx.lineDashOffset = ((7 - antsPhase) % 7) / z
      ctx.strokeStyle = '#000000'
      ctx.stroke(sel.path)
      ctx.setLineDash([])
    } else {
      const edges = maskEdges(sel.mask)
      const pts = edges.points
      const total = pts.length / 2
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      const px = doc.zoom
      const s = Math.max(1, 2 * px)
      for (let fy = 0; fy < 2; fy++) {
        ctx.fillStyle = fy === 0 ? '#ffffff' : '#000000'
        const phase = antsPhase + fy * 4
        for (let i = 0; i < total; i++) {
          const x = pts[i * 2]
          const y = pts[i * 2 + 1]
          if (((x + y + phase) & 7) >= 4) continue
          ctx.fillRect(x * px + doc.panX, y * px + doc.panY, s, s)
        }
      }
    }
  }, [doc, revision, size, antsPhase, cropBox, shapeBox, marqueeBox, lassoPts, polyPts, penDraft])

  /* ---------------- native wheel ---------------- */
  useEffect(() => {
    const el = containerRef.current
    if (!el) return
    const onWheel = (e: WheelEvent) => {
      const st = useEditor.getState()
      const d = st.docs.find((x) => x.id === st.activeDocId)
      if (!d) return
      e.preventDefault()
      const rect = el.getBoundingClientRect()
      if (e.ctrlKey || e.altKey || e.metaKey) {
        const factor = e.deltaY < 0 ? Math.pow(2, 0.5) : Math.pow(2, -0.5)
        st.setZoom(d.id, d.zoom * factor, { x: e.clientX - rect.left, y: e.clientY - rect.top })
      } else {
        st.panBy(d.id, -e.deltaX, -e.deltaY)
      }
    }
    el.addEventListener('wheel', onWheel, { passive: false })
    return () => el.removeEventListener('wheel', onWheel)
  })

  /* ---------------- eyedropper ---------------- */
  function sampleColor(world: { x: number; y: number }, toBg: boolean): void {
    if (!stage) return
    const px = Math.floor(world.x)
    const py = Math.floor(world.y)
    if (px < 0 || py < 0 || px >= stage.width || py >= stage.height) return
    const data = canvasCtx(stage).getImageData(px, py, 1, 1).data
    if (data[3] === 0) {
      useEditor.getState().showToast('Sampled: transparent')
      return
    }
    const hex = '#' + [data[0], data[1], data[2]].map((v) => v.toString(16).padStart(2, '0')).join('')
    const st = useEditor.getState()
    if (toBg) st.setBg(hex)
    else st.setFg(hex)
  }

  /* ---------------- selection creation ---------------- */
  function newShapeMask(tool: ToolId, x0: number, y0: number, x1: number, y1: number, w: number, h: number): HTMLCanvasElement {
    const mask = makeMask(w, h)
    const ctx = maskCtx(mask)
    if (tool === 'marquee-rect') fillRectMask(ctx, x0, y0, x1, y1, useToolSettings.getState().feather)
    else fillEllipseMask(ctx, x0, y0, x1, y1, useToolSettings.getState().feather)
    return mask
  }

  function shapePath(tool: ToolId, x0: number, y0: number, x1: number, y1: number): Path2D {
    const path = new Path2D()
    if (tool === 'marquee-rect') {
      path.rect(Math.min(x0, x1), Math.min(y0, y1), Math.abs(x1 - x0), Math.abs(y1 - y0))
    } else {
      path.ellipse((x0 + x1) / 2, (y0 + y1) / 2, Math.abs(x1 - x0) / 2, Math.abs(y1 - y0) / 2, 0, 0, Math.PI * 2)
    }
    return path
  }

  function commitMarquee(m: MarqueeState): void {
    const st = useEditor.getState()
    const d = st.docs.find((x) => x.id === st.activeDocId)
    if (!d) return
    let mask: HTMLCanvasElement | null = newShapeMask(m.tool, m.x0, m.y0, m.x1, m.y1, d.width, d.height)
    let path: Path2D | null = shapePath(m.tool, m.x0, m.y0, m.x1, m.y1)
    if (distSmall(m.x0, m.y0, m.x1, m.y1, d.zoom)) {
      st.setSelection(null, 'Deselect')
      return
    }
    if (m.alt && d.selection) {
      mask = subtractMask(d.selection.mask, mask)
      path = null
    }
    else if (m.shift && d.selection) {
      mask = combineMask(d.selection.mask, mask)
      path = null
    }
    st.setSelection({ mask, path }, m.alt ? 'Marquee Subtract' : m.shift && d.selection ? 'Marquee Add' : 'Marquee Selection')
  }

  function distSmall(x0: number, y0: number, x1: number, y1: number, zoom: number): boolean {
    return Math.abs(x1 - x0) * zoom < 2 && Math.abs(y1 - y0) * zoom < 2
  }

  function commitLasso(pts: number[], alt: boolean, add: boolean, isLassoTool: boolean): void {
    const st = useEditor.getState()
    const d = st.docs.find((x) => x.id === st.activeDocId)
    setLassoPts(null)
    if (!d || pts.length < 6) return
    const path = new Path2D()
    path.moveTo(pts[0], pts[1])
    for (let i = 2; i < pts.length; i += 2) path.lineTo(pts[i], pts[i + 1])
    path.closePath()
    const mask = makeMask(d.width, d.height)
    fillPathMask(maskCtx(mask), path, d.width, d.height, useToolSettings.getState().feather)
    let final = mask
    let label = isLassoTool ? 'Lasso Selection' : 'Polygonal Lasso'
    if (d.selection && (alt || add)) {
      final = alt ? subtractMask(d.selection.mask, mask) : combineMask(d.selection.mask, mask)
      label = alt ? 'Lasso Subtract' : 'Lasso Add'
    }
    st.setSelection({ mask: final, path: null }, label)
  }

  /* ---------------- global drag handlers ---------------- */
  useEffect(() => {
    if (!dragging || !dragRef.current) return
    const cont = containerRef.current
    const rect = cont?.getBoundingClientRect()
    const localOf = (e: MouseEvent) => (rect ? { x: e.clientX - rect.left, y: e.clientY - rect.top } : { x: 0, y: 0 })
    const worldOf = () => {
      const st = useEditor.getState()
      const d = st.docs.find((x) => x.id === st.activeDocId)!
      const local = localOfLast
      return { x: (local.x - d.panX) / d.zoom, y: (local.y - d.panY) / d.zoom, d, local }
    }

    let localOfLast = { x: 0, y: 0 }

    const move = (e: MouseEvent) => {
      const drag = dragRef.current
      if (!drag) return
      localOfLast = localOf(e)

      if (isPan(drag)) {
        const st = useEditor.getState()
        const d = st.docs.find((x) => x.id === st.activeDocId)
        if (!d) return
        st.panBy(d.id, e.clientX - drag.x, e.clientY - drag.y)
        drag.x = e.clientX
        drag.y = e.clientY
        return
      }

      const { x: wx, y: wy, d } = worldOf()

      if (isTransformDrag(drag)) {
        transformMove(drag, wx, wy, e.shiftKey, e.altKey)
        scheduleBump()
        setSessionTick((n) => n + 1)
        return
      }
      if (isCrop(drag)) {
        drag.x1 = wx
        drag.y1 = wy
        setCropBox({
          x0: Math.min(drag.x0, drag.x1), y0: Math.min(drag.y0, drag.y1),
          x1: Math.max(drag.x0, drag.x1), y1: Math.max(drag.y0, drag.y1),
        })
        return
      }
      if (isShape(drag)) {
        drag.x1 = wx
        drag.y1 = wy
        setShapeBox({
          x0: Math.min(drag.x0, drag.x1), y0: Math.min(drag.y0, drag.y1),
          x1: Math.max(drag.x0, drag.x1), y1: Math.max(drag.y0, drag.y1),
        })
        return
      }
      if (isMarquee(drag)) {
        drag.x1 = wx
        drag.y1 = wy
        if (drag.constrain) {
          const side = Math.max(Math.abs(wx - drag.x0), Math.abs(wy - drag.y0))
          drag.x1 = drag.x0 + Math.sign(wx - drag.x0 || 1) * side
          drag.y1 = drag.y0 + Math.sign(wy - drag.y0 || 1) * side
        }
        setMarqueeBox({ x0: drag.x0, y0: drag.y0, x1: drag.x1, y1: drag.y1, tool: drag.tool === 'marquee-rect' ? 'rect' : 'ellipse' })
        return
      }
      if (isLasso(drag)) {
        const pts = drag.points
        const lx = pts[pts.length - 2]
        const ly = pts[pts.length - 1]
        if (Math.hypot(wx - lx, wy - ly) * d.zoom > 3) {
          pts.push(wx, wy)
          setLassoPts([...pts])
        }
        return
      }
      if (isGrad(drag)) {
        drag.x1 = wx
        drag.y1 = wy
        setGradLine({ x0: drag.x0, y0: drag.y0, x1: drag.x1, y1: drag.y1 })
        return
      }
      if (isMoveLayer(drag)) {
        const dx = Math.round(wx - drag.startX)
        const dy = Math.round(wy - drag.startY)
        const layer = docLayerOf(d, drag.layerId)
        if (!layer) return
        const ctx = canvasCtx(layer.canvas)
        ctx.setTransform(1, 0, 0, 1, 0, 0)
        ctx.clearRect(0, 0, layer.canvas.width, layer.canvas.height)
        if (drag.hasSel && drag.region) {
          ctx.drawImage(drag.base, 0, 0)
          ctx.drawImage(drag.region, dx, dy)
        } else {
          ctx.drawImage(drag.base, dx, dy)
        }
        drag.lastDX = dx
        drag.lastDY = dy
        scheduleBump()
        return
      }
      if (isPenDrag(drag)) {
        const draft = penDraftRef.current
        if (!draft || draft.points.length === 0) return
        const pts = draft.points.slice()
        const last = { ...pts[pts.length - 1] }
        const vx = wx - last.x
        const vy = wy - last.y
        last.c2x = last.x + vx
        last.c2y = last.y + vy
        if (!e.altKey) {
          /* mirrored smooth handles; Alt breaks the symmetry (corner point) */
          last.c1x = last.x - vx
          last.c1y = last.y - vy
        }
        pts[pts.length - 1] = last
        updatePenDraft({ ...draft, points: pts })
        return
      }
      if (isPathEdit(drag)) {
        const draft = penDraftRef.current
        if (!draft) return
        const dx = wx - drag.lastX
        const dy = wy - drag.lastY
        drag.lastX = wx
        drag.lastY = wy
        const pts = draft.points.map((p, i) => {
          if (drag.mode === 'whole') {
            return { ...p, x: p.x + dx, y: p.y + dy, c1x: p.c1x + dx, c1y: p.c1y + dy, c2x: p.c2x + dx, c2y: p.c2y + dy }
          }
          if (i !== drag.idx) return p
          if (drag.mode === 'anchor') {
            return { ...p, x: p.x + dx, y: p.y + dy, c1x: p.c1x + dx, c1y: p.c1y + dy, c2x: p.c2x + dx, c2y: p.c2y + dy }
          }
          if (drag.side === 'out') return { ...p, c2x: p.c2x + dx, c2y: p.c2y + dy }
          return { ...p, c1x: p.c1x + dx, c1y: p.c1y + dy }
        })
        updatePenDraft({ ...draft, points: pts })
        return
      }
      if (isStroke(drag)) {
        const settings = useToolSettings.getState()
        const layer = docLayerOf(d, drag.layerId)
        if (!layer || layer.locked) return
        const layerTarget = drag.target === 'mask' ? layer.mask : layer.canvas
        const target = drag.masked ? scratch.current : layerTarget
        if (!target) return
        const spacing = Math.max(0.75, settings.brushSize * settings.brushSpacing / 100)
        /* coalesced events: dense sub-samples between rAF frames for smooth fast strokes */
        const native = e as MouseEvent & { getCoalescedEvents?: () => MouseEvent[] }
        const subs = native.getCoalescedEvents ? native.getCoalescedEvents() : []
        const events: MouseEvent[] = subs.length > 0 ? [...subs] : [e]
        for (const ev of events) {
          const l = rect ? { x: ev.clientX - rect.left, y: ev.clientY - rect.top } : localOf(ev)
          const ex = (l.x - d.panX) / d.zoom
          const ey = (l.y - d.panY) / d.zoom
          const ctx = canvasCtx(target)
          ctx.save()
          ctx.globalCompositeOperation = drag.maskMode === 'conceal' || drag.kind === 'eraser' ? 'destination-out' : 'source-over'
          walkStamp(
            ctx,
            drag.walker,
            ex, ey,
            spacing,
            {
              size: settings.brushSize,
              hardness: drag.kind === 'pencil' ? 100 : settings.brushHardness,
              color: drag.target === 'mask' ? '#ffffff' : drag.kind === 'eraser' ? '#000000' : drag.color,
              alpha: drag.masked ? settings.brushFlow / 100 : (settings.brushOpacity / 100) * (settings.brushFlow / 100),
            },
            drag.kind === 'pencil' ? 'pencil' : 'brush',
          )
          ctx.restore()
        }
        drag.painted = true
        if (drag.masked && (drag.kind === 'eraser' || drag.maskMode === 'conceal') && drag.snapshot && d.selection && scratch.current && layerTarget) {
          /* live erase preview: snapshot minus masked scratch */
          const erasedMasked = getScratchMasked(scratch.current, d.selection)
          const lctx = canvasCtx(layerTarget)
          lctx.setTransform(1, 0, 0, 1, 0, 0)
          lctx.clearRect(0, 0, layer.canvas.width, layer.canvas.height)
          lctx.drawImage(drag.snapshot, 0, 0)
          lctx.globalCompositeOperation = 'destination-out'
          lctx.drawImage(erasedMasked, 0, 0)
          lctx.globalCompositeOperation = 'source-over'
        }
        scheduleBump()
        return
      }
      if (isRetouch(drag)) {
        const settings = useToolSettings.getState()
        const spacing = Math.max(0.75, settings.brushSize * settings.brushSpacing / 100)
        const mctx = canvasCtx(drag.mask)
        walkStamp(
          mctx,
          drag.walker,
          wx, wy,
          spacing,
          { size: settings.brushSize, hardness: settings.brushHardness, color: '#ffffff', alpha: 1 },
          'brush',
        )
        drag.painted = true
        applyRetouch(drag, d)
        scheduleBump()
        return
      }
    }

    const up = () => {
      const drag = dragRef.current
      const st = useEditor.getState()
      const d = st.docs.find((x) => x.id === st.activeDocId)
      if (drag && d) {
        if (isGrad(drag)) {
          const layer = docLayerOf(d, drag.layerId)
          if (layer && !layer.locked) {
            const s = useToolSettings.getState()
            const from = s.gradientPreset === 'black-white' ? '#000000' : hexToRgba(st.fg, 1)
            const to = s.gradientPreset === 'black-white' ? '#ffffff'
              : s.gradientPreset === 'fg-transparent' ? hexToRgba(st.fg, 0) : hexToRgba(st.bg, 1)
            if (drag.masked && scratch.current) {
              paintGradient(canvasCtx(scratch.current), d.width, d.height, drag.x0, drag.y0, drag.x1, drag.y1, from, to, s.gradientType)
              const masked = getScratchMasked(scratch.current, d.selection)
              canvasCtx(layer.canvas).drawImage(masked, 0, 0)
            } else {
              paintGradient(canvasCtx(layer.canvas), d.width, d.height, drag.x0, drag.y0, drag.x1, drag.y1, from, to, s.gradientType)
            }
            st.pushHistory('Gradient')
          }
        } else if (isPenDrag(drag)) {
          /* commit handle positions after the drag; no history entry yet */
          const p = penDraftRef.current
          if (p) useEditor.getState().setWorkPath(clonePenPath(p))
        } else if (isPathEdit(drag)) {
          const p = penDraftRef.current
          if (p) {
            useEditor.getState().setWorkPath(clonePenPath(p), 'Edit Path')
            penCommittedRef.current = true
          }
        } else if (isStroke(drag)) {
          const layer = docLayerOf(d, drag.layerId)
          if (layer && drag.painted) {
            const layerTarget = drag.target === 'mask' ? layer.mask : layer.canvas
            if (drag.masked && scratch.current && drag.kind !== 'eraser' && drag.maskMode !== 'conceal' && layerTarget) {
              const masked = getScratchMasked(scratch.current, d.selection)
              const lctx = canvasCtx(layerTarget)
              lctx.save()
              lctx.globalAlpha = useToolSettings.getState().brushOpacity / 100
              lctx.drawImage(masked, 0, 0)
              lctx.restore()
            }
            st.pushHistory(drag.target === 'mask' ? 'Paint Layer Mask' : drag.kind === 'brush' ? 'Brush Stroke' : drag.kind === 'pencil' ? 'Pencil Stroke' : 'Eraser')
          }
        } else if (isMarquee(drag)) {
          commitMarquee(drag)
          setMarqueeBox(null)
        } else if (isLasso(drag)) {
          commitLasso(drag.points, drag.alt, drag.shift, true)
        } else if (isMoveLayer(drag)) {
          if (drag.lastDX !== 0 || drag.lastDY !== 0) {
            const movedLayer = docLayerOf(d, drag.layerId)
            if (movedLayer?.textData && !drag.hasSel) {
              movedLayer.textData = { ...movedLayer.textData, x: movedLayer.textData.x + drag.lastDX, y: movedLayer.textData.y + drag.lastDY }
            }
            st.pushHistory(drag.hasSel ? 'Move Selection' : 'Move Layer')
          }
        } else if (isCrop(drag)) {
          if (Math.abs(drag.x1 - drag.x0) * d.zoom < 4) setCropBox(null)
        } else if (isShape(drag)) {
          const layer = docLayerOf(d, drag.layerId)
          const x = Math.round(Math.min(drag.x0, drag.x1))
          const y = Math.round(Math.min(drag.y0, drag.y1))
          const w = Math.round(Math.abs(drag.x1 - drag.x0))
          const h = Math.round(Math.abs(drag.y1 - drag.y0))
          if (layer && !layer.locked && w > 0 && h > 0) {
            if (layer.type === 'text') { layer.type = 'pixel'; layer.textData = undefined }
            const shape = makeCanvas(d.width, d.height)
            const sctx = canvasCtx(shape)
            sctx.fillStyle = st.fg
            sctx.fillRect(x, y, w, h)
            if (d.selection) {
              sctx.globalCompositeOperation = 'destination-in'
              sctx.drawImage(d.selection.mask, 0, 0)
              sctx.globalCompositeOperation = 'source-over'
            }
            canvasCtx(layer.canvas).drawImage(shape, 0, 0)
            st.pushHistory('Rectangle Shape')
          }
          setShapeBox(null)
        } else if (isRetouch(drag)) {
          if (drag.painted) {
            const label = drag.kind === 'blur' ? 'Blur Tool'
              : drag.kind === 'dodge' ? 'Dodge / Burn'
                : drag.kind === 'stamp' ? 'Clone Stamp' : 'Healing Brush'
            st.pushHistory(label)
          }
        }
      }
      dragRef.current = null
      setDragging(false)
      setGradLine(null)
      scratchKind.current = null
    }

    window.addEventListener('mousemove', move)
    window.addEventListener('mouseup', up)
    return () => {
      window.removeEventListener('mousemove', move)
      window.removeEventListener('mouseup', up)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dragging])

  /* ---------------- transform drag math (rotated frame) ---------------- */
  function transformMove(d: TransformDragState, wx: number, wy: number, constrain = false, fromCenter = false): void {
    const sess = transformSession.current
    if (!sess) return
    if (d.mode === 'move') {
      let dx = wx - d.startX
      let dy = wy - d.startY
      if (constrain) {
        if (Math.abs(dx) > Math.abs(dy)) dy = 0
        else dx = 0
      }
      sess.cx = d.cx0 + dx
      sess.cy = d.cy0 + dy
      return
    }
    if (d.mode === 'rotate') {
      const a1 = Math.atan2(wy - sess.cy, wx - sess.cx)
      let angle = d.rot0 + (a1 - d.angle0)
      if (constrain) angle = Math.round(angle / (Math.PI / 12)) * (Math.PI / 12)
      sess.rot = angle
      return
    }
    if (d.mode === 'skew') {
      if (d.horiz) sess.skewY = d.skewY0 + (wy - d.startY) / Math.max(4, d.hw0 * 2)
      if (d.vert) sess.skewX = d.skewX0 + (wx - d.startX) / Math.max(4, d.hh0 * 2)
      return
    }
    /* scale — anchor is fixed in world space, math in the unrotated frame */
    const rot = d.rot0
    const ca = Math.cos(-rot)
    const sa = Math.sin(-rot)
    const rl = (x: number, y: number) => ({ x: ca * (x - d.cx0) - sa * (y - d.cy0), y: sa * (x - d.cx0) + ca * (y - d.cy0) })
    const l = rl(wx, wy)
    const a = rl(d.anchorX, d.anchorY)
    let clx: number
    let cly: number
    let hw: number
    let hh: number
    if (fromCenter) {
      clx = 0
      cly = 0
      hw = d.horiz ? Math.max(2, Math.abs(l.x)) : d.hw0
      hh = d.vert ? Math.max(2, Math.abs(l.y)) : d.hh0
    } else if (d.horiz && d.vert) {
      clx = (l.x + a.x) / 2
      cly = (l.y + a.y) / 2
      hw = Math.max(2, Math.abs(l.x - a.x) / 2)
      hh = Math.max(2, Math.abs(l.y - a.y) / 2)
    } else if (d.horiz) {
      clx = (l.x + a.x) / 2
      cly = 0
      hw = Math.max(2, Math.abs(l.x - a.x) / 2)
      hh = d.hh0
    } else {
      clx = 0
      cly = (l.y + a.y) / 2
      hw = d.hw0
      hh = Math.max(2, Math.abs(l.y - a.y) / 2)
    }
    if (constrain && d.horiz && d.vert) {
      const ratio = d.hw0 / Math.max(1, d.hh0)
      if (hw / Math.max(1, hh) > ratio) hh = hw / ratio
      else hw = hh * ratio
    }
    const cw = Math.cos(rot)
    const sw = Math.sin(rot)
    sess.cx = d.cx0 + cw * clx - sw * cly
    sess.cy = d.cy0 + sw * clx + cw * cly
    sess.hw = hw
    sess.hh = hh
  }

  /* ---- hit test transform handles (local rotated frame) ---- */
  function hitTransform(local: { x: number; y: number }): { mode: 'move' | 'scale' | 'rotate'; horiz: boolean; vert: boolean; ax: number; ay: number } | null {
    const sess = transformSession.current
    if (!sess || !doc) return null
    const z = doc.zoom
    const ca = Math.cos(-sess.rot)
    const sa = Math.sin(-sess.rot)
    const wx = (local.x - doc.panX) / z
    const wy = (local.y - doc.panY) / z
    const lx = ca * (wx - sess.cx) - sa * (wy - sess.cy)
    const ly = sa * (wx - sess.cx) + ca * (wy - sess.cy)
    const hw = Math.max(2, sess.hw)
    const hh = Math.max(2, sess.hh)
    const tol = 9 / z
    const near = (v: number, t: number) => Math.abs(v - t) <= tol

    const ry = -hh - 24 / z
    if (near(lx, 0) && near(ly, ry)) return { mode: 'rotate', horiz: false, vert: false, ax: 0, ay: 0 }

    const onTop = near(ly, -hh) && lx >= -hw - tol && lx <= hw + tol
    const onBottom = near(ly, hh) && lx >= -hw - tol && lx <= hw + tol
    const onLeft = near(lx, -hw) && ly >= -hh - tol && ly <= hh + tol
    const onRight = near(lx, hw) && ly >= -hh - tol && ly <= hh + tol

    if (onTop) {
      const mid = Math.abs(lx) < hw - tol
      return mid
        ? { mode: 'scale', horiz: false, vert: true, ax: 0, ay: hh }
        : { mode: 'scale', horiz: true, vert: true, ax: lx > 0 ? -hw : hw, ay: hh }
    }
    if (onBottom) {
      const mid = Math.abs(lx) < hw - tol
      return mid
        ? { mode: 'scale', horiz: false, vert: true, ax: 0, ay: -hh }
        : { mode: 'scale', horiz: true, vert: true, ax: lx > 0 ? -hw : hw, ay: -hh }
    }
    if (onLeft) {
      const mid = Math.abs(ly) < hh - tol
      return mid
        ? { mode: 'scale', horiz: true, vert: false, ax: hw, ay: 0 }
        : { mode: 'scale', horiz: true, vert: true, ax: hw, ay: ly > 0 ? -hh : hh }
    }
    if (onRight) {
      const mid = Math.abs(ly) < hh - tol
      return mid
        ? { mode: 'scale', horiz: true, vert: false, ax: -hw, ay: 0 }
        : { mode: 'scale', horiz: true, vert: true, ax: -hw, ay: ly > 0 ? -hh : hh }
    }
    if (Math.abs(lx) <= hw && Math.abs(ly) <= hh) {
      return { mode: 'move', horiz: false, vert: false, ax: 0, ay: 0 }
    }
    return null
  }

  /* ---------------- mouse down ---------------- */
  const onMouseDown = (e: React.MouseEvent) => {
    if (!doc) return
    /* transform session takes over the canvas */
    if (transformSession.current && e.button === 0) {
      const cont = containerRef.current!
      const rect = cont.getBoundingClientRect()
      const local = { x: e.clientX - rect.left, y: e.clientY - rect.top }
      const hit = hitTransform(local)
      if (!hit) return
      const z = doc.zoom
      const wx = (local.x - doc.panX) / z
      const wy = (local.y - doc.panY) / z
      const sess = transformSession.current
      const ca = Math.cos(sess.rot)
      const sa = Math.sin(sess.rot)
      dragRef.current = {
        type: 'transform',
        mode: e.ctrlKey && hit.mode === 'scale' ? 'skew' : hit.mode,
        horiz: hit.horiz,
        vert: hit.vert,
        anchorX: sess.cx + ca * hit.ax - sa * hit.ay,
        anchorY: sess.cy + sa * hit.ax + ca * hit.ay,
        startX: wx,
        startY: wy,
        rot0: sess.rot,
        angle0: Math.atan2(wy - sess.cy, wx - sess.cx),
        hw0: sess.hw,
        hh0: sess.hh,
        cx0: sess.cx,
        cy0: sess.cy,
        skewX0: sess.skewX,
        skewY0: sess.skewY,
      }
      setDragging(true)
      return
    }
    if (transformSession.current) return

    if (e.button === 1 || spaceHeld || (e.button === 0 && tool === 'hand')) {
      dragRef.current = { type: 'pan', x: e.clientX, y: e.clientY }
      setDragging(true)
      return
    }
    if (e.button !== 0) return
    const cont = containerRef.current!
    const rect = cont.getBoundingClientRect()
    const local = { x: e.clientX - rect.left, y: e.clientY - rect.top }
    const world = { x: (local.x - doc.panX) / doc.zoom, y: (local.y - doc.panY) / doc.zoom }
    const st = useEditor.getState()

    if (tool === 'zoom') {
      st.setZoom(doc.id, doc.zoom * (e.altKey ? Math.pow(2, -0.5) : Math.pow(2, 0.5)), local)
      return
    }
    if (tool === 'eyedropper' || (PAINT_TOOLS.has(tool) && e.altKey)) {
      sampleColor(world, e.altKey)
      return
    }
    if (tool === 'marquee-rect' || tool === 'marquee-ellipse') {
      dragRef.current = {
        type: 'marquee',
        tool,
        x0: world.x, y0: world.y, x1: world.x, y1: world.y,
        shift: e.shiftKey && !e.altKey,
        alt: e.altKey,
        constrain: e.shiftKey && !e.altKey && !doc.selection,
      }
      setDragging(true)
      return
    }
    if (tool === 'lasso') {
      dragRef.current = { type: 'lasso', points: [world.x, world.y], alt: e.altKey, shift: e.shiftKey && !e.altKey }
      setDragging(true)
      return
    }
    if (tool === 'lasso-poly') {
      if (!polyPts) {
        polyModeRef.current = { alt: e.altKey, shift: e.shiftKey && !e.altKey }
        setPolyPts([world.x, world.y])
      } else setPolyPts([...polyPts, world.x, world.y])
      return
    }
    if (tool === 'type') {
      commitTypeDraft() /* finalize any in-progress draft (blur may not fire on remount) */
      const active = doc.layers.find((l) => l.id === doc.activeLayerId)
      if (!active || !beginEditTextLayer(active.id)) {
        updateTypeDraft({ x: world.x, y: world.y, text: '' })
      }
      return
    }
    if (tool === 'pen') {
      const tol = 9 / doc.zoom
      const draft = penDraftRef.current
      /* click on the first anchor (≈3+ points, still open) closes the path */
      if (draft && !draft.closed && draft.points.length >= 3) {
        const p0 = draft.points[0]
        if (Math.hypot(p0.x - world.x, p0.y - world.y) <= tol) {
          const closedDraft: PenPath = { points: draft.points, closed: true }
          updatePenDraft(closedDraft)
          st.setWorkPath(clonePenPath(closedDraft), 'Draw Path')
          penCommittedRef.current = true
          return
        }
      }
      /* starting fresh replaces the previous committed path */
      if (draft?.closed) {
        updatePenDraft(null)
        penCommittedRef.current = false
      }
      const cur = penDraftRef.current
      const anchor: PenPoint = { x: world.x, y: world.y, c1x: world.x, c1y: world.y, c2x: world.x, c2y: world.y }
      const next: PenPath = { closed: false, points: cur ? [...cur.points, anchor] : [anchor] }
      updatePenDraft(next)
      dragRef.current = { type: 'pen' }
      setDragging(true)
      scheduleBump()
      return
    }
    if (tool === 'path-select') {
      const src = penDraftRef.current ?? doc.workPath
      if (!src || src.points.length === 0) {
        st.showToast('No path yet — draw one with the pen tool (P)')
        return
      }
      const working = clonePenPath(src)!
      updatePenDraft(working)
      penCommittedRef.current = true
      const tol = 9 / doc.zoom
      const h = handleHit(working.points, world.x, world.y, tol)
      if (h) {
        dragRef.current = { type: 'path-edit', mode: 'handle', idx: h.idx, side: h.side, lastX: world.x, lastY: world.y }
        setDragging(true)
        return
      }
      const a = anchorHit(working.points, world.x, world.y, tol)
      if (a >= 0) {
        dragRef.current = { type: 'path-edit', mode: 'anchor', idx: a, side: null, lastX: world.x, lastY: world.y }
        setDragging(true)
        return
      }
      if (working.closed) {
        const probe = makeCanvas(1, 1)
        const inside = canvasCtx(probe).isPointInPath(buildPath2D(working.points, true), world.x, world.y)
        if (inside) {
          dragRef.current = { type: 'path-edit', mode: 'whole', idx: -1, side: null, lastX: world.x, lastY: world.y }
          setDragging(true)
          return
        }
      }
      return
    }
    if (tool === 'wand') {
      const layer = doc.layers.find((l) => l.id === doc.activeLayerId)
      if (!layer) return
      if (layer.type === 'group' || layer.type === 'adjustment') {
        st.showToast('Select a pixel layer before using Magic Wand')
        return
      }
      const mask = floodMask(layer.canvas, world.x, world.y, useToolSettings.getState().tolerance)
      let final = mask
      let label = 'Magic Wand Selection'
      if (doc.selection && (e.altKey || e.shiftKey)) {
        final = e.altKey ? subtractMask(doc.selection.mask, mask) : combineMask(doc.selection.mask, mask)
        label = e.altKey ? 'Wand Subtract' : 'Wand Add'
      }
      st.setSelection({ mask: final, path: null }, label)
      return
    }
    if (tool === 'bucket') {
      if (world.x < 0 || world.y < 0 || world.x >= doc.width || world.y >= doc.height) return
      const layer = doc.layers.find((l) => l.id === doc.activeLayerId)
      if (!layer) return
      if (layer.locked) {
        st.showToast(`“${layer.name}” is locked — unlock it to fill`)
        return
      }
      const targetingMask = editingMaskLayerId === layer.id && !!layer.mask
      if ((layer.type === 'adjustment' || layer.type === 'group') && !targetingMask) {
        st.showToast('Target the layer mask before filling')
        return
      }
      const target = targetingMask ? layer.mask! : layer.canvas
      if (!targetingMask && layer.type === 'text') {
        layer.type = 'pixel'
        layer.textData = undefined
      }
      const region = floodMask(target, world.x, world.y, useToolSettings.getState().tolerance)
      if (doc.selection) {
        const rctx = canvasCtx(region)
        rctx.globalCompositeOperation = 'destination-in'
        rctx.drawImage(doc.selection.mask, 0, 0)
        rctx.globalCompositeOperation = 'source-over'
      }
      const targetCtx = canvasCtx(target)
      if (targetingMask) {
        const color = parseInt(st.fg.replace('#', ''), 16)
        const luma = (((color >> 16) & 255) * 0.299) + (((color >> 8) & 255) * 0.587) + ((color & 255) * 0.114)
        if (luma < 128) {
          targetCtx.save()
          targetCtx.globalCompositeOperation = 'destination-out'
          targetCtx.drawImage(region, 0, 0)
          targetCtx.restore()
        } else {
          const fill = makeCanvas(doc.width, doc.height)
          const fctx = canvasCtx(fill)
          fctx.fillStyle = '#ffffff'
          fctx.fillRect(0, 0, doc.width, doc.height)
          fctx.globalCompositeOperation = 'destination-in'
          fctx.drawImage(region, 0, 0)
          targetCtx.drawImage(fill, 0, 0)
        }
      } else {
        const fill = makeCanvas(doc.width, doc.height)
        const fctx = canvasCtx(fill)
        fctx.fillStyle = st.fg
        fctx.fillRect(0, 0, doc.width, doc.height)
        fctx.globalCompositeOperation = 'destination-in'
        fctx.drawImage(region, 0, 0)
        targetCtx.drawImage(fill, 0, 0)
      }
      st.pushHistory(targetingMask ? 'Fill Layer Mask' : 'Paint Bucket')
      return
    }
    if (tool === 'crop') {
      dragRef.current = { type: 'crop', x0: world.x, y0: world.y, x1: world.x, y1: world.y }
      setCropBox({ x0: world.x, y0: world.y, x1: world.x, y1: world.y })
      setDragging(true)
      return
    }
    if (tool === 'shape') {
      const layer = doc.layers.find((l) => l.id === doc.activeLayerId)
      if (!layer) return
      if (layer.locked) {
        st.showToast(`“${layer.name}” is locked — unlock it to draw a shape`)
        return
      }
      dragRef.current = { type: 'shape', layerId: layer.id, x0: world.x, y0: world.y, x1: world.x, y1: world.y }
      setShapeBox({ x0: world.x, y0: world.y, x1: world.x, y1: world.y })
      setDragging(true)
      return
    }
    if (tool === 'move') {
      const layer = doc.layers.find((l) => l.id === doc.activeLayerId)
      if (!layer) return
      if (layer.locked) {
        st.showToast(`"${layer.name}" is locked — unlock it in the Layers panel`)
        return
      }
      if (layer.type === 'group' || layer.type === 'adjustment') {
        st.showToast('Select a pixel or text layer to move its content')
        return
      }
      const snapshot = cloneCanvas(layer.canvas)
      let base: HTMLCanvasElement = snapshot
      let region: HTMLCanvasElement | null = null
      if (doc.selection) {
        if (layer.type === 'text') { layer.type = 'pixel'; layer.textData = undefined }
        region = cloneCanvas(snapshot)
        const rctx = canvasCtx(region)
        rctx.globalCompositeOperation = 'destination-in'
        rctx.drawImage(doc.selection.mask, 0, 0)
        rctx.globalCompositeOperation = 'source-over'
        base = cloneCanvas(snapshot)
        const bctx = canvasCtx(base)
        bctx.globalCompositeOperation = 'destination-out'
        bctx.drawImage(doc.selection.mask, 0, 0)
        bctx.globalCompositeOperation = 'source-over'
      }
      dragRef.current = {
        type: 'move',
        layerId: layer.id,
        base,
        region,
        startX: world.x,
        startY: world.y,
        lastDX: 0,
        lastDY: 0,
        hasSel: !!doc.selection,
      }
      setDragging(true)
      return
    }
    if (RETOUCH_TOOLS.has(tool)) {
      const kind = tool as RetouchState['kind']
      const layer = doc.layers.find((l) => l.id === doc.activeLayerId)
      if (!layer) return
      if (layer.type === 'adjustment' || layer.type === 'group') {
        st.showToast('Target the adjustment layer mask or select a pixel layer to retouch')
        return
      }
      if (layer.locked) {
        st.showToast(`“${layer.name}” is locked — unlock it to retouch`)
        return
      }
      if (layer.type === 'text') { layer.type = 'pixel'; layer.textData = undefined }
      if ((kind === 'stamp' || kind === 'heal') && e.altKey) {
        cloneSource.current = { layerId: layer.id, x: world.x, y: world.y }
        st.showToast(`${kind === 'stamp' ? 'Clone' : 'Healing'} source set`)
        return
      }
      const sourcePoint = cloneSource.current
      if ((kind === 'stamp' || kind === 'heal') && (!sourcePoint || sourcePoint.layerId !== layer.id)) {
        st.showToast('Alt+click the active layer to set a source first')
        return
      }
      const settings = useToolSettings.getState()
      const spacing = Math.max(0.75, settings.brushSize * settings.brushSpacing / 100)
      const snapshot = cloneCanvas(layer.canvas)
      const mask = makeCanvas(doc.width, doc.height)
      stampAlongLine(
        canvasCtx(mask), world.x, world.y, world.x, world.y, spacing,
        { size: settings.brushSize, hardness: settings.brushHardness, color: '#ffffff', alpha: 1 },
        'brush',
      )
      const drag: RetouchState = {
        type: 'retouch',
        kind,
        layerId: layer.id,
        snapshot,
        source: makeRetouchSource(snapshot, kind, world.x, world.y, sourcePoint, e.altKey),
        mask,
        result: makeCanvas(doc.width, doc.height),
        walker: beginWalker(world.x, world.y, spacing),
        painted: true,
        opacity: (settings.brushOpacity / 100) * (kind === 'heal' ? 0.7 : 1),
      }
      dragRef.current = drag
      applyRetouch(drag, doc)
      setDragging(true)
      scheduleBump()
      return
    }
    if (PAINT_TOOLS.has(tool) || tool === 'gradient') {
      const layer = doc.layers.find((l) => l.id === doc.activeLayerId)
      if (!layer) return
      if (layer.locked) {
        st.showToast(`"${layer.name}" is locked — unlock it in the Layers panel to paint`)
        return
      }
      const targetingLayerMask = editingMaskLayerId === layer.id && !!layer.mask
      if ((layer.type === 'adjustment' || layer.type === 'group') && !targetingLayerMask) {
        st.showToast('Add or target this layer mask to paint on it')
        return
      }
      if ((layer.type === 'adjustment' || layer.type === 'group') && tool === 'gradient') {
        st.showToast('Use Brush, Pencil, or Eraser to edit an adjustment mask')
        return
      }
      if (!targetingLayerMask && layer.type === 'text') { layer.type = 'pixel'; layer.textData = undefined }
      const masked = !!doc.selection
      if (PAINT_TOOLS.has(tool)) {
        const settings = useToolSettings.getState()
        const spacing = Math.max(0.75, settings.brushSize * settings.brushSpacing / 100)
        const targetingMask = targetingLayerMask
        const paintTarget = targetingMask ? layer.mask! : layer.canvas
        const fgValue = parseInt(st.fg.replace('#', ''), 16)
        const fgLuma = (((fgValue >> 16) & 255) * 0.299) + (((fgValue >> 8) & 255) * 0.587) + ((fgValue & 255) * 0.114)
        const maskMode: StrokeState['maskMode'] = targetingMask
          ? (tool === 'eraser' || fgLuma < 128 ? 'conceal' : 'reveal')
          : null
        if (masked) {
          scratch.current = makeCanvas(doc.width, doc.height)
          scratchKind.current = 'paint'
          const sctx = canvasCtx(scratch.current)
          stampAlongLine(
            sctx, world.x, world.y, world.x, world.y, spacing,
            {
              size: settings.brushSize,
              hardness: tool === 'pencil' ? 100 : settings.brushHardness,
              color: targetingMask ? '#ffffff' : tool === 'eraser' ? '#000000' : st.fg,
              alpha: settings.brushFlow / 100,
            },
            tool === 'pencil' ? 'pencil' : 'brush',
          )
        } else {
          /* single dot straight onto the layer */
          const ctx = canvasCtx(paintTarget)
          ctx.save()
          ctx.globalCompositeOperation = maskMode === 'conceal' || tool === 'eraser' ? 'destination-out' : 'source-over'
          stampAlongLine(
            ctx, world.x, world.y, world.x, world.y, spacing,
            {
              size: settings.brushSize,
              hardness: tool === 'pencil' ? 100 : settings.brushHardness,
              color: targetingMask ? '#ffffff' : tool === 'eraser' ? '#000000' : st.fg,
              alpha: (settings.brushOpacity / 100) * (settings.brushFlow / 100),
            },
            tool === 'pencil' ? 'pencil' : 'brush',
          )
          ctx.restore()
        }
        dragRef.current = {
          type: 'stroke',
          kind: tool as 'brush' | 'pencil' | 'eraser',
          layerId: layer.id,
          color: st.fg,
          walker: beginWalker(world.x, world.y, spacing),
          painted: true,
          masked,
          snapshot: masked ? cloneCanvas(paintTarget) : null,
          target: targetingMask ? 'mask' : 'pixels',
          maskMode,
        }
        setDragging(true)
        if (masked && (tool === 'eraser' || maskMode === 'conceal') && scratch.current && doc.selection) {
          const erasedMasked = getScratchMasked(scratch.current, doc.selection)
          const lctx = canvasCtx(paintTarget)
          lctx.clearRect(0, 0, paintTarget.width, paintTarget.height)
          lctx.drawImage(dragRef.current.snapshot!, 0, 0)
          lctx.globalCompositeOperation = 'destination-out'
          lctx.drawImage(erasedMasked, 0, 0)
          lctx.globalCompositeOperation = 'source-over'
        }
        scheduleBump()
      } else {
        if (masked) {
          scratch.current = makeCanvas(doc.width, doc.height)
          scratchKind.current = 'paint'
        }
        dragRef.current = {
          type: 'gradient',
          layerId: layer.id,
          x0: world.x, y0: world.y, x1: world.x, y1: world.y,
          masked,
        }
        setDragging(true)
      }
    }
  }

  /* crop commit: Enter / Esc — also triggered from the right-click menu */
  useEffect(() => {
    if (!cropBox) return
    const apply = () => {
      const st = useEditor.getState()
      const d = st.docs.find((x) => x.id === st.activeDocId)
      if (d) {
        st.cropDocument(
          Math.round(cropBox.x0), Math.round(cropBox.y0),
          Math.round(cropBox.x1 - cropBox.x0), Math.round(cropBox.y1 - cropBox.y0),
        )
      }
      setCropBox(null)
    }
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Enter') apply()
      if (e.key === 'Escape') setCropBox(null)
    }
    const onCtxApply = () => apply()
    const onCtxCancel = () => setCropBox(null)
    window.addEventListener('keydown', onKey)
    window.addEventListener('pc:cropApply', onCtxApply)
    window.addEventListener('pc:cropCancel', onCtxCancel)
    return () => {
      window.removeEventListener('keydown', onKey)
      window.removeEventListener('pc:cropApply', onCtxApply)
      window.removeEventListener('pc:cropCancel', onCtxCancel)
    }
  }, [cropBox])

  /* double-click closes polygonal lasso */
  useEffect(() => {
    const onDbl = (e: MouseEvent) => {
      if (!polyPts) return
      e.preventDefault()
      commitLasso(polyPts, polyModeRef.current.alt, polyModeRef.current.shift, false)
      setPolyPts(null)
    }
    const el = containerRef.current
    el?.addEventListener('dblclick', onDbl)
    return () => el?.removeEventListener('dblclick', onDbl)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [polyPts, doc?.id])

  /* ---------------- empty state ---------------- */
  if (!doc) {
    return (
      <div className="docview-empty">
        <div className="empty-card">
          <div className="empty-title">Photoclone</div>
          <div className="empty-sub">No document open</div>
          <div className="empty-hint">
            Create a new canvas or open an image to start editing. Everything stays on this machine.
          </div>
          <div className="empty-actions">
            <button className="btn primary" onClick={() => (globalThis as any).__photocloneOpenNew?.()}>New — Ctrl+N</button>
            <button className="btn" onClick={() => (globalThis as any).__photocloneOpenFile?.()}>Open — Ctrl+O</button>
          </div>
        </div>
      </div>
    )
  }

  const cursorCss =
    spaceHeld || (dragging && dragRef.current?.type === 'pan')
      ? 'grabbing'
      : tool === 'hand'
        ? 'grab'
        : CURSORS[tool] ?? 'default'

  const showBrushRing = (PAINT_TOOLS.has(tool) || RETOUCH_TOOLS.has(tool)) && cursor !== null && cursorCss === 'crosshair'

  return (
    <div className="docview">
      <div className="tab-strip" role="tablist">
        {docs.map((d) => (
          <div
            key={d.id}
            role="tab"
            aria-selected={d.id === activeDocId}
            aria-grabbed={tabDrag?.id === d.id}
            draggable
            title={`${d.dirty ? 'Unsaved changes · ' : ''}Drag to reorder document tabs`}
            className={`doc-tab ${d.id === activeDocId ? 'active' : ''} ${tabDrag?.id === d.id ? 'dragging' : ''} ${tabDrag?.overId === d.id ? `drop-${tabDrag.side}` : ''}`}
            onClick={() => {
              if (!tabJustDragged.current) useEditor.getState().setActiveDoc(d.id)
            }}
            onDragStart={(e) => {
              if ((e.target as HTMLElement).closest('.doc-tab-close')) {
                e.preventDefault()
                return
              }
              tabJustDragged.current = true
              e.dataTransfer.effectAllowed = 'move'
              e.dataTransfer.setData('application/x-photoclone-doc', d.id)
              e.dataTransfer.setData('text/plain', d.name)
              setTabDrag({ id: d.id, overId: null, side: 'after' })
            }}
            onDragOver={(e) => {
              const dragId = tabDrag?.id || e.dataTransfer.getData('application/x-photoclone-doc')
              if (!dragId || dragId === d.id) return
              e.preventDefault()
              e.dataTransfer.dropEffect = 'move'
              const r = e.currentTarget.getBoundingClientRect()
              const side = e.clientX < r.left + r.width / 2 ? 'before' : 'after'
              setTabDrag((cur) => cur ? { ...cur, overId: d.id, side } : { id: dragId, overId: d.id, side })
            }}
            onDrop={(e) => {
              e.preventDefault()
              const dragId = tabDrag?.id || e.dataTransfer.getData('application/x-photoclone-doc')
              if (dragId && dragId !== d.id) {
                useEditor.getState().reorderDoc(dragId, d.id, tabDrag?.side ?? 'before')
              }
              setTabDrag(null)
            }}
            onDragEnd={() => {
              setTabDrag(null)
              window.setTimeout(() => { tabJustDragged.current = false }, 0)
            }}
            onMouseDown={(e) => {
              if (e.button === 1) {
                e.preventDefault()
                useEditor.getState().closeDoc(d.id)
              }
            }}
          >
            <span className="doc-tab-name">{d.name}{d.dirty ? ' *' : ''}</span>
            <button
              className="doc-tab-close"
              title="Close"
              draggable={false}
              onClick={(e) => {
                e.stopPropagation()
                useEditor.getState().closeDoc(d.id)
              }}
            >
              ×
            </button>
          </div>
        ))}
        <div
          className={`tab-strip-spacer ${tabDrag?.overId === null && tabDrag ? 'drop-end' : ''}`}
          onDragOver={(e) => {
            if (!tabDrag) return
            e.preventDefault()
            e.dataTransfer.dropEffect = 'move'
            setTabDrag((cur) => cur ? { ...cur, overId: null, side: 'after' } : cur)
          }}
          onDrop={(e) => {
            e.preventDefault()
            const dragId = tabDrag?.id || e.dataTransfer.getData('application/x-photoclone-doc')
            if (dragId) useEditor.getState().reorderDoc(dragId, null, 'after')
            setTabDrag(null)
          }}
        />
      </div>

      <div
        ref={containerRef}
        className="doc-viewport"
        style={{ cursor: cursorCss }}
        onMouseDown={onMouseDown}
        onMouseMove={(e) => {
          if (!PAINT_TOOLS.has(tool) && !RETOUCH_TOOLS.has(tool)) return setCursor(null)
          const rect = (e.currentTarget as HTMLElement).getBoundingClientRect()
          setCursor({ x: e.clientX - rect.left, y: e.clientY - rect.top })
        }}
        onMouseLeave={() => setCursor(null)}
        onContextMenu={(e) => e.preventDefault()}
      >
        <canvas ref={canvasRef} style={{ width: '100%', height: '100%', display: 'block' }} />
        <canvas
          ref={overlayRef}
          className="overlay-canvas"
          style={{ width: '100%', height: '100%', display: 'block' }}
        />

        {showBrushRing && cursor && (
          <div
            className="brush-ring"
            style={{
              width: Math.max(6, useToolSettings.getState().brushSize * doc.zoom),
              height: Math.max(6, useToolSettings.getState().brushSize * doc.zoom),
              left: cursor.x,
              top: cursor.y,
            }}
          />
        )}

        {gradLine && doc && (
          <svg className="grad-preview">
            <line
              x1={gradLine.x0 * doc.zoom + doc.panX}
              y1={gradLine.y0 * doc.zoom + doc.panY}
              x2={gradLine.x1 * doc.zoom + doc.panX}
              y2={gradLine.y1 * doc.zoom + doc.panY}
            />
            <circle cx={gradLine.x0 * doc.zoom + doc.panX} cy={gradLine.y0 * doc.zoom + doc.panY} r={3} />
            <circle cx={gradLine.x1 * doc.zoom + doc.panX} cy={gradLine.y1 * doc.zoom + doc.panY} r={3} />
          </svg>
        )}

        {typeDraft && doc && (
          <textarea
            className="type-draft"
            autoFocus
            value={typeDraft.text}
            placeholder="Type here…"
            spellCheck={false}
            style={{
              left: typeDraft.x * doc.zoom + doc.panX,
              top: typeDraft.y * doc.zoom + doc.panY,
              fontSize: `${textSize * doc.zoom}px`,
              lineHeight: `${(textLeading > 0 ? textLeading : textSize * 1.2) * doc.zoom}px`,
              fontFamily: `'${textFont}', sans-serif`,
              fontWeight: textBold ? 700 : 400,
              fontStyle: textItalic ? 'italic' : 'normal',
              color: textColor,
              width: textMode === 'paragraph' ? `${textBoxWidth * doc.zoom}px` : undefined,
              height: textMode === 'paragraph' ? `${textBoxHeight * doc.zoom}px` : undefined,
              textAlign: textAlign === 'justify' ? 'justify' : textAlign,
              letterSpacing: `${textSize * textTracking / 1000 * doc.zoom}px`,
              writingMode: textOrientation === 'vertical' ? 'vertical-rl' : 'horizontal-tb',
              textDecoration: `${textUnderline ? 'underline ' : ''}${textStrike ? 'line-through' : ''}` || 'none',
            }}
            onChange={(e) => updateTypeDraft({ ...typeDraft, text: e.target.value })}
            onKeyDown={(e) => {
              e.stopPropagation()
              if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                e.preventDefault()
                commitTypeDraft()
              } else if (e.key === 'Escape') {
                e.preventDefault()
                e.stopPropagation()
                cancelTypeDraft()
              }
            }}
            onMouseDown={(e) => e.stopPropagation()}
          />
        )}
      </div>
    </div>
  )
}
