import { useEffect, useRef } from 'react'
import { makeCanvas, canvasCtx } from '../editor/store'

/** Draws a small live thumbnail of a layer (checker + content, contain-fit). */
export function LayerThumb({ canvas, revision }: { canvas: HTMLCanvasElement; revision: number }) {
  const ref = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const out = ref.current
    if (!out) return
    const octx = canvasCtx(out)
    octx.clearRect(0, 0, out.width, out.height)
    /* checker */
    const tile = makeCanvas(8, 8)
    const tctx = canvasCtx(tile)
    tctx.fillStyle = '#9a9a9a'
    tctx.fillRect(0, 0, 8, 8)
    tctx.fillStyle = '#c6c6c6'
    tctx.fillRect(0, 0, 4, 4)
    tctx.fillRect(4, 4, 4, 4)
    octx.fillStyle = octx.createPattern(tile, 'repeat')!
    octx.fillRect(0, 0, out.width, out.height)
    /* content contain-fit */
    const s = Math.min(out.width / canvas.width, out.height / canvas.height)
    const w = canvas.width * s
    const h = canvas.height * s
    if (w > 0 && h > 0 && Number.isFinite(w)) {
      octx.imageSmoothingEnabled = s < 1
      octx.drawImage(canvas, (out.width - w) / 2, (out.height - h) / 2, w, h)
    }
  }, [canvas, revision])

  return <canvas ref={ref} className="layer-thumb" width={44} height={34} />
}
