import { useEffect, useRef, useState } from 'react'
import { MenuDef, MenuEntry } from './menus'

interface Props {
  menus: MenuDef[]
  onOpenChange?: (open: boolean) => void
}

function Item({
  entry,
  onPick,
}: {
  entry: MenuEntry
  onPick: (e: MenuEntry) => void
}) {
  if ((entry as any).label === 'sep') {
    return <div className="menu-sep" />
  }
  return (
    <button
      type="button"
      disabled={entry.disabled}
      className="menu-item"
      onClick={() => onPick(entry)}
    >
      <span className="menu-item-label">{entry.label}</span>
      {entry.accel && <span className="menu-item-accel">{entry.accel}</span>}
    </button>
  )
}

export default function MenuBar({ menus, onOpenChange }: Props) {
  const [open, setOpen] = useState<string | null>(null)
  const barRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!open) return
    const close = (ev: MouseEvent) => {
      if (barRef.current && !barRef.current.contains(ev.target as Node)) setOpen(null)
    }
    document.addEventListener('mousedown', close)
    return () => document.removeEventListener('mousedown', close)
  }, [open])

  useEffect(() => {
    onOpenChange?.(open !== null)
  }, [open, onOpenChange])

  const pick = (entry: MenuEntry) => {
    setOpen(null)
    entry.onSelect?.()
  }

  return (
    <div className="menubar" ref={barRef} onMouseLeave={() => { /* keep open while inside */ }}>
      <div className="brand">
        <span className="brand-mark" aria-hidden>
          Ps
        </span>
        <span className="brand-name">Photoclone</span>
      </div>
      {menus.map((m) => (
        <div key={m.label} className="menu-root">
          <button
            type="button"
            className={`menubar-top ${open === m.label ? 'open' : ''}`}
            onClick={() => setOpen(open === m.label ? null : m.label)}
            onMouseEnter={() => open && setOpen(m.label)}
          >
            {m.label}
          </button>
          {open === m.label && (
            <div className="menu-panel" role="menu">
              {m.entries.map((e, i) => (
                <Item key={i} entry={e} onPick={pick} />
              ))}
            </div>
          )}
        </div>
      ))}
      <div className="menubar-spacer" />
    </div>
  )
}
