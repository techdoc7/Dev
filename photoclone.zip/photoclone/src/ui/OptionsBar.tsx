import { useEditor } from '../editor/store'
import { useToolSettings, FONT_LIST } from '../editor/toolSettings'
import { TOOL_BY_ID } from '../editor/tools'

function NumField({
  label,
  value,
  min,
  max,
  step = 1,
  onChange,
}: {
  label: string
  value: number
  min: number
  max: number
  step?: number
  onChange: (v: number) => void
}) {
  return (
    <label className="opt-field">
      <span className="opt-label">{label}</span>
      <span className="opt-numwrap">
        <input
          type="number"
          className="opt-num"
          value={value}
          min={min}
          max={max}
          step={step}
          onChange={(e) => {
            const v = Number(e.target.value)
            if (!Number.isNaN(v)) onChange(Math.min(max, Math.max(min, v)))
          }}
        />
      </span>
    </label>
  )
}

function Slider({
  label,
  value,
  onChange,
  suffix = '',
}: {
  label: string
  value: number
  onChange: (v: number) => void
  suffix?: string
}) {
  return (
    <label className="opt-field">
      <span className="opt-label">{label}</span>
      <input
        type="range"
        min={0}
        max={100}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="opt-slider"
      />
      <span className="opt-value">
        {value}
        {suffix}
      </span>
    </label>
  )
}

const PAINT_TOOLS = new Set(['brush', 'pencil', 'eraser'])
const RETOUCH_TOOLS = new Set(['blur', 'dodge', 'stamp', 'heal'])

export default function OptionsBar() {
  const tool = useEditor((s) => s.tool)
  const ts = useToolSettings()
  const doc = useEditor((s) => s.docs.find((d) => d.id === s.activeDocId))
  const editingMaskLayerId = useEditor((s) => s.editingMaskLayerId)
  const transformActive = useEditor((s) => s.transformActive)
  const def = TOOL_BY_ID.get(tool)

  return (
    <div className="options-bar">
      <span className="opt-tool-name">{def?.label ?? 'Tool'}</span>
      <span className="opt-divider" />

      {transformActive && (
        <>
          <span className="opt-static">Drag inside to move · handles scale · top handle rotates · Shift constrains · Alt scales from center · Ctrl+edge skews</span>
          <button type="button" className="btn-xs opt-btn" onClick={() => window.dispatchEvent(new CustomEvent('pc:transformRotate', { detail: -90 }))}>↶ 90°</button>
          <button type="button" className="btn-xs opt-btn" onClick={() => window.dispatchEvent(new CustomEvent('pc:transformRotate', { detail: 90 }))}>↷ 90°</button>
          <button type="button" className="btn-xs opt-btn" onClick={() => window.dispatchEvent(new CustomEvent('pc:transformFlip', { detail: 'h' }))}>Flip H</button>
          <button type="button" className="btn-xs opt-btn" onClick={() => window.dispatchEvent(new CustomEvent('pc:transformFlip', { detail: 'v' }))}>Flip V</button>
          <button type="button" className="btn-xs opt-btn transform-commit" onClick={() => window.dispatchEvent(new Event('pc:transformCommit'))}>✓ Commit</button>
          <button type="button" className="btn-xs opt-btn" onClick={() => window.dispatchEvent(new Event('pc:transformCancel'))}>× Cancel</button>
        </>
      )}

      {PAINT_TOOLS.has(tool) && (
        <>
          <NumField label="Size" value={ts.brushSize} min={1} max={5000} onChange={(v) => ts.set('brushSize', v)} />
          {tool !== 'pencil' && (
            <>
              <Slider label="Hardness" value={ts.brushHardness} suffix="%" onChange={(v) => ts.set('brushHardness', v)} />
            </>
          )}
          <Slider label="Opacity" value={ts.brushOpacity} suffix="%" onChange={(v) => ts.set('brushOpacity', v)} />
          <Slider label="Flow" value={ts.brushFlow} suffix="%" onChange={(v) => ts.set('brushFlow', v)} />
          <Slider label="Spacing" value={ts.brushSpacing} suffix="%" onChange={(v) => ts.set('brushSpacing', Math.max(1, v))} />
          <span className="opt-static">
            {editingMaskLayerId ? 'Painting layer mask · white reveals, black conceals' : 'Alt+click samples color · Space-drag pans'}
          </span>
        </>
      )}

      {tool === 'gradient' && (
        <>
          <label className="opt-field">
            <span className="opt-label">Preset</span>
            <select
              className="opt-select"
              value={ts.gradientPreset}
              onChange={(e) => ts.set('gradientPreset', e.target.value as any)}
            >
              <option value="fg-bg">Foreground → Background</option>
              <option value="fg-transparent">Foreground → Transparent</option>
              <option value="black-white">Black → White</option>
            </select>
          </label>
          <label className="opt-field">
            <span className="opt-label">Type</span>
            <select
              className="opt-select"
              value={ts.gradientType}
              onChange={(e) => ts.set('gradientType', e.target.value as any)}
            >
              <option value="linear">Linear</option>
              <option value="radial">Radial</option>
            </select>
          </label>
          <span className="opt-static">Drag across the canvas to paint the gradient into the active layer</span>
        </>
      )}

      {tool === 'bucket' && (
        <>
          <NumField label="Tolerance" value={ts.tolerance} min={0} max={255} onChange={(v) => ts.set('tolerance', v)} />
          <span className="opt-static">Click to fill a contiguous area · selection and targeted layer masks are respected</span>
        </>
      )}

      {RETOUCH_TOOLS.has(tool) && (
        <>
          <NumField label="Size" value={ts.brushSize} min={1} max={1000} onChange={(v) => ts.set('brushSize', v)} />
          <Slider label="Hardness" value={ts.brushHardness} suffix="%" onChange={(v) => ts.set('brushHardness', v)} />
          <Slider label="Strength" value={ts.brushOpacity} suffix="%" onChange={(v) => ts.set('brushOpacity', v)} />
          <Slider label="Spacing" value={ts.brushSpacing} suffix="%" onChange={(v) => ts.set('brushSpacing', Math.max(1, v))} />
          <span className="opt-static">
            {tool === 'stamp' || tool === 'heal'
              ? 'Alt+click sets the source · drag to retouch'
              : tool === 'dodge'
                ? 'Drag to lighten · Alt-drag darkens'
                : 'Drag to soften detail'}
          </span>
        </>
      )}

      {tool === 'shape' && <span className="opt-static">Drag to draw a filled rectangle using the foreground color</span>}

      {(tool === 'wand' || tool === 'lasso' || tool === 'lasso-poly' || tool === 'marquee-rect' || tool === 'marquee-ellipse') && (
        <>
          {tool === 'wand' && (
            <NumField label="Tolerance" value={ts.tolerance} min={0} max={255} onChange={(v) => ts.set('tolerance', v)} />
          )}
          <NumField label="Feather (px)" value={ts.feather} min={0} max={250} onChange={(v) => ts.set('feather', v)} />
          <span className="opt-static">Shift-drag adds · Alt-drag subtracts · Feather applies on new selections</span>
        </>
      )}

      {tool === 'crop' && <span className="opt-static">Drag a region · Enter applies the crop · Esc cancels</span>}
      {tool === 'move' && <span className="opt-static">Drag to move the active layer (or the selection inside it)</span>}
      {tool === 'eyedropper' && <span className="opt-static">Click the canvas to sample · Alt+click samples into the background chip</span>}
      {tool === 'zoom' && <span className="opt-static">Click to zoom in · Alt+click to zoom out</span>}
      {tool === 'hand' && <span className="opt-static">Drag to pan · Space bar with any tool pans too</span>}
      {tool === 'type' && (
        <>
          <button type="button" className="btn-xs opt-btn" disabled={!doc} onClick={() => window.dispatchEvent(new Event('pc:newText'))}>New Text</button>
          <label className="opt-field"><span className="opt-label">Type</span><select className="opt-select" value={ts.textMode} onChange={(e) => ts.set('textMode', e.target.value as any)}><option value="point">Point</option><option value="paragraph">Paragraph</option></select></label>
          <label className="opt-field"><span className="opt-label">Direction</span><select className="opt-select" value={ts.textOrientation} onChange={(e) => ts.set('textOrientation', e.target.value as any)}><option value="horizontal">Horizontal</option><option value="vertical">Vertical</option></select></label>
          <label className="opt-field">
            <span className="opt-label">Font</span>
            <select
              className="opt-select"
              value={ts.textFont}
              onChange={(e) => ts.set('textFont', e.target.value)}
            >
              {FONT_LIST.map((f) => (
                <option key={f} value={f} style={{ fontFamily: `'${f}'` }}>{f}</option>
              ))}
            </select>
          </label>
          <NumField label="Size" value={ts.textSize} min={4} max={1200} onChange={(v) => ts.set('textSize', v)} />
          <NumField label="Leading" value={ts.textLeading} min={0} max={2000} onChange={(v) => ts.set('textLeading', v)} />
          <NumField label="Tracking" value={ts.textTracking} min={-500} max={2000} onChange={(v) => ts.set('textTracking', v)} />
          <label className="opt-field"><span className="opt-label">Align</span><select className="opt-select" value={ts.textAlign} onChange={(e) => ts.set('textAlign', e.target.value as any)}><option value="left">Left</option><option value="center">Center</option><option value="right">Right</option><option value="justify">Justify</option></select></label>
          {ts.textMode === 'paragraph' && (
            <>
              <NumField label="Box W" value={ts.textBoxWidth} min={20} max={10000} onChange={(v) => ts.set('textBoxWidth', v)} />
              <NumField label="Box H" value={ts.textBoxHeight} min={20} max={10000} onChange={(v) => ts.set('textBoxHeight', v)} />
            </>
          )}
          <button
            type="button"
            className={`opt-toggle ${ts.textBold ? 'on' : ''}`}
            style={{ fontWeight: 700 }}
            title="Bold"
            onClick={() => ts.set('textBold', !ts.textBold)}
          >
            B
          </button>
          <button type="button" className={`opt-toggle ${ts.textUnderline ? 'on' : ''}`} style={{ textDecoration: 'underline' }} title="Underline" onClick={() => ts.set('textUnderline', !ts.textUnderline)}>U</button>
          <button type="button" className={`opt-toggle ${ts.textStrike ? 'on' : ''}`} style={{ textDecoration: 'line-through' }} title="Strikethrough" onClick={() => ts.set('textStrike', !ts.textStrike)}>S</button>
          <button
            type="button"
            className={`opt-toggle ${ts.textItalic ? 'on' : ''}`}
            style={{ fontStyle: 'italic' }}
            title="Italic"
            onClick={() => ts.set('textItalic', !ts.textItalic)}
          >
            I
          </button>
          <label className="opt-field">
            <span className="opt-label">Color</span>
            <input
              className="opt-color"
              type="color"
              value={ts.textColor}
              onChange={(e) => ts.set('textColor', e.target.value)}
            />
          </label>
          <button type="button" className="btn-xs opt-btn" onClick={() => window.dispatchEvent(new Event('pc:textCommit'))}>✓ Commit</button>
          <button type="button" className="btn-xs opt-btn" onClick={() => window.dispatchEvent(new Event('pc:textCancel'))}>× Cancel</button>
          <span className="opt-static">Click canvas or New Text · Enter adds a line · Ctrl+Enter commits · double-click a text layer to edit</span>
        </>
      )}

      {tool === 'pen' && (
        <>
          <span className="opt-static">Click adds a corner · drag pulls out handles · Alt breaks symmetry · click the first anchor to close · Esc pops a point</span>
          <span className="opt-divider" />
          <button type="button" className="btn-xs opt-btn" disabled={!doc?.workPath} onClick={() => useEditor.getState().pathMakeSelection(ts.feather)}>Make Selection</button>
          <button type="button" className="btn-xs opt-btn" onClick={() => {
            const st = useEditor.getState()
            st.pathStroke({ color: st.fg, size: ts.brushSize, hardness: ts.brushHardness, opacity: ts.brushOpacity })
          }}>Stroke Path</button>
        </>
      )}

      {tool === 'path-select' && (
        <>
          <span className="opt-static">Drag anchors to move · drag handle knobs to reshape · drag inside a closed path translates it</span>
          <span className="opt-divider" />
          <button type="button" className="btn-xs opt-btn" disabled={!doc?.workPath} onClick={() => useEditor.getState().pathMakeSelection(ts.feather)}>Make Selection</button>
          <button type="button" className="btn-xs opt-btn" onClick={() => {
            const st = useEditor.getState()
            st.pathStroke({ color: st.fg, size: ts.brushSize, hardness: ts.brushHardness, opacity: ts.brushOpacity })
          }}>Stroke Path</button>
        </>
      )}

      <span className="opt-flex" />

      {doc && (
        <span className="opt-docmeta" title="Document size">
          {doc.width} × {doc.height} px
        </span>
      )}
    </div>
  )
}
