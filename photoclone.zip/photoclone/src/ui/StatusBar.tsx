import { useEditor } from '../editor/store'

export default function StatusBar() {
  const doc = useEditor((s) => s.docs.find((d) => d.id === s.activeDocId))
  const tool = useEditor((s) => s.tool)
  const persistenceStatus = useEditor((s) => s.persistenceStatus)
  const lastAutosave = useEditor((s) => s.lastAutosave)
  const zoom = doc ? doc.zoom : 1
  const pct = Math.round(zoom * 100)

  const setPct = (p: number) => {
    const st = useEditor.getState()
    if (!doc) return
    st.setZoom(doc.id, Math.min(32, Math.max(0.0078125, p / 100)))
  }

  return (
    <div className="statusbar">
      <span className="status-zoom" title="Document zoom — click × steps">
        <button className="mini" onClick={() => setPct(zoom * 100 / 1.27)}>−</button>
        <span className="zoom-val">{pct}%</span>
        <button className="mini" onClick={() => setPct(zoom * 100 * 1.27)}>＋</button>
      </span>
      <span className="status-sep" />
      <span className="status-dims">{doc ? `${doc.width} × ${doc.height} px (${doc.layers.length} layer${doc.layers.length === 1 ? '' : 's'})` : 'No document'}</span>
      <span className="status-flex" />
      <span
        className={`status-save status-${persistenceStatus}`}
        title={lastAutosave ? `Last local autosave: ${new Date(lastAutosave).toLocaleString()}` : 'IndexedDB local autosave'}
      >
        {persistenceStatus === 'saving' ? 'saving…' : persistenceStatus === 'error' ? 'autosave error' : lastAutosave ? 'autosaved' : 'autosave ready'}
      </span>
      <span className="status-sep" />
      <span className="status-doc">{doc ? doc.name : ''}</span>
      <span className="status-sep" />
      <span className="status-tool">{tool.replace('-', ' ')}</span>
      <span className="status-brand">offline · everything stays local</span>
    </div>
  )
}
