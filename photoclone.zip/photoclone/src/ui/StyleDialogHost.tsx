/* Layer Style dialog — non-destructive stroke & drop shadow.
   Opened via `pc:openStyle` CustomEvent, detail: { tab: 'stroke' | 'shadow' }.
   Changes live-apply to the active layer (no history spam); Cancel restores
   the style captured at open, OK pushes a history entry, Clear removes all. */

import { useEffect, useState } from 'react'
import { useEditor } from '../editor/store'
import { LayerStyle } from '../editor/types'

type StyleTab = 'stroke' | 'shadow'

interface OpenState {
  layerId: string
  layerName: string
  tab: StyleTab
  prev: LayerStyle | null
  key: number
}

const DEFAULT_STROKE = { width: 3, color: '#ff6600' }
const DEFAULT_SHADOW = { dx: 6, dy: 6, blur: 10, color: '#000000bf' }

function clone(s: LayerStyle | null | undefined): LayerStyle | null {
  return s ? (JSON.parse(JSON.stringify(s)) as LayerStyle) : null
}

function Row({
  label,
  value,
  min,
  max,
  onChange,
}: {
  label: string
  value: number
  min: number
  max: number
  onChange: (v: number) => void
}) {
  return (
    <div className="dlg-row">
      <label className="dlg-label">{label}</label>
      <input
        className="dlg-range"
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
      />
      <span className="dlg-live">{value}</span>
    </div>
  )
}

export default function StyleDialogHost() {
  const [open, setOpen] = useState<OpenState | null>(null)
  const [style, setStyle] = useState<LayerStyle>({})

  useEffect(() => {
    const onOpen = (e: Event) => {
      const detail = (e as CustomEvent).detail as { tab?: StyleTab } | undefined
      const st = useEditor.getState()
      const doc = st.docs.find((d) => d.id === st.activeDocId)
      const layer = doc?.layers.find((l) => l.id === doc.activeLayerId)
      if (!doc || !layer) {
        st.showToast('Layer Style needs an open document')
        return
      }
      const prev = clone(layer.style)
      setStyle(prev ?? {})
      setOpen({
        layerId: layer.id,
        layerName: layer.name,
        tab: detail?.tab === 'shadow' ? 'shadow' : 'stroke',
        prev,
        key: Date.now(),
      })
    }
    window.addEventListener('pc:openStyle', onOpen)
    return () => window.removeEventListener('pc:openStyle', onOpen)
  }, [])

  /* Esc = cancel */
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation()
        e.preventDefault()
        useEditor.getState().setLayerStyle(open.layerId, open.prev)
        setOpen(null)
      }
    }
    window.addEventListener('keydown', onKey, true)
    return () => window.removeEventListener('keydown', onKey, true)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open])

  if (!open) return null

  const applyLive = (s: LayerStyle): void => {
    setStyle(s)
    useEditor.getState().setLayerStyle(open.layerId, s)
  }

  const setStroke = (on: boolean): void =>
    applyLive({ ...style, stroke: on ? { ...DEFAULT_STROKE } : undefined })
  const setShadow = (on: boolean): void =>
    applyLive({ ...style, shadow: on ? { ...DEFAULT_SHADOW } : undefined })

  const cancel = (): void => {
    setOpen(null)
    useEditor.getState().setLayerStyle(open.layerId, open.prev)
  }

  const ok = (): void => {
    setOpen(null)
    const st = useEditor.getState()
    st.setLayerStyle(open.layerId, clone(style))
    st.pushHistory('Layer Style')
  }

  const strokeOn = !!style.stroke
  const shadowOn = !!style.shadow

  return (
    <div
      className="modal-scrim"
      onMouseDown={() => cancel()}
      onContextMenu={(e) => e.preventDefault()}
    >
      <div className="modal pdialog" style={{ width: 380 }} onMouseDown={(e) => e.stopPropagation()}>
        <div className="modal-title">Layer Style — {open.layerName}</div>
        <div className="modal-body">
          <div className="dlg-channels">
            <button
              type="button"
              className={`dlg-chip ${open.tab === 'stroke' ? 'active' : ''}`}
              onClick={() => setOpen({ ...open, tab: 'stroke' })}
            >
              Stroke
            </button>
            <button
              type="button"
              className={`dlg-chip ${open.tab === 'shadow' ? 'active' : ''}`}
              onClick={() => setOpen({ ...open, tab: 'shadow' })}
            >
              Drop Shadow
            </button>
          </div>

          {open.tab === 'stroke' && (
            <>
              <label className="dlg-check">
                <input type="checkbox" checked={strokeOn} onChange={(e) => setStroke(e.target.checked)} />
                Outer Stroke
              </label>
              {style.stroke && (
                <>
                  <Row
                    label="Width (px)"
                    value={style.stroke.width}
                    min={1}
                    max={60}
                    onChange={(v) => applyLive({ ...style, stroke: { ...style.stroke!, width: v } })}
                  />
                  <div className="dlg-row">
                    <label className="dlg-label">Color</label>
                    <input
                      className="opt-color"
                      type="color"
                      value={style.stroke.color}
                      onChange={(e) => applyLive({ ...style, stroke: { ...style.stroke!, color: e.target.value } })}
                    />
                  </div>
                </>
              )}
            </>
          )}

          {open.tab === 'shadow' && (
            <>
              <label className="dlg-check">
                <input type="checkbox" checked={shadowOn} onChange={(e) => setShadow(e.target.checked)} />
                Drop Shadow
              </label>
              {style.shadow && (
                <>
                  <Row label="Offset X (px)" value={style.shadow.dx} min={-80} max={80} onChange={(v) => applyLive({ ...style, shadow: { ...style.shadow!, dx: v } })} />
                  <Row label="Offset Y (px)" value={style.shadow.dy} min={-80} max={80} onChange={(v) => applyLive({ ...style, shadow: { ...style.shadow!, dy: v } })} />
                  <Row label="Blur (px)" value={style.shadow.blur} min={0} max={120} onChange={(v) => applyLive({ ...style, shadow: { ...style.shadow!, blur: v } })} />
                  <div className="dlg-row">
                    <label className="dlg-label">Color</label>
                    <input
                      className="opt-color"
                      type="color"
                      value={style.shadow.color.slice(0, 7)}
                      onChange={(e) =>
                        /* color picker gives #rrggbb — fix the alpha at ~75% for a soft shadow */
                        applyLive({ ...style, shadow: { ...style.shadow!, color: `${e.target.value}bf` } })
                      }
                    />
                  </div>
                </>
              )}
            </>
          )}

          <div className="dlg-hint">Non-destructive: Cancel restores the captured style, OK commits to history.</div>
        </div>
        <div className="modal-foot">
          <button className="btn" onClick={() => applyLive({})}>Clear</button>
          <span style={{ flex: 1 }} />
          <button className="btn" onClick={() => cancel()}>Cancel</button>
          <button className="btn primary" onClick={() => ok()}>OK</button>
        </div>
      </div>
    </div>
  )
}
