import { useEditor } from '../editor/store'

export default function Toast() {
  const toast = useEditor((s) => s.toast)
  if (!toast) return null
  return (
    <div className="toast" key={toast.id} role="status">
      {toast.text}
    </div>
  )
}
