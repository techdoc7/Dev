import { useEditor } from '../editor/store'
import { TOOL_LIST, ToolDef, TOOL_BY_ID } from '../editor/tools'

function ToolIcon({ def }: { def: ToolDef }) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={16}
      height={16}
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      {def.icon.map((d, i) => (
        <path key={i} d={d} />
      ))}
    </svg>
  )
}

/** Group boundaries: tools between indices render with a divider before them. */
const GROUP_STARTS = new Set(['marquee-rect', 'lasso', 'wand', 'crop', 'eyedropper', 'heal', 'brush', 'stamp', 'gradient', 'blur', 'pen', 'shape', 'transform', 'hand', 'type'])

export default function ToolPalette() {
  const tool = useEditor((s) => s.tool)
  const setTool = useEditor((s) => s.setTool)

  return (
    <div className="tool-palette" role="toolbar" aria-label="Tools">
      {TOOL_LIST.map((t, i) => (
        <div key={t.id}>
          {i > 0 && GROUP_STARTS.has(t.id) && <div className="tool-sep" />}
          <button
            type="button"
            className={`tool-btn ${tool === t.id ? 'active' : ''}`}
            title={`${t.label} (${t.shortcut})`}
            onClick={() => setTool(t.id)}
          >
            <ToolIcon def={TOOL_BY_ID.get(t.id)!} />
          </button>
        </div>
      ))}
      <div className="tool-sep" />
      <div className="color-chips" title="Foreground / background colors (X to swap, D to reset)">
        <label className="chip chip-bg" title="Background color">
          <BgSwatch />
        </label>
        <label className="chip chip-fg" title="Foreground color">
          <FgSwatch />
        </label>
      </div>
    </div>
  )
}

function FgSwatch() {
  const fg = useEditor((s) => s.fg)
  const setFg = useEditor((s) => s.setFg)
  return (
    <span className="chip-inner" style={{ background: fg }}>
      <input type="color" value={fg} onChange={(e) => setFg(e.target.value)} />
    </span>
  )
}

function BgSwatch() {
  const bg = useEditor((s) => s.bg)
  const setBg = useEditor((s) => s.setBg)
  return (
    <span className="chip-inner" style={{ background: bg }}>
      <input type="color" value={bg} onChange={(e) => setBg(e.target.value)} />
    </span>
  )
}
