import { useState } from 'react'
import { useEditor } from '../../editor/store'

type ExportFormat = 'png' | 'jpeg' | 'webp'

function loadSettings(): { format: ExportFormat; quality: number } {
  try {
    const value = JSON.parse(localStorage.getItem('photoclone.batchExport') || '')
    if (['png', 'jpeg', 'webp'].includes(value.format)) return { format: value.format, quality: Number(value.quality) || 92 }
  } catch {}
  return { format: 'png', quality: 92 }
}

export default function BatchExportDialog({ onClose }: { onClose: () => void }) {
  const initial = loadSettings()
  const [format, setFormat] = useState<ExportFormat>(initial.format)
  const [quality, setQuality] = useState(initial.quality)
  const [running, setRunning] = useState(false)
  const docs = useEditor((s) => s.docs)

  const run = async () => {
    if (!docs.length || running) return
    setRunning(true)
    localStorage.setItem('photoclone.batchExport', JSON.stringify({ format, quality }))
    await useEditor.getState().exportAllDocuments(format, quality / 100)
    setRunning(false)
    onClose()
  }

  return (
    <div className="modal-scrim" onMouseDown={(e) => !running && e.target === e.currentTarget && onClose()}>
      <div className="modal batch-export-modal" role="dialog" aria-modal="true" aria-label="Batch export documents">
        <div className="modal-title">Image Processor</div>
        <div className="modal-body">
          <div className="batch-summary">Export all {docs.length} open document{docs.length === 1 ? '' : 's'}</div>
          <label className="form-row">
            <span>Format</span>
            <select value={format} disabled={running} onChange={(e) => setFormat(e.target.value as ExportFormat)}>
              <option value="png">PNG — lossless transparency</option>
              <option value="jpeg">JPEG — white background</option>
              <option value="webp">WebP — compact transparency</option>
            </select>
          </label>
          {format !== 'png' && (
            <label className="batch-quality">
              <span>Quality</span>
              <input type="range" min={10} max={100} value={quality} disabled={running} onChange={(e) => setQuality(Number(e.target.value))} />
              <output>{quality}%</output>
            </label>
          )}
          <div className="size-note">
            On supported browsers you can choose a destination folder. Otherwise each file is downloaded separately. Files are encoded sequentially to control memory use.
          </div>
        </div>
        <div className="modal-foot">
          <button className="btn" disabled={running} onClick={onClose}>Cancel</button>
          <span className="foot-flex" />
          <button className="btn primary" disabled={running || !docs.length} onClick={() => { void run() }}>{running ? 'Exporting…' : 'Choose Folder & Export'}</button>
        </div>
      </div>
    </div>
  )
}
