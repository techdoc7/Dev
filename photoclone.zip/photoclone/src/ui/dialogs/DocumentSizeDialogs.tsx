import { useState } from 'react'
import { useEditor } from '../../editor/store'

export type DocumentSizeDialogKind = 'image' | 'canvas'

export default function DocumentSizeDialog({ kind, onClose }: { kind: DocumentSizeDialogKind; onClose: () => void }) {
  const doc = useEditor((s) => s.docs.find((d) => d.id === s.activeDocId))
  const [width, setWidth] = useState(doc?.width ?? 1)
  const [height, setHeight] = useState(doc?.height ?? 1)
  const [linked, setLinked] = useState(true)
  const [smooth, setSmooth] = useState(true)
  const [anchorX, setAnchorX] = useState<-1 | 0 | 1>(0)
  const [anchorY, setAnchorY] = useState<-1 | 0 | 1>(0)
  const ratio = doc ? doc.width / doc.height : 1

  if (!doc) return null

  const setW = (value: number) => {
    const next = Math.max(1, Math.min(32768, Math.round(value || 1)))
    setWidth(next)
    if (kind === 'image' && linked) setHeight(Math.max(1, Math.round(next / ratio)))
  }
  const setH = (value: number) => {
    const next = Math.max(1, Math.min(32768, Math.round(value || 1)))
    setHeight(next)
    if (kind === 'image' && linked) setWidth(Math.max(1, Math.round(next * ratio)))
  }
  const apply = () => {
    if (kind === 'image') useEditor.getState().resizeDocument(width, height, smooth)
    else useEditor.getState().resizeCanvas(width, height, anchorX, anchorY)
    onClose()
  }

  return (
    <div className="modal-scrim" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal size-modal" role="dialog" aria-modal="true" aria-label={kind === 'image' ? 'Image Size' : 'Canvas Size'}>
        <div className="modal-title">{kind === 'image' ? 'Image Size' : 'Canvas Size'}</div>
        <div className="modal-body">
          <div className="size-current">Current: {doc.width} × {doc.height} px</div>
          <label className="form-row">
            <span>Width (px)</span>
            <input autoFocus type="number" min={1} max={32768} value={width} onChange={(e) => setW(Number(e.target.value))} onKeyDown={(e) => e.key === 'Enter' && apply()} />
          </label>
          <label className="form-row">
            <span>Height (px)</span>
            <input type="number" min={1} max={32768} value={height} onChange={(e) => setH(Number(e.target.value))} onKeyDown={(e) => e.key === 'Enter' && apply()} />
          </label>

          {kind === 'image' ? (
            <>
              <label className="size-check"><input type="checkbox" checked={linked} onChange={(e) => setLinked(e.target.checked)} /> Constrain proportions</label>
              <label className="size-check"><input type="checkbox" checked={smooth} onChange={(e) => setSmooth(e.target.checked)} /> Smooth resampling</label>
              <div className="size-note">All layers, masks, selections, and paths will be resampled.</div>
            </>
          ) : (
            <>
              <div className="form-row form-row-head"><span>Anchor</span></div>
              <div className="anchor-grid" aria-label="Canvas anchor">
                {([-1, 0, 1] as const).flatMap((y) => ([-1, 0, 1] as const).map((x) => (
                  <button key={`${x},${y}`} type="button" className={anchorX === x && anchorY === y ? 'active' : ''} onClick={() => { setAnchorX(x); setAnchorY(y) }} title={`Anchor ${x}, ${y}`}>
                    {anchorX === x && anchorY === y ? '●' : '○'}
                  </button>
                )))}
              </div>
              <div className="size-note">The anchor fixes the existing image while canvas space is added or removed.</div>
            </>
          )}
        </div>
        <div className="modal-foot">
          <button className="btn" onClick={onClose}>Cancel</button>
          <span className="foot-flex" />
          <button className="btn primary" onClick={apply}>Apply</button>
        </div>
      </div>
    </div>
  )
}
