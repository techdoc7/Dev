import { useState } from 'react'
import { useEditor, NewDocOptions } from '../../editor/store'

const PRESETS: { name: string; width: number; height: number }[] = [
  { name: 'Default — 2000 × 1500', width: 2000, height: 1500 },
  { name: 'Full HD — 1920 × 1080', width: 1920, height: 1080 },
  { name: 'Square — 1080 × 1080', width: 1080, height: 1080 },
  { name: 'Portrait — 1080 × 1350', width: 1080, height: 1350 },
  { name: 'Story — 1080 × 1920', width: 1080, height: 1920 },
  { name: 'A4 print @300ppi — 2480 × 3508', width: 2480, height: 3508 },
  { name: 'Card A @300ppi — 1050 × 600', width: 1050, height: 600 },
  { name: 'UHD 4K — 3840 × 2160', width: 3840, height: 2160 },
]

type BgKind = NewDocOptions['background']

export default function NewDocumentDialog({ onClose }: { onClose: () => void }) {
  const [name, setName] = useState('Untitled-1')
  const [presetIdx, setPresetIdx] = useState(0)
  const preset = PRESETS[presetIdx]
  const [width, setWidth] = useState(preset.width)
  const [height, setHeight] = useState(preset.height)
  const [bg, setBg] = useState<BgKind>('white')

  const pickPreset = (i: number) => {
    setPresetIdx(i)
    setWidth(PRESETS[i].width)
    setHeight(PRESETS[i].height)
  }

  const create = () => {
    useEditor.getState().newDoc({ name, width, height, background: bg })
    onClose()
  }

  return (
    <div className="modal-scrim" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal" role="dialog" aria-modal="true" aria-label="New document">
        <div className="modal-title">New Document</div>
        <div className="modal-body">
          <div className="modal-columns">
            <div className="modal-left">
              <label className="form-row">
                <span>Name</span>
                <input
                  autoFocus
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && create()}
                />
              </label>
              <div className="form-row form-row-head">
                <span>Preset</span>
              </div>
              <div className="preset-list">
                {PRESETS.map((p, i) => (
                  <button
                    key={p.name}
                    className={`preset-row ${i === presetIdx ? 'active' : ''}`}
                    onClick={() => pickPreset(i)}
                  >
                    {p.name}
                  </button>
                ))}
              </div>
            </div>
            <div className="modal-right">
              <label className="form-row">
                <span>Width (px)</span>
                <input
                  type="number"
                  min={1}
                  max={10000}
                  value={width}
                  onChange={(e) => setWidth(Math.max(1, Math.min(10000, Number(e.target.value) || 1)))}
                />
              </label>
              <label className="form-row">
                <span>Height (px)</span>
                <input
                  type="number"
                  min={1}
                  max={10000}
                  value={height}
                  onChange={(e) => setHeight(Math.max(1, Math.min(10000, Number(e.target.value) || 1)))}
                />
              </label>
              <div className="form-row form-row-head">
                <span>Background</span>
              </div>
              <div className="bg-choices">
                {(['white', 'black', 'transparent'] as BgKind[]).map((b) => (
                  <label key={b} className="bg-choice">
                    <input type="radio" name="bg" checked={bg === b} onChange={() => setBg(b)} />
                    <span className={b === 'transparent' ? 'bg-swatch transparent' : 'bg-swatch'} style={b !== 'transparent' ? { background: b } : undefined} />
                    <span className="cap">{b}</span>
                  </label>
                ))}
              </div>
              <div className="new-meta">
                {width} × {height} px · {(width * height / 1e6).toFixed(1)} MP
              </div>
            </div>
          </div>
        </div>
        <div className="modal-foot">
          <button className="btn" onClick={onClose}>Cancel</button>
          <span className="foot-flex" />
          <button className="btn primary" onClick={create}>Create</button>
        </div>
      </div>
    </div>
  )
}
