/* Live-preview adjustment / filter dialogs. All original code.
   Preview pipeline: dialog keeps a pristine snapshot of the active layer;
   each render mutates a copy of its ImageData, masks it against the current
   selection if any, and blits onto the layer. OK keeps the result (+ history),
   Cancel restores the snapshot. */

import { useEffect, useRef, useState } from 'react'
import { create } from 'zustand'
import { useEditor, canvasCtx, makeCanvas, cloneCanvas } from '../../editor/store'
import { Selection } from '../../editor/types'
import * as A from '../../engine/adjustments'

/* ------------------------------------------------------------------ */
/* Dialog open/close store                                             */
/* ------------------------------------------------------------------ */

export type PixmapDialogId =
  | 'brightness' | 'levels' | 'curves' | 'exposure' | 'hue-sat' | 'vibrance' | 'color-balance'
  | 'threshold' | 'posterize'
  | 'gaussian' | 'motion' | 'unsharp' | 'noise' | 'mosaic'

interface PixmapDialogState {
  open: PixmapDialogId | null
  tick: number
  openDialog: (id: PixmapDialogId) => void
  close: () => void
}

export const usePixmapDialog = create<PixmapDialogState>((set) => ({
  open: null,
  tick: 0,
  openDialog: (id) => set((s) => ({ open: id, tick: s.tick + 1 })),
  close: () => set({ open: null }),
}))

/* ------------------------------------------------------------------ */
/* Immediate (dialog-free) operations                                  */
/* ------------------------------------------------------------------ */

type ImmediateId =
  | 'invert' | 'desaturate' | 'black-white' | 'auto-tone' | 'sharpen' | 'emboss' | 'find-edges'

const IMMEDIATE_LABELS: Record<ImmediateId, string> = {
  invert: 'Invert',
  desaturate: 'Desaturate',
  'black-white': 'Black & White',
  'auto-tone': 'Auto Tone',
  sharpen: 'Sharpen',
  emboss: 'Emboss',
  'find-edges': 'Find Edges',
}

const IMMEDIATE_RUN: Record<ImmediateId, (img: ImageData) => void> = {
  invert: (img) => A.invert(img),
  desaturate: (img) => A.desaturate(img),
  'black-white': (img) => A.blackAndWhite(img),
  'auto-tone': (img) => A.autoTone(img),
  sharpen: (img) => A.sharpen(img, 100),
  emboss: (img) => A.emboss(img),
  'find-edges': (img) => A.findEdges(img),
}

function currentTarget(): { doc: ReturnType<typeof useEditor.getState>['docs'][number]; layer: { canvas: HTMLCanvasElement; id: string } | null } | null {
  const st = useEditor.getState()
  const doc = st.docs.find((d) => d.id === st.activeDocId)
  if (!doc) return null
  const layer = doc.layers.find((l) => l.id === doc.activeLayerId) ?? null
  return { doc, layer: layer ? { canvas: layer.canvas, id: layer.id } : null }
}

/** Apply a dialog-free pixel operation to the active layer (selection-aware). */
export function applyPixmapImmediate(id: ImmediateId): void {
  const t = currentTarget()
  const st = useEditor.getState()
  if (!t?.layer) {
    st.showToast('No document open')
    return
  }
  const layer = t.doc.layers.find((l) => l.id === t.layer!.id)!
  const ctx = canvasCtx(layer.canvas)
  const img = ctx.getImageData(0, 0, layer.canvas.width, layer.canvas.height)
  if (t.doc.selection) {
    /* clip to selection: run on a copy of the pixels, mask, blit */
    const work = new ImageData(new Uint8ClampedArray(img.data), img.width, img.height)
    IMMEDIATE_RUN[id](work)
    const out = cloneCanvas(layer.canvas)
    const octx = canvasCtx(out)
    octx.putImageData(work, 0, 0)
    octx.globalCompositeOperation = 'destination-in'
    octx.drawImage(t.doc.selection.mask, 0, 0)
    octx.globalCompositeOperation = 'source-over'
    const lctx = canvasCtx(layer.canvas)
    lctx.setTransform(1, 0, 0, 1, 0, 0)
    lctx.drawImage(out, 0, 0)
  } else {
    IMMEDIATE_RUN[id](img)
    ctx.putImageData(img, 0, 0)
  }
  st.pushHistory(IMMEDIATE_LABELS[id])
}

/* ------------------------------------------------------------------ */
/* Filter session + preview mechanics                                  */
/* ------------------------------------------------------------------ */

interface FilterSession {
  layerId: string
  snap: HTMLCanvasElement
  orig: ImageData
  work: HTMLCanvasElement
  sel: Selection | null
  pending: ((img: ImageData) => void) | null
  raf: number
}

function applyFiltered(sess: FilterSession, fn: (img: ImageData) => void): void {
  const st = useEditor.getState()
  const doc = st.docs.find((d) => d.id === st.activeDocId)
  const layer = doc?.layers.find((l) => l.id === sess.layerId)
  if (!layer) return
  const copy = new ImageData(new Uint8ClampedArray(sess.orig.data), sess.orig.width, sess.orig.height)
  fn(copy)
  const wctx = canvasCtx(sess.work)
  wctx.setTransform(1, 0, 0, 1, 0, 0)
  wctx.globalCompositeOperation = 'source-over'
  wctx.putImageData(copy, 0, 0)
  if (sess.sel) {
    wctx.globalCompositeOperation = 'destination-in'
    wctx.drawImage(sess.sel.mask, 0, 0)
    wctx.globalCompositeOperation = 'source-over'
  }
  const lctx = canvasCtx(layer.canvas)
  lctx.setTransform(1, 0, 0, 1, 0, 0)
  lctx.clearRect(0, 0, layer.canvas.width, layer.canvas.height)
  lctx.drawImage(sess.snap, 0, 0)
  lctx.drawImage(sess.work, 0, 0)
  st.bump()
}

function schedulePreview(sess: FilterSession, fn: (img: ImageData) => void): void {
  sess.pending = fn
  if (sess.raf) return
  sess.raf = requestAnimationFrame(() => {
    sess.raf = 0
    if (sess.pending) {
      applyFiltered(sess, sess.pending)
      sess.pending = null
    }
  })
}

function flushSession(sess: FilterSession): void {
  if (sess.raf) {
    cancelAnimationFrame(sess.raf)
    sess.raf = 0
  }
  if (sess.pending) {
    applyFiltered(sess, sess.pending)
    sess.pending = null
  }
}

function restoreSnap(sess: FilterSession): void {
  const st = useEditor.getState()
  const doc = st.docs.find((d) => d.id === st.activeDocId)
  const layer = doc?.layers.find((l) => l.id === sess.layerId)
  if (!layer) return
  const ctx = canvasCtx(layer.canvas)
  ctx.setTransform(1, 0, 0, 1, 0, 0)
  ctx.clearRect(0, 0, layer.canvas.width, layer.canvas.height)
  ctx.drawImage(sess.snap, 0, 0)
  st.bump()
}

/* ------------------------------------------------------------------ */
/* Title registry                                                      */
/* ------------------------------------------------------------------ */

const TITLES: Record<PixmapDialogId, string> = {
  brightness: 'Brightness/Contrast',
  levels: 'Levels',
  curves: 'Curves',
  exposure: 'Exposure',
  'hue-sat': 'Hue/Saturation',
  vibrance: 'Vibrance',
  'color-balance': 'Color Balance',
  threshold: 'Threshold',
  posterize: 'Posterize',
  gaussian: 'Gaussian Blur',
  motion: 'Motion Blur',
  unsharp: 'Unsharp Mask',
  noise: 'Add Noise',
  mosaic: 'Mosaic',
}

/* ------------------------------------------------------------------ */
/* Shared UI bits                                                      */
/* ------------------------------------------------------------------ */

function SliderRow({ label, min, max, step, value, onChange }: {
  label: string
  min: number
  max: number
  step?: number
  value: number
  onChange: (v: number) => void
}) {
  const st = step ?? 1
  return (
    <div className="dlg-row">
      <label className="dlg-label">{label}</label>
      <input
        className="dlg-range"
        type="range"
        min={min}
        max={max}
        step={st}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
      />
      <input
        className="dlg-number"
        type="number"
        min={min}
        max={max}
        step={st}
        value={Math.round(value * 100) / 100}
        onChange={(e) => {
          const v = Number(e.target.value)
          if (!Number.isNaN(v)) onChange(Math.max(min, Math.min(max, v)))
        }}
      />
    </div>
  )
}

function checkRow(label: string, checked: boolean, onChange: (v: boolean) => void) {
  return (
    <label className="dlg-check">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      <span>{label}</span>
    </label>
  )
}

/* ------------------------------------------------------------------ */
/* Individual dialogs                                                  */
/* ------------------------------------------------------------------ */

interface DialogProps {
  sess: FilterSession
}

function BrightnessDialog({ sess }: DialogProps) {
  const [b, setB] = useState(0)
  const [c, setC] = useState(0)
  useEffect(() => {
    schedulePreview(sess, (img) => A.brightnessContrast(img, b, c))
  }, [b, c, sess])
  return (
    <>
      <SliderRow label="Brightness" min={-150} max={150} value={b} onChange={setB} />
      <SliderRow label="Contrast" min={-100} max={100} value={c} onChange={setC} />
    </>
  )
}

function LevelsDialog({ sess }: DialogProps) {
  const [inBlack, setInBlack] = useState(0)
  const [gamma, setGamma] = useState(1)
  const [inWhite, setInWhite] = useState(255)
  const [outBlack, setOutBlack] = useState(0)
  const [outWhite, setOutWhite] = useState(255)
  const histRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    /* histogram of the original, RGB overlaid */
    const canvas = histRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')!
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    const h = A.histogram(sess.orig)
    const max = Math.max(
      Math.max(...h.r), Math.max(...h.g), Math.max(...h.b), 1,
    )
    const draw = (arr: Uint32Array, color: string) => {
      ctx.fillStyle = color
      for (let i = 0; i < 256; i++) {
        const v = Math.sqrt(arr[i] / max) * canvas.height
        ctx.fillRect(i, canvas.height - v, 1, v)
      }
    }
    ctx.globalAlpha = 0.5
    draw(h.g, '#00cc00')
    draw(h.b, '#3355ff')
    draw(h.r, '#ff2222')
    ctx.globalAlpha = 1
  }, [sess])

  useEffect(() => {
    schedulePreview(sess, (img) => A.levels(img, inBlack, gamma, inWhite, outBlack, outWhite))
  }, [inBlack, gamma, inWhite, outBlack, outWhite, sess])

  return (
    <>
      <canvas ref={histRef} width={256} height={90} className="dlg-hist" />
      <SliderRow label="Input Black" min={0} max={254} value={inBlack}
        onChange={(v) => { setInBlack(Math.min(v, inWhite - 1)) }} />
      <SliderRow label="Gamma" min={0.1} max={3} step={0.01} value={gamma} onChange={setGamma} />
      <SliderRow label="Input White" min={1} max={255} value={inWhite}
        onChange={(v) => { setInWhite(Math.max(v, inBlack + 1)) }} />
      <SliderRow label="Output Black" min={0} max={255} value={outBlack} onChange={setOutBlack} />
      <SliderRow label="Output White" min={0} max={255} value={outWhite} onChange={setOutWhite} />
    </>
  )
}

type CurveChannel = 'all' | 'r' | 'g' | 'b'

const DEFAULT_CURVE: A.CurvePoint[] = [{ x: 0, y: 0 }, { x: 255, y: 255 }]

function CurvesDialog({ sess }: DialogProps) {
  const [curves, setCurves] = useState<Record<CurveChannel, A.CurvePoint[]>>({
    all: DEFAULT_CURVE.map((p) => ({ ...p })),
    r: DEFAULT_CURVE.map((p) => ({ ...p })),
    g: DEFAULT_CURVE.map((p) => ({ ...p })),
    b: DEFAULT_CURVE.map((p) => ({ ...p })),
  })
  const [channel, setChannel] = useState<CurveChannel>('all')

  useEffect(() => {
    schedulePreview(sess, (img) => {
      const la = A.splineLUT(curves.all)
      A.applyLUT(img, la, la, la)
      const lr = A.splineLUT(curves.r)
      const lg = A.splineLUT(curves.g)
      const lb = A.splineLUT(curves.b)
      A.applyLUT(img, lr, lg, lb)
    })
  }, [curves, sess])

  return (
    <>
      <div className="dlg-channels">
        {(['all', 'r', 'g', 'b'] as CurveChannel[]).map((ch) => (
          <button
            key={ch}
            className={`dlg-chip ${channel === ch ? 'active' : ''}`}
            onClick={() => setChannel(ch)}
          >
            {ch === 'all' ? 'RGB' : ch.toUpperCase()}
          </button>
        ))}
      </div>
      <CurveEditor
        points={curves[channel]}
        channel={channel}
        onChange={(pts) => setCurves((c) => ({ ...c, [channel]: pts }))}
      />
    </>
  )
}

function CurveEditor({ points, channel, onChange }: {
  points: A.CurvePoint[]
  channel: CurveChannel
  onChange: (pts: A.CurvePoint[]) => void
}) {
  const ref = useRef<HTMLCanvasElement>(null)
  const dragIdx = useRef<number | null>(null)

  useEffect(() => {
    const canvas = ref.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')!
    const S = canvas.width
    ctx.clearRect(0, 0, S, S)
    /* grid */
    ctx.strokeStyle = 'rgba(255,255,255,0.12)'
    ctx.lineWidth = 1
    for (let i = 1; i < 4; i++) {
      const p = (S * i) / 4
      ctx.beginPath(); ctx.moveTo(p, 0); ctx.lineTo(p, S); ctx.stroke()
      ctx.beginPath(); ctx.moveTo(0, p); ctx.lineTo(S, p); ctx.stroke()
    }
    /* diagonal */
    ctx.strokeStyle = 'rgba(255,255,255,0.18)'
    ctx.beginPath(); ctx.moveTo(0, S); ctx.lineTo(S, 0); ctx.stroke()
    /* curve */
    const lut = A.splineLUT(points)
    ctx.strokeStyle = channel === 'r' ? '#ff3b3b' : channel === 'g' ? '#2fd13b' : channel === 'b' ? '#3b6bff' : '#f2f2f2'
    ctx.lineWidth = 1.5
    ctx.beginPath()
    for (let v = 0; v <= 255; v++) {
      const x = v
      const y = S - lut[v]
      if (v === 0) ctx.moveTo(x, y)
      else ctx.lineTo(x, y)
    }
    ctx.stroke()
    /* points */
    for (const p of points) {
      ctx.fillStyle = '#ffffff'
      ctx.fillRect(p.x - 3, S - p.y - 3, 6, 6)
      ctx.strokeStyle = '#000000'
      ctx.strokeRect(p.x - 3, S - p.y - 3, 6, 6)
    }
  }, [points, channel])

  const toCanvas = (e: React.PointerEvent<HTMLCanvasElement>, canvas: HTMLCanvasElement) => {
    const r = canvas.getBoundingClientRect()
    return {
      x: Math.max(0, Math.min(255, Math.round(((e.clientX - r.left) / r.width) * 255))),
      y: Math.max(0, Math.min(255, Math.round((1 - (e.clientY - r.top) / r.height) * 255))),
    }
  }

  return (
    <canvas
      ref={ref}
      width={256}
      height={256}
      className="dlg-curve"
      onPointerDown={(e) => {
        const canvas = e.currentTarget
        const p = toCanvas(e, canvas)
        let best = -1
        let bestDist = 15
        for (let i = 0; i < points.length; i++) {
          const d = Math.hypot(points[i].x - p.x, points[i].y - p.y)
          if (d < bestDist) { bestDist = d; best = i }
        }
        if (best >= 0) {
          dragIdx.current = best
        } else if (points.length < 12) {
          const merged = [...points, p].sort((a, b) => a.x - b.x)
          dragIdx.current = merged.findIndex((q) => q.x === p.x && q.y === p.y)
          onChange(merged)
        }
        canvas.setPointerCapture(e.pointerId)
      }}
      onPointerMove={(e) => {
        if (dragIdx.current === null) return
        const i = dragIdx.current
        const p = toCanvas(e, e.currentTarget)
        const lo = i > 0 ? points[i - 1].x + 2 : 0
        const hi = i < points.length - 1 ? points[i + 1].x - 2 : 255
        const next = points.map((q, qi) => (qi === i ? { x: Math.max(lo, Math.min(hi, p.x)), y: p.y } : q))
        onChange(next)
      }}
      onPointerUp={() => { dragIdx.current = null }}
      onDoubleClick={(e) => {
        if (points.length <= 2) return
        const p = toCanvas(e as unknown as React.PointerEvent<HTMLCanvasElement>, e.currentTarget)
        const i = points.findIndex((q) => Math.hypot(q.x - p.x, q.y - p.y) < 10)
        const isEnd = i === 0 || i === points.length - 1
        if (i >= 0 && !isEnd) {
          onChange(points.filter((_, qi) => qi !== i))
        }
      }}
    />
  )
}

function ExposureDialog({ sess }: DialogProps) {
  const [stops, setStops] = useState(0)
  const [offset, setOffset] = useState(0)
  const [gammaC, setGammaC] = useState(1)
  useEffect(() => {
    schedulePreview(sess, (img) => A.exposure(img, stops, offset, gammaC))
  }, [stops, offset, gammaC, sess])
  return (
    <>
      <SliderRow label="Exposure (EV)" min={-5} max={5} step={0.05} value={stops} onChange={setStops} />
      <SliderRow label="Offset" min={-0.5} max={0.5} step={0.01} value={offset} onChange={setOffset} />
      <SliderRow label="Gamma Correction" min={0.2} max={2.5} step={0.01} value={gammaC} onChange={setGammaC} />
    </>
  )
}

function HueSatDialog({ sess }: DialogProps) {
  const [hue, setHue] = useState(0)
  const [sat, setSat] = useState(0)
  const [light, setLight] = useState(0)
  useEffect(() => {
    schedulePreview(sess, (img) => A.hueSaturation(img, hue, sat, light))
  }, [hue, sat, light, sess])
  return (
    <>
      <SliderRow label="Hue" min={-180} max={180} value={hue} onChange={setHue} />
      <SliderRow label="Saturation" min={-100} max={100} value={sat} onChange={setSat} />
      <SliderRow label="Lightness" min={-100} max={100} value={light} onChange={setLight} />
    </>
  )
}

function VibranceDialog({ sess }: DialogProps) {
  const [amount, setAmount] = useState(25)
  useEffect(() => {
    schedulePreview(sess, (img) => A.vibrance(img, amount))
  }, [amount, sess])
  return <SliderRow label="Vibrance" min={-100} max={100} value={amount} onChange={setAmount} />
}

function ColorBalanceDialog({ sess }: DialogProps) {
  const [r, setR] = useState(0)
  const [g, setG] = useState(0)
  const [b, setB] = useState(0)
  useEffect(() => {
    schedulePreview(sess, (img) => A.colorBalance(img, r, g, b))
  }, [r, g, b, sess])
  return (
    <>
      <SliderRow label="Cyan → Red" min={-100} max={100} value={r} onChange={setR} />
      <SliderRow label="Magenta → Green" min={-100} max={100} value={g} onChange={setG} />
      <SliderRow label="Yellow → Blue" min={-100} max={100} value={b} onChange={setB} />
    </>
  )
}

function ThresholdDialog({ sess }: DialogProps) {
  const [level, setLevel] = useState(128)
  useEffect(() => {
    schedulePreview(sess, (img) => A.threshold(img, level))
  }, [level, sess])
  return <SliderRow label="Threshold Level" min={0} max={255} value={level} onChange={setLevel} />
}

function PosterizeDialog({ sess }: DialogProps) {
  const [levelsN, setLevelsN] = useState(6)
  useEffect(() => {
    schedulePreview(sess, (img) => A.posterize(img, levelsN))
  }, [levelsN, sess])
  return <SliderRow label="Levels" min={2} max={24} value={levelsN} onChange={setLevelsN} />
}

function GaussianDialog({ sess }: DialogProps) {
  const [radius, setRadius] = useState(4)
  useEffect(() => {
    schedulePreview(sess, (img) => A.gaussianBlur(img, radius))
  }, [radius, sess])
  return <SliderRow label="Radius (px)" min={0.5} max={60} step={0.5} value={radius} onChange={setRadius} />
}

function MotionDialog({ sess }: DialogProps) {
  const [angle, setAngle] = useState(0)
  const [distance, setDistance] = useState(30)
  useEffect(() => {
    schedulePreview(sess, (img) => A.motionBlur(img, angle, distance))
  }, [angle, distance, sess])
  return (
    <>
      <SliderRow label="Angle" min={-180} max={180} value={angle} onChange={setAngle} />
      <SliderRow label="Distance (px)" min={1} max={150} value={distance} onChange={setDistance} />
    </>
  )
}

function UnsharpDialog({ sess }: DialogProps) {
  const [amount, setAmount] = useState(80)
  const [radius, setRadius] = useState(2)
  const [cut, setCut] = useState(0)
  useEffect(() => {
    schedulePreview(sess, (img) => A.unsharpMask(img, amount, radius, cut))
  }, [amount, radius, cut, sess])
  return (
    <>
      <SliderRow label="Amount %" min={10} max={300} value={amount} onChange={setAmount} />
      <SliderRow label="Radius (px)" min={0.5} max={20} step={0.1} value={radius} onChange={setRadius} />
      <SliderRow label="Threshold" min={0} max={100} value={cut} onChange={setCut} />
    </>
  )
}

function NoiseDialog({ sess }: DialogProps) {
  const [amount, setAmount] = useState(12)
  const [mono, setMono] = useState(true)
  useEffect(() => {
    schedulePreview(sess, (img) => A.addNoise(img, amount, mono))
  }, [amount, mono, sess])
  return (
    <>
      <SliderRow label="Amount" min={0} max={100} value={amount} onChange={setAmount} />
      {checkRow('Monochromatic', mono, setMono)}
    </>
  )
}

function MosaicDialog({ sess }: DialogProps) {
  const [cell, setCell] = useState(10)
  useEffect(() => {
    schedulePreview(sess, (img) => A.mosaic(img, cell))
  }, [cell, sess])
  return <SliderRow label="Cell Size (px)" min={2} max={80} value={cell} onChange={setCell} />
}

/* ------------------------------------------------------------------ */
/* Host                                                                */
/* ------------------------------------------------------------------ */

const DIALOG_COMPONENTS: Record<PixmapDialogId, (p: DialogProps) => JSX.Element> = {
  brightness: BrightnessDialog,
  levels: LevelsDialog,
  curves: CurvesDialog,
  exposure: ExposureDialog,
  'hue-sat': HueSatDialog,
  vibrance: VibranceDialog,
  'color-balance': ColorBalanceDialog,
  threshold: ThresholdDialog,
  posterize: PosterizeDialog,
  gaussian: GaussianDialog,
  motion: MotionDialog,
  unsharp: UnsharpDialog,
  noise: NoiseDialog,
  mosaic: MosaicDialog,
}

export default function PixmapDialogHost(): JSX.Element | null {
  const open = usePixmapDialog((s) => s.open)
  const tick = usePixmapDialog((s) => s.tick)
  const sessRef = useRef<FilterSession | null>(null)
  const [sess, setSess] = useState<FilterSession | null>(null)

  useEffect(() => {
    if (!open) {
      if (sessRef.current) {
        flushSession(sessRef.current)
        sessRef.current = null
        setSess(null)
      }
      return
    }
    const st = useEditor.getState()
    if (sessRef.current) {
      flushSession(sessRef.current)
      restoreSnap(sessRef.current)
    }
    const doc = st.docs.find((d) => d.id === st.activeDocId)
    const layer = doc?.layers.find((l) => l.id === doc.activeLayerId)
    if (!doc || !layer) {
      st.showToast('No document open')
      usePixmapDialog.getState().close()
      return
    }
    const snap = cloneCanvas(layer.canvas)
    const orig = canvasCtx(snap).getImageData(0, 0, snap.width, snap.height)
    const s: FilterSession = {
      layerId: layer.id,
      snap,
      orig,
      work: makeCanvas(doc.width, doc.height),
      sel: doc.selection,
      pending: null,
      raf: 0,
    }
    sessRef.current = s
    setSess(s)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, tick])

  if (!open || !sess) return null
  const Component = DIALOG_COMPONENTS[open]

  const onOk = () => {
    const s = sessRef.current
    if (s) flushSession(s)
    sessRef.current = null
    setSess(null)
    useEditor.getState().pushHistory(TITLES[open])
    usePixmapDialog.getState().close()
  }
  const onCancel = () => {
    const s = sessRef.current
    if (s) {
      flushSession(s)
      restoreSnap(s)
    }
    sessRef.current = null
    setSess(null)
    usePixmapDialog.getState().close()
  }

  return (
    <div
      className="modal-scrim"
      onMouseDown={(e) => e.target === e.currentTarget && onCancel()}
      onKeyDown={(e) => {
        if (e.key === 'Escape') onCancel()
        if (e.key === 'Enter' && !(e.target instanceof HTMLTextAreaElement)) {
          e.preventDefault()
          onOk()
        }
      }}
    >
      <div className="modal pdialog" role="dialog" aria-modal="true" aria-label={TITLES[open]}>
        <div className="modal-title">{TITLES[open]}</div>
        <div className="modal-body pdialog-body">
          <Component sess={sess} />
          <div className="dlg-hint">Preview is live — adjust, then OK to keep · Cancel restores</div>
        </div>
        <div className="modal-foot">
          {sess.sel && <span className="dlg-sel-note">Applies to selection</span>}
          <button className="btn" onClick={onCancel}>Cancel</button>
          <span className="foot-flex" />
          <button className="btn primary" onClick={onOk}>OK</button>
        </div>
      </div>
    </div>
  )
}
