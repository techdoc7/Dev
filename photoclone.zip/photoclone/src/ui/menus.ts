/** Command surface the menu bar dispatches into (wired in App.tsx). */
export interface Commands {
  noDoc: () => boolean
  toast: (msg: string) => void
  newDialog: () => void
  openFile: () => void
  exportPng: () => void
  exportJpeg: () => void
  exportWebp: () => void
  batchExport: () => void
  saveProject: () => void
  saveProjectAs: () => void
  close: () => void
  undo: () => void
  redo: () => void
  cut: () => void
  copy: () => void
  paste: () => void
  clear: () => void
  fill: () => void
  strokeSelection: () => void
  flatten: () => void
  mergeDown: () => void
  zoomIn: () => void
  zoomOut: () => void
  zoomActual: () => void
  zoomFit: () => void
  addLayer: () => void
  duplicateLayer: () => void
  deleteLayer: () => void
  selectAll: () => void
  deselect: () => void
  invertSelection: () => void
  feather: () => void
  expand: () => void
  contract: () => void
  freeTransform: () => void
  rotate90: () => void
  rotate270: () => void
  rotate180: () => void
  flipH: () => void
  flipV: () => void
  /** open an adjustment/filter dialog or run an immediate pixel op */
  pixmap: (id: string) => void
  /** Layer Style dialog (stroke / shadow tab) */
  styleDialog: (tab: 'stroke' | 'shadow') => void
  styleClear: () => void
  toggleClipping: () => void
  pathMakeSelection: () => void
  pathStroke: () => void
  cropTool: () => void
  nextTab: () => void
  imageSize: () => void
  canvasSize: () => void
}

export interface MenuEntry {
  label: string
  accel?: string
  onSelect?: () => void
  disabled?: boolean
  sep?: boolean
}

export interface MenuDef {
  label: string
  entries: MenuEntry[]
}

/** Build menus from commands that are fully available in this build. */
export function buildMenus(c: Commands): MenuDef[] {
  const nd = c.noDoc
  const toast = c.toast
  const O = (label: string, onSelect?: () => void, accel?: string, disabled?: boolean): MenuEntry => ({ label, onSelect, accel, disabled })

  return [
    {
      label: 'File',
      entries: [
        O('New…', c.newDialog, 'Ctrl+N'),
        O('Open…', c.openFile, 'Ctrl+O'),
        { label: 'sep' } as any,
        O('Export as PNG…', () => (nd() ? null : c.exportPng()), 'Ctrl+Shift+E', nd()),
        O('Export as JPEG…', () => (nd() ? null : c.exportJpeg()), undefined, nd()),
        O('Export as WebP…', () => (nd() ? null : c.exportWebp()), undefined, nd()),
        O('Image Processor…', c.batchExport, undefined, nd()),
        O('Save .pclone', () => (nd() ? null : c.saveProject()), 'Ctrl+S', nd()),
        O('Save As…', () => (nd() ? null : c.saveProjectAs()), 'Ctrl+Shift+S', nd()),
        { label: 'sep' } as any,
        O('Close Tab', () => (nd() ? null : c.close()), 'Ctrl+W', nd()),
        O('Quit', () => toast('Photoclone runs in your browser — just close the tab')),
      ],
    },
    {
      label: 'Edit',
      entries: [
        O('Undo', () => (nd() ? null : c.undo()), 'Ctrl+Z', nd()),
        O('Redo', () => (nd() ? null : c.redo()), 'Ctrl+Shift+Z', nd()),
        { label: 'sep' } as any,
        O('Cut', c.cut, 'Ctrl+X', nd()),
        O('Copy', c.copy, 'Ctrl+C', nd()),
        O('Paste', c.paste, 'Ctrl+V', nd()),
        O('Clear', c.clear, 'Delete', nd()),
        { label: 'sep' } as any,
        O('Fill with Foreground', c.fill, 'Shift+Backspace', nd()),
        O('Stroke Selection', c.strokeSelection, undefined, nd()),
        { label: 'sep' } as any,
        O('Free Transform', c.freeTransform, 'Ctrl+T', nd()),
      ],
    },
    {
      label: 'Image',
      entries: [
        O('Image Size…', c.imageSize, 'Alt+Ctrl+I', nd()),
        O('Canvas Size…', c.canvasSize, 'Alt+Ctrl+C', nd()),
        { label: 'sep' } as any,
        O('Rotate 90° CW', () => (nd() ? null : c.rotate90()), undefined, nd()),
        O('Rotate 90° CCW', () => (nd() ? null : c.rotate270()), undefined, nd()),
        O('Rotate 180°', () => (nd() ? null : c.rotate180()), undefined, nd()),
        O('Flip Horizontal', () => (nd() ? null : c.flipH()), undefined, nd()),
        O('Flip Vertical', () => (nd() ? null : c.flipV()), undefined, nd()),
        { label: 'sep' } as any,
        O('Crop…', c.cropTool, 'C', nd()),
        { label: 'sep' } as any,
        O('Adjustments: Brightness/Contrast…', () => c.pixmap('brightness'), undefined, nd()),
        O('Adjustments: Levels…', () => c.pixmap('levels'), undefined, nd()),
        O('Adjustments: Curves…', () => c.pixmap('curves'), undefined, nd()),
        O('Adjustments: Exposure…', () => c.pixmap('exposure'), undefined, nd()),
        O('Adjustments: Vibrance…', () => c.pixmap('vibrance'), undefined, nd()),
        O('Adjustments: Color Balance…', () => c.pixmap('color-balance'), undefined, nd()),
        { label: 'sep' } as any,
        O('Adjustments: Auto Tone', () => c.pixmap('auto-tone'), undefined, nd()),
        O('Adjustments: Black & White', () => c.pixmap('black-white'), undefined, nd()),
        O('Adjustments: Desaturate', () => c.pixmap('desaturate'), undefined, nd()),
        O('Adjustments: Invert', () => c.pixmap('invert'), 'Ctrl+I', nd()),
        O('Adjustments: Threshold…', () => c.pixmap('threshold'), undefined, nd()),
        O('Adjustments: Posterize…', () => c.pixmap('posterize'), undefined, nd()),
      ],
    },
    {
      label: 'Layer',
      entries: [
        O('New Layer', c.addLayer, 'Ctrl+Shift+N', nd()),
        O('New Text Layer', () => window.dispatchEvent(new Event('pc:newText')), 'T', nd()),
        O('Duplicate Layer', c.duplicateLayer, 'Ctrl+J', nd()),
        O('Delete Layer', c.deleteLayer, undefined, nd()),
        { label: 'sep' } as any,
        O('Layer Style: Stroke…', () => c.styleDialog('stroke'), undefined, nd()),
        O('Layer Style: Drop Shadow…', () => c.styleDialog('shadow'), undefined, nd()),
        O('Clear Layer Style', () => (nd() ? null : c.styleClear()), undefined, nd()),
        { label: 'sep' } as any,
        O('Create / Release Clipping Mask', c.toggleClipping, 'Alt+Ctrl+G', nd()),
        { label: 'sep' } as any,
        O('Merge Down', c.mergeDown, 'Ctrl+E', nd()),
        O('Flatten Image', c.flatten, undefined, nd()),
      ],
    },
    {
      label: 'Select',
      entries: [
        O('All', c.selectAll, 'Ctrl+A', nd()),
        O('Deselect', c.deselect, 'Ctrl+D', nd()),
        O('Inverse', c.invertSelection, 'Ctrl+Shift+I', nd()),
        { label: 'sep' } as any,
        O('Feather (options bar value)', c.feather, undefined, nd()),
        O('Expand (5 px)', c.expand, undefined, nd()),
        O('Contract (5 px)', c.contract, undefined, nd()),
        { label: 'sep' } as any,
        O('Make Selection from Path', () => (nd() ? null : c.pathMakeSelection()), undefined, nd()),
      ],
    },
    {
      label: 'Filter',
      entries: [
        O('Blur: Gaussian…', () => c.pixmap('gaussian'), undefined, nd()),
        O('Blur: Motion…', () => c.pixmap('motion'), undefined, nd()),
        { label: 'sep' } as any,
        O('Sharpen', () => c.pixmap('sharpen'), undefined, nd()),
        O('Sharpen: Unsharp Mask…', () => c.pixmap('unsharp'), undefined, nd()),
        { label: 'sep' } as any,
        O('Noise: Add Noise…', () => c.pixmap('noise'), undefined, nd()),
        O('Pixelate: Mosaic…', () => c.pixmap('mosaic'), undefined, nd()),
        { label: 'sep' } as any,
        O('Stylize: Emboss', () => c.pixmap('emboss'), undefined, nd()),
        O('Stylize: Find Edges', () => c.pixmap('find-edges'), undefined, nd()),
        { label: 'sep' } as any,
        O('Stroke Path (brush settings)', () => (nd() ? null : c.pathStroke()), undefined, nd()),
      ],
    },
    {
      label: 'View',
      entries: [
        O('Zoom In', c.zoomIn, 'Ctrl+='),
        O('Zoom Out', c.zoomOut, 'Ctrl+-'),
        O('Actual Pixels', c.zoomActual, 'Ctrl+1'),
        O('Fit on Screen', c.zoomFit, 'Ctrl+0'),
      ],
    },
    {
      label: 'Window',
      entries: [
        O('Next Document', c.nextTab, 'Ctrl+Tab', nd()),
      ],
    },
    {
      label: 'Help',
      entries: [
        O('Keyboard Shortcuts', () => toast('Ctrl+S save · Ctrl+Shift+S save as · Ctrl+O open · Ctrl+Z undo · tool letters match the toolbar')),
        O('About Photoclone', () => toast('Photoclone v1.0.0 — original, offline, MIT')),
      ],
    },
  ]
}
