import { useEditor } from '../../editor/store'

const SWATCHES = [
  '#000000', '#404040', '#808080', '#c0c0c0', '#ffffff',
  '#9d2b2b', '#d14444', '#ef8350', '#f4a259',
  '#2b6e9d', '#3aa0d1', '#7ad3f0', '#2b9d63', '#54c78a', '#a8e6c0',
  '#7a4fbf', '#a06bd8', '#d67ab1', '#bf9d2b', '#e3c057',
]

export default function ColorPanel() {
  const fg = useEditor((s) => s.fg)
  const bg = useEditor((s) => s.bg)
  const swap = useEditor((s) => s.swapColors)
  const reset = useEditor((s) => s.resetColors)
  const setFg = useEditor((s) => s.setFg)
  const setBg = useEditor((s) => s.setBg)
  const setTool = useEditor((s) => s.setTool)
  const tool = useEditor((s) => s.tool)
  const toast = useEditor((s) => s.showToast)

  return (
    <div className="panel">
      <div className="panel-head">Color</div>
      <div className="color-body">
        <div className="color-swatches">
          <div className="chip-stack" title="Foreground / background (X swaps, D resets)">
            <label className="chip-inner" style={{ background: fg }}>
              <input
                type="color"
                value={fg}
                onChange={(e) => {
                  setFg(e.target.value)
                  if (tool !== 'type' && tool !== 'pen') setTool('brush')
                }}
              />
            </label>
            <label className="chip-inner" style={{ background: bg }}>
              <input type="color" value={bg} onChange={(e) => setBg(e.target.value)} />
            </label>
          </div>
          <div className="color-btns">
            <button className="mini" title="Swap colors (X)" onClick={swap} style={{ transform: 'rotate(45deg)' }}>⇆</button>
            <button className="mini" title="Reset (D)" onClick={reset}>▣</button>
          </div>
        </div>
        <div className="swatch-grid">
          {SWATCHES.map((c) => (
            <button
              key={c}
              className="swatch"
              style={{ background: c }}
              title={`${c} — click sets foreground · Shift+click sets background`}
              onClick={(e) => {
                if (e.shiftKey) setBg(c)
                else setFg(c)
              }}
            />
          ))}
        </div>
        <button
          className="mini wide"
          title="Switch to the Eyedropper (I) to click-sample any color off the canvas"
          onClick={() => setTool('eyedropper')}
        >
          Sample from canvas…
        </button>
      </div>
    </div>
  )
}
