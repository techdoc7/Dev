import { useEditor } from '../../editor/store'

export default function HistoryPanel() {
  const doc = useEditor((s) => s.docs.find((d) => d.id === s.activeDocId))

  if (!doc) {
    return (
      <div className="panel">
        <div className="panel-head">History</div>
        <div className="panel-empty">Open a document to track its history.</div>
      </div>
    )
  }

  const jump = (target: number) => {
    useEditor.getState().jumpHistory(target)
  }

  const rows = doc.history.map((h, i) => ({ h, i }))
  return (
    <div className="panel panel-history">
      <div className="panel-head">History</div>
      <div className="history-list">
        {rows.map(({ h, i }) => {
          const current = i === doc.historyIndex
          const future = i > doc.historyIndex
          return (
            <button
              key={i}
              className={`history-row ${current ? 'current' : ''} ${future ? 'future' : ''}`}
              onClick={() => jump(i)}
              title={current ? 'Current state' : `Revert to: ${h.label}`}
            >
              <span className="history-num">{i + 1}.</span>
              <span className="history-label">{h.label}</span>
            </button>
          )
        })}
      </div>
    </div>
  )
}
