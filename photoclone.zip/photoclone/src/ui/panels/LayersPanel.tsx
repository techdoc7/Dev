import { useState } from 'react'
import { useEditor } from '../../editor/store'
import { BLEND_LABELS, BlendMode } from '../../editor/types'
import { AdjustmentKind, AdjustmentLayerData } from '../../editor/types'
import { LayerThumb } from '../LayerThumb'
import { ADJUSTMENT_LABELS } from '../../engine/adjustmentLayer'

const BLEND_ORDER: BlendMode[] = [
  'pass-through', 'normal', 'dissolve',
  'darken', 'multiply', 'color-burn', 'linear-burn', 'darker-color',
  'lighten', 'screen', 'color-dodge', 'linear-dodge', 'lighter-color',
  'overlay', 'soft-light', 'hard-light', 'vivid-light', 'linear-light', 'pin-light', 'hard-mix',
  'difference', 'exclusion', 'divide',
  'hue', 'saturation', 'color', 'luminosity',
]

/* blend modes that render via CSS fallbacks today */
const EXPANDED_MODES = new Set([
  'dissolve', 'linear-burn', 'darker-color', 'linear-dodge', 'lighter-color',
  'vivid-light', 'linear-light', 'pin-light', 'hard-mix', 'divide',
])

const ADJUSTMENT_ORDER: AdjustmentKind[] = [
  'brightness-contrast', 'levels', 'exposure', 'hue-saturation', 'vibrance',
  'color-balance', 'black-white', 'invert', 'threshold', 'posterize',
]

const PARAMS: Partial<Record<AdjustmentKind, Array<{ key: string; label: string; min: number; max: number; step?: number }>>> = {
  'brightness-contrast': [
    { key: 'brightness', label: 'Brightness', min: -150, max: 150 },
    { key: 'contrast', label: 'Contrast', min: -100, max: 100 },
  ],
  levels: [
    { key: 'inBlack', label: 'Input black', min: 0, max: 254 },
    { key: 'gamma', label: 'Gamma', min: 0.1, max: 3, step: 0.05 },
    { key: 'inWhite', label: 'Input white', min: 1, max: 255 },
    { key: 'outBlack', label: 'Output black', min: 0, max: 255 },
    { key: 'outWhite', label: 'Output white', min: 0, max: 255 },
  ],
  exposure: [
    { key: 'exposure', label: 'Exposure', min: -5, max: 5, step: 0.1 },
    { key: 'offset', label: 'Offset', min: -0.5, max: 0.5, step: 0.01 },
    { key: 'gamma', label: 'Gamma', min: 0.1, max: 3, step: 0.05 },
  ],
  'hue-saturation': [
    { key: 'hue', label: 'Hue', min: -180, max: 180 },
    { key: 'saturation', label: 'Saturation', min: -100, max: 100 },
    { key: 'lightness', label: 'Lightness', min: -100, max: 100 },
  ],
  vibrance: [{ key: 'vibrance', label: 'Vibrance', min: -100, max: 100 }],
  'color-balance': [
    { key: 'red', label: 'Red / Cyan', min: -100, max: 100 },
    { key: 'green', label: 'Green / Magenta', min: -100, max: 100 },
    { key: 'blue', label: 'Blue / Yellow', min: -100, max: 100 },
  ],
  threshold: [{ key: 'threshold', label: 'Threshold', min: 0, max: 255 }],
  posterize: [{ key: 'levels', label: 'Levels', min: 2, max: 32 }],
}

function AdjustmentProperties({ layerId, data }: { layerId: string; data: AdjustmentLayerData }) {
  const specs = PARAMS[data.kind] ?? []
  if (!specs.length) return <div className="adjustment-properties adjustment-static">{ADJUSTMENT_LABELS[data.kind]} has no parameters.</div>
  const commit = () => useEditor.getState().pushHistory(`Edit ${ADJUSTMENT_LABELS[data.kind]}`)
  return (
    <div className="adjustment-properties">
      <div className="adjustment-title">{ADJUSTMENT_LABELS[data.kind]}</div>
      {specs.map((spec) => (
        <label className="adjustment-row" key={spec.key}>
          <span>{spec.label}</span>
          <input
            type="range"
            min={spec.min}
            max={spec.max}
            step={spec.step ?? 1}
            value={data.params[spec.key] ?? 0}
            onChange={(e) => useEditor.getState().updateLayerAdjustment(layerId, { [spec.key]: Number(e.target.value) })}
            onPointerUp={commit}
            onKeyUp={(e) => { if (e.key === 'Enter') commit() }}
          />
          <output>{Number(data.params[spec.key] ?? 0).toFixed((spec.step ?? 1) < 1 ? 2 : 0)}</output>
        </label>
      ))}
    </div>
  )
}

export default function LayersPanel() {
  const doc = useEditor((s) => s.docs.find((d) => d.id === s.activeDocId))
  const revision = useEditor((s) => s.revision)
  const editingMaskLayerId = useEditor((s) => s.editingMaskLayerId)
  const st = useEditor.getState
  const [editingId, setEditingId] = useState<string | null>(null)
  const [adjustmentChoice, setAdjustmentChoice] = useState('')
  const [groupChoice, setGroupChoice] = useState('')

  if (!doc) {
    return (
      <div className="panel">
        <div className="panel-head">Layers</div>
        <div className="panel-empty">Open a document to see its layers.</div>
      </div>
    )
  }

  const activeLayer = doc.layers.find((l) => l.id === doc.activeLayerId) ?? doc.layers[doc.layers.length - 1]
  const groupIds = new Set(doc.layers.filter((l) => l.type === 'group').map((l) => l.id))
  const rows: Array<{ layer: typeof activeLayer; depth: number }> = []
  const appendRows = (parentId: string | null, depth: number) => {
    const members = doc.layers.filter((layer) => parentId === null
      ? !layer.parentId || !groupIds.has(layer.parentId)
      : layer.parentId === parentId).reverse()
    for (const layer of members) {
      rows.push({ layer, depth })
      if (layer.type === 'group' && layer.opened !== false) appendRows(layer.id, depth + 1)
    }
  }
  appendRows(null, 0)

  return (
    <div className="panel panel-layers">
      <div className="panel-head">Layers</div>

      {/* mode / opacity header (applies to active layer) */}
      <div className="layers-head">
        <select
          className="blend-select"
          value={activeLayer.blendMode}
          title={EXPANDED_MODES.has(activeLayer.blendMode) ? 'Advanced mode — rendered with the nearest browser blend' : 'Blend mode'}
          onChange={(e) => doc && st().setLayerBlend(activeLayer.id, e.target.value as BlendMode)}
        >
          {BLEND_ORDER.map((b) => (
            <option key={b} value={b}>
              {BLEND_LABELS[b] + (EXPANDED_MODES.has(b) ? ' ≈' : '')}
            </option>
          ))}
        </select>
        <div className="lock-row">
          <button
            className={`lock-btn ${activeLayer.locked ? 'on' : ''}`}
            title={activeLayer.locked ? 'Unlock layer' : 'Lock layer'}
            onClick={() => doc && st().setLocked(activeLayer.id, !activeLayer.locked)}
          >
            {activeLayer.locked ? '●' : '○'}
          </button>
        </div>
        <div className="opacity-row">
          <span className="opacity-label">Opacity {Math.round(activeLayer.opacity * 100)}%</span>
          <input
            type="range"
            min={0}
            max={100}
            value={Math.round(activeLayer.opacity * 100)}
            disabled={activeLayer.locked}
            onChange={(e) => doc && st().setLayerOpacity(activeLayer.id, Number(e.target.value) / 100)}
          />
        </div>
      </div>

      {activeLayer.type === 'adjustment' && activeLayer.adjustment && (
        <AdjustmentProperties layerId={activeLayer.id} data={activeLayer.adjustment} />
      )}

      {/* rows */}
      <div className="layers-list">
        {rows.map(({ layer: l, depth }) => (
          <div
            key={l.id}
            className={`layer-row ${l.id === activeLayer.id ? 'active' : ''} ${l.locked ? 'locked' : ''}`}
            style={{ paddingLeft: 8 + depth * 14 }}
            onClick={() => st().selectLayer(l.id)}
          >
            {l.type === 'group' ? (
              <button className="group-disclosure" title={l.opened === false ? 'Expand group' : 'Collapse group'} onClick={(e) => { e.stopPropagation(); st().toggleGroupOpen(l.id) }}>
                {l.opened === false ? '▸' : '▾'}
              </button>
            ) : <span className="group-indent" />}
            <button
              className={`eye ${l.visible ? 'on' : ''}`}
              title={l.visible ? 'Hide layer' : 'Show layer'}
              onClick={(e) => {
                e.stopPropagation()
                st().toggleVisible(l.id)
              }}
            >
              {l.visible ? '◉' : '○'}
            </button>
            <div className={`layer-thumbwrap ${l.type === 'group' ? 'group-thumb' : ''}`}>
              {l.type === 'group' ? <span className="group-folder">▰</span> : <LayerThumb canvas={l.canvas} revision={revision} />}
              {l.locked && <span className="thumb-lock" title="Locked">🔒</span>}
            </div>
            {l.mask && (
              <button
                type="button"
                className={`layer-mask-thumb ${l.maskEnabled === false ? 'disabled' : ''} ${editingMaskLayerId === l.id ? 'targeted' : ''}`}
                title="Click to target this mask for painting · Shift+click to enable/disable"
                onClick={(e) => {
                  e.stopPropagation()
                  st().selectLayer(l.id)
                  if (e.shiftKey) st().toggleLayerMask(l.id)
                  else st().setEditingMask(l.id)
                }}
              >
                <LayerThumb canvas={l.mask} revision={revision} />
              </button>
            )}
            <div className="layer-name" onDoubleClick={() => {
              if (l.type === 'text' && l.textData) {
                st().selectLayer(l.id)
                st().setTool('type')
                requestAnimationFrame(() => window.dispatchEvent(new CustomEvent('pc:editText', { detail: l.id })))
              } else setEditingId(l.id)
            }}>
              {editingId === l.id ? (
                <input
                  autoFocus
                  defaultValue={l.name}
                  onBlur={(e) => {
                    st().renameLayer(l.id, e.target.value)
                    setEditingId(null)
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') (e.target as HTMLInputElement).blur()
                    if (e.key === 'Escape') setEditingId(null)
                  }}
                />
              ) : (
                <span title={`${l.name} — double-click to rename (locked layers: repaint unlocked first)`}>
                  {l.type === 'text' ? <span className="text-layer-badge" title="Text layer">T </span> : null}
                  {l.type === 'adjustment' ? <span className="adjustment-layer-badge" title="Adjustment layer">◐ </span> : null}
                  {l.type === 'group' ? <span className="group-layer-badge" title="Layer group">Group · </span> : null}
                  {l.clipping ? <span className="clip-layer-badge" title="Clipped to layer below">↳ </span> : null}
                  {l.name}
                </span>
              )}
            </div>
            <div className="layer-btns">
              <button
                className={`mini fx ${l.style && (l.style.stroke || l.style.shadow) ? 'on' : ''}`}
                title={l.style && (l.style.stroke || l.style.shadow) ? 'Edit layer style (fx active)' : 'Layer Style (fx) — non-destructive stroke & shadow'}
                onClick={(e) => {
                  e.stopPropagation()
                  st().selectLayer(l.id)
                  requestAnimationFrame(() =>
                    window.dispatchEvent(new CustomEvent('pc:openStyle', { detail: { tab: 'stroke' } })),
                  )
                }}
              >
                fx
              </button>
              <button className="mini" title="Move up"
                onClick={(e) => { e.stopPropagation(); st().moveLayer(l.id, 1) }}>▲</button>
              <button className="mini" title="Move down"
                onClick={(e) => { e.stopPropagation(); st().moveLayer(l.id, -1) }}>▼</button>
            </div>
          </div>
        ))}
      </div>

      {/* footer actions */}
      <div className="layers-foot">
        <button className="mini" title="New layer (renders above the active one)" onClick={() => st().addLayer()}>＋</button>
        <button className="mini" title="New layer group" onClick={() => st().addGroup()}>▰</button>
        <button className="mini" title="Duplicate active layer" onClick={() => activeLayer && st().duplicateLayer(activeLayer.id)}>⧉</button>
        <select
          className="adjustment-add"
          aria-label="Add adjustment layer"
          title="Add adjustment layer"
          value={adjustmentChoice}
          onChange={(e) => {
            const kind = e.target.value as AdjustmentKind
            if (kind) st().addAdjustmentLayer(kind)
            setAdjustmentChoice('')
          }}
        >
          <option value="">＋ Adj</option>
          {ADJUSTMENT_ORDER.map((kind) => <option key={kind} value={kind}>{ADJUSTMENT_LABELS[kind]}</option>)}
        </select>
        <select
          className="group-parent-select"
          aria-label="Move active layer to group"
          title="Move active layer into a group"
          value={groupChoice}
          disabled={activeLayer.type === 'group' && doc.layers.filter((l) => l.type === 'group').length === 1}
          onChange={(e) => {
            const value = e.target.value
            if (value !== '') st().setLayerParent(activeLayer.id, value === 'root' ? null : value)
            setGroupChoice('')
          }}
        >
          <option value="">Move…</option>
          <option value="root">Top level</option>
          {doc.layers.filter((l) => l.type === 'group' && l.id !== activeLayer.id).map((group) => <option key={group.id} value={group.id}>{group.name}</option>)}
        </select>
        <button
          className="mini"
          title={doc.selection ? 'Add layer mask from the current selection' : 'Add reveal-all layer mask'}
          onClick={() => activeLayer && st().addLayerMask(activeLayer.id)}
        >▣</button>
        {activeLayer.mask && (
          <>
            <button className="mini" title={activeLayer.maskEnabled === false ? 'Enable layer mask' : 'Disable layer mask'} onClick={() => st().toggleLayerMask(activeLayer.id)}>{activeLayer.maskEnabled === false ? '○M' : '●M'}</button>
            <button className="mini" title="Invert layer mask" onClick={() => st().invertLayerMask(activeLayer.id)}>±M</button>
            <button className="mini danger" title="Delete layer mask" onClick={() => st().removeLayerMask(activeLayer.id)}>×M</button>
          </>
        )}
        <button
          className={`mini ${activeLayer.clipping ? 'on' : ''}`}
          disabled={doc.layers.findIndex((l) => l.id === activeLayer.id) === 0}
          title={activeLayer.clipping ? 'Release clipping mask' : 'Clip active layer to the layer below'}
          onClick={() => st().setLayerClipping(activeLayer.id, !activeLayer.clipping)}
        >↳</button>
        <button className="mini" title="Merge active layer down" onClick={() => activeLayer && st().mergeDown(activeLayer.id)}>↓</button>
        <span className="foot-flex" />
        <button className="mini danger" title="Delete active layer" onClick={() => activeLayer && st().removeLayer(activeLayer.id)}>🗑</button>
      </div>
    </div>
  )
}
